package com.nbcu.sphere.ObjectRepository;

public class SphereCommon {	

	
	////////////////////////////////////////Sphere Login/Home Page Objects////////////////////////////////////////////////////
		
	//By Id
	public static final String Main_InputUserId_id = "username";						//Username
	public static final String Main_InputPassword_id = "password";						//Password
//	public static final String Main_BtnSignIn_id = "submit_form";                       	

	
	public static final String Main_MsgSignInError_id = "InfoMessage";     
	public static final String Main_BtnSignInError_id = "InfoOK";     
	//public static final String Main_BtnSignIn_nm = "Submit";    //Login Button
	public static final String Main_BtnSignIn_nm = "//button[contains(text(),'SIGN IN')]";
	//By Name
	public static final String Main_TitleSpherePage_nm = "NBCU Sphere";  //Window title of Sphere login page
	
	//By Xpath
	//public static final String Main_labelHomePageWelcome_xp =  "/html/body/div[2]/div[3]/div[2]/div[4]/div[1]/h1";
	//public static final String Main_labelHomePageWelcome_xp =  "//h2[@class='page-title ng-scope' and text()='Welcome to Sphere!']";//Now X-path changed
	//public static final String Main_labelHomePageWelcome_xp =  "//h2[@class='ng-scope' and contains(text(),'Welcome')]";
	//public static final String Main_labelHomePageWelcome_xp =  "//h2[@ng-show='home.user' and contains(text(),'Welcome')]";
	public static final String Main_HomeLogoImage_xp =  "//figure[@class='logo' and @title='Sphere: NBCUniversal']";
	public static final String Main_HomeLogoText_xp =  "//span[contains(@class,'app-name') and text()='SPHERE']";
	public static final String Main_labelHomePageComingSoon_xp="//div[@class='coming-soon ng-scope']//h1";
	public static final String Deals_Title="//h3[@translate='DEALS.TITLE']";
	public static final String Main_HomeNavigationLinks_xp =  "//ul/li[@menu='menu' and @sp-nav-menu-item='menuItem']";
	public static final String Main_HomeNavigation_DashbordLink_xp="//ul/li[@menu='menu' and @sp-nav-menu-item='menuItem'][2]";
	//public static final String Customers_CreditApprovalNotification_Title_msg = "Credit Approval Notification";
	public static final String Customers_CreditApprovalNotification_Title_xp="//h2[@translate='CREDIT_APPROVAL.TITLE' and text()='Credit Approval Notification']";
	//<a ui-sref="login" href="#/login">Logout</a>
	//public static final String Main_LogoutLink_xp =  "/html/body/div[2]/div[2]/div/div/a[3]";
	public static final String Main_LogoutLink_xp =  "//a[@ui-sref='login' and @href='#/login' and text()='Logout']";
	
	public static final String Main_BtnSignIn_xp = "//input[@type='submit' and @value='LOGIN']";                       //Login Button
	public static final String Main_HomePageLogo_xp = "//img[@alt='Google' and @id='hplogo']"; 
	
	public static final String Main_MenuSignOut_xp = "//li[@class='dropdown']/a/span";    //Sphere Logout Menu
	public static final String Main_LinkSignOut_xp = "//ul[@class='dropdown-menu']/li[2]/a";    //Sphere Logout Link
	
	public static final String Main_HomeDashBoard_xp="//h3[@translate='DASHBOARD.TITLE']";
	public static final String Main_BtnMenuExpand_xp= "//div[@class='toggleIcon toggleIconOnLeft']/i[contains(@class,'fa-angle-double-right')]";
	public static final String Main_BtnMenuLeftArrow_xp="//div[@class='toggleIcon toggleIconOnRight']/i[contains(@class,'fa-angle-double-left')]";
	
	
	
	
	public static final String Main_InputUserId_id_tv="//input[@name='username']";
	public static final String Main_BtnSignIn_nm_tv = "//input[@value='Log In to Sandbox']";
	public static final String Main_InputPassword_id_tv = "//input[@name='pw']";
	//public static final String Main_BtnSignIn_nm_tv = "//button[contains(text(),'SIGN IN')]";
	
	
	
	//By Tag Name

	
}
