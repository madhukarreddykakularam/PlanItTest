package com.nbcu.sphere.ObjectRepository;

public class SphereModules {

	/**
	 * @param args
	 */
	
	public static final String Common_ViewUserModule_Table_xp = "//div[@class='users']/sp-table-view-new/sp-table-new/table/tbody";
	public static final String Common_ViewNationalAccountModule_Table_xp = "//div[@class='parentCompanies']/sp-table-view-new/sp-table-new/table/tbody";
	//div[@class='parentCompanies']/sp-table-view-new/sp-table-new/table/tbody"
	//public static final String Common_ViewCustomersModule_Table_xp = "//div[contains(@class,'customers')]/sp-table-view[contains(@name,'CUSTOMERS.TITLE')]/sp-table/table/tbody"; //Uncomment once view customer table gets fixed 
	public static final String Common_ViewCustomersModule_Table_xp="//div[contains(@class,'customers')]//sp-table-view-new/sp-table-new/table/tbody";
	public static final String Common_SSPRequests_Table_xp="//div[@class='sspRequests ng-scope']//sp-table-view-new//sp-table-new//table//tbody";
	public static final String Common_SSPRequests_Title="//h3[@translate='SSP_REQUESTS.TITLE' and text()='SSP Requests']";
	public static final String Common_SSP_AccountStatements_Table="//div[@class='account-statements ng-scope']//sp-table-view-new//sp-table-new//table//tbody";
	public static final String Common_Orders_Table_xp="//div[@class='orders ng-scope']//sp-table-view-new//sp-table-new//table//tbody";
	public static final String Common_Invoice_Statement_Table_xp="//div[@class='invoices']//sp-table-view-new//sp-table-new//table//tbody";
	public static final String Common_Invoice_Statement_Tool_Tip_xp="(//ul/li[@menu='menu' and @sp-nav-menu-item='menuItem'][6]//ul//li[5]//div)[1]";
	//public static final String Common_ViewCustomersModule_Table_xp = "//sp-table-view[contains(@name,'CUSTOMERS.TITLE')]/sp-table/table"; //Comment once view customer table gets fixed
	public static final String Common_BillingSuspense_Table_xp="//sp-table-view-new/sp-table-new/table/tbody";
	public static final String Common_BillingSuspense_Table_Rows_xp="//sp-table-view-new/sp-table-new/table/tbody/tr";
	
	
																
	public static final String Common_ViewDealModule_Table_xp= "//div[@class='deals']/sp-table-view-new/sp-table-new/table/tbody";
	public static final String Common_ViewQueueLogging_Table_xp="//div[@class='customerQueue ng-scope']/sp-table-view-new/sp-table-new/table/tbody";
	public static final String Common_ViewModules_InputSearchBox_xp = "//input[@type='text' and @name='search']";
	public static final String Common_ViewModules_ClickFirstRow_xp = "//sp-table-new/table/tbody/tr/td[3]";
	public static final String Common_ViewModules_InputSearchBox_DocumentNumber_xp = "//input[@placeholder='Search Document Number...']";
	
	
	public static final String Common_ViewModules_LinkAll_xp = "//span[text()='All']";
	public static final String Common_ViewModules_LinkAll_Approved = "(//span[text()='All'])[2]";
	
	public static final String Common_ViewModules_LinkActive_xp = "//span[text()='Active']";
	public static final String Common_ViewModules_LinkInactive_xp = "//span[text()='Inactive']";
	public static final String Common_ViewModules_IconPageLoad_xp = "//span[@class='loadingText' and text()='Loading...']";
	public static final String Common_AddEditModules_InputSearchCostCenter_xp = "//input[@type='search' and @role='combobox']";
	//public static final String Common_AddEditModules_ListSearchedCostCenter_xp = "//div[contains(@id,'ui-select-choices-row')]/span/span[contains(@ng-bind-html,'costCenterName')]/span";
	public static final String Common_ViewModules_ActiveCount_xp="//span[@class ='ng-binding active']";
	//public static final String Common_AddEditModules_ListSearchedCostCenter_xp = "//div[contains(@id,'ui-select-choices-row')]/span/span[contains(@ng-bind-html,'costCenter')]/span";
	public static final String Common_ViewModules_LinkOpen_Xp= "//span[@translate='TABLE_FILTERS.DEALSTATUSCODEID.13005']";
	public static final String Common_ViewModules_LinkClosed_Xp= "//span[@translate='TABLE_FILTERS.DEALSTATUSCODEID.13001']";
	public static final String Common_ViewModules_LinkComplete_Xp="//span[@class='ng-binding']/span[@translate='TABLE_FILTERS.STATUS.COMPLETE' and text()='Complete']";
	//public static final String Common_ViewModules_LinkFailure_Xp="//span[@class='ng-binding ng-hide']/span[@translate='TABLE_FILTERS.STATUS.FAILURE' and text()='Failure']";
	public static final String Common_ViewModules_LinkFailure_Xp="//span[@translate='TABLE_FILTERS.STATUS.FAILURE' and text()='Failure']";
	public static final String Common_ViewModules_LinkError_Xp= "//span[@class='ng-binding']/span[@translate='TABLE_FILTERS.STATUS.ERROR' and text()='Error']";
	//public static final String Common_ViewModules_LinkAll_Xp= "//span[@class='ng-binding']/span[@translate='TABLE_FILTERS.STATUS.ALL' and text()='All']";
	public static final String Common_ViewModules_LinkAll_Xp= "//span[@translate='TABLE_FILTERS.STATUS.ALL' and text()='All']";
	
	
	public static final String Common_View_pagination_groupText_xp="//div[@class='col-sm-12']//p[contains(text(),'Showing items')]";
	public static final String Common_View_pagination_numbersequence_xp="//div[@class='pagination-group']//ul[@class='pagination']";
	public static final String Common_View_pagination_dropDown_xp="//select[@ng-model='queryParameters.setPageSize']";
	public static final String Common_View_pagination_dropDown50_xp="//select[@ng-model='queryParameters.setPageSize']//option[@value='50']";
	public static final String Common_View_pagination_dropDown100_xp="//select[@ng-model='queryParameters.setPageSize']//option[@value='100']";
	public static final String Common_View_pagination_dropDown20_xp="//select[@ng-model='queryParameters.setPageSize']//option[@value='20']";
	public static final String Common_View_pagination_nextButton_xp="//ul[@class='pagination']//li[@class='next ng-scope']//span[@class='ng-binding']";
	public static final String Common_View_pagination_previousButton_xp="//ul[@class='pagination']//li[@class='prev ng-scope']//span[@class='ng-binding']";
		
	//public static final String Common_AddEditModules_InputSearchCostCenter_xp = "//input[@type='search' and @role='combobox']";

	//public static final String Common_AddEditModules_ListSearchedCostCenter_xp = "//div[contains(@id,'ui-select-choices-row')]/span/span[contains(@ng-bind-html,'costCenterNumber')]/span";
	//public static final String Common_AddEditModules_ListSearchedCostCenter_xp = "//div[contains(@ng-attr-id,'ui-select-choices-row')]/span/span[contains(@ng-bind-html,'costCenterNumber')]";
	
	///new xpaths///
	public static final String Common_AddEditModules_ListSearchedCostCenter_xp="//div[@class='ui-select-choices-row ng-scope active']/span/span[contains(@ng-bind-html,'costCenterName')]";
	public static final String Common_AddEditModules_PerformingCostCenterCostCenter_xp="//div[@name='allPerformingCostCenters']//input[@role='combobox']";
	//public static final String Common_AddEditModules_ListSearchedCostCenter_xp = "//div[contains(@id,'ui-select-choices-row')]/span/span[contains(@ng-bind-html,'costCenter')]/span";
	
	//public static final String Common_ViewCustomersModule_Table_First_Row_xp="//div[contains(@class,'customers')]/sp-table-view[contains(@name,'CUSTOMERS.TITLE')]/sp-table/table/tbody/tr[1]"; //Uncomment once view customer table gets fixed 
	//public static final String Common_ViewNationalAccountModule_Table_First_Row_xp="//div[@class='parentCompanies ng-scope']/sp-table-view/sp-table/table/tbody/tr[1]";
	
	//public static final String Common_BtnAsc_Sorting_xp="//i[@class='fa fa-sort']";
	//public static final String Common_Btn_Sorting_xp="//table[@class='table table-striped']/thead/tr/th/";

	public static final String Common_ViewModules_ListPagination_Xp= "//div[@class='pagination-group']/ul[@class='pagination']/li";
	public static final String Common_Btn_Sorting_Column_1="//table[@class='table table-striped']/thead/tr/th[1]/i";
	public static final String Common_Btn_Sorting_Column_2="//table[@class='table table-striped']/thead/tr/th[2]/i";
	public static final String Common_Btn_Sorting_Column_2_Desc="//table[@class='table table-striped']/thead/tr/th[2]/i[@class='fa ng-scope fa-sort-down']";
	public static final String Common_Btn_Sorting_Column_3="//table[@class='table table-striped']/thead/tr/th[3]/i";
	public static final String Common_Btn_Sorting_Column_4="//table[@class='table table-striped']/thead/tr/th[4]/i";
	public static final String Common_Btn_Sorting_Column_5="//table[@class='table table-striped']/thead/tr/th[5]/i";
	public static final String Common_Btn_Sorting_Column_6="//table[@class='table table-striped']/thead/tr/th[6]/i";
	public static final String Common_Btn_Sorting_Column_7="//table[@class='table table-striped']/thead/tr/th[7]/i";
	public static final String Common_Btn_Sorting_Column_8="//table[@class='table table-striped']/thead/tr/th[8]/i";
	public static final String Common_Btn_Sorting_Column_9="//table[@class='table table-striped']/thead/tr/th[9]/i";
	public static final String Common_Costcenter_xp="//input[@class='ui-select-search input-xs ng-pristine ng-valid ng-empty ng-touched']";

    public static final String Common_AddEditModules_BtnFormExitConfirmation_xp = "//button[@translate='FORM_EXIT_YES_BUTTON']";
	
    public static final String Common_InterceptMenu_ViewEdit_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View/Edit Deal']";
	public static final String Common_InterceptMenu_Deactivate_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Deactivate']";
	public static final String Customer_InterceptMenu_Copy_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Copy']";
	public static final String Common_InterceptMenu_Copy_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Copy Deal']";
	public static final String Common_InterceptMenu_Open_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Open Deal']";
	public static final String Common_InterceptMenu_Close_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Close Deal']";
	
	public static final String Common_InterceptMenu_ViewTransactions_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View Transactions']";
	public static final String Common_InterceptMenu_CloseOrder_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Close']";
	public static final String CustomerPage_DeactivateButton="//div[@class='intercept-menu-container']//ul//li//a[contains(text(),'Deactivate')]";
	
	
	public static final String creditAction_id="creditAction";
	public static final String reversalActions_id="reversalActions";
	public static final String Reverse_InvoiceStatement_Reversal_xp="(//ul[@class='dropdown-menu exportActionsList']//li/a)[1]";
	public static final String Reverse_CostOfSalesAdjustments_xp="(//ul[@class='dropdown-menu exportActionsList']//li/a)[2]";
	public static final String Reverse_InvoiceStatement_Reverse_Btn_xp="//button[@class='btn btn-small confirm ng-scope']";
	public static final String Reverse_CostOfSalesAdjustments_Adjust_Btn_xp="//button[@class='btn btn-small confirm ng-scope']";
	public static final String Reverse_Invoice_Popup_Title_xp="//h3[@translate='TRANSACTION_RESEARCH.REVERSAL.DIALOG.TITLE']";
	public static final String Reverse_CostOfSalesAdjustment_Popup_Title_xp="//h3[@translate='TRANSACTION_RESEARCH.COSA.DIALOG.TITLE']";
	public static final String creditTransactionTitle="//h3[@translate='TRANSACTION_RESEARCH.CREDIT.DIALOG.TITLE']";
	public static final String creditReason_Id="creditReason";
	public static final String creditReason_CreditButton_xp="//button[@class='btn btn-small credit ng-scope']";
	public static final String Common_InterceptMenu_Activate_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Activate']";
    public static final String Common_AddEditModules_MsgSuccess_xp = "//div[@ng-bind-html='message']";
    public static final String Common_AddEditModules_MsgError_xp= "//div[contains(@class,'ui-notification ng-scope error clickable')]";
     
    
    
    public static final String Customer_InterceptMenu_ViewEdit_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View/ Edit']";
    public static final String Common_View_Sap_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)";
    
    public static final String Common_View_ChartOfAccount_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)[1]";
    public static final String Common_View_WBSE_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)[2]";
    public static final String Common_View_CostCenter_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)[3]";
    public static final String Common_View_ProfitCenter_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)[4]";
    public static final String Common_View_InternalOrders_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)[5]";
    public static final String Common_View_Manual_Funds_Commitment_Table_xp="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody)[6]";
   
    public static final String Common_View_Modules_Table_FirstRow_xp="//sp-table-new/table/tbody/tr[1]/td[3]";
    public static final String Common_ViewModules_LinkDepartmentClosed_Xp= "//span[@translate='TABLE_FILTERS.DEALSTATUSCODEID.13006']";
    public static final String Common_View_Transactions_Page_Table_xp="//sp-table-view-new//sp-table-new//table//tbody";
   // public static final String Common_View_Exceptions_Table_xp= "//div[@class='accordion']/table/tbody";
    public static final String Common_View_Billing_Approvals_Table_xp="//div[@class='accordion']/table/tbody/tr[@class='ng-scope']";
    public static final String Billing_Deny_PopUp_Title_xp="//h3[contains(text(),'Deny Transaction(s)')]";
    public static final String Billing_Deny_messagebox_xp="(//textarea[@id='notes'])";
    public static final String Billing_Deny_Yes_Btn_xp2="//button[contains(text(),'Yes, I'm Sure')]";
    public static final String Billing_Deny_meassge_xp="//div[contains(text(),'Deny request successfully processed')]";
    public static final String Common_View_Exceptions_Table_xp="//div[@class='accordion']/table/tbody/tr[not(contains(@class,'ng-scope collapse')) and not(contains(@class,'collapse ng-scope'))]";
    public static final String Common_View_Exceptions_Table_Managing_CostCenter_xp="//div[@class='accordion']//table/thead/tr[1]/th[7]";
    public static final String Common_View_Exceptions_ExpandIcon_xp="//div[@class='accordion']/table/tbody/tr[1]//div[@class='expand-icon']//i";
    public static final String Common_View_Transactions_Table_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//tbody";
    public static final String Common_View_Transactions_Table_First_Row_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//tbody//tr[1]";
    public static final String BillingRequest_Table_xp="(//table[@class='table table-striped']//tr)[2]";
    public static final String BillingRequest_Table_xp1="(//table[@class='table table-responsive']//tr)[2]";
    public static final String BillingRequest_Focused_FirstRow_xp="//div[@class='accordion']/table/tbody/tr[@class='ng-scope focused']";
    public static final String BillingRequest_OrderNotExist_Text_xp="//div[@class='accordion']//table/tbody/tr[1]/td[6]/sp-exception-button/div/div/div[@class='exception-btn-text ng-binding' and text()='Order Does Not Exist']";
    public static final String BillingRequest_OrderNotOpen_Text_xp="//div[@class='accordion']//table/tbody/tr[1]/td[6]/sp-exception-button/div/div/div[@class='exception-btn-text ng-binding' and text()='Order Not Open']";
    public static final String BillingRequest_InvalidCostObject_Text_xp="//div[@class='accordion']//table/tbody/tr[1]/td[10]/sp-exception-button/div/div/div[@class='exception-btn-text ng-binding' and text()='Cost Object Invalid']";
    public static final String BillingRequest_BtnSave_xp="//button[@class='btn rightButton ng-scope' and @ng-click='editBillingExceptions.saveBillingRequest()']";
    public static final String BillingRequest_PopupMessage_xp="//div[@class='ui-notification confirm-template ng-scope']//div[@class='message confirmBody ng-binding']";
    public static final String BillingRequest_BtnCancel_xp="//a[@class='btn leftButton' and @ng-click='editBillingExceptions.close()']";
    public static final String BillingRequest_Transaction_BtnCancel_xp="//a[@class='btn leftButton' and @ng-click='transactionFormCtrl.close()']";
    public static final String BillingRequest_Cancel_xp="//i[@class='fa fa-times fa-2x fa-inverse' and @ng-click='sideviewModal.confirmFormExit()']";
    
    public static final String BillingRequest_MissingCostObject_Text_xp="//div[@class='accordion']//table/tbody/tr[1]/td[10]/sp-exception-button/div/div/div[@class='exception-btn-text ng-binding' and text()='Cost Object Missing']";
    public static final String BillingRequest_Transaction_Row_MissingCostObject_Text_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//tbody//tr[1]/td[11]/sp-exception-button/div/div/div[@class='exception-btn-text ng-binding' and text()='Cost Object Missing']";
    public static final String BillingRequest_Transaction_Row_InvalidCostObject_Text_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//tbody//tr[1]/td[11]/sp-exception-button/div/div/div[@class='exception-btn-text ng-binding' and text()='Cost Object Invalid']";
    public static final String BillingRequest_TransactionCostObject_Text_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//tbody/tr[1]/td[11]";
    public static final String BillingRequest_CostObject_Text_xp="//div[@class='accordion']//table/tbody/tr[1]/td[10]//span";
    public static final String BillingRequest_OrderNumber_xp="//div[@class='accordion']//table/tbody/tr[1]/td[6]";
    public static final String BillingRequest_DeptSysNumber_xp="//div[@class='accordion']//table/tbody/tr[1]/td[3]";
    public static final String BillingRequest_CostObject_xp="//div[@class='accordion']//table/tbody/tr[1]/td[10]";
    public static final String BillingRequest_DealNumber_xp="//div[@class='accordion']//table/tbody/tr[1]/td[5]";
    public static final String BillingRequest_PopupMessage_OK_xp="//div[@class='message buttonContainer']//button[text()='OK']";
    //public static final String BillingRequest_CostObjectInvalid_Text_xp="//p[@class='invalidInputMessage ng-scope' and text()='Cost Object Invalid']";
    public static final String BillingRequest_CostObjectInvalid_Text_xp="//p[@class='invalidInputMessage ng-scope']";
    public static final String BillingRequest_Amount_xp="//div[@class='accordion']//table/tbody/tr[1]/td[13]";
    //public static final String BillingRequest_CostObjectMissing_Text_xp="//p[@class='invalidInputMessage ng-scope' and text()='Cost Object Missing']";
    public static final String BillingRequest_CostObjectMissing_Text_xp="//p[@class='invalidInputMessage ng-scope']";
    public static final String BillingRequest_CostObject_Row_xp="//div[@class='accordion']//table/tbody/tr[1]";
    public static final String BillingRequest_FirstRow_xp="//div[@class='accordion']//table/tbody/tr[1]";
    
    public static final String BillingRequest_ExitForm_Title_xp="//h3[@class='confirmTitle ng-scope']";
    public static final String BillingRequest_ExitForm_Cancel_xp="//button[@class='btn btn-small reject ng-scope']";
    public static final String BillingRequest_ExitForm_Yes_xp="//button[@class='btn btn-small confirm ng-scope']";

    
    
    //table[@id='accordion-table']//thead/tr/th[3]/i[contains(@class,'fa fa-sort')]
   
    public static final String Common_View_Transactions_Table_Column1_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[1]/i";
    public static final String Common_View_Transactions_Table_Column2_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[2]/i";
    public static final String Common_View_Transactions_Table_Column3_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[3]/i";
    public static final String Common_View_Transactions_Table_Column4_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[4]/i";
    public static final String Common_View_Transactions_Table_Column5_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[5]/i";
    public static final String Common_View_Transactions_Table_Column6_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[6]/i";
    public static final String Common_View_Transactions_Table_Column7_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[7]/i";
    public static final String Common_View_Transactions_Table_Column8_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[8]/i";
    public static final String Common_View_Transactions_Table_Column9_Sort_xp="//table[@id='accordion-table']//tr[@id='subTable0']//sp-table-view-new//sp-table-new//table//thead/tr/th[9]/i";
    
    public static final String Accordian_pagination_groupText_xp="//sp-table-view-new//div[@class='col-sm-12']//p[contains(text(),'Showing items')]";
   
    //public static final String Accordian_pagination_dropDown_xp="//sp-table-view-new//select[@ng-model='queryParameters.setPageSize']";
    public static final String Transaction_Customer_Field_xp="//div[@description='model.customerName']//fieldset";
    public static final String Transaction_Deal_Field_xp="//div[@description='model.dealTitle']//fieldset";
    public static final String Transaction_Order_Field_xp="//div[@description='model.orderDescription']//fieldset";
    public static final String Transaction_Department_System_xp="//label[@translate='TRANSACTIONS.FORM.DEPARTMENT_SYSTEM']";
    public static final String Transaction_InterfaceCode_id="interfaceCode";
    public static final String Transaction_date_xp="//label[@translate='TRANSACTIONS.FORM.TRANSACTION_DATE']";
    public static final String Transaction_Performing_Cost_Center_xp="//label[@translate='TRANSACTIONS.FORM.PERFORMING_COST_CENTER']";
    public static final String Transaction_accountNumber_id="accountNumber";
    public static final String Transaction_costObject_id="costObject";
    public static final String Transaction_LineDescription_id="lineDescription";
    public static final String Transaction_poNumber_id="poLineNumber";
    public static final String Transaction_taxYes_id="taxYes";
    public static final String Transaction_taxNo_id="taxNo";
    public static final String Transaction_requestDate_id="requestDate";
    public static final String Transaction_cashSaleIndicator_id="cashSaleIndicator";
    public static final String Transaction_recordType_id="recordType";
    public static final String Transaction_rentalStartDate_id="rentalStartDate";
    public static final String Transaction_rentalEndDate_id="rentalEndDate";
    public static final String Transaction_pricelist_id="priceList";
    public static final String Transaction_itemCode_id="itemCode";
    public static final String Transaction_rate_id="rate";
    public static final String Transaction_unitOfMeasure_id="unitOfMeasure";
    public static final String Transaction_quantity_id="quantity";
    public static final String Transaction_amount_id="amount";
    public static final String Transaction_sapIndicator_id="sapIndicator";
    public static final String Transaction_sapTerritory_id="sapTerritory";
    public static final String Transaction_Amount_xp="//label[@translate='TRANSACTIONS.FORM.AMOUNT']";
    public static final String Transaction_Comapany_Code_xp="//select[@name='sapCompany']";
    
    public static final String Transaction_customer_GreenIndicator="//div[@description='model.customerName']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope activeRecord')]";
    public static final String Transaction_customer_Name_xp="//div[@description='model.customerName']//fieldset//span[contains(@class,'synopsis-description ng-binding')]";
    public static final String Deal_CostCenter_Column_xp="//div[@class='deals']/sp-table-view-new/sp-table-new/table/tbody/tr[1]/td[8]";
    public static final String Transaction_customer_Number_xp="//div[@description='model.customerName']//fieldset//div[@ng-transclude='dataSlot']//div";
    public static final String Transaction_deal_GreenIndicator="//div[@description='model.dealTitle']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope activeRecord')]";
    public static final String Transaction_deal_Title_xp="//div[@description='model.dealTitle']//fieldset//span[contains(@class,'synopsis-description ng-binding')]";
    public static final String Transaction_deal_Number_dealType_xp="(//div[@description='model.dealTitle']//fieldset//div[@ng-transclude='dataSlot']//div)[1]";
    public static final String Transaction_deal_Managing_CostCenter_xp="(//div[@description='model.dealTitle']//fieldset//div[@ng-transclude='dataSlot']//div)[2]";
    public static final String Transaction_OrderDescription_xp="//div[@description='model.orderDescription']//fieldset//span[contains(@class,'synopsis-description ng-binding')]";
    public static final String Transaction_Ordernumber_xp="(//div[@description='model.orderDescription']//fieldset//div[@ng-transclude='dataSlot']//div)[1]";
    public static final String Transaction_Episode_xp="(//div[@description='model.orderDescription']//fieldset//div[@ng-transclude='dataSlot']//div)[2]";
    public static final String Transaction_Location_xp="(//div[@description='model.orderDescription']//fieldset//div[@ng-transclude='dataSlot']//div)[3]";
    public static final String Transaction_NoCustomerDetails_xp="//div[@description='model.customerName']//fieldset//div[@class='synopsis-no-data']";
    public static final String Transaction_NoDealDetails_xp="//div[@description='model.dealTitle']//fieldset//div[@class='synopsis-no-data']";
   // public static final String Transaction_NoOrderDetails_xp="//div[@description='model.orderDescription']//fieldset//div[@class='synopsis-no-data']";
    public static final String Transaction_NoOrderDetails_xp="//div[@description='model.orderDescription']//fieldset/div[2]";
    //div[@description='model.orderDescription']//fieldset//div[@class='synopsis-no-data']/no-data
    public static final String Transaction_deal_RedIndicator="//div[@description='model.dealTitle']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope inactiveRecord')]";
    public static final String Transaction_DealIndicator="//div[@description='model.dealTitle']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope')]";
    public static final String Transaction_CustomerIndicator="//div[@description='model.customerName']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope')]";
    public static final String Transaction_OrderIndicator="//div[@description='model.orderDescription']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope')]";
    public static final String Transaction_customer_RedIndicator="//div[@description='model.customerName']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope inactiveRecord')]";
    public static final String Transaction_Accordian_Table_xp="//div[@class='accordion']/table/tbody";
    public static final String Transaction_Accordian_Table_DealMngCol_xp="//div[@class='accordion']//table/tbody/tr[1]/td[8]//span";
  //div[@class='accordion']//table/tbody/tr[1]/td[10]//span
    public static final String Transaction_Slide_Amount_Table__xp="//table[@class='table']/tbody";
    public static final String Transaction_transactionType_id="transactionType";
    
    
    public static final String Order_Screen_OrderNumber_SearchBar_xp="//input[@placeholder='Search ...']";
    public static final String Order_Table_Col4_xp = "//sp-table-new/table/tbody/tr/td[3]";

    public static final String Order_Screen_Table_xp="//div[@class='orders ng-scope']//sp-table-view-new//sp-table-new//table//tbody";
    public static final String Transaction_Order_RedIndicator="//div[@description='model.orderDescription']//fieldset//sp-status-color/i[contains(@class,'fa fa-circle ng-scope inactiveRecord')]";
    public static final String BillingRequest_Table_Tax_Label_xp="//label[@translate='EXCEPTIONS.BILLING_REQUEST_FORM.TAX_LABEL']";
    public static final String BillingRequest_Transaction_BtnSave_xp="//button[@class='btn rightButton ng-scope' and @type='submit']";
    public static final String Billings_Suspense_Btn_xp="//label[@class='switch-label switch-label-2']";
    public static final String Billings_Rejection_Btn_xp="//label[@class='switch-label switch-label-1']";
    public static final String Billings_Suspense_Transdate_Filter_Btn_xp="(//button[@class='btn btn-primary set-range'])[1]";
    public static final String Billings_Suspense_ClearAll_Btn_xp="//span[@translate='TABLE_FILTERS.CLEAR_ALL']";
	public static final String Billing_Suspense_Search_bar_xp="//input[@placeholder='Search ...']";
	public static final String Billing_Suspense_Screen_Reassign_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
    
    public static final String Billings_Suspense_FilterTranDate_DownArrow_xp="//div[@class='filter-titles']/ul/li[5]/span";
    public static final String Billings_Suspense_FilterSuspendedDate_DownArrow_xp="//div[@class='filter-titles']/ul/li[6]/span";
    public static final String Billings_Suspense_Tran_MinDate_xp="(//input[@name='minDate'])[1]";
	public static final String Billings_Suspense_Tran_MaxDate_xp="(//input[@name='maxDate'])[1]";
	public static final String Billings_Suspense_Suspended_MinDate_xp="(//input[@name='minDate'])[2]";
	public static final String Billings_Suspense_Suspended_MaxDate_xp="(//input[@name='maxDate'])[2]";
	public static final String Billings_Suspense_Suspensedate_Filter_Btn_xp="(//button[@class='btn btn-primary set-range'])[2]";
	public static final String Billings_Suspense_Intercept_ViewEditTransaction_Option_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View/Edit Transaction']";
	public static final String Billings_Suspense_Notes_Tab_xp="//ul[@class='nav nav-tabs']/li[2]";
	public static final String Billings_Suspense_NotesPage_DealNumber_xp="//label[@translate='TRANSACTIONS.FORM.DEAL_NUMBER']";
	public static final String Billings_Suspense_NotesPage_AddNote_Btn_xp="//h4[contains(@class,'nbc-blue-text cursor-pointer-on-hover')]/i";
	public static final String Billings_Suspense_NotesPage_Table_xp="//table[@class='table table-striped note-info-table']/tbody";
	public static final String Billings_Suspense_Notes_TextBox_id ="notes";
	public static final String Billings_Suspense_Notes_TextBox_2_xp ="(//textarea[@id='notes'])[2]";
	public static final String Billings_Suspense_Transaction_Save_xp ="//button[@class='btn rightButton ng-scope' and @type='submit']";
	public static final String Billings_Suspense_NotesPage_OrderNumber_xp="//label[@translate='TRANSACTIONS.FORM.ORDER_NUMBER']";
	public static final String Billings_Suspense_NotesPage_LineDescription_xp="//label[@translate='TRANSACTIONS.FORM.DESCRIPTION']";
	public static final String Billings_Suspense_Intercept_Reassign_Move_to_ARC_Option_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Reassign & Move to ARC']";
	public static final String Billings_Suspense_Intercept_Move_to_SAP_Option_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Move to SAP']";
	
	public static final String WIP_Recon_Summary_SAP_Amount_xp="//input[@ng-model='wipRecon.totals.inSAP']";
	public static final String WIP_Recon_Summary_ARC_DraftBill_Amount_xp="//input[@ng-model='wipRecon.totals.inArcOrDB']";
	public static final String WIP_Recon_Summary_WIP_In_Suspense_Amount_xp="//input[@ng-model='wipRecon.totals.totalSuspenseAmount']";
	public static final String WIP_Recon_Summary_Perspective_Date_xp="//div[@class='datePickerInput input-group']//input[@ng-model='wipRecon.perspectiveDate']";
	public static final String WIP_Recon_Summary_Recon_Summary_Title_xp="//h3[@translate='WIP.RECON.TITLE']";
	public static final String WIP_Recon_Summary_ARC_DraftBill_xp="//a[text()='WIP in ARC & Draft Bill']";
	public static final String WIP_Recon_Summary_WIP_In_Suspense_xp="//a[text()='WIP in Suspense']";
	
	public static final String WIP_Aging_Table_xp="//sp-table-new/table/tbody";
	public static final String WIP_Transaction_Detail_Title_xp="//h3[@translate='WIP.DETAIL.TITLE']";
	
	public static final String WIP_Aging_Table_CC_xp="//sp-table-new/table/tbody/tr[1]/td[1]";
	public static final String WIP_TransactionDetail_Table_xp="//sp-table-new/table/tbody";
	
	public static final String Back_to_aging_xp="//a[text()='<< Back to Aging']";
	public static final String Back_to_Summary_xp="//a[text()='<< Back to Summary']";
	
	public static final String WIP_TransactionDetail_Total_Table_xp="//table[@class='table ng-scope']/tbody";
	public static final String WIP_TransactionDetail_Total_Table_xp1="//table[@class='table table-striped']/tbody";
	
	//public static final String WIP_TransactionDetail_Total_Table_Amount_td_xp="//table[@class='table ng-scope']/tbody/tr[1]/td[1]";
	public static final String WIP_TransactionDetail_Total_Table_Amount_td_xp="//table[@class='table table-striped']/tbody/tr[1]/td[7]";
	
	
	////////////////////////////////Users Objects////////////////////////////////////////////
	public static final String Users_AddUser_InputSSO_id = "sso";
	public static final String Users_AddUser_InputFirstName_id = "firstName";
	public static final String Users_AddUser_InputLastName_id = "lastName";
	
	//public static final String Users_AddUser_LinkAddPlusSign_xp = "//div[@class='users ng-scope']/a[@ui-sref='users.addUser']/i";
	//public static final String Users_AddUser_LinkAddPlusSign_xp = "//section[@class='content ng-scope']/a[@ui-sref='users.addUser']/i";
	//public static final String Users_AddUser_LinkAddPlusSign_xp = "//span[@ui-sref='users.addUser']";
	public static final String Users_AddUser_LinkAddPlusSign_xp = "//span[contains(@ng-click,'users.showAddForm')]";
	//public static final String Users_AddUser_LinkHiddenAddPlusSign_xp = "//div[contains(@class,'ng-hide')]/span[@ui-sref='users.addUser']";
	public static final String Users_AddUser_LinkHiddenAddPlusSign_xp = "//div[contains(@class,'ng-hide')]/span[contains(@ng-click,'users.showAddForm')]";
	
	public static final String Users_AddUser_BtnAdd_xp = "//button[@type='submit' and text()='Add']";
	public static final String Users_AddUser_LabelAddUserTitle_xp = "//div[@class='addUserModalHeader']/h1[@class='title ng-scope']";
	//public static final String Users_AddUser_BtnCancel_xp = "//a[@class='btn cancelButton']/span[text()='Cancel']";
	public static final String Users_AddUser_BtnCancel_xp = "//a[@class='btn leftButton']/span[text()='Cancel']";
	//public static final String Users_AddUser_BtnClose_xp = "//div[@class='addUserModalHeader']/a/i";
	public static final String Users_AddUser_BtnClose_xp = "//div[@class='sideview-header']/i";
	
	//public static final String Users_AddUser_ComboRole_xp = "//select[@name='role' and @ng-model='addUser.role']";
	public static final String Users_AddUser_ComboRole_xp = "//select[@name='role' and @ng-model='newUser.role']";
	public static final String Users_AddUser_SelectCostCenters_xp = "//div[@id='costCenters']/ul[@class='addUserMenu']/li";
	
	//public static final String Users_AddUser_MsgSuccess_xp = "//div[@ng-show='users.addUserSuccess']";
	//public static final String Users_AddUser_MsgSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! A new user has been created.']";
	public static final String Users_AddUser_MsgSuccess_xp = "//div[@ng-bind-html='message']";
	
	public static final String Users_AddUser_MsgError_xp = "//div[contains(@class,'nbc-alert-danger') and @ng-show='addUser.displayErrorAlert()']";
	//public static final String Users_AddUser_MsgSSOError_xp = "//p[contains(@class,'invalidInputMessage') and contains(@ng-show,'ssoInput')]";
	public static final String Users_AddUser_MsgSSOError_xp = "//p[contains(@class,'invalidInputMessage') and text()='SSO is a required field']";
//	public static final String Users_AddUser_MsgFirstNameError_xp = "//p[contains(@class,'invalidInputMessage') and contains(@ng-show,'firstNameInput')]";
	public static final String Users_AddUser_MsgFirstNameError_xp = "//p[contains(@class,'invalidInputMessage') and text()='First Name is a required field']";
	//public static final String Users_AddUser_MsgLastNameError_xp = "//p[contains(@class,'invalidInputMessage') and contains(@ng-show,'lastNameInput')]";
	public static final String Users_AddUser_MsgLastNameError_xp = "//p[contains(@class,'invalidInputMessage') and text()='Last Name is a required field']";
	
	//public static final String Users_ViewUser_BtnBulkActions_xp = "//button[@type='button' and contains(text(),'Bulk Actions')]";
	public static final String Users_ViewUser_BtnBulkActions_id= "bulkActions";
	//public static final String Users_ViewUser_BtnBulkActions_xp = "//button[@type='button' and contains(text(),'Bulk Actions')]";
	public static final String Users_ViewUser_ComboDeactivateChangeRole_xp = "//ul[@class='dropdown-menu bulkActionsList']/li[1]";
	
	public static final String Users_ViewUser_ConfirmDeactivateYesBtn_xp = "//button[@class='btn btn-small confirm ng-scope']";
	
	public static final String Roles_ViewRole_DivFirstRole_xp = "//div[@class='roles ng-scope']/div[2]";
	public static final String Roles_ViewRole_PlusSignFirstRole_xp = "//div[@sp-role='role']/form/div[@class='panel-heading']/span[1]";
	public static final String Roles_ViewRole_TextFirstRole_xp = "//div[@sp-role='role']/form/div[@class='panel-heading']/span[2]";
	public static final String Roles_ViewRole_TableRoles_xp ="//div[@sp-role='role']/form[@name='addRoleForm']/div[@class='panel-body']/div";
	
	public static final String Roles_EditRole_BtnSave_xp ="//button[contains(@class,'btn') and contains(text(),'Save')]";
	//public static final String Roles_EditRole_BtnSave_xp ="//button[@class='btn rightButton ng-scope' and contains(text(),'Save')]";
	public static final String Roles_EditRole_BtnCancel_xp ="//button[contains(@class,'btn') and contains(text(),'Cancel')]";
	public static final String Roles_EditRole_MsgSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! The role was updated.']";
	
	//public static final String Users_EditUser_BtnDeactivate_xp ="//button[contains(@class,'btn') and contains(text(),'Deactivate')]";
	public static final String Users_EditUser_BtnDeactivate_xp ="//span[contains(@class,'ng-scope') and contains(text(),'Deactivate')]";
	public static final String Users_EditUser_BtnSave_xp ="//button[contains(@class,'btn') and contains(text(),'Save')]";
	
	public static final String Users_Edit_PhoneNumber=" //input[@name='phone']";
	//public static final String Users_Edit_Role="//select[@id='roleDropDown' and @name='role']";
	public static final String Users_Edit_Role="//select[@name='role']";
	//public static final String Users_Edit_Role="roleDropDown";
	public static final String Users_Edit_Department="//select[@name='dept']";
	//public static final String Users_Cost_Center= "//input[@type='search']";
	public static final String Users_Cost_Center="//input[@type='search' and @ng-disabled='$select.disabled']";
	public static final String Users_Edit_NewCustomers_id="New Customers";
	public static final String Users_Edit_CreditApproval_id="Credit Approval";
	public static final String Users_Edit_CreditApproval_id1="Credit Approval (customer)";
	//public static final String Users_Edit_CreditApproval_notification_id="Credit Approval Notification";
	public static final String Users_Edit_CreditApproval_notification_id="//input[@id='Credit Approval Notification' and @class='ng-pristine ng-untouched ng-valid ng-empty']";
	public static final String Users_Edit_CreditApproval_customer_id="Credit Approval (customer)";
	//public static final String Users_Edit_Deactivate_Btn= "//a[@class='btn leftButton ng-hide']//span[@translate='FORM_DEACTIVATE_BUTTON']";
	//	//public static final String Users_Edit_Deactivate_Btn="//form[@name='editUserCtrl.form']//a[@class='btn leftButton']//span[ text()='Deactivate']";
	//public static final String Users_Edit_Deactivate_Btn="//a[@class='btn leftButton']//span[@translate='FORM_DEACTIVATE_BUTTON']";
	public static final String Users_Edit_Deactivate_Btn="//a[contains(@class,'btn leftButton')]//span[@translate='FORM_DEACTIVATE_BUTTON']";
	
	public static final String Users_Edit_Advanced_xp="//a[@class='nav-link ng-binding' and text()='ADVANCED']";
	//input[@type='search']
	public static final String Users_Cost_Center_Close_xp="//span[@class='close ui-select-match-close']";
	public static final String Users_Cost_Center_label="//label[text()='Cost Centers*']";
	public static final String Users_Cost_Center_Close="//span[@class='close ui-select-match-close']";
	
	public static final String Users_Managing_CCenter_Label="//label[@translate='USERS.MANAGING_COST_CENTERS_REQUIRED_LABEL']";
	
	public static final String Users_Edit_Deactivate_Btn_xp="//a[contains(@class,'btn leftButton')]//span";
	public static final String Ssp_Requests_All_xp="//span[@translate='TABLE_FILTERS.ISAPPROVED.ALL' and text()='All']";
	public static final String Ssp_Requests_User_Login_Email="//input[@name='emailAddress']";
	public static final String Ssp_Requests_User_Login_Password="//input[@name='password']";
	public static final String Ssp_Requests_User_Login_RequestAccess_Btn="//button[@class='btn btn-lg btn-default ng-scope' and text()='Request Access']";
	public static final String Ssp_Requests_User_RequestAccess_Login_Email="//input[@name='email']";
	public static final String Ssp_Requests_User_RequestAccess_Password="//input[@name='password']";
	public static final String Ssp_Requests_User_RequestAccess_Confirm_Password="//input[@name='confirmPassword']";
	public static final String Ssp_Requests_User_RequestAccess_Login_FirstName="//input[@name='firstName']";
	public static final String Ssp_Requests_User_RequestAccess_Login_LastName="//input[@name='lastName']";
	public static final String Ssp_Requests_User_RequestAccess_Login_Title="//input[@name='title']";
	public static final String Ssp_Requests_User_RequestAccess_Login_Cancel="//div[@class='actions']//button[text()='Cancel']";
	public static final String Ssp_Requests_User_RequestAccess_Login_Continue="//div[@class='actions']//button[text()='Continue']";
	public static final String Ssp_Requests_User_Approve_xp="//div[@class='sspRequests ng-scope']//sp-table-view-new//sp-table-new//table//tbody//tr[1]//td[8]";
	public static final String Ssp_Requests_User_Deny_xp="//div[@class='sspRequests ng-scope']//sp-table-view-new//sp-table-new//table//tbody//tr[1]//td[9]";
	public static final String Ssp_Requests_User_Approve_Btn_xp="//div[@class='approve-button ng-scope']//button[@class='btn btn-success ng-binding ng-scope' and text()='Approve']";
	public static final String Ssp_Requests_User_Deny_Btn_xp="//button[@class='btn btn-danger ng-binding ng-scope' and text()='Deny']";
	public static final String Ssp_Requests_Approve_PopUp_Title_xp="//h3[@class='ng-scope' and text()='Please Confirm']";
	public static final String Ssp_Requests_Approve_PopUp_Text_xp="//div[@class='message confirmBody ng-scope']";
	public static final String Ssp_Requests_Approve_PopUp_Yes_Btn_xp="//button[@class='btn btn-small confirm ng-scope']";
	public static final String Ssp_Requests_Approve_PopUp_No_Btn_xp="//button[@class='btn btn-small reject ng-scope']";
	public static final String Ssp_Requests_Deny_PopUp_Text_xp="//div[@class='message confirmBody ng-scope']";
	public static final String SelfServicePortal_Title="//span[@translate='SELF_SERVICE_PORTAL.LOGIN_FORM.PAGE_TITLE']";
	public static final String NotRegisteredUser_Alert_xp="//div[@class='nbc-alert-danger ng-binding ng-scope']";
	public static final String SelfServicePortal_UserLoginTitleText_xp="//div[@class='title']//h3[@translate='SELF_SERVICE_PORTAL.LOGIN_FORM.TITLE' and text()='User Log In']";
	public static final String SelfServicePortal_Customer_List="//form[@name='selectCustomerFormCtrl.form']//ul//li//span[@class='ui-select-highlight']";
	public static final String SelfServicePortal_ReasonForRequest="//textarea[@name='reasonForRequest']";
	public static final String SelfServicePortal_Customer_Submit="//button[@class='btn btn-lg btn-primary ng-scope' and text()='Submit']";
	public static final String SelfServicePortal_Customer_Cancel="//button[@class='btn btn-lg btn-default ng-scope' and text()='Cancel']";
	public static final String SelfServicePortal_RequestAccess_Title_xp="//span[@translate='SELF_SERVICE_PORTAL.NEW_USER_FORM.PAGE_TITLE' and text()= 'Request Access']";
	public static final String SelfServicePortal_Customer_Search_Box_xp="//input[@placeholder='Select customers...']";
	public static final String Ssp_Requests_Title="//h3[@translate='SSP_REQUESTS.TITLE']";
	public static final String Ssp_Requests_Login_Btn="//button[@type='submit' and @class='btn btn-lg btn-primary ng-scope']";
	public static final String Ssp_Requests_Account_Statement_Internal_Customer_1_xp="//div[@class='message confirmBody']//div//ul//li[1]";
	public static final String Ssp_Requests_Account_Statement_External_Customer_2_xp="//div[@class='message confirmBody']//div//ul//li[2]";
	public static final String Ssp_Requests_SelectCustomer_xp="//h3[@translate='CONFIRM_SELECT_CUSTOMER']";
	public static final String Ssp_Requests_SelectCustomer_OK_xp="//button[@class='btn btn-lg confirm ng-scope' and text()='OK']";
	public static final String Ssp_Requests_Account_Statement_InterceptMenu_Download_Invoice_xp="//div[@class='intercept-menu-container']//ul//li[1]//a[text()='Download Invoice']";
	public static final String Ssp_Requests_Account_Statement_InterceptMenu_Email_Invoice_xp="//div[@class='intercept-menu-container']//ul//li[2]//a[text()='Email Invoice']";
	public static final String Ssp_Requests_Account_Statement_InterceptMenu_View_BackUp_xp="//div[@class='intercept-menu-container']//ul//li[3]//a[text()='View Backup']";
	public static final String Ssp_Requests_Account_Statement_InterceptMenu_View_PDF_xp="//div[@class='intercept-menu-container']//ul//li[4]//a[text()='View PDF']";
	public static final String Ssp_Requests_Account_Statement_ToClickFirstCheckBox_xp="//div[@class='account-statements ng-scope']//sp-table-view-new//sp-table-new//table//tbody//tr[1]//td[1]";
	public static final String Ssp_Requests_Account_Statement_BulkActions_id="bulkActions";
	public static final String Ssp_Requests_Account_Statement_BulkActions_MenuFirstOption_xp="//div[@class='table-bulk-action ng-scope']//ul//li[1]";
	public static final String Ssp_Requests_Account_Statement_BulkActions_MenuSecondOption_xp="//div[@class='table-bulk-action ng-scope']//ul//li[2]";
	public static final String Ssp_Requests_NBCU_User_ClickloginMsg_xp="//p[@class='nbc-alert-danger ng-binding ng-scope']";
	public static final String Ssp_Requests_NBCU_SSO_UserName_id="username";
	public static final String Ssp_Requests_NBCU_SSO_PassWord_id="password";
	public static final String Ssp_Requests_NBCU_SSO_HomePage_Title_xp="//div[@id='sign_in_form']/h1";
	public static final String Ssp_Requests_NBCU_SignIn_xp="//button[@name='Submit']";
	public static final String Ssp_Requests_Account_Statement_Title_xp="//h3[@translate='ACCOUNT_STATEMENTS.TITLE']";
	public static final String Ssp_Requests_Account_Statement_SelectCustomer_PopUp_Close_xp="//i[@class='fa fa-times fa-2x fa-inverse pull-right ng-scope']";
	public static final String Ssp_Request_OtherCustomer_NotInList_xp="//div[@class='requestCustomer']/a/span";
	public static final String Ssp_Request_OtherCustomer_CustomerNumber_Field_xp="//input[@ng-model='selectCustomerFormCtrl.newUserObj.customerNumberTitle']";
	public static final String Ssp_Requests_User_Find_Btn_xp="//div[@class='find-button ng-scope']/button[@class='btn btn-default ng-binding ng-scope']";
	public static final String Ssp_Requests_User_Find_Popup_SelectCustomer_Title_xp="//h3[@translate='CONFIRM_SELECT_CUSTOMER' and text()='Select Customer']";
	public static final String Ssp_Requests_User_Find_Popup_SearchBox_xp="//input[@placeholder='Search Customers...']";
	public static final String Ssp_Requests_User_Find_Popup_SelectCustomer_dropdown_xp="//ul[@class='dropdown-menu ng-isolate-scope']/li/a/span[1]";
	public static final String Ssp_Requests_User_Find_Popup_SelectCustomer_SelectandApprove_Btn_xp="//button[@class='btn btn-lg btn-primary confirm ng-scope' and text()='Select & Approve']";
	public static final String Ssp_Requests_User_PasswordNotMatchError_xp="//p[@class='invalidInputMessage']//span[@translate='SELF_SERVICE_PORTAL.NEW_USER_FORM.INVALID_PASSWORD' and text()='Passwords do not match']";
	public static final String Ssp_InvoceMinDate_xp="//input[@name='minDate']";
	public static final String Ssp_InvoceMaxDate_xp="//input[@name='maxDate']";
	public static final String Ssp_InvoceMinDate_id="minDate";
	public static final String Ssp_InvoceMaxDate_id="maxDate";
	public static final String Ssp_InvoceFilter_xp="//div[@class='filters ng-scope']//div[@class='filter-titles rounded-bottom']//ul/li[2]//span";
	public static final String Ssp_InvoceFilter_Btn_xp="//button[@class='btn btn-primary set-range']";
	public static final String Ssp_AccountStatementPage_Table_xp="//div[@class='account-statements ng-scope']//sp-table-view-new/sp-table-new/table/tbody";
	
	
	
	public static final String Orders_Title_xp="//h3[@translate='ORDERS.TITLE' and text()='Orders']";
	public static final String Orders_Add_Form_Title_xp="//h1[@class='title ng-scope' and text()='Add Order']";
	public static final String Orders_DealNumber_SearchBox_xp="//div[@class='searchBar']//input[@type='text']";
	public static final String Orders_DealNumber_SearchBtn_xp="//div[@class='searchBar']//button[@class='btn searchButton ng-scope' and text()='Search']";
	public static final String Orders_Plus_Add_Sign_xp="//span[@ng-click='ordersCtrl.showAddForm = true;']";
	public static final String Orders_Add_Form_Customer_Field_xp="//div[@model='orderCtrl.selectedDeal.customer']//fieldset";
	public static final String Orders_Add_Form_Deal_Field_xp="//div[@model='orderCtrl.selectedDeal']//fieldset";
	//public static final String Orders_Add_Form_Order_Managing_CostCenter_xp="//div[@name='costCenter']";
	public static final String Orders_Add_Form_Order_Description_id="orderDescription";
	public static final String Orders_Add_Form_Order_Number_id="setNumber";
	public static final String Orders_Add_Form_Order_Number_xp="//input[@ng-model='orderNum']";
	public static final String Orders_Add_Form_TotalEstimateAmount_id="orderEstimateAmount";
	public static final String Orders_Add_Form_POnumber_id="orderPoNumber";
	public static final String Orders_Add_Form_WIP_Charge_Method_id="wipChargeMethod";
	public static final String Orders_Add_Form_Location_id="location";
	public static final String Orders_Add_Form_EpisodeNumber_id="episode";
	public static final String Orders_Add_Form_RequestorName_id="requestorName";
	public static final String Orders_Add_Form_RequestorPhone_id="requestorPhoneNumber";
	public static final String Orders_Add_Form_RequestorPhone_xp="//input[@name='requestorPhoneNumber']";
	public static final String Orders_Add_Form_Approver_Name_id="approverName";
	public static final String Orders_Add_Form_Approver_Phone_id="approverPhoneNumber";
	public static final String Orders_Add_Form_Approver_Phone_xp="//input[@name='approverPhoneNumber']";
	//public static final String Orders_Add_Form_Save_Btn_xp="//button[@class='btn rightButton ng-scope' and text()='Save']";
	public static final String Orders_Add_Form_Save_Btn_xp="//button[@translate='ORDERS.ADD_ORDER.SUBMIT_BUTTON']";
	public static final String Orders_Add_Form_Cancel_Btn_xp="//span[@translate='FORM_CANCEL_BUTTON' and text()='Cancel']";
	public static final String Orders_Add_Form_AlertMessage_Text_xp="//div[@class='nbc-alert-danger ng-binding' ]";
	//public static final String Orders_Add_Form_Order_Managing_CostCenter_xp="//div[@class='ui-select-container ui-select-multiple ui-select-bootstrap dropdown form-control ng-pristine ng-untouched ng-scope ng-empty ng-invalid ng-invalid-required']";
	public static final String Orders_Add_Form_Order_Managing_CostCenter_xp="//div[@name='costCenter']";
	public static final String Orders_Add_Form_Order_Managing_CostCenter_Label_xp="//label[@translate='ORDERS.ADD_ORDER.ORDER_MANAGING_COST_CENTER']";
	public static final String Orders_Add_Form_Default_WIP_Charge_Method_Value_xp="//select[@id='wipChargeMethod']//option[@selected='selected']";
	public static final String Orders_Add_Form_Default_DealNumber_Value_xp="//div[@description='model.dealTitle']//data//div[1]";
	public static final String Orders_Add_Form_ExistOrderMessage_xp="//p[@class='invalidInputMessage ng-scope']";
	public static final String Orders_Edit_Form_Title_xp="//h1[@class='title ng-scope']";
	public static final String Orders_Add_Form_Default_CostCenter_Value_xp="//div[@name='costCenter']//span[@class='ng-binding ng-scope']";
	public static final String Orders_Add_Form_Disabled_Order_Managing_CostCenter_xp="//input[@class='ui-select-search input-xs ng-pristine ng-untouched ng-valid ng-empty']";
	public static final String Orders_Add_Form_Border_Color_Managing_CostCenter_xp="//div[@class='ui-select-container ui-select-multiple ui-select-bootstrap dropdown form-control ng-pristine ng-untouched ng-scope ng-empty ng-invalid ng-invalid-required']";
	public static final String Orders_Edit_Order_BtnStatus_id="orderStatus";
	public static final	String Orders_Edit_Order_ClosedBtnStatus_xp="//select[@name='orderStatus']//option[@label='Closed']";
	public static final	String Orders_Edit_Order_OpenBtnStatus_xp="//select[@name='orderStatus']//option[@label='Open']";
	public static final	String Orders_Edit_Order_Orderclose_xp="//i[@class='fa fa-times fa-2x fa-inverse']";
	public static final	String Orders_Edit_Order_OrderexitYes_xp="//button[@class='btn btn-small confirm ng-scope' and @translate='FORM_EXIT_YES_BUTTON']";
	
	public static final String Dashboard_SearchBy_InvoiceNumber_xp="//ng-form[@name='Tile.detailForm']//select";
	public static final String Dashboard_invoiceNum_SearchBar_xp="(//input[@placeholder='Enter Search Criteria...'])[1]";
	public static final String Dashboard_SearchBy_Deal_xp="//ng-form[@name='Tile.orderForm']//select";
	public static final String Dashboard_Deal_SearchBar_xp="//ng-form[@name='Tile.orderForm']//input[@type='search']";
	public static final String Dashboard_Deal_SearchBar_FirstRow_xp="//span[@class='ui-select-choices-row-inner']/span/span";
	public static final String Dashboard_Deal_Search_Go_Btn_xp="//ng-form[@name='Tile.orderForm']//button[@class='btn btn-primary']";
	
	public static final String BulkActionsList_xp="//ul[@class='dropdown-menu bulkActionsList']/li";
	
	public static final	String Orders_CostObject_id="costObject";
	public static final	String Orders_AccountNumber_id="accountNumber";
	public static final	String Orders_sapTerritory_id="sapTerritory";
	//////Shameem's mini Regression merged code xpaths//////////////////
	public static final String Deals_AddAltAddress_BtnAddPlusLink_xp = "//div[contains(@class,'ng-not-empty')]/div[contains(@class,'multi-search-select')]/div[@class='add']/i";
	public static final String Deals_AddDeal_InputAltAddrDesc_id="alternateAddressDescription";
	public static final String Deals_AddDeal_InputAltAddressLine1_id="alternateAddressLine1";
	public static final String Deals_AddDeal_InputAltAddressLine2_id="alternateAddressLine2";
	public static final String Deals_AddDeal_InputAltAddressLine3_id="alternateAddressLine3";
	public static final String Deals_AddDeal_ComboAltCountry_id="alternateCountry";
	public static final String Deals_AddDeal_ComboAltState_id="alternateState";
	public static final String Deals_AddDeal_InputAltCity_id="alternateCity";
	public static final String Deals_AddDeal_InputAltZipId_id="alternateZip";
	public static final String Deals_AddAltAddress_BtnAdd_xp = "//div[@class='addressInputsContainer']/form/div[@class='actions']/a[contains(@ng-click,'altAddrCtrl')]/i";
	public static final String Deals_Interceptmenu_ViewTransactions_xp ="//div[@class='intercept-menu-container']/ul/li[6]";
	
	//////////////////////////////////////End Users Objects////////////////////////////////////////////
	//////////////////////////////////////Queue logging objects/////////////////////////////////////////
	
	public static final String Common_ViewQueueLogging_BtnBulkActions_xp= "//button[@type='button' and contains(text(),'Bulk Actions')]";
	public static final String Common_ViewQueueLogging_SearchBox_xp="//input[@class='search ng-pristine ng-valid ng-empty ng-touched']";
	public static final String Common_ViewQueueLogging_firstColumn_xp="//div[@class='customerQueue ng-scope']//tr//th[1]";
	//public static final String Common_ViewQueueLogging_Status_xp="//div[@class='filter-titles rounded-bottom']/ul/li/span";
	public static final String Common_ViewQueueLogging_Status_xp="//div[@class='filter-titles']/ul/li[2]/span";
	public static final String Common_ViewQueueLogging_Status_Close_xp="//div[@class='col-md-12']/ul[@class='applied-filters']//li/span[@class='fa fa-close']";
	public static final String Common_ViewQueueLogging_Status_ClearAll_Btn="//span[@translate='TABLE_FILTERS.CLEAR_ALL']";
	public static final String Queuelogging_Screen_Integration_Error_Title_xp="//h1[@class='title ng-scope']";
	public static final String Queuelogging_Screen_Integration_Error_xp="//div[@class='error-message ng-binding']";
	public static final String Order_Screen_DealNumber_SearchBar_xp="//input[@ng-model='ordersCtrl.dealNumberSearch']";
	public static final String ARC_Title_xp="//h3[@translate='ARC.TITLE']";
	public static final String ARC_Screen_Order_list_1="//div[@class='panel panel-default ng-scope ng-isolate-scope']//ul[@class='list-group']//li[1]";
	public static final String ARC_Screen_Order_list_2="//div[@class='panel panel-default ng-isolate-scope' and @search-method='Arc.searchOrders']//ul[@class='list-group']//li[1]";
	public static final String ARC_Screen_Deal_list_1="//div[@class='panel panel-default ng-isolate-scope']//ul[@class='list-group']//li[1]";
	public static final String ARC_Screen_OrderNumber_SearchBar_xp="//input[@placeholder='Search Orders...']";
	public static final String ARC_Screen_Order_Search_Bar_xp="//input[@placeholder='Search Orders...']";
	public static final String ARC_Screen_transaction_table_xp="//div[@class='arc-table']//sp-table-view-new//sp-table-new//table//tbody";
	public static final String ARC_Screen_Clear_Btn_xp="//span[@translate='TABLE_FILTERS.CLEAR_ALL']";
	public static final String ARC_Screen_Deal_Search_Bar_xp="//input[@placeholder='Search Deals...']";
	public static final String Transaction_Accordian_Table_Rows_xp="//div[@class='accordion']/table/tbody/tr";
	public static final String ARC_Screen_DealNumber_Clear_Btn_xp="//span[@class='clear']";
	public static final String ARC_Screen_Approved_Btn_xp="//span[@translate='TABLE_FILTERS.TRANSACTIONSTATUSCODEID.31006']";
	public static final String ARC_Screen_UnApproved_Btn_xp="//span[@translate='TABLE_FILTERS.TRANSACTIONSTATUSCODEID.31005']";
	public static final String ARC_Screen_Approved_BulkOption_Reassign_xp="//ul[@class='dropdown-menu bulkActionsList']/li[1]";
	public static final String ARC_Screen_Approved_BulkOption_UnApprove_xp="//ul[@class='dropdown-menu bulkActionsList']/li[2]";
	public static final String ARC_Screen_Approved_BulkOption_Suspend_xp="//a[contains(text(),'Suspend')]";
	public static final String ARC_Screen_Approved_BulkOption_Non_Bilable_xp="//a[contains(text(),'Make Non-Billable')]";
	public static final String ARC_Screen_Approved_BulkOption_Bilable_xp="//ul[@class='dropdown-menu bulkActionsList']/li[6]";
	public static final String ARC_Screen_ReassignForm_Title_xp="//h3[@translate='ARC.MOVE.DIALOG.TITLE']";
	public static final String ARC_Screen_Reassign_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_UnApprove_Confirm_Yes_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_SuspendTransactionForm_Title_xp="//h3[@translate='ARC.SUSPEND.DIALOG.TITLE']";
	public static final String ARC_Screen_MakeTransactionNonBillableForm_Title_xp="//h3[@translate='ARC.FLIP_BILLABLE.DIALOG.TITLE']";
	public static final String ARC_Screen_MakeTransactionBillableForm_Title_xp="//h3[@translate='ARC.FLIP_BILLABLE.DIALOG.TITLE']";
	public static final String ARC_Screen_WIP_MakeTransactionNonBillableForm_Error_Msg_xp="//h4[@class='error-heading ng-scope' and text()='Cannot Make Billable']";
	public static final String ARC_Screen_WIP_MakeTransactionNonBillableForm_Error_Msg2_xp="//p[@translate='ARC.FLIP_BILLABLE.DIALOG.ERROR.COST']";
	public static final String ARC_Screen_WIP_MakeTransactionNonBillableForm_Cancel_xp="//button[@class='btn btn-small reject ng-scope']";
	
	public static final String ARC_Screen_Suspend_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_MakeTransactionNonBillableForm_Continue_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_MakeTransactionBillableForm_Continue_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_Billable_Yes_Btn_True_xp="//input[@id='billableYes' and @class='ng-pristine ng-untouched ng-valid ng-not-empty']";
	public static final String ARC_Screen_Billable_No_Btn_True_xp="//div[@class='radioYesNo']//input[@id='billableNo' and @ng-value='true']";
	public static final String ARC_Screen_Suspend_Error_xp="//div[@ng-message='required' and text()='Please enter a note.']";
	public static final String ARC_Screen_notes_id="notes";
	public static final String ARC_Screen_Approved_BulkOption_Reject_xp="(//a[contains(text(),'Reject')])[1]";
	public static final String ARC_Screen_RejectTransactionForm_Title_xp="//h3[@translate='ARC.REJECT.DIALOG.TITLE']";
	public static final String ARC_Screen_Reject_Btn_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_Reject_errortext_xp="//p[@translate='ARC.REJECT.ERROR.622' and text()='Department System Number  has transactions in the exception queue.' ]";
	public static final String ARC_Screen_Reject_errortext1_xp="//h4[@translate='ARC.REJECT.ERROR.HEADER' and text()='Cannot Reject Transactions' ]";
	public static final String ARC_Screen_send_Errortext1_xp="//h4[@translate='ARC.APPROVE_SEND.ERROR.HEADER' and text()='Cannot Send Transactions' ]";
	public static final String ARC_Screen_send_Errortext_xp="//p[@translate='ARC.APPROVE_SEND.ERROR.622' and text()='Dept system number  has transactions that are in exception queue' ]";
	public static final String ARC_Screen_Reject_Cancel_Btn_xp="//button[@class='btn btn-small reject ng-scope' ]";
	public static final String ARC_Screen_InterceptMenu_Approve_Send_Btn_xp="//div[@class='intercept-menu-container']/ul/li[2]/a";
	public static final String ARC_Screen_Transaction_notes_xp="//li[@class='notes-tab uib-tab nav-item ng-scope ng-isolate-scope']";
	public static final String ARC_Screen__Send_Popup_Title_xp="//h3[@translate='ARC.SEND.TITLE']";
	public static final String ARC_Screen_Make_Transaction_Non_Billable_Popup_Title_xp="//h3[@translate='ARC.FLIP_BILLABLE.DIALOG.TITLE']";
	public static final String ARC_Screen__Suspend_Popup_Title_xp="//h3[@translate='ARC.SUSPEND.DIALOG.TITLE']";
	public static final String ARC_Screen__Reassign_Popup_Title_xp="//h3[@translate='ARC.MOVE.DIALOG.TITLE']";
	public static final String ARC_Screen__Reject_Popup_Title_xp="//h3[@translate='ARC.REJECT.DIALOG.TITLE']";
	
	public static final String ARC_Screen_Popup_Close_xp="//i[@class='fa fa-times fa-inverse pull-right']";
	
	public static final String ARC_Screen_Make_Transaction_Non_Billable_Popup_Continue_xp="//button[contains(@class,'btn btn-small confirm')]";
	public static final String ARC_Screen_Non_Billable_InterceptMenuList_xp="//div[@class='intercept-menu-container']";
	public static final String ARC_Screen_Transaction_Title_xp="//h1[@translate='TRANSACTIONS.FORM.TITLE']";
	public static final String ARC_Screen_InterceptMenu_Send_Btn_xp="//div[@class='intercept-menu-container']/ul/li[4]/a";
	public static final String ARC_Screen_InterceptMenu_Non_Billable_Btn_xp="//div[@class='intercept-menu-container']/ul/li[8]/a";
	public static final String ARC_Screen_InterceptMenu_Reassign_Btn_xp="//div[@class='intercept-menu-container']/ul/li[6]/a";
	public static final String ARC_Screen_InterceptMenu_Reject_Btn_xp="//div[@class='intercept-menu-container']/ul/li[7]/a";
	public static final String ARC_Screen_InterceptMenu_Suspend_Btn_xp="//div[@class='intercept-menu-container']/ul/li[10]/a";
	public static final String ARC_Screen_Transaction_PerformingCostCenter_xp="//div[@name='costCenter']//input[@role='combobox']";
	public static final String ARC_Screen_Transaction_Save_Btn_xp="//button[@class='btn rightButton ng-scope']";
	public static final String ARC_Screen_PopMenu_DSN_Number_xp="//div[@class='department-system-numbers ng-scope']";
	public static final String ARC_Screen_Transaction_PerformingCC_Text_xp="//span[@class='ui-select-match-item btn btn-default btn-xs']//span[@class='ng-binding ng-scope']";
	public static final String ARC_Screen__Send_Btn_xp="//button[@class='btn btn-small confirm ng-scope' and text()='Send']";
	public static final String ARC_Screen_ClickFirstRow_xp = "//sp-table-new/table/tbody/tr/td[10]";
	public static final String ARC_Screen_DeptSystem_xp="//div[@class='col-md-6']//div[@class='ng-binding']";
	public static final String ARC_Screen_Approve_Send_Btn_xp="//button[@class='btn btn-small confirm ng-scope' and text()='Approve & Send']";
	
	public static final String Transactions_AddTransaction_LabelAddTransaction_Title_xp="//h1[@class='title ng-scope']";
	public static final String Transactions_AddTransaction_LinkAddTransaction_Sign_xp ="//span[@ui-sref-opts='{notify: false}']";
	public static final String Transaction_PageTitle_xp ="//h3[@translate='TRANSACTION_RESEARCH.TITLE']";
	public static final String Transaction_AddTransaction_SearchOrder_xp="//input[@placeholder='Search Orders...']";
	public static final String Transaction_AddTransaction_PoNumber_id="poNumber";
	public static final String Transaction_AddTransaction_PoNumber_id1="//*[@id='poLineNumber']";
	public static final String Transaction_AddTransaction_transactiondate="//label[contains(text(),'Interface Code')]";
	public static final String Transaction_AddTransaction_TransactionDate_id="transactionDate";
	public static final String Transaction_AddTransaction_RentalStartDate_id="rentalStartDate";
	public static final String Transaction_AddTransaction_RentalEndDate_id="rentalEndDate";
	public static final String Transaction_AddTransaction_Description_xp="//input[@name='lineDescription']";
	public static final String Transaction_AddTransaction_Qty_xp="//input[@name='quantity']";
	public static final String Transaction_AddTransaction_UnitofMeasure_id="unitOfMeasure";
	public static final String Transaction_AddTransaction_Rate_xp="//input[@name='rate']";
	public static final String Transaction_AddTransaction_TransactionType_id="transactionType";
	public static final String Transaction_AddTransaction_Save_Btn_xp="//button[@class='btn rightButton ng-scope' and @translate='EXCEPTIONS.BILLING_REQUEST_FORM.SUBMIT_BUTTON']";
	public static final String Transaction_AddTransaction_Form_All_Fields_List_xp="//sp-add-transaction[@ng-if='transactionResearchCtrl.showAddForm']";
	
	
	public static final String Billing_Approvals_Title_xp="//h3[@translate='APPROVALS.TITLE']";
	public static final String Billing_Approvals_SearchBox_xp="//input[@name='search']";
	public static final String Billing_Approvals_Approve_Btn_xp="//div[@class='approve-button ng-scope']//button[@class='btn btn-success ng-binding ng-scope' and text()='Approve']";
	public static final String Billing_Approvals_Approve_Yes_Btn_xp="//button[@class='btn btn-small confirm ng-scope']";
	public static final String Billing_Approvals_PopUp_Title_xp="//h3[@translate='Approve Transaction(s)']";
	public static final String Billing_DraftBilling_Intercept_View_Edit_DraftBill_xp="//div[@class='intercept-menu-container']/ul/li/a[@ng-click='interceptMenuCtrl.clickAction(menu)']";
	public static final String Billing_DraftBilling_DCS_View_Edit_CustomerBlock_xp="//div[@model='EditSummaryBill.draftBill.deal.customer']//fieldset";
	public static final String Billing_DraftBilling_DCS_View_Edit_DealBlock_xp="//div[@model='EditSummaryBill.draftBill.deal']//fieldset";
	public static final String Billing_DraftBilling_DCS_View_Edit_AddressBlock_xp="//div[@class='address form-box']";
	public static final String Billing_DraftBilling_DCS_View_Edit_Description_Field_xp="//input[@name='invoiceName']";
	public static final String Billing_DraftBilling_DCS_View_Edit_InvoiceFormat_Field_xp="//p[@class='ng-binding' and text()='DCS - Direct Charge Summary']";
	public static final String Billing_DraftBilling_DCS_View_Edit_DeliveryMethod_id="deliveryMethod";
	public static final String Billing_DraftBilling_DCS_View_Edit_DCS_Receiving_Contacts_xp="//div[@class='form-box rounded contacts-list']";
	public static final String Billing_DraftBilling_DCS_View_Edit_DCS_Amount_xp="//b[@class='bold' and text()='DCS Amount:']";
	public static final String Billing_DraftBilling_DraftBill_List_xp="//ul[@class='list-group accordion-double-button']//li[1]";
	//public static final String Billing_DraftBilling_DraftBill_List_xp="//ul[@class='list-group accordion-single-button']//li[1]";
	//public static final String Billing_DraftBilling_DraftBill_List_2_xp="//ul[@class='list-group accordion-single-button']//li[2]//p[2]";
	public static final String Billing_DraftBilling_DraftBill_List_2_xp="//ul[@class='list-group accordion-single-button']//li[1]//p[2]";
	public static final String Billing_DraftBilling_DraftBill_List_3_xp="//ul[@class='list-group accordion-double-button']//li[1]//p[2]";
	public static final String Billing_DraftBilling_Title_xp="//h3[@translate='DRAFT_BILLING.TITLE']";
	public static final String Billing_DraftBilling_DraftBill_Number_xp="//ul[@class='list-group accordion-double-button']//li[1]//p[1]";
	//public static final String Billing_DraftBilling_DraftBill_Number_xp="//ul[@class='list-group accordion-single-button']//li[1]//p[1]";
	public static final String Billing_DraftBilling_AddNewDraftBill_plus_xp="//i[@class='fa fa-plus-circle']";
	public static final String Billing_DraftBilling_AddNewDraftBill_Save_Btn_xp="//button[@ng-click='EditDraftBill.saveNewDraft()']";
	public static final String Billing_DraftBilling_AddNewDraftBill_deliveryMethod_id="deliveryMethod";
	public static final String Billing_DraftBilling_DealSearchBar_xp="//input[@placeholder='Search Deals...']";
	public static final String Billing_DraftBilling_Deal_list_1="//div[@class='panel panel-default ng-isolate-scope']//ul[@class='list-group']//li[1]";
	public static final String Billing_DraftBilling_Edit_Title_xp="//div[@class='sideview-header']//h1";
	//public static final String Billing_DraftBilling_Edit_Create_xp="//button[@class='btn btn-primary dropdown-toggle']";
	public static final String Billing_DraftBilling_Edit_Create_xp="//button[@type='button' and @class='btn btn-primary dropdown-toggle']";
	public static final String Billing_DraftBilling_Edit="//div[@ng-if='Accordion.isMulti']//p[2]";
	//public static final String Billing_DraftBilling_immediate_xp="//a[@ng-click='EditSummaryBill.sendImmediate()']";
	public static final String Billing_DET_DraftBilling_immediate_xp="//a[@ng-click='EditDraftBill.sendImmediate()']";
	public static final String Billing_DCS_DraftBilling_immediate_xp="//a[@ng-click='EditSummaryBill.sendImmediate()']";
	public static final String Billing_DraftBilling_immediate_xp="//a[contains(@ng-click,'sendImmediate()')]";
	public static final String Billing_DraftBilling_DeliveryMethod_xp="//select[@name='deliveryMethod']//option[@selected='selected']";
	
	public static final String Billing_DraftBilling_percent_id="0-percent";
	public static final String Billing_DraftBilling_percent_id1="1-percent";
	public static final String Billing_DraftBilling_percent_id2="2-percent";
	
	public static final String Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp="//button[@class='btn btn-small confirm ng-scope']";
	//public static final String Billing_DraftBilling_createImmediate_PopUp_Title_xp="//h3[@translate='Create Immediate DCS Summary']";
	public static final String Billing_DraftBilling_createImmediate_PopUp_Title_xp="//h3[contains(@translate,'Create Immediate')]";
	
	public static final String Billing_DraftBilling_sendToArc_Btn_xp="//button[@class='btn btn-default ng-binding' and @ng-click='EditDraftBill.sendToArc()']";
	public static final String Billing_DraftBilling_Delete_Btn_xp="//button[@class='btn btn-default ng-binding' and @ng-click='EditDraftBill.sendToArc()']";
	public static final String Transaction_Order_Error_xp = "//div[contains(@class,'nbc-alert-danger')]";
	public static final String Transaction_Order_AddOrder_xp = "//div[@class='add']/i[@class='fa fa-plus-circle cursor-pointer-on-hover']";
	public static final String Billing_DraftBilling_Add_AccountNumber_xp="//i[@class='fa fa-plus']";
	public static final String Billing_DraftBilling_CostObject_2_xp="//input[@name='1-sapCostObject']";
	public static final String Billing_DraftBilling_AccountNumber_2_xp="//input[@name='1-sapAccountNumber']";
	public static final String Billing_DraftBilling_sapIndicator_2_xp="(//select[@name='sapIndicator'])[2]";
	public static final String Billing_DraftBilling_sapTerritory_2_xp="(//input[@name='sapTerritory'])[2]";
	public static final String Billing_DraftBilling_CostObject_RightArrow_xp="//i[@class='fa fa-caret-right']";
	public static final String Billing_DraftBilling_CostObject_1_xp="//input[@name='0-sapCostObject']";
	public static final String Billing_DraftBilling_AccountNumber_1_xp="//input[@name='0-sapAccountNumber']";
	public static final String Billing_DraftBilling_sapIndicator_1_xp="//select[@name='sapIndicator']";
	public static final String Billing_DraftBilling_sapTerritory_1_xp="//input[@name='sapTerritory']";
	public static final String Billing_DraftBilling_sapCompany_1_xp="//select[@name='sapCompany']";
	
	public static final String Billing_DraftBilling_percent_id_2="1-percent";
	public static final String Billing_DraftBilling_amount_id_2="1-amount";
	//public static final String Billing_DraftBilling_amount_id="0-amount";
	
	public static final String Billing_DraftBilling_Transactions_SearchBox_xp="//input[@placeholder='Search Charges...']";
	public static final String Billing_DraftBilling_customer_FilterContent_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[4]//li";
	public static final String Billing_DraftBilling_customer_FilterName_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[5]//span";
	public static final String Billing_DCS_DraftBilling_MissingSAP_message_xp="//p[@class='fa fa-warning ng-scope']/span";
	
	public static final String Billing_DraftBilling_DraftBillPanel_Clear_Btn="//div[@title='Draft Bill']//span[2]";
	public static final String Billing_DraftBilling_DealPanel_Clear_Btn="//div[@title='Deal']//span[2]";
	public static final String Billing_DraftBilling_Applied_DealMaker_Name_xp="(//ul[@class='applied-filters']//li)[1]";
	
	public static final String Billing_DraftBilling_View_Edit_Available_Prepayment_Amount="(//div[@class='summary']//div[@class='col-sm-4 ng-binding'])[1]";
	public static final String Billing_DraftBilling_View_Edit_InvoiceAmount_Amount="(//div[@class='summary']//div[@class='col-sm-4 ng-binding'])[2]";
	public static final String Billing_DraftBilling_View_Edit_Applied_Prepayment_Amount="(//div[@class='summary']//div[@class='col-sm-4 ng-binding'])[3]";
	public static final String Billing_DraftBilling_View_Edit_Invoice_NetAmount_Amount="(//div[@class='summary']//div[@class='col-sm-4 ng-binding'])[4]";
	public static final String Billing_DraftBilling_Available_Prepayment="//strong[@translate='DRAFT_BILLING.TOTAL_TABLE.AVAILABLE_PREPAYMENT']";
	public static final String Billing_DraftBilling_Available_Prepayment_Table_xp= "//table[@class='table']/tbody";
	public static final String Billing_DraftBilling__Table_column_Deal_xp= "//table[@class='table']/tbody/tr[1]/td[1]";
	public static final String Billing_DraftBilling__Table_column_Selected_xp= "//table[@class='table']/tbody/tr[2]/td[1]";
	
	public static final String Billing_DraftBilling__Table_column_Deal_InvoiceAmount_td_xp="//table[@class='table']/tbody/tr[1]/td[2]";
	public static final String Billing_DraftBilling__Table_column_Deal_AppliedPrePayment_td_xp="//table[@class='table']/tbody/tr[1]/td[3]";
	public static final String Billing_DraftBilling__Table_column_Deal_InvoiceNetAmount_td_xp="//table[@class='table']/tbody/tr[1]/td[4]";
	
	public static final String Billing_DraftBilling__Table_column_Selected_InvoiceAmount_td_xp= "//table[@class='table']/tbody/tr[2]/td[2]";
	public static final String Billing_DraftBilling__Table_column_Selected_AppliedPrePayment_td_xp="//table[@class='table']/tbody/tr[2]/td[3]";
	public static final String Billing_DraftBilling__Table_column_Selected_InvoiceNetAmount_td_xp="//table[@class='table']/tbody/tr[1]/td[4]";
	
	public static final String Billing_DraftBilling_note_id_1="0-note";
	public static final String Billing_DraftBilling_note_id_2="1-note";
	public static final String Billing_DraftBilling_amount_numbers_xp="//div[@class='col-sm-4 account-values']/p";
	public static final String Billing_DraftBilling_percent_numbers_xp="//div[@class='col-sm-2 account-values']/p";
	public static final String Billing_DraftBilling_sapCompany_xp="(//select[@name='sapCompany'])[2]";
	public static final String Billing_DraftBilling_X_button_2_xp="(//i[@class='fa fa-times remove-account ng-scope'])[2]";
	public static final String Billing_DraftBilling_X_button_1_xp="(//i[@class='fa fa-times remove-account ng-scope'])[1]";
	public static final String Billing_DraftBilling_Total_Amount_xp="//div[@class='col-sm-4 account-values']";
	public static final String Billing_DraftBilling_Total_xp="//div[@class='col-sm-12 account-items account-items-footer']//div[@class='col-sm-2 account-values']";
	public static final String Billing_DraftBilling_amount_id="0-amount";
	public static final String Billing_DraftBilling_amount_error_xp="//div[@class='col-sm-12 totals-validation ng-scope']";
	public static final String Billing_DraftBilling_View_Edit_AvailablePrepayment_xp="(//div[@class='col-sm-8']/strong)[1]";
	public static final String Billing_DraftBilling_View_Edit_InvoiceAmount_xp="(//div[@class='col-sm-8']/strong)[2]";
	public static final String Billing_DraftBilling_View_Edit_AppliedPrepayment_xp="(//div[@class='col-sm-8']/strong)[3]";
	public static final String Billing_DraftBilling_View_Edit_InvoiceNetAmount_xp="(//div[@class='col-sm-8']/strong)[4]";
	public static final String Billing_DraftBilling_View_Edit_AvailablePrepayment_Amount_xp="(//div[@class='col-sm-4 ng-binding'])[1]";
	public static final String Billing_DraftBilling_View_Edit_InvoiceAmount_Amount_xp="(//div[@class='col-sm-4 ng-binding'])[2]";
	public static final String Billing_DraftBilling_View_Edit_AppliedPrepayment_Amount_xp="(//div[@class='col-sm-4 ng-binding'])[3]";
	public static final String Billing_DraftBilling_View_Edit_InvoiceNetAmount_Amount_xp="(//div[@class='col-sm-4 ng-binding'])[4]";
	public static final String Billing_DraftBilling_View_Edit_Close_Btn_xp="//i[@class='fa fa-times fa-2x fa-inverse']";
	
	public static final String InvoiceStatement_InvoiceSummary__CustomerBlock_xp="//div[@model='EditDraftBill.draftBill.deal.customer']//fieldset";
	public static final String InvoiceStatement_InvoiceSummary__DealBlock_xp="//div[@model='EditDraftBill.draftBill.deal']//fieldset";
	public static final String InvoiceStatement_InvoiceSummary__BillingAddress_xp="//div[@class='address form-box']";
	public static final String InvoiceStatement_InvoiceSummary__InvoiceName_xp="//input[@name='invoiceName']";
	public static final String InvoiceStatement_InvoiceSummary__DeliveryMethod_xp="//select[@name='deliveryMethod']";
	public static final String InvoiceStatement_InvoiceSummary__SummaryCheckBox_xp="//input[@name='isSummary']";
	public static final String InvoiceStatement_InvoiceSummary__EmailField_xp="//div[@class='form-box contacts-list']";
	public static final String InvoiceStatement_Table_xp="//table[@class='table table-striped']/tbody";
	public static final String InvoiceStatement_Customer_Filter_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[2]//span";
	public static final String InvoiceStatement_Customer_Filter_Content_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[1]//li";
	public static final String InvoiceStatement_InvoiceDate_Filter_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[4]//span";
	public static final String InvoiceStatement_Deal_SearchBar_Filter_xp="//input[@placeholder='Search Deal Number...']";
	public static final String InvoiceStatement_Customer_SearchBar_Filter_xp="//input[@placeholder='Search Customer...']";
	public static final String InvoiceStatement_Deal_Filter_Content_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[2]//li";
	
	//div[@class='message confirmBody ng-scope']
	///////////////////////////////////////Parent Company/National Account Objects////////////////////////////////////////////
	
	public static final String Customers_AddNationalAccount_InputName_id = "name";
	public static final String Customers_AddNationalAccount_InputEmail_id = "email";
	public static final String Customers_AddNationalAccount_InputAddressLine1_id = "addressLine1";
	public static final String Customers_AddNationalAccount_InputAddressLine2_id = "addressLine2";
	public static final String Customers_AddNationalAccount_InputAddressLine3_id = "addressLine3";
	public static final String Customers_AddNationalAccount_InputCity_id = "city";
	public static final String Customers_AddNationalAccount_ComboState_id = "state";
	public static final String Customers_AddNationalAccount_InputZip_id = "zip";
	public static final String Customers_AddNationalAccount_ComboCountry_id = "country";
	                                                                        
	
	public static final String Customers_AddNationalAccount_BtnAdd_xp = "//button[@type='submit' and text()='Add']";
	public static final String Customers_AddNationalAccount_LabelAddNationalAccountTitle_xp = "//h1[text()='Add Parent Company']";
	//public static final String Customers_AddNationalAccount_BtnCancel_xp = "//a[@class='btn cancelButton']/span[text()='Cancel']";//translate='FORM_CANCEL_BUTTON'
	public static final String Customers_AddNationalAccount_BtnCancel_xp = "//a[@class='btn leftButton' and contains(@ng-click,'addParentCompany')]/span[text()='Cancel']";
	//public static final String Customers_AddNationalAccount_BtnClose_xp = "//div[@class='addEditModalHeader']/i";
	public static final String Customers_AddNationalAccount_BtnClose_xp = "//div[@class='sideview-header']/i";
	//public static final String Customers_AddNationalAccount_BtnClose_xp="//i[@class='fa fa-times fa-2x fa-inverse']";
	//public static final String Customers_AddNationalAccount_MsgSuccess_xp = "//div[@ng-show='parentCompanies.addParentCompanySuccess']/p";
	public static final String Customers_AddNationalAccount_MsgSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! A new parent company has been created.']";;
	public static final String Customers_AddNationalAccount_MsgError_xp = "//div[contains(@class,'nbc-alert-danger') and @ng-show='addParentCompany.displayErrorAlert()']";
	
	public static final String Customers_AddNationalAccount_MsgNameError_xp = "//p[@ng-message='required' and contains(@translate,'NAME_REQUIRED_MESSAGE')]";
	public static final String Customers_AddNationalAccount_MsgCustomerTypeError_xp = "//p[@ng-message='required' and contains(@translate,'CUSTOMER_TYPE_REQUIRED_MESSAGE')]";
	public static final String Customers_AddNationalAccount_MsgProductionTypeError_xp = "//p[@ng-message='required' and contains(@translate,'PRODUCTION_TYPE_REQUIRED_MESSAGE')]";
	public static final String Customers_AddNationalAccount_MsgAddressError_xp = "//p[contains(@class,'invalidInputMessage') and contains(@translate,'ADDRESS_REQUIRED_MESSAGE')]";
	
	//public static final String Customers_ViewNationalAccountModule_Table_xp = "//div[@class='parentCompanies ng-scope']/sp-table/table/tbody";
	public static final String Customers_ViewNationalAccountModule_Table_xp = "//div[@class='parentCompanies']/sp-table-view-new/sp-table-new/table/tbody";
	//public static final String Customers_AddNationalAccount_LinkAddPlusSign_xp = "//section[@class='content ng-scope']/a[@ui-sref='parentCompanies.add']/i";
	//public static final String Customers_AddNationalAccount_LinkAddPlusSign_xp = "//section[@class='content ng-scope']/a/i";
	public static final String Customers_AddNationalAccount_LinkAddPlusSign_xp = "//section[@class='content ng-scope']/div/a/i";
	
	public static final String Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp = "//h1[@class='title ng-scope']";
	public static final String Customers_EditNationalAccount_ComboCustomerType_id = "customerType";
	public static final String Customers_EditNationalAccount_ComboProductionType_id = "productionType";
	//public static final String Customers_EditNationalAccount_BtnSave_xp = "//button[@type='submit' and text()='Save']";

	public static final String Customers_EditNationalAccount_BtnSave_xp = "//button[@type='submit' and text()='Save' and contains(@ng-click,'ParentCompany')]";
	
	public static final String Customers_EditNationalAccount_BtnDeactivate_xp = "//a[@class='btn leftButton']/span[text()='Deactivate']";
	//public static final String Customers_EditNationalAccount_BtnDeactivate_xp="//a[@class='btn leftButton']//span[@translate='FORM_DEACTIVATE_BUTTON']";
	//public static final String Customers_EditNationalAccount_MsgSuccess_xp = "//div[@ng-show='parentCompanies.addParentCompanySuccess']/p";
	public static final String Customers_EditNationalAccount_MsgSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! The parent company was updated.']";
	
	public static final String Customers_EditNationalAccount_ComboDeactNationalAccount_id = "parentCompanies";
	public static final String Customers_EditNationalAccount_BtnDeactivateYes_xp = "//button[@type='submit' and text()='Yes']";
	public static final String Customers_EditNationalAccount_BtnDeactivateNo_xp = "//a[@class='btn leftButton']/span[text()='No']";
	public static final String Customers_EditNationalAccount_MsgDeactivateConfirmation_xp = "//h2[contains(@class,'deactivateConfirmMessage') and contains(text(),'Are you sure you want to deactivate')]";
	//public static final String Customers_EditNationalAccount_MsgDeactivateSuccess_xp = "//div[@ng-show='parentCompanies.addParentCompanySuccess']/p";
	public static final String Customers_EditNationalAccount_MsgDeactivateSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! The parent company was deactivated.']";
	
	//public static final String CustomersMaster_AddCustomer_LinkAddPlusSign_xp = "//span[@ui-sref='customers.add']";
	public static final String CustomersMaster_AddCustomer_LinkAddPlusSign_xp = "//span[@ng-click='customers.addCustomer()']";
	
	public static final String CustomersMaster_AddCustomer_LinkHiddenAddPlusSign_xp = "//div[contains(@class,'ng-hide')]/span[@ui-sref='customers.add']";
	public static final String CustomersMaster_AddCustomer_InputName_id = "name";
	public static final String CustomersMaster_AddCustomer_InputTaxId_id = "taxId";
	//public static final String CustomersMaster_AddCustomer_InputAddressLine1_id = "customerAddressLine1"; //Will be used later on 
	//public static final String CustomersMaster_AddCustomer_InputAddressLine2_id = "customerAddressLine2"; //Will be used later on 
	public static final String CustomersMaster_AddCustomer_InputAddressLine1_id = "addressLine1"; //Will be used later on 
	public static final String CustomersMaster_AddCustomer_InputAddressLine2_id = "addressLine2"; //Will be used later on 
	
	public static final String CustomersMaster_AddCustomer_InputAddressLine3_id = "customerAddressLine3"; //Will be used later on 
	public static final String CustomersMaster_AddCustomer_InputCity_id = "customerCity";  //Will be used later on 
	public static final String CustomersMaster_AddCustomer_ComboState_id = "customerState"; //Will be used later on 
	public static final String CustomersMaster_AddCustomer_InputZip_id = "customerZip";  //Will be used later on 
	public static final String CustomersMaster_AddCustomer_ComboCountry_id = "customerCountry";  //Will be used later on 
	public static final String CustomersMaster_AddCustomer_ComboParentCompany_id = "parentCompany";
	public static final String CustomersMaster_AddCustomer_ComboParentCompany_xp="//select[@name='parentCompany']";
	public static final String CustomersMaster_AddCustomer_ComboCollector_id = "collector";
	public static final String CustomersMaster_AddCustomer_ComboLegalEntity_id = "legalEntity";
	public static final String CustomersMaster_AddCustomer_InputStartDate_id = "startDate";
	public static final String CustomersMaster_AddCustomer_InputCreditExpDate_id = "expDate";
	
	public static final String CustomersMaster_AddCustomer_ProductionType_id = "//select[@name='productionType']";
	
	//public static final String CustomerMaster_Customer_DepartmentAdmin_Deactivate_xp="//a[@class='btn leftButton ng-hide']//span[@translate='FORM_DEACTIVATE_BUTTON']";
	//public static final String Customers_EditNationalAccount_DepartmentAdmin_BtnDeactivate_xp="//a[@class='btn leftButton ng-hide']//span[text()='Deactivate']";
	
	//public static final String CustomersMaster_AddCustomer_BtnStartDate_xp = "//button[@type='button' and contains(@ng-click,'addCustomer.openDatePicker1')]";
	//public static final String CustomersMaster_AddCustomer_BtnStartDateDone_xp = "//button[@type='button' and text()='Done']";
	//public static final String CustomersMaster_AddCustomer_InputPhoneNumber_id = "phoneNumber";
	
	//public static final String CustomersMaster_AddCustomer_InputPhoneNumber_xp="//div[@class='input-group phone-number ng-pristine ng-untouched ng-valid ng-scope ng-isolate-scope ng-empty']//input[@ng-attr-name='{{name}}'and @ng-model='phoneNumber' ]";
	public static final String CustomersMaster_AddCustomer_InputPhoneNumber_xp="//input[@id='phoneNumber' and @name='phoneNumber']";
	public static final String CustomersMaster_AddCustomer_InputEmail_id = "emailAddress";
	public static final String CustomersMaster_AddCustomer_InputCreditLimit_id = "creditLimit";
	public static final String CustomersMaster_AddCustomer_RadioPermCustomerYes_id = "alternateRadio";
	public static final String CustomersMaster_AddCustomer_RadioPermCustomerNo_id = "mainRadio";
	public static final String CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp = "//div[@class='row' and @ng-show='alternateAddresses']/div/p/input"; //"//div[@class='row' and @ng-show='alternateAddresses']/div/input";
	public static final String CustomersMaster_AddCustomer_CheckBoxFirstGroup_xp = "//*[@id='customerGroups']/div[1]/span[1]/input";
	
	//public static final String CustomersMaster_AddCustomer_CustomerTypeCombo_xp="//select[@name='customerType']";
	public static final String CustomersMaster_AddCustomer_CustomerTypeCombo_xp="//div[@class='col-md-6']//select[@name='customerType']";
	public static final String CustomersMaster_AddCustomer_BtnAdd_xp = "//button[@type='submit' and text()='Add']";
	public static final String CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp = "//h1[text()='Add Customer']";
	//public static final String CustomersMaster_AddCustomer_BtnCancel_xp = "//a[@class='btn cancelButton']/span[text()='Cancel']";//translate='FORM_CANCEL_BUTTON'
	//public static final String CustomersMaster_AddCustomer_BtnCancel_xp = "//a[@class='btn leftButton']/span[text()='Cancel']";
	public static final String CustomersMaster_AddCustomer_BtnCancel_xp = "//a[@class='btn leftButton' and @ng-click='addCustomer.close()']//span[@translate='FORM_CANCEL_BUTTON']";
	public static final String CustomersMaster_AddCustomer_BtnClose_xp = "//div[@class='sideview-header']/i";
	public static final String CustomersMaster_EditCustomer_ResendBtn = "//button[contains(text(),'Resend')]";
	public static final String CustomersMaster_EditCustomer_ResendBtn1 = "(//button[@class='btn rightButton ng-scope'])[5]";
	//public static final String CustomersMaster_AddCustomer_MsgSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! A new customer has been created.']";
	public static final String CustomersMaster_AddCustomer_MsgSuccess_xp ="//div[contains(@class,'message') and contains(text(),'Success! A new customer')]";
	
	public static final String CustomersMaster_AddCustomer_MsgError_xp = "//div[contains(@class,'nbc-alert-danger') and @ng-show='addCustomer.displayErrorAlert()']";
	public static final String CustomersMaster_AddCustomer_MsgNameError_xp = "//p[@ng-message='required' and contains(@translate,'NAME_REQUIRED_MESSAGE')]";
	public static final String CustomersMaster_AddCustomer_MsgCustomerTypeError_xp = "//p[@ng-message='required' and contains(@translate,'CUSTOMER_TYPE_REQUIRED_MESSAGE')]";
	public static final String CustomersMaster_AddCustomer_MsgProductionTypeError_xp = "//p[@ng-message='required' and contains(@translate,'PRODUCTION_TYPE_REQUIRED_MESSAGE')]";
	public static final String CustomersMaster_AddCustomer_MsgAddressError_xp = "//p[contains(@class,'invalidInputMessage') and contains(@translate,'ADDRESS_REQUIRED_MESSAGE')]";
	
	public static final String CustomersMaster_EditCustomer_MsgSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! The customer was updated.']";
	public static final String CustomersMaster_EditCustomer_ButtonCreditLimit_xp = "//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]";
	//public static final String CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp = "//div[@class='sideview-header']//h1";
	public static final String CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp ="//div[@class='sideview-header']//h1";
	//public static final String CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp ="//h1[@class='title ng-scope']";
	public static final String CustomersMaster_EditCustomer_LabelCreatedBy_xp = "//label[@translate='FORM_TIMESTAMP_CREATED_BY' and text()='Created By:']";
	public static final String CustomersMaster_EditCustomer_LabelCreatedOn_xp = "//label[@translate='FORM_TIMESTAMP_CREATED_ON' and text()='Created On:']";
	public static final String CustomersMaster_EditCustomer_LabelCreditAvaliable_xp = "//label[@translate='CUSTOMERS.EDIT_CUSTOMER.CREDIT_AVAILABLE' and text()='Credit Available']";
	
	//public static final String CustomersMaster_EditCustomer_BtnSave_xp = "//button[@type='submit' and text()='Save']";
	public static final String CustomersMaster_EditCustomer_BtnSave_xp="//button[@class='btn rightButton ng-scope' and @ng-click='editCustomer.updateCustomer()']";
	public static final String editdeals_savebtn="(//button[contains(text(),'Save')])[4]";

	
	public static final String CustomersMaster_EditCustomer_BtnHiddenSave_xp = "//button[contains(@class,'ng-hide') and @type='submit' and text()='Save']";
	//public static final String CustomersMaster_EditCustomer_BtnDeactivate_xp = "//a[@class='btn leftButton']";
	public static final String CustomersMaster_EditCustomer_BtnDeactivate_xp = "//a[@class='btn leftButton' and contains(@ng-show,'Deactivate')]";
	public static final String CustomersMaster_EditCustomer_BtnHiddenDeactivate_xp = "//a[@class='btn leftButton ng-hide']";
	
	//public static final String CustomersMaster_ViewCustomer_ListDynamicFilters_xp = "//sp-table-filters/div[contains(@class,'filters')]/div[@class='filter-titles']/ul/li";
	public static final String CustomersMaster_ViewCustomer_ListDynamicFilters_xp = "//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-titles')]/ul/li";
	//public static final String CustomersMaster_ViewCustomer_ListDynamicFiltersContent_xp = "//sp-table-filters/div[contains(@class,'filters')]/div[@class='filter-content ng-scope']/ul/li";
	public static final String CustomersMaster_ViewCustomer_ListDynamicFiltersContent_xp = "//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//ul//li";
	public static final String Common_BtnSorting_xp = "./img[@src='images/sort-arrows.png']";
	//public static final String CustomersMaster_EditCustomer_BtnEditAddress_xp = "//div[@ng-hide='alternateAddresses' and not(contains(@class,'ng-hide'))]/div[@class='addressListView']/ul/li[@class='inline editDeleteIcons']/span";
	public static final String CustomersMaster_EditCustomer_BtnEditAddress_xp = "//div[contains(@class,'addressListView')]//ul/li[@class='inline editDeleteIcons']//span[@class='fa fa-pencil fa-lg']";
	public static final String CustomersMaster_AddCustomer_BtnAddGroup_xp = "//div[contains(@class,'groups sub-form')]/div[contains(@class,'multi-search-select')]/div[@class='add']/i";
	public static final String CustomersMaster_AddCustomer_InputGroupName_xp =  "//input[@name='groupName']";
	//public static final String CustomersMaster_AddCustomer_BtnGroupSave_xp =  "//ng-form[@name='groupForm']/div/span[@class='actions']/i[1]";
	//public static final String CustomersMaster_AddCustomer_BtnGroupSave_xp =  "//ng-form[@name='groupForm']/div[@class='actions groupActions']/i[1]";
	//public static final String CustomersMaster_AddCustomer_BtnGroupCancel_xp =  "//ng-form[@name='groupForm']/div[@class='actions groupActions']/i[2]";
	public static final String CustomersMaster_AddCustomer_BtnGroupSave_xp =  "//ng-form[@name='groupForm']/div[@class='actions groupActions']/i[2]";
	public static final String CustomersMaster_AddCustomer_BtnGroupCancel_xp =  "//ng-form[@name='groupForm']/div[@class='actions groupActions']/i[1]";
	
	//public static final String CustomersMaster_AddCustomer_LabelLegalEntity_xp =  "//sp-authorize-field[@permission-name='customerContactInfo']/div/ng-transclude/div[2]";
	public static final String CustomersMaster_AddCustomer_LabelLegalEntity_xp =  "//div[@class='legal_entity ng-binding ng-scope']";
	//div[@class='legal_entity ng-binding ng-scope']
	
	public static final String CustomersMaster_AddCustomer_BtnAddPlusLink_xp = "//div[contains(@class,'contacts sub-form')]/div[contains(@class,'multi-search-select')]/div[@class='add']/i";
	public static final String CustomersMaster_AddContact_InputFirstName_xp = "//input[@type='text' and @name='firstName']";
	public static final String CustomersMaster_AddContact_InputLastName_xp = "//input[@type='text' and @name='lastName']";
	public static final String CustomersMaster_AddContact_InputTitle_xp = "//input[@type='text' and @name='type']";
	//public static final String CustomersMaster_AddContact_InputPhone_xp = "//input[@type='tel' and @name='phone']";
	//public static final String CustomersMaster_AddContact_InputPhone_xp="//div[@class='input-group phone-number ng-isolate-scope ng-empty ng-valid']//input[@ng-attr-name='{{name}}'and @ng-model='phoneNumber' ]";
	public static final String CustomersMaster_AddContact_InputPhone_xp= "//input[@ng-model='phoneNumber' and @name='phone']";
	//public static final String CustomersMaster_AddContact_InputPhone_xp="//form[@name='contactsCtrl.contactForm']//div[@class='col-sm-6']//div[@class='input-group phone-number ng-isolate-scope ng-empty ng-valid']//input[@ng-attr-name='{{name}}' and @ng-model='phoneNumber']";
	public static final String CustomersMaster_AddContact_InputFax_xp = "//input[@type='text' and @name='fax']";
	public static final String CustomersMaster_AddContact_InputEmail_xp = "//input[@type='text' and @name='emailAddress']";
	
	public static final String CustomersMaster_AddContact_CheckboxMainContact_xp = "//input[@type='checkbox' and @id='isMainContact']";
	public static final String CustomersMaster_AddContact_CheckboxRecInvoice_xp = "//input[@type='checkbox' and @id='isInvoiceRecipient']";
	
	public static final String CustomersMaster_AddContact_BtnAdd_xp = "//a[contains(@ng-click,'saveContact')]/i";
	public static final String CustomersMaster_AddContact_BtnCancel_xp = "//a[contains(@ng-click,'cancel')]/i";
	
	
	//public static final String CustomersMaster_AddAltAddress_BtnAddPlusLink_xp = "//div[@class='alternate-address sub-form ng-isolate-scope']/div[contains(@class,'multi-search-select')]/div[@class='add']/i";
	public static final String CustomersMaster_AddAltAddress_BtnAddPlusLink_xp = "//div[contains(@class,'ng-not-empty')]/div[contains(@class,'multi-search-select')]/div[@class='add']/i";
		//public static final String CustomersMaster_AddAltAddress_ButtonAddDesc_xp = "//form[@name='altAddrCtrl.formObj']/div[@class='alt-address-desc']/div[@class='desc-header']/i";
	//public static final String CustomersMaster_AddAltAddress_ButtonAddDesc_xp ="//div[@class='addressInputsContainer ng-hide']//div[@class='alt-address-desc']//div[@class='desc-header']//i";
	
	public static final String CustomersMaster_AddAltAddress_ButtonAddDesc_xp="//ng-transclude/form/div[@class='alt-address-desc']/div[@class='desc-header']/i";
	
	//public static final String CustomersMaster_AddAltAddress_InputAddrDesc_id = "alternateAddressDescription";
	public static final String CustomersMaster_AddAltAddress_InputAddrDesc_id = "customerAlternateAddressDescription";
	public static final String CustomersMaster_AddAltAddress_InputAddnlInfo1_id = "customerAlternateAdditionalInfo1";
	public static final String CustomersMaster_AddAltAddress_InputAddnlInfo2_id = "customerAlternateAdditionalInfo2";
	public static final String CustomersMaster_AddAltAddress_InputAddrLine1_id = "customerAlternateAddressLine1";
	public static final String CustomersMaster_AddAltAddress_InputAddrLine2_id = "customerAlternateAddressLine2";
	public static final String CustomersMaster_AddAltAddress_InputAddrLine3_id = "customerAlternateAddressLine3";
	public static final String CustomersMaster_AddAltAddress_ComboCountry_id = "customerAlternateCountry";
	public static final String CustomersMaster_AddAltAddress_ComboState_id = "customerAlternateState";
	public static final String CustomersMaster_AddAltAddress_InputCity_id = "customerAlternateCity";
	public static final String CustomersMaster_AddAltAddress_InputZip_id = "customerAlternateZip";
	
	//public static final String CustomersMaster_AddAltAddress_BtnAdd_xp = "//a[contains(@ng-click,'saveSingleAddress')]/i";
	//public static final String CustomersMaster_AddAltAddress_BtnAdd_xp= "//div[@class='alternateAddressListContainer']//div[@class='alternate-address sub-form ng-isolate-scope']//div[@class='addressInputsContainer ng-hide']//div[@class='actions']//a[2]/i[@class='fa fa-check check-icon-custom-font']";
	//public static final String CustomersMaster_AddAltAddress_BtnAdd_xp="//div[@class='addressInputsContainer ng-hide']//div[@class='actions']//a[contains(@ng-click,'saveSingleAddress')]/i";
	public static final String CustomersMaster_AddAltAddress_BtnAdd_xp="//ng-transclude/form/div[@class='actions']/a[contains(@ng-click,'altAddrCtrl')]/i";
	
	public static final String CustomersMaster_AddAltAddress_BtnCancel_xp="//ng-transclude/form/div[@class='actions']/a[contains(@ng-click,'cancel()')]/i";
	//public static final String CustomersMaster_AddAltAddress_BtnCancel_xp = "//div[@class='addressInputsContainer']/form/div[@class='actions']/a[@ng-click='cancel()']/i";
	
	public static final String CustomersMaster_USPSValidationWindow_Title_xp = "//h3[@translate='FORM_ADDRESS.VALIDATION.TITLE']";
	public static final String CustomersMaster_USPSValidationWindow_LabelResponse_xp = "//div[@class='modal-body confirmBody']/div[2]/div/div/p";
	public static final String CustomersMaster_USPSValidationWindow_BtnSave_xp = "//button[@ng-click='useUserAddress()']";
	public static final String CustomersMaster_USPSValidationWindow_BtnEdit_xp = "//button[@ng-click='dismiss()']";
	
	public static final String CustomerMaster_Search_Contacts_xp="//input[@placeholder='Search Contacts...']";
	

	public static final String CustomerMaster_firstRow="//table[@class='table table-striped']/tbody/tr[1]/td[2]";
	public static final String CustomerMaster_secondRow="//table[@class='table table-striped']/tbody/tr[2]/td[2]";
	public static final String CustomerMaster_firstRow_secondCol="//table[@class='table table-striped']/tbody/tr[1]/td[2]";
	//public static final String CustomersMaster_EditCustomer_BtnEditAddress_xp = "//div[@ng-hide='alternateAddresses' and not(contains(@class,'ng-hide'))]/div[@class='addressListView']/ul/li[@class='inline editDeleteIcons']/span";
	public static final String Customers_NationalAccount_AddAltAddress_ButtonAddDesc_xp ="//div[@class='alt-address-desc']/div[@class='desc-header']/i";
	public static final String Customers_NationalAccount_AddDesc_id="addressDescription";
	public static final String Customers_NationalAccount_InputAddnlInfo1_id = "additionalInformation1";
	public static final String Customers_NationalAccount_InputAddnlInfo2_id = "additionalInformation2";
	
	public static final String CustomerMaster_Customer_CreditExpiration_id="expDate";
	
	public static final String CustomerMaster_Customer_DepartmentAdmin_Deactivate_xp="//a[@class='btn leftButton ng-hide']//span[@translate='FORM_DEACTIVATE_BUTTON']";
	public static final String Customers_EditNationalAccount_DepartmentAdmin_BtnDeactivate_xp="//a[@class='btn leftButton ng-hide']//span[text()='Deactivate']";
	public static final String Customers_Edit_Copy_xp="//span[@translate='FORM_COPY_BUTTON']";
	//public static final String CustomersMaster_EditCustomer_InputPhoneNumber_DepartmentAdmin_xp="//input[@class='form-control ng-pristine ng-untouched ng-valid ng-isolate-scope ng-valid-phone-number ng-empty ng-valid-required' and @name='phoneNumber' ]";
	
	public static final String CustomersMaster_EditCustomer_InputPhoneNumber_DepartmentAdmin_id="phoneNumber";
	public static final String CustomersMaster_Address_ButtonAddDesc_xp="//div[@id='customerAddressInputsContainer']//div[@class='desc-header']/i";
	public static final String CustomersMaster_Address_InputAddrDesc_id = "customerAddressDescription";
	public static final String CustomersMaster_Address_InputAddnlInfo1_id = "customerAdditionalInformation1";
	public static final String CustomersMaster_Address_InputAddnlInfo2_id = "customerAdditionalInformation2";
	
	//public static final String CustomersMaster_EditCustomer_BtnEditMainAddress_xp="//div[@class='addressListView ng-scope']/ul/li[@class='inline editDeleteIcons']/span";
	public static final String CustomersMaster_EditCustomer_BtnEditMainAddress_xp="//li[@class='inline editDeleteIcons']//span";
	
	//public static final String CustomersMaster_EditCustomer_BtnEditMainAddress_xp="//ng-transclude//ng-form//li[@class='inline editDeleteIcons']/span";
	//public static final String CustomersMaster_EditCustomer_BtnEditMainAddress_xp="//ng-transclude//div[@class='addressListView ng-scope']//span";
	public static final String CustomerMaster_Customer_FinanceAdmin_Deactivate_xp="//a[@class='btn leftButton' ]//span[@translate='FORM_DEACTIVATE_BUTTON']";
	
	public static final String CustomerMaster_EXit_Confirm_page_xp="//button[@class='btn btn-small confirm ng-scope']";
	
	//public static final String CustomerMaster_EditContact_Pencil="//div[@class='contacts sub-form ng-scope ng-isolate-scope']//span[@class='fa fa-pencil fa-lg ng-scope']";
	public static final String CustomerMaster_EditContact_Pencil="//div[@class='col-md-12']//div[@class='contacts sub-form ng-scope ng-isolate-scope']//span[@class='fa fa-pencil fa-lg ng-scope']";
	//public static final String CustomerMaster_EditAltAddress_Pencil="//div[@class='alternate-address sub-form ng-isolate-scope']//div[@class='options pull-right']/a[2]/span";
	
	public static final String CustomerMaster_EditAltAddress_Pencil="//div[@name='altAddress']//div[@class='options pull-right']/a[2]/span";
	//public static final String Customers_EditCustomer_MsgDeactivateConfirmation_xp = "//h2[contains(@class,'confirmMessage') and contains(text(),'Are you sure you want to deactivate')]";
	public static final String Customers_EditCustomer_MsgDeactivateConfirmation_xp = "//div[contains(@class,'message confirmBody') and contains(text(),'Are you sure you want to deactivate')]";
	
	public static final String Customers_EditCustomer_MsgDeactivateSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! The customer was deactivated.']";
	
	public static final String Customers_EditCustomer_MsgReactivateConfirmation_xp = "//div[contains(@class,'message confirmBody ng-scope') and contains(text(),'Are you sure you want to activate')]";
	public static final String Customers_EditCustomer_MsgReactivateSuccess_xp = "//div[@ng-bind-html='message' and text()='Success! The customer was reactivated.']";
	public static final String CustomersMaster_EditCustomer_BtnActivate_xp = "//a[contains(@class,'btn')]//span[text()='Activate']";
	public static final String CustomersMaster_EditCustomer_BtnActivate_Yes_xp ="//div[@class='message buttonContainer']//button[@class='btn btn-small confirm ng-scope']";
	public static final String Customers_InterceptMenu_ViewEdit_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View/ Edit']";
	public static final String Customers_InterceptMenu_Deactivate_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Deactivate']";
	public static final String Customers_InterceptMenu_Copy_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='Copy']";
	
	public static final String Customers_EditCustomer_MsgDeactivateConfirmation_Yes_xp="//div[@class='message buttonContainer']//button[@class='btn btn-small confirm ng-scope']";
	
	//public static final String Customers_Edit_Deal_Customer_Cannot_DeactivateConfirmation_xp = "//div[contains(@class,'message confirmBody') and contains(text(),'Customer ')]";
	//public static final String Customers_Edit_Deal_Customer_Cannot_DeactivateConfirmation_btn_Ok_xp="//button[@translate='FORM_OK_BUTTON']";
	public static final String Customers_Deal_Customer_Cannot_Be_Deactivated_xp ="//div[contains(@class,'cannotDeactivate') and text()='Customer cannot be deactivated']";
	public static final String Customers_Deal_Customer_ToCloseDeals_Display_Text_xp="//p[contains(@class,'closeFollowingDeals') and contains(text(),'The following deals must be closed before deactivating')]";
	public static final String Customers_Deal_Customer_Deals_Display_xp="//ul[@class='openDealList']//li";
	public static final String Customers_Deal_Customer_View_Open_Deals_Btn_xp="//button[contains(@class,'btn btn-small confirm ng-scope') and text()='View Open Deals']";
	public static final String Customers_Deal_Customer_View_Close_Btn_xp="//button[contains(@class,'btn btn-small') and text()='Cancel']";
	public static final String Customers_Deal_Customer_View_Title_Btn_xp="//h3[@class='confirmTitle ng-scope']";
	public static final String Customers_CreditApprovalNotification_View_Logo_xp="//div[@class='credit-approval-notification ng-scope']//img[@src='/assets/images/universal.png']";
	public static final String Customers_CreditApprovalNotification_View_table_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr//td//span";//tr[2]//td//span";
	public static final String Customers_CreditApprovalNotification_View_Btn_xp="//div[@class='credit-notification ng-scope']/a[contains(@class,'btn btn-default') and text()='View']";
	public static final String Customers_CreditApprovalNotification_Title_xp="//h2[@translate='CREDIT_APPROVAL.TITLE' and text()='Credit Approval Notification']";
	public static final String Customers_CreditApprovalNotification_Text_xp="//div[@class='credit-approval-notification ng-scope']//strong[@translate='CREDIT_APPROVAL.DESCRIPTION' and text()='Please be advised of the following new credit information']";
	public static final String Customers_CreditApprovalNotification_Columns_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td//strong";//strong
	public static final String Customers_CreditApprovalNotification_Print_xp="//button[contains(@class,'btn')and text()='Print']";
	public static final String Customers_CreditApprovalNotification_CreateDeal_xp="//button[contains(@class,'btn')and text()='Create Deal']";
	public static final String Customers_CreditApprovalNotification_Deal_customer_xp="(//div[@name='customer']//div[@class='item ng-scope']//span)[1]";
	public static final String Customers_CreditApprovalNotification_customer_MainPhone_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[1]/p[1]/strong";
	public static final String Customers_CreditApprovalNotification_customer_Email_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[1]/p[2]/strong";
	public static final String Customers_CreditApprovalNotification_Accounting_Contact_1_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[1]/p[3]/strong";
	public static final String Customers_CreditApprovalNotification_UPM_Contact_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[1]/p[3]/strong";
	public static final String Customers_CreditApprovalNotification_UPM_Contact_Name_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[1]/p[3]/span";
	public static final String Customers_CreditApprovalNotification_customer_Number_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[1]/strong";
	public static final String Customers_CreditApprovalNotification_customer_Name_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[2]/strong";
	public static final String Customers_CreditApprovalNotification_customer_Address_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[3]/strong";
	public static final String Customers_CreditApprovalNotification_production_Type_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[4]/strong";
	public static final String Customers_CreditApprovalNotification_creditlimit_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[5]/strong";
	public static final String Customers_CreditApprovalNotification_startdate_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[6]/strong";
	public static final String Customers_CreditApprovalNotification_expirationdate_xp="//div[@class='credit-approval-notification ng-scope']//table//tbody//tr[2]//td[2]/p[7]/strong";
	public static final String Customers_ViewCustomer_ComboDeactivate_xp_old="//ul[@class='dropdown-menu bulkActionsList']/li[2]";
	public static final String Customers_ViewCustomer_ComboDeactivate_xp="//ul[@class='dropdown-menu bulkActionsList']/li";
	//public static final String Customers_CustomerType_LegalEntity_xp="//div[contains(@class,'legal_entity')]//span";
	public static final String Customers_CustomerType_LegalEntity_xp="///div[contains(@class,'legal_entity ng-binding ng-scope')]";
	public static final String Customers_Edit_Customer_Associated_Item_Btn_xp="//ng-transclude/form//sp-associated-item//i";
	public static final String Customers_Search_Alt_Address_First_Row_xp="//div[@class='alternateAddressListContainer']//div[@class='search']//ul//li/a//span//strong";
	public static final String Customers_AltAddress_SearchBar_xp="//div[@class='alternateAddressListContainer']//div[@class='search']//input";
	public static final String Customers_AltAddress_AssociatedItems_list_xp="//div[@class='address-desc-header ng-scope in collapse']//ul//li";
	public static final String Customers_AltAddress_AssociatedItems_DealNumber_xp="//div[@class='address-desc-header ng-scope in collapse']//ul//li[3]//span[3]";
	public static final String Customers_AltAddress_AssociatedItems_FirstCustomer_xp="//div[@class='address-desc-header ng-scope in collapse']//ul//li[1]//span[1]";
	public static final String CustomersMaster_AddAltAddress_ComboSelectedCountry_xp="//select[@id='customerAlternateCountry']//option[@selected='selected']";
	public static final String CustomersMaster_AddAltAddress_ComboSelectedState_xp="//select[@id='customerAlternateState']//option[@selected='selected']";
	public static final String Queuelogging_DealNumber_xp="//sp-table-new/table/tbody/tr/td[5]";
	public static final String CustomersMaster_CreditToggle_ON_xp="//div[@class='switch switch-blue']//label[contains(@class,'switch-label switch-label-off') and text()='ON']";
	public static final String CustomersMaster_CreditToggle_OFF_xp="//div[@class='switch switch-blue']//label[contains(@class,'switch-label switch-label-on') and text()='OFF']";
	
	public static final String Customers_Name_xp="//sp-table-new/table/tbody/tr/td[3]";
	public static final String Customers_CostObject_id="costObject";
	public static final String Customers_AccountNumber_id="accountNumber";
	///////////////////////////////////////Deal page Objects////////////////////////////////////////////
	//public static final String Common_ViewModules_LinkOpen_Xp= "//span[@translate='TABLE_FILTERS.DEALSTATUSCODEID.13005']";
	//public static final String Common_ViewModules_LinkClosed_Xp= "//span[@translate='TABLE_FILTERS.DEALSTATUSCODEID.13001']";
	public static final String Deals_AddDeal_InputDealTitle_id="dealTitle";
	
	//public static final String Deals_AddDeal_InputDealType_id="//select[@class='input-group ng-pristine ng-isolate-scope ng-empty ng-invalid ng-invalid-required ng-touched']";
	//public static final String Deals_AddDeal_InputDealType_id="//div[@class='col-md-6 ng-scope']//select[@ng-attr-id='{{id}}' and @model='ctrl.dealObj.dealTypeCodeId']";
	//public static final String Deals_AddDeal_InputDealType_id="//div[@class='col-md-6 ng-scope']//select[@ng-attr-id='{{lookupId}}' and @model='dealFormCtrl.dealObj.dealTypeCodeId']";
	//public static final String Deals_AddDeal_InputDealType_id="dealType";
	public static final String Deals_AddDeal_InputDealType_id="//select[@id='dealType' and @name='dealType']";
	public static final String Deals_AddDeal_CustomerCodexpath="//select[@id='customerCode']";
	public static final String Deals_AddDeal_LabelAddDealTitle_xp="//h1[@class='title ng-scope']";
	public static final String Deals_AddDeal_ComboDealMaker_id="dealmaker";
	//public static final String Deals_AddDeal_UseCostCenter_id="useCostCenter";
	public static final String Deals_AddDeal_UseCostCenter_xp="//input[@placeholder='Select a cost center...']";
	                                                         
	public static final String Deals_AddDeal_UseCostCenter_listxp="//ng-form[@name='ctrl.dealForm']//div[@class='ui-select-container ui-select-multiple ui-select-bootstrap dropdown form-control ng-pristine ng-untouched ng-valid ng-scope ng-empty open']//ul//li";
	public static final String Deals_AddDeal_AddProject_ProjectName_xp="//input[@name='projectName']";
	//public static final String Deals_AddDeal_AddProject_ProjectCluster_xp="//input[@name='projectCluster']";
	public static final String Deals_AddDeal_AddProject_ProjectCluster_xp="//div[@class='col-sm-12 form-group']//input[@name='projectCluster']";	
	//public static final String Deals_AddDeal_AddProject_Project_Type_xp="//div[@class='col-sm-6 form-group']/select[@ng-attr-id='{{id}}']";
	public static final String Deals_AddDeal_AddProject_Project_Type_xp="//form[@name='projectsCtrl.projectForm']//select[@ng-attr-id='{{lookupId}}' and @ng-model='model']";
	//public static final String Deals_AddDeal_AddProject_Project_Type_xp="//div[@class='col-sm-6 form-group']//select[@model='projectObj.projectTypeCodeId']";
	//public static final String Deals_AddDeal_AddProject_InternalProject_xp="//input[@class='ng-pristine ng-valid ng-empty ng-touched' and @name='projectName']";
	public static final String Deals_AddDeal_AddProject_InternalProject_xp="//input[@ng-model='projectObj.isInternal']";
	
	
	public static final String Deals_AddDeal_SearchDeals="//input[@type='text' and @name='search'][1]";
	public static final String Deals_AddDeal_SearchCustomers_xp="//input[@placeholder='Search Customers...']";
	public static final String Deals_AddDeal_SearchAddresses_xp="//input[@placeholder='Search Addresses...']";
	public static final String Deals_AddDeal_SearchProjects_xp="//input[@placeholder='Search Projects...']";
	public static final String Deals_AddDeal_SearchContacts_xp="//input[@placeholder='Search Contacts...']";
	//public static final String Deals_AddDeal_AddCustomer_xp="//span[text()='Add New Customer']/../i[@class='fa fa-plus-circle']";
	public static final String Deals_AddDeal_AddCustomer_xp="//span[text()='Add New Customer']/../i[@class='fa fa-plus-circle cursor-pointer-on-hover']";
	public static final String Deals_AddDeal_AddNewAddresses_xp="//span[text()='Add New Address']/../i[@class='fa fa-plus-circle']";
	public static final String Deals_AddDeal_AddNewProject_xp="//span[text()='Add New Project']/../i[@class='fa fa-plus-circle cursor-pointer-on-hover']";
	//public static final String Deals_AddDeal_AddNewContact_xp="//span[text()='Add New Contact']/../i[@class='fa fa-plus-circle']";
	public static final String Deals_AddDeal_AddNewContact_xp="//span[text()='Add New Contact']/../i[@class='fa fa-plus-circle cursor-pointer-on-hover']";
	public static final String Deals_AddDeal_ProjectListSearch_xp= "//ul[@class='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']/a";
	public static final String Deals_AddDeal_ContactListSearch_xp= "//ul[@class='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']/a";
	public static final String Deals_AddDeal_AddNewProject_save_xp="//form[@name='projectsCtrl.projectForm']/div[4]/a[2]/i";
	public static final String Deals_AddDeal_AddNewProject_cancel_xp="//form[@name='projectsCtrl.projectForm']/div[4]/a[1]/i";
	public static final String Deals_AddDeal_AddNewContact_save_xp="//form[@name='contactsCtrl.contactForm']/div[4]/a[2]/i";
	//public static final String Deals_AddDeal_AddNewContact_cancel_xp="//form[@name='contactsCtrl.contactForm']/div[4]/a[1]/i";
	public static final String Deals_AddDeal_AddNewContact_cancel_xp="//form[@name='contactsCtrl.contactForm']/div[4]/a[1]/i";
	//public static final String Deals_AddDeal_AddNewContact_cancel_xp="//form[@name='contactsCtrl.contactForm']//a[@class='cancelAction']/i";
	public static final String Deals_AddDeal_AddNewContact_FirstName_xp="//input[@name='firstName']";
	public static final String Deals_AddDeal_AddNewContact_LastName_xp="//input[@name='lastName']";
	public static final String Deals_AddDeal_AddNewContact_Title_xp="//input[@name='type']";
	public static final String Deals_AddDeal_AddNewContact_Phone_xp="//input[@name='phone']";
	public static final String Deals_AddDeal_AddNewContact_email_xp="//input[@name='emailAddress' and @ng-model='selectedContact.emailAddress']";
	
	//public static final String Deals_AddDeal_PhoneNumber_xp="//input[@name='phone']";
	public static final String Deals_AddDeal_PhoneNumber_xp="//input[@ng-attr-name='{{name}}'and @ng-model='phoneNumber' ]";
	public static final String Deals_AddDeal_FaxNumber_xp="//input[@name='fax']";
	public static final String Deals_AddDeal_EmailAddress_xp="//input[@name='emailAddress']";
	public static final String Deals_AddDeal_MainContact_id="isMainContact";
	public static final String Deals_AddDeal_ReceivesInvoice_id="isInvoiceRecipient";
	
	public static final String Deals_AddDeal_InsuranceExpiration_id="insuranceExp";
	//public static final String Deals_AddDeal_ComboCostCenter_xp="//div[@class='selectedCenters']";
	public static final String Deals_AddDeal_CostCenter_xp="//input[@placeholder='Select a cost center...']";
	public static final String Deals_AddDeal_CostCenterValue_xp="//span[@class='ui-select-choices-row-inner']//span[2]";
	//public static final String Deals_AddDeal_ComboCostCenter_xp="//div[@id='costCenters']//li[2]";
	
	public static final String Deals_AddDeal_CheckBoxMultipleDepartment_id="multiDept";
	public static final String Deals_AddDeal_CheckBoxInternal_id="internal";
	public static final String Deals_AddDeal_RadioCustomerAddress_id="customerMainAddress";
	//public static final String Deals_AddDeal_RadioCustomerAddress_xp="//div[@class='col-md-12 radioContainer']//input[@ng-model='ctrl.dealObj.useCustomerAddress' and@value='true']";
	
	public static final String Deals_AddDeal_RadioCustomerAlternateAddress_id="alternateAddress";
	public static final String Deals_AddDeal_BtnAlternateAddress_id="altenateAddress";
	public static final String Deals_AddDeal_InputAddressLine1_id="alternateAddressLine1";
	public static final String Deals_AddDeal_InputAddressLine2_id="alternateAddressLine2";
	public static final String Deals_AddDeal_InputAddressLine3_id="alternateAddressLine3";
	public static final String Deals_AddDeal_ComboCountry_xp="alternateCountry";
	public static final String Deals_AddDeal_ComboState_xp="alternateState";
	public static final String Deals_AddDeal_InputCity_xp="alternateCity";
	public static final String Deals_AddDeal_InputZipId_id="alternateZip";
	public static final String Deals_AddDeal_InputPoNumber_id="poNumber";
	public static final String Deals_AddDeal_ComboCustomerCode_id="customerCode";
	public static final String Deals_AddDealBtnInsuranceCertifiedYes_id="insuranceCertYes";
	public static final String Deals_AddDealBtnInsuranceCertifiedNo_id="insuranceCertNo";
	public static final String Deals_AddDeal_InsuranceExpiredDate_id="insuranceExpirationDate";
	public static final String Deals_AddDealBtnOnLotYes_id="onLotYes";
	public static final String Deals_AddDealBtnOnLotNo_id="onLotNo";
	public static final String Deals_AddDealBtnRevenueShareYes_id="revenueYes";
	public static final String Deals_AddDealBtnRevenueShareNo_id="revenueNo";
	public static final String Deals_AddDealBtnTaxYes_id="taxYes";
	public static final String Deals_AddDealBtnTaxNo_id="taxNo";
	public static final String Deals_AddDealBtnCostPlusYes_id="costPlusYes";
	public static final String Deals_AddDealBtnCostPlusNo_id="costPlusNo";
	public static final String Deals_AddDealBtnCostcurrency_id="select[id='currency']";
	//public static final String Deals_AddDealComboInvoiceFormat_id="invoiceFormat";
	//public static final String Deals_AddDealComboInvoiceFormat_xp="//select[@class='input-group ng-isolate-scope ng-touched ng-not-empty ng-dirty ng-valid-parse ng-valid ng-valid-required']";	
	//public static final String Deals_AddDealComboInvoiceFormat_xp="//div[@class='col-md-6 ng-scope']//select[@ng-attr-id='{{id}}' and @model='ctrl.dealObj.invoiceFormatCodeId']";
	//public static final String Deals_AddDealComboBillingSchedule_id="billingSchedule";
	//public static final String Deals_AddDealComboInvoiceFormat_xp="//select[@name='invoiceFormat' and @ng-model='dealFormCtrl.dealObj.invoiceFormatCodeId']";
	public static final String Deals_AddDealComboInvoiceFormat_xp= "//div[@class='col-md-6 ng-scope']//select[@name='invoiceFormat' and @ng-model='dealFormCtrl.dealObj.invoiceFormatCodeId']";
	//public static final String Deals_AddDealComboBillingSchedule_xp="//div[@class='col-md-6 ng-scope']//select[@ng-attr-id='{{lookupId}}' and @model='dealFormCtrl.dealObj.billingScheduleCodeId']";
	public static final String Deals_AddDealComboBillingSchedule_xp="//div[@class='col-md-6 ng-scope']//select[@name='billingSchedule']";
	
	public static final String Deals_AddDealComboInvoiceFormat_id="invoiceFormat";
	public static final String Deals_AddDealComboBillingSchedule_id="billingSchedule";
	
	public static final String Deals_AddDealInputSalesForceId_id="salesforce";
	
	public static final String Deals_AddDealBtnStatusOpen_id="statusOpen";
	public static final String Deals_AddDealBtnStatusClosed_id="statusClosed";
	public static final String Deals_AddDealBtnStatusOpen_xp="//select[@name='dealStatus']//option[@label='Open']";
	public static final	String Deals_AddDealBtnStatusClosed_xp="//select[@name='dealStatus']//option[@label='Closed']";	
	public static final	String Deals_AddDealBtnStatusDepartmentClosed_xp="//select[@name='dealStatus']//option[@label='Department Closed']";	
	public static final String Deals_AddDealBtnStatus_id="dealStatus";
	//public static final String Deals_AddDealBtnCreditApprovedStudio_id="studioRadio";
	public static final String Deals_AddDealBtnDepartment_CreditApproved_id="departmentCredit";
	public static final String Deals_AddDealComboCreditApprover_xp="//div[@class='col-md-6 ng-scope']//select[ @ng-attr-id='{{lookupId}}' and @model='ctrl.dealObj.creditApprovedUserId']";
	public static final String Deals_AddDealInputCreditLimit_id="creditLimit";
	//public static final String Deals_AddDeal_CustomerListSearch_xp="//ul[@class='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']/a";
	public static final String Deals_AddDeal_CustomerListSearch_xp="//ul[@class='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']/a/span[contains(@ng-bind-html,'match.label.main')]";
	public static final String Deals_AddDeal_AddressListSearch_xp="//ul[@class='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']/a/span[contains(@ng-bind-html,'match.label.main')]";
	public static final String Deals_ExistAddressListSearch_xp="//div[@name='altAddress']//ul//li[1]//a//span//strong";
	//public static final String Deals_AddDeal_BtnSave_xp = "//button[@class='btn rightButton ng-scope']";
	public static final String Deals_AddDeal_BtnSave_xp= "//div[@class='footerButtonContainer']//button[@class='btn rightButton ng-scope'  and @translate='DEALS.DEAL_FORM.SUBMIT_BUTTON']";
	public static final String Deals_AddDeal_BtnCancel_xp="//a[@class='btn leftButton']/span[text()='Cancel']";
	public static final String Deals_EditDeal_BtnCopy_xp="//span[@translate='FORM_COPY_BUTTON']";
	
	public static final String Deals_AddDeal_MsgSuccess_xp="//div[@ng-bind-html='message' and contains(text(),'Success!')]";
	
	public static final String Deals_ViewDeal_BtnBulkActions_xp="//button[@type='button' and contains(text(),'Bulk Actions')]";
	public static final String Deals_ViewDeal_ComboDeactivateExport_xp="//ul[@class='dropdown-menu bulkActionsList']/li[1]";
	
	public static final String Deals_AddDeal_LinkAddPlusSign_xp ="//span[@ui-sref-opts='{notify: false}']";
	
	public static final String Deals_AddDeal_BtnClose_xp= "//i[@class='fa fa-times fa-2x fa-inverse']";
	public static final String Deals_AddDeal_MsgDealTitleError_xp="//p[contains(@class,'invalidInputMessage ng-scope') and text()='Title is a required field']";
	//public static final String Deals_EditDeal_LabelEditDealTitle_xp="//h1[@class='title ng-scope' and @translate='DEALS.EDIT_DEAL.TITLE']";
	//public static final String Deals_EditDeal_LabelEditDealTitle_xp ="//h1[@class='title ng-scope']";
	public static final String Deals_EditDeal_LabelEditDealTitle_xp="//div[@class='sideview-header']//h1[@class='title ng-scope']";
	public static final String Deals_EditDeal_MsgSuccess_xp="";
	
	public static final String Deals_AddDeal_MsgDealTypeError_xp= "//p[contains(@class,'invalidInputMessage ng-scope') and text()='Deal Type is a required field']";
	public static final String Deals_EditDeal_LabelCreatedBy_xp = "//label[@translate='FORM_TIMESTAMP_CREATED_BY' and text()='Created By:']";
	public static final String Deals_EditDeal_LabelCreatedOn_xp = "//label[@translate='FORM_TIMESTAMP_CREATED_ON' and text()='Created On:']";
	//public static final String Deals_EditDeal_BtnSave_xp="//button[contains(@class,'btn') and contains(text(),'Save')]";
	public static final String Deals_EditDeal_BtnSave_xp="//div[@class='footerButtonContainer']//button[@class='btn rightButton ng-scope'  and @translate='DEALS.DEAL_FORM.SUBMIT_BUTTON']";
	public static final String Deals_EditDeal_BtnDeactivate_xp="//span[contains(@class,'ng-scope') and contains(text(),'Deactivate')]";
	
	public static final String Deals_DealType_Filter_BtnClose_xp="(//span[@class='fa fa-close'])[1]";
	public static final String Deals_Project_Filter_BtnClose_xp="(//span[@class='fa fa-close'])[2]";
	public static final String Deals_Customer_Filter_BtnClose_xp="(//span[@class='fa fa-close'])[3]";
	public static final String Deals_CostCenter_Filter_BtnClose_xp="(//span[@class='fa fa-close'])[4]";
	
	public static final String Deals_AddDealBtnInsuranceCertified_id="insuranceCertificate";
	
	public static final String Deals_EditDeal_EditContact_Pencil="(//div[@id='contact']//span[@class='fa fa-pencil fa-lg ng-scope'])[1]";
	public static final String Deals_EditDeal_EditContact_Pencil_2="(//div[@name='contact']//span[@class='fa fa-pencil fa-lg ng-scope'])[2]";
	public static final String Deals_EditDeal_EditContact_Pencil_4="(//div[@name='contact']//span[@class='fa fa-pencil fa-lg ng-scope'])[4]";
	public static final String Deals_EditDeal_EditContact_Pencil_3="(//div[@name='contact']//span[@class='fa fa-pencil fa-lg ng-scope'])[3]";
	public static final String Deals_EditDeal_DeleteContact="(//div[@id='contact']//span[@class='fa fa-trash fa-lg'])[2]";
	
	public static final String Deals_DealNumber_xp="//input[@name='dealNumber']";
	public static final String Deals_Add_Address_Save_xp="//div[@class='addressInputsContainer']/form/div[@class='actions']/a[contains(@ng-click,'altAddrCtrl')]/i";
	public static final String Deals_Add_Address_Close_xp="//div[@class='addressInputsContainer']/form/div[@class='actions']/a[contains(@class,'cancelAction')]/i";
	public static final String Deals_AddAltAddress_ButtonAddDesc_xp="//div/form/div[@class='alt-address-desc']/div[@class='desc-header']/i";
	public static final String Deals_AddAltAddress_InputAddrDesc_id="alternateAddressDescription";
	public static final String Deals_Address_InputAddnlInfo1_id = "alternateAdditionalInformation1";
	public static final String Deals_Address_InputAddnlInfo2_id = "alternateAdditionalInformation2";
	
	//public static final String Deals_EditDeal_EditAltAddress_Pencil_xp="//div[@class='alternate-address sub-form ng-isolate-scope']//span[@class='fa fa-pencil fa-lg ng-scope']";
	public static final String Deals_EditDeal_EditAltAddress_Pencil_xp="//div[@name='altAddress']//div[@class='options pull-right']//a[2]//span[@class='fa fa-pencil fa-lg ng-scope']";
	public static final String Deals_EditDeal_EditAltAddress_Delete_xp="//div[@name='altAddress']//div[@class='options pull-right']//a[1]//span[@class='fa fa-trash fa-lg']";
	public static final String Deals_EditDeal_EdditProject_Pencil_xp="//div[@id='project']//span[@class='fa fa-pencil fa-lg ng-scope']";
	public static final String Deals_EditDeal_EdditProject_Delete_xp="//div[@name='project']//div[@class='options pull-right']//a[1]//span";
	public static final String Deals_AddDeal_AddProject_ActiveCheck_xp="//input[@ng-model='projectObj.isActive']";
	
	public static final String Deals_Add_Address_Cancel_xp="//div[@class='addressInputsContainer']/form/div[@class='actions']/a[contains(@ng-click,'cancel()')]/i";
	public static final String Deals_Edit_Customer_Pencil="//div[@name='customer']//div[@class='options pull-right']//a[2]/span";
	public static final String Deals_Edit_Customer_Delete_icon_xp="//div[@name='customer']//div[@class='options pull-right']//a[1]/span";
	
	public static final String Deals_DealCustomer_CustomerType_id="customerType";
	public static final String Deals_Edit_DealCustomer_MainInputAddressLine1_id="addressLine1";
	public static final String Deals_Edit_DealCustomer_MainInputAddressLine2_id="addressLine2";
	public static final String Deals_Edit_DealCustomer_MainInputAddressLine3_id="addressLine3";
	public static final String Deals_Edit_DealCustomer_ComboCountry_id="country";
	public static final String Deals_Edit_DealCustomer_ComboState_id="state";
	public static final String Deals_Edit_DealCustomer_InputCity_id="city";
	public static final String Deals_Edit_DealCustomer_InputZipId_id="zip";
	public static final String Deal_Edit_DealCustomer_ButtonAddDesc_xp="//div[@id='addressInputsContainer']//div[@class='desc-header']/i";
	public static final String Deals_Edit_DealCustomer_InputAddrDesc_id = "addressDescription";
	public static final String Deals_Edit_DealCustomer_InputAddnlInfo1_id = "additionalInformation1";
	public static final String Deals_Edit_DealCustomer_InputAddnlInfo2_id = "additionalInformation2";
	public static final String Deals_Edit_AltAddressCustomer_ButtonAddDesc_xp="//div[@class='col-md-12']//div[@class='addressInputsContainer']//div[@class='desc-header']/i";
	public static final String Deals_Edit_AltAddressCustomer_BtnAddPlusLink_xp="//div[@class='col-md-12']//div[@class='alternate-address sub-form ng-isolate-scope']//div[@class='add']/i";
	public static final String Deals_Edit_Customer_Contact_BtnCancel_xp="//form[@name='contactsCtrl.contactForm']//a[contains(@ng-click,'cancel')]/i";
	public static final String Deals_InterceptMenu_ViewEdit_Link_xp="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View/ Edit']";
	
	//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//i
	public static final String Deals_AddDeal_Search_Contact_ToolTip_Icon_xp="//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//i";
	public static final String Deals_AddDeal_Search_Contact_Cancel_Btn_xp="//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//div[3]//a[1]/span";
	public static final String Deals_AddDeal_Search_Contact_Save_Btn_xp="//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//div[3]//button";
	public static final String Deals_AddDeal_Search_Contact_FirstName_xp="//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//h4";
	public static final String Deals_AddDeal_MainContact_CheckBox_xp="//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//input[@type='checkbox' and @id='mainOption']";
	public static final String Deals_AddDeal_ReceiveInvoice_CheckBox_xp="//div[@class='contacts sub-form ng-isolate-scope']//div[@class='dialog']//input[@type='checkbox' and @id='invoiceOption']";
	public static final String Deals_EditDeal_ContactList_First_Row_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@ng-repeat='item in items'])[1]";
	public static final String Deals_AddDeal_Contact_ReceiveInvoice_Msg_xp="//div[@class='tooltip-inner ng-binding' and contains(text(),'There can be no more than 3 invoice recieving contacts in ORBIT. This restriction is temporary and will be removed once Sphere manages invoicing.')]";
	public static final String Deals_EditDeal_ExistContact_First_Row_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='item ng-scope']//span[contains(@class,'ng-binding')])[1]";
	
	public static final String Deals_AddDeal_MultiDepartment_text_xp="(//ng-form[@name='dealFormCtrl.dealForm']//div[@class='pull-right']//span)[2]";
	public static final String Deals_AddDeal_Customer_Adress_List_xp="//div[@class='addressListView ng-scope']//ul//li";
	public static final String Deals_Add_Deal_Status_Open_xp="//select[@name='dealStatus']//option[@selected='selected']";
	public static final String Deals_Add_Deal_Invoice_Format_Selected_Value_xp="//select[@name='invoiceFormat']//option[text()='DET - Detailed Invoice']";
	public static final String Deals_Add_Deal_Biling_Request_Selected_Value_xp="//select[@name='billingSchedule']//option[@selected='selected']";//R-On Request
	public static final String Deals_Add_Deal_Status_id="dealStatus";
	public static final String Deals_AddDeal_SelectedCountry_xp="//select[@id='alternateCountry']//option[@selected='selected']";
	public static final String Deals_AddDeal_SelectedState_xp="//select[@id='alternateState']//option[@selected='selected']";
	public static final String Deals_AddDeal_SelectedProject_xp="//form[@name='projectsCtrl.projectForm']//select[@ng-attr-id='{{lookupId}}' and @ng-model='model']//option[@selected='selected']";
	public static final String Deals_AddDeal_CostCenter_Filter_List_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[4]//li";
	public static final String Deals_AddDeal_CostCenter_Filter_List_xp1="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[5]//li";
	
	public static final String Deals_AddDeal_Customer_Filter_List_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[3]//li";
	public static final String Deals_AddDeal_Project_Filter_List_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[2]//li";
	public static final String Deals_AddDeal_DealType_Filter_List_xp="(//sp-table-filters/div[contains(@class,'filters')]/div[contains(@class,'filter-content ng-scope')]//div[@class='filter-items ng-scope'])[1]//li";
	public static final String Deals_AddDeal_CostCenter_Filter_Title_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[5]//span";
	public static final String Deals_AddDeal_CostCenter_Filter_Title_xp1="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[6]//span";

	//public static final String Deals_AddDeal_Customer_Filter_Title_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[@class='filter-titles']//ul//li)[4]//span";
	public static final String Deals_AddDeal_Customer_Filter_Title_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[4]//span";
	public static final String Deals_AddDeal_Project_Filter_Title_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[3]//span";
	public static final String Deals_AddDeal_DealType_Filter_Title_xp="(//sp-table-filters/div[contains(@class,'filters')]//div[contains(@class,'filter-titles')]//ul//li)[2]//span";
	
	
	public static final String Deals_AddDeal_MainIdentifier_1_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[1]//span[2]";
	public static final String Deals_AddDeal_MainIdentifier_2_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[2]//span[2]";
	public static final String Deals_AddDeal_ReceiveInvoiceIdentifier_xp_1="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[1]//span[1]";
	public static final String Deals_AddDeal_ReceiveInvoiceIdentifier_xp_2="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[2]//span[1]";
	public static final String Deals_AddDeal_DeleteIcon_1_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[1]//a[1]//span";
	public static final String Deals_AddDeal_ReceiveInvoiceIdentifier_xp_4="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[4]//span[1]";
	public static final String Deals_AddDeal_ReceiveInvoiceIdentifier_xp_3="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[3]//span[1]";
	public static final String Deals_AddDeal_DeleteIcon_4_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[4]//a[1]//span";
	public static final String Deals_AddDeal_DeleteIcon_3_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[3]//a[1]//span";
	public static final String Deals_AddDeal_DeleteIcon_2_xp="(//div[@class='contacts sub-form ng-isolate-scope']//div[@class='options pull-right'])[2]//a[1]//span";
	public static final String Deals_AddDeal_GreenColor_xp="//sp-table-new/table/tbody/tr[1]/td[2]/sp-status-color/i";
	public static final String Deals_AddDeal_Customer_Code_id="customerCode";
	public static final String Deals_AddDeal_exportActions_id="exportActions";
	public static final String Deals_AddDeal_sExportWarningMsg_xp="//div[@ng-bind-html='message' and contains(text(),'You cannot export more than 2000 records.')]";
	public static final String Deals_Export_Message_xp="//div[@class='message confirmBody ng-scope' and text()='Are you sure you want to export more than 250 records?']";
	public static final String Deals_Export_Message_Yes_xp="//div[@class='message buttonContainer']//button[@class='btn btn-small confirm ng-scope']";
	public static final String Deals_Customer_Filter_Search_xp="//input[@placeholder='Search Customer...']";
	//public static final String Deals_Export_Alert_Message_xp="//div[contains(@class,'message') and text()='You cannot export more than 2000 records.']";
	public static final String Deals_Export_Alert_Message_xp="//div[@class='ui-notification ng-scope warning clickable']//div[text()='You cannot export more than 2000 records.']";
	public static final String Deals_NumberOfDeals_id="numberOfDeals";
	//public static final String Deals_NumberOfDeals_ToolTip="//div[@class='col-md-6 dealInput ng-scope']//i";
	public static final String Deals_NumberOfDeals_ToolTip="//div[@class='col-md-6 dealInput ng-scope']//i[@class='fa fa-info-circle' and @uib-tooltip='Using a value greater than 1 will result in multiple deals being created']";
	public static final String Deals_NumberOfDeals_ErrorMessage="//div[@class='col-md-6 dealInput ng-scope']//p[@class='invalidInputMessage ng-scope']";
	public static final String Deals_Title_Length_ErrorMessage="//div[@class='dealInput ng-scope col-md-6']//p[@class='invalidInputMessage ng-binding ng-scope']";
	public static final String Deals_BulkDeal_yes="//button[@class='btn btn-small confirm ng-scope']";
	public static final String Deals_ExhaustedNumberofDeals_Error_xp="//div[@ng-messages='dealFormCtrl.dealForm.numberOfDeals.$error']//p";
	public static final String Deals_AddDeal_ComboSelected_Country_xp="//select[@id='alternateCountry']//option[@selected='selected']";
	public static final String Deals_AddDeal_ComboSelected_State_xp="//select[@id='alternateState']//option[@selected='selected']";
	public static final String Deals_EditDeal_Associated_Item_xp="//div/form/sp-associated-item//i";
	public static final String Deal_Departmentcredit_id="departmentCredit";
	public static final String Deals_AddDealComboCreditApprover_id="creditApprover";
	public static final String Deals_AddDealCheckboxInsuranceCertified_id="insuranceCertificate";
	
	public static final String Deals_Form_AletMessage_xp="//div[@class='nbc-alert-danger ng-binding']";
	public static final String Deals_Form_OpenOrder_ErrorMessage_xp="//div[@class='ui-notification confirm-template open-orders-error ng-scope']//button";
	
	public static final String Common_ViewModules_ComboPageSize_xp = "//select[@name='pageSize']";
	//public static final String Common_ViewModules_BtnPreviousLink_xp = "//button[@class='btn btn-xs btn-orange pageSelect' and @ng-click='previousPage()']";
	public static final String Common_ViewModules_BtnPreviousLink_xp = "//button[contains(@class,'btn-orange') and @ng-click='previousPage()']";
	//public static final String Common_ViewModules_BtnNextLink_xp = "//button[@class='btn btn-xs btn-orange pageSelect' and @ng-click='nextPage()']";
	public static final String Common_ViewModules_BtnNextLink_xp = "//button[contains(@class,'btn-orange') and @ng-click='nextPage()']";
	public static final String Common_ViewModules_InputPageNum_xp = "//input[@name='currentPage' and @type='number' and @ng-model='currentPage']";
	public static final String Common_ViewModules_LabelPageNum_xp = "//label[@for='currentPage' and @class='sr-only']";
	public static final String Common_ViewModules_LabelTotalPages_xp = "//span[@class='totalPages ng-binding']";
	
	public static final String Common_AddModule_BtnSave_xp = "//button[@type='submit' and text()=' SAVE']";
	public static final String Common_AddModule_BtnCancel_xp = "//button[@type='button' and text()=' CANCEL']";
	//public static final String Common_AllModules_ComboCorporateName_xp = "//select[@name='corporationSelect']";
	//public static final String Common_AllModules_ComboOfficeCode_xp = "//select[@name='officeSelect']";
	
	public static final String Common_AllModules_ComboCorporateName_xp = "//ul[@class='dropdown-menu contextSelect corporationSelect ng-isolate-scope' and @aria-labelledby='dropdownMenu1']";
	public static final String Common_AllModules_ComboOfficeCode_xp = "//ul[@class='dropdown-menu contextSelect officeSelect ng-isolate-scope' and @aria-labelledby='dropdownMenu1']";
	public static final String Common_AllModules_ComboOfficeSelect_xp = "//div[@id='officeSelect']";
	public static final String Common_AllModules_ComboCorporateSelect_xp = "//*[@id='corporationSelect']";
	public static final String Common_AllModules_ComboOfficeText_xp = "//*[@id='officeName']";
	public static final String Common_AllModules_ComboCorporateText_xp = "//*[@id='corporationSelect']/div";
	
	//public static final String Common_AddModule_TextDialogBox = "//div[@class='confirmSaveContent']/p[@class='saveText']";
	//public static final String Common_AddModule_BtnDialogBox = "//div[@class='confirmSaveContent']/button[@class='btn btn-default closeButtonOk']";
	 
	 public static final String Common_AddModule_TextDialogBox = "//div[@class='appDialogContent']/p[@class='popupText']";
	 public static final String Common_AddModule_BtnDialogBox = "//div[@class='popupButtonContainer']/button[@class='btn btn-default alertButton']";
	 
	 
	 
	 public static final String Common_CancelModule_TextDialogBox = "//div[@class='popupButtonContainer']/button[@class='btn btn-default alertButton']";
	 public static final String Common_CancelModule_BtnYes = "//div[@class='popupButtonContainer']/button[@class='btn btn-default alertButtonRight']";
	 public static final String Common_CancelModule_BtnNo = "//div[@class='popupButtonContainer']/button[@class='btn btn-default alertButtonLeft']";
	 
	 
	
	
	//By Id
	public static final String Users_BtnDummy_id = "Dummy_Id";
	
	//By Name
	public static final String Users_InputDummy_nm = "Dummy_Name";
	//By XPath
	
	public static final String Users_LinkUsersOption_xp = "//*[@id='menu_bar']/li/a[text()='Users']";
	
	//By Tag Name
	public static final String Users_LabelDummy_tn = "Dummy_TagName";
	
	///////////////////////////////////////Users Object End/////////////////////////////////////////
	//////////////////////////////////////SAP VALIDATION///////////////////////////////////////////
	public static final String Sap_Validation_Screen_Table_Search_bar_xp="//input[@placeholder='Search ...']";
	public static final String Sap_Validation_Screen_Table_Active_Green_xp="//div[@class='active-filter pull-right']//i[@class='fa fa-circle ng-scope activeRecord']";
	public static final String Sap_Validation_Screen_Table_Active_Red_xp="//div[@class='active-filter pull-right']//i[@class='fa fa-circle ng-scope inactiveRecord']";
	public static final String Sap_Validation_Screen_Search_bar_xp="//input[@placeholder='Search for a Cost Object']";
	public static final String Sap_Validation_Screen_Search_bar_text_xp="//input[@class='form-control ng-pristine ng-valid ng-empty ng-touched']";
	public static final String Sap_Validation_Screen_Title_xp="//h3[@translate='SAP.TITLE' and text()='SAP Validation']";
	public static final String Sap_Validation_Screen_Title_Logo_xp="//div[@class='sapTitleContainer']//i";
	public static final String Sap_Validation_Screen_Search_Btn_xp="//button[contains(@class,'btn btn-block btn-primary') and text()='Search']";
	public static final String Sap_Validation_Screen_Cost_Object_List_xp="//div[@class='meta-data']//ul//li";
	public static final String Sap_Validation_Screen_ChartOfAccount_Search_xp="(//input[@placeholder='Search ...'])[1]";
	public static final String Sap_Validation_Screen_WBSE_Search_xp="(//input[@placeholder='Search ...'])[2]";
	public static final String Sap_Validation_Screen_CostCenter_Search_xp="(//input[@placeholder='Search ...'])[3]";
	public static final String Sap_Validation_Screen_ProfitCenter_Search_xp="(//input[@placeholder='Search ...'])[4]";
	public static final String Sap_Validation_Screen_InternalOrders_Search_xp="(//input[@placeholder='Search ...'])[5]";
	public static final String Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp="(//input[@placeholder='Search ...'])[6]";
	public static final String Sap_Validation_Screen_Cost_Object_WBSE_CheckBox_xp="(//div[@class='meta-data']//ul//li/span)[1]";
	public static final String Sap_Validation_Screen_Cost_Object_CostCenter_CheckBox_xp="(//div[@class='meta-data']//ul//li/span)[2]";
	public static final String Sap_Validation_Screen_Cost_Object_InternalOrders_CheckBox_xp="(//div[@class='meta-data']//ul//li/span)[3]";
	public static final String Sap_Validation_Screen_Cost_Object_ChartOfAccount_CheckBox_xp="(//div[@class='meta-data']//ul//li/span)[4]";
	public static final String Sap_Validation_Screen_Cost_Object_ProfitCenter_CheckBox_xp="(//div[@class='meta-data']//ul//li/span)[5]";
	public static final String Sap_Validation_Screen_Cost_Object_ManualFundsCommitement_CheckBox_xp="(//div[@class='meta-data']//ul//li/span)[6]";
	public static final String Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp="//h2[contains(@class,'sap-table-header ng-binding') and text()='Chart Of Account']";
	public static final String Sap_Validation_Screen_Search_btn_xp="//button[contains(@class,'btn btn-block btn-primary') and text()='Search']";
	public static final String Sap_Validation_Screen_Cost_Object_WBSE_Title_xp="//h2[contains(@class,'sap-table-header ng-binding') and text()='WBSE']";
	public static final String Sap_Validation_Screen_Cost_Object_CostCenter_Title_xp="//h2[contains(@class,'sap-table-header ng-binding') and text()='Cost Center']";
	public static final String Sap_Validation_Screen_Cost_Object_ProfitCenter_Title_xp="//h2[contains(@class,'sap-table-header ng-binding') and text()='Profit Center']";
	public static final String Sap_Validation_Screen_Cost_Object_InternalOrders_Title_xp="//h2[contains(@class,'sap-table-header ng-binding') and text()='Internal Orders']";
	public static final String Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp="//h2[contains(@class,'sap-table-header ng-binding') and text()='Manual Funds Commitment']";
	public static final String Sap_Validation_Screen_Cost_Object_WBSE_Indicator_xp="//strong[contains(@class,'sap-table-ind ng-binding ng-scope') and contains(text(),'- Indicator A')]";
	public static final String Sap_Validation_Screen_Cost_Object_Cost_Center_Indicator_xp="//strong[contains(@class,'sap-table-ind ng-binding ng-scope') and text()='- Indicator K']";
	public static final String Sap_Validation_Screen_Cost_Object_Profit_Center_Indicator_xp="//strong[contains(@class,'sap-table-ind ng-binding ng-scope') and text()='- Indicator Z']";
	public static final String Sap_Validation_Screen_Cost_Object_Internal_Order_Indicator_xp="//strong[contains(@class,'sap-table-ind ng-binding ng-scope') and text()='- Indicator W']";
	public static final String Sap_Validation_Screen_Cost_Object_ManualFunds_Indicator_xp="//strong[contains(@class,'sap-table-ind ng-binding ng-scope') and text()='- Indicator M']";
	public static final String Sap_Validation_ChartOfAccount_Pagination_xp="(//div[@class='pagination-group'])[1]";
	public static final String Sap_Validation_Wbse_Pagination_xp="(//div[@class='pagination-group'])[2]";
	public static final String Sap_Validation_CostCenter_Pagination_xp="(//div[@class='pagination-group'])[3]";
	public static final String Sap_Validation_ProfitCenter_Pagination_xp="(//div[@class='pagination-group'])[4]";
	public static final String Sap_Validation_InternalOrders_Pagination_xp="(//div[@class='pagination-group'])[5]";
	public static final String Sap_Validation_ManualFunds_Pagination_xp="(//div[@class='pagination-group'])[6]";
	public static final String Sap_Validation_ChartOfAccount_Pagination_Text_xp="(//p[@translate='TABLE.SHOWING_ITEMS' and contains(text(),'Showing items')])[1]";
	public static final String Sap_Validation_Wbse_Pagination_Text_xp="(//p[@translate='TABLE.SHOWING_ITEMS' and contains(text(),'Showing items')])[2]";
	public static final String Sap_Validation_CostCenter_Pagination_Text_xp="(//p[@translate='TABLE.SHOWING_ITEMS' and contains(text(),'Showing items')])[3]";
	public static final String Sap_Validation_ProfitCenter_Pagination_Text_xp="(//p[@translate='TABLE.SHOWING_ITEMS' and contains(text(),'Showing items')])[4]";
	public static final String Sap_Validation_InternalOrders_Pagination_Text_xp="(//p[@translate='TABLE.SHOWING_ITEMS' and contains(text(),'Showing items')])[5]";
	public static final String Sap_Validation_ManualFunds_Pagination_Text_xp="(//p[@translate='TABLE.SHOWING_ITEMS' and contains(text(),'Showing items')])[6]";
	public static final String Sap_Validation_ChartOfAccount_Pagination_Next_xp="(//div[@class='pagination-group']//ul//li[@class='next ng-scope']//a//span)[1]";
	public static final String Sap_Validation_ChartOfAccount_Pagination_Previous_xp="(//div[@class='pagination-group']//ul//li[@class='prev ng-scope']//a//span)[1]";
	public static final String Sap_Validation_Wbse_Pagination_Next_xp="(//div[@class='pagination-group']//ul//li[@class='next ng-scope']//a//span)[2]";
	public static final String Sap_Validation_Wbse_Pagination_Previous_xp="(//div[@class='pagination-group']//ul//li[@class='prev ng-scope']//a//span)[2]";
	public static final String Sap_Validation_CostCenter_Pagination_Next_xp="(//div[@class='pagination-group']//ul//li[@class='next ng-scope']//a//span)[3]";
	public static final String Sap_Validation_CostCener_Pagination_Previous_xp="(//div[@class='pagination-group']//ul//li[@class='prev ng-scope']//a//span)[3]";
	public static final String Sap_Validation_ProfitCenter_Pagination_Next_xp="(//div[@class='pagination-group']//ul//li[@class='next ng-scope']//a//span)[4]";
	public static final String Sap_Validation_ProfitCenter_Pagination_Previous_xp="(//div[@class='pagination-group']//ul//li[@class='prev ng-scope']//a//span)[4]";
	public static final String Sap_Validation_InternalOrders_Pagination_Next_xp="(//div[@class='pagination-group']//ul//li[@class='next ng-scope']//a//span)[5]";
	public static final String Sap_Validation_InternalOrders_Pagination_Previous_xp="(//div[@class='pagination-group']//ul//li[@class='prev ng-scope']//a//span)[5]";
	public static final String Sap_Validation_ManualFunds_Pagination_Next_xp="(//div[@class='pagination-group']//ul//li[@class='next ng-scope']//a//span)[6]";
	public static final String Sap_Validation_ManualFunds_Pagination_Previous_xp="(//div[@class='pagination-group']//ul//li[@class='prev ng-scope']//a//span)[6]";
	public static final String Sap_Validation_Btn_Sorting_ChartOfAccount_Column_1="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[1]/thead/tr/th[1]/i";
	public static final String Sap_Validation_Btn_Sorting_ChartOfAccount_Column_2="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[1]/thead/tr/th[2]/i";
	public static final String Sap_Validation_Btn_Sorting_ChartOfAccount_Column_3="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[1]/thead/tr/th[3]/i";
	public static final String Sap_Validation_Btn_Sorting_Wbse_Column_1="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[2]/thead/tr/th[1]/i";
	public static final String Sap_Validation_Btn_Sorting_Wbse_Column_2="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[2]/thead/tr/th[2]/i";
	public static final String Sap_Validation_Btn_Sorting_Wbse_Column_3="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[2]/thead/tr/th[3]/i";
	public static final String Sap_Validation_Btn_Sorting_Wbse_Column_4="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[2]/thead/tr/th[4]/i";
	public static final String Sap_Validation_Btn_Sorting_Wbse_Column_5="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[2]/thead/tr/th[5]/i";
	public static final String Sap_Validation_Btn_Sorting_CostCenter_Column_1="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[3]/thead/tr/th[1]/i";
	public static final String Sap_Validation_Btn_Sorting_CostCenter_Column_2="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[3]/thead/tr/th[2]/i";
	public static final String Sap_Validation_Btn_Sorting_CostCenter_Column_3="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[3]/thead/tr/th[3]/i";
	public static final String Sap_Validation_Btn_Sorting_ProfitCenter_Column_1="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[4]/thead/tr/th[1]/i";
	public static final String Sap_Validation_Btn_Sorting_ProfitCenter_Column_2="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[4]/thead/tr/th[2]/i";
	public static final String Sap_Validation_Btn_Sorting_ProfitCenter_Column_3="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[4]/thead/tr/th[3]/i";
	public static final String Sap_Validation_Btn_Sorting_InternalOrder_Column_1="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[5]/thead/tr/th[1]/i";
	public static final String Sap_Validation_Btn_Sorting_InternalOrder_Column_2="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[5]/thead/tr/th[2]/i";
	public static final String Sap_Validation_Btn_Sorting_InternalOrder_Column_3="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[5]/thead/tr/th[3]/i";
	public static final String Sap_Validation_Btn_Sorting_ManualFunds_Column_1="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[6]/thead/tr/th[1]/i";
	public static final String Sap_Validation_Btn_Sorting_ManualFunds_Column_2="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[6]/thead/tr/th[2]/i";
	public static final String Sap_Validation_Btn_Sorting_ManualFunds_Column_3="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[6]/thead/tr/th[3]/i";
	public static final String Sap_Validation_Btn_Sorting_ManualFunds_Column_4="(//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table)[6]/thead/tr/th[4]/i";
	
	
	public static final String ParentCompany_Export_Popup_Alert="//h3[@translate='CONFIRM_EXPORT_TITLE' and text()='Are you sure?']";
	public static final String ParentCompany_Export_Popup_Alert_Yes_Btn_xp="//button[@class='btn btn-small confirm ng-scope']";
	
	//public static final String Common_Btn_Sorting_Column_8="//table[@class='table table-striped']/thead/tr/th[8]/i";
	//public static final String Common_Btn_Sorting_Column_9="//table[@class='table table-striped']/thead/tr/th[9]/i";
	//div[contains(@class,'results')]//sp-cost-object//sp-table-view-new/sp-table-new/table/tbody/thead)[1]
	
	
	
	
	
//*******************************************************************Code added by Surja*************************************************************
	
	
	
	
	
    public static final String ARC_Approve_and_Send_pop_up_xp = ("/html/body/div[1]/div/div/div/div[1]/h3");
    public static final String ARC_transaction_right_click_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr[1]/td[3]\",\"transaction");
    public static final String ARC_transaction_unapprove_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[3]/a");
    public static final String ARC_transaction_TAX_field_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr[2]/td[3]");
    public static final String ARC_transaction_unapprove_sure_button_xp = ("/html/body/div[1]/div/div/div/div[3]/button[2]");
    public static final String ARC_transaction_unapprove_xp1 = ("//sp-table-view-new/div[1]/sp-table-status-filter/div/div/span[3]/span[1]/span");
    public static final String ARC_transaction_unapprove_sure_button_xp1 = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]");
    public static final String ARC_transaction_approve_and_send_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[2]/a");
    public static final String ARC_Approve_and_send_pop_up_colour_code_xp = ("/html/body/div[1]/div/div/div/div[1]");
    public static final String ARC_transaction_E_record_note_field_xp = ("//*[contains(text(),'Extended Upload Note')]");
    public static final String ARC_trasaction_slide_out_close_xp = ("/html/body/div[1]/div/div/div/div[1]/i");
    
    public static final String Common_ViewModules_LinkAll_xp1 = "//span[@translate='TABLE_FILTERS.TRANSACTIONSTATUSCODEID.ALL']";
    public static final String Common_ARC_ViewTransaction_xp = "//table[@class='table table-striped']/tbody/tr/td[@ng-repeat='column in options.visibleColumns']/sp-status-color[@colors='statusColors']";
    public static final String ARC_transaction_click_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]");
    //public static final String Exceptions_accordian_table_billing_request_popup_close_xp1 =("//button[@translate='FORM_EXIT_YES_BUTTON']");
    
    public static final String Transaction_Quantity_ARC_Record_Type = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[5]/span");
	public static final String Transaction_Quantity_ARC_Record_Type1 = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[6]/span");
	public static final String Transaction_Quantity_ARC_Record_Type2 = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[7]/span");
	public static final String Transaction_Hub_ARC_ApproveSend_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]/span");
	public static final String Transaction_Hub_ARC_ApproveSend_xp1 = ("//sp-table-view-new/sp-table-new/div/ul/li[2]/a");
	public static final String Billing_ARC_Deal_Visibility_xp = ("//*[starts-with(@id,'collapse_')]/div/div/ul/li");
	//public static final String Billing_ARC_View_transaction_Note_Visibility_xp = ("//transaction-form/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[1]/ul/li[2]/a");
	public static final String Billing_ARC_View_transaction_Note_Visibility_xp = ("//a[contains(text(),'NOTES')]");

	
	public static final String Billing_ARC_View_transaction_Note_Content_xp = ("//transaction-form/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[1]/div/div[2]/div[2]/table/tbody/tr/td[4]");
	public static final String Approve_and_Send_billable_transactions_xp = ("/html/body/div[1]/div/div/div/div[2]/div/div[1]");
	public static final String Approve_and_Send_billable_transactions_xp1 = ("/html/body/div[1]/div/div/div/div[2]/div/div[1]/../../..//h3");
	public static final String Billing_ARC_View_transaction_Extended_Note_Content_xp =("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[1]/div/div[2]/div[2]/table/tbody/tr[2]/td[3]");
	public static final String Billing_ARC_View_Transaction_Notes_tab_xp = ("//transaction-form/sp-sideview-modal/div/div[2]/div[2]");
	public static final String Dashboard_Order_edit_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]");
	public static final String WIP_Charge_Method_xp = ("//*[@id='wipChargeMethod']");
	public static final String Right_click_on_transaction_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr[1]/td[3]");
	public static final String Reassign_a_transaction_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[6]/a");
	public static final String Click_the_Reassign_button_xp = ("/html/body/div[1]/div/div/div/div[3]/button[2]");
	public static final String Reassign_message_display_xp =("//div[contains(.,'You are about to REASSIGN')]");
	public static final String Dashboard_order_edit_link_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[2]/a");
	public static final String ARC_view_transaction_company_code_xp = ("//sp-authorize-field/div/ng-transclude/div/div/div[6]/select");
	public static final String ARC_view_transaction_cost_object_xp = ("//*[@id='costObject']");
	public static final String ARC_view_transaction_SAP_account_number_xp = ("//*[@id='accountNumber']");
	public static final String ARC_view_transaction_SAP_Indicator_xp = ("//*[@id='sapIndicator']");
	public static final String ARC_view_transaction_SAP_Territory_xp = ("//*[@id='sapTerritory']");
	public static final String ARC_view_transaction_Save_button = ("//button[contains(text(),'Save')]");
	public static final String Create_deal_invoice_format_xp = ("//*[@id='invoiceFormat']");
	public static final String ARC_screen_reset_default_button_xp = ("//sp-table-filters/div/div[9]/div/ul/span[8]/li/span");
	public static final String Exceptions_accordian_table_billing_request_view_xp = ("//*[@id='accordion-table']/tbody/tr[1]/td[5]");
	public static final String Exceptions_billing_request_slide_out_xp = ("//edit-billing-exceptions/sp-sideview-modal/div/div[2]/div[1]/h1");
	public static final String Exceptions_deal_search_text_box_xp = ("//sp-accordion-table-view/div[1]/div/ng-include/div/input");
    public static final String Exceptions_accordian_table_display = ("//*[@id='subTable0']/td[2]");
    public static final String Exceptions_accordian_table_transaction1_xp = ("//*[@id='subTable0']/td[2]/sp-table-view-new/sp-table-new/table/tbody/tr[1]/td[10]/span");
    public static final String Exceptions_accordian_table_transaction2_xp = ("//*[@id='subTable0']/td[2]/sp-table-view-new/sp-table-new/table/tbody/tr[2]/td[10]/span");
    public static final String Exceptions_accordian_table_billing_request_close_xp = ("//edit-billing-exceptions/sp-sideview-modal/div/div[2]/div[1]/i");
    public static final String Exceptions_accordian_table_transaction_slide_out_display_xp = ("//transaction-form/sp-sideview-modal/div/div[2]/div[2]");
    public static final String Exceptions_accordian_table_billing_request_popup_close_xp = ("/html/body/div[1]/div/div/div/div[2]/button[2]");
    public static final String Exceptions_accordian_table_billing_request_popup_close_xp1 =("//button[@translate='FORM_EXIT_YES_BUTTON']");
    public static final String Exceptions_accordian_table_billing_request_cost_object1_xp = ("//*[@id='subTable0']/td[2]/sp-table-view-new/sp-table-new/table/tbody/tr[1]/td[11]/span");
    public static final String Exceptions_accordian_table_billing_request_cost_object2_xp = ("//*[@id='subTable0']/td[2]/sp-table-view-new/sp-table-new/table/tbody/tr[2]/td[11]/span");
    public static final String Exceptions_accordian_table_billing_request_cost_object_edit_xp = ("//*[@id='costObject']");
    public static final String Exceptions_accordian_table_transaction_view_close_xp = ("//transaction-form/sp-sideview-modal/div/div[2]/div[1]/i");
    public static final String Split_a_transaction_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[5]/a");
    public static final String Split_popup_display_xp = ("/html/body/div[1]/div/div/div/form/div");
    public static final String Transaction_AddTransaction_cashflag_id =("cashSaleIndicator");
    public static final String Exceptions_billing_request_slide_creditreason_xp =("//*[@id='creditReasonOther']");
    public static final String Reassign_TotalRevenueAmount = ("/html/body/div[1]/div/div/div/div[2]/div/div[1]/div/div[1]/div");
    public static final String Reassign_TaxAmount = ("/html/body/div[1]/div/div/div/div[2]/div/div[1]/div/div[3]/div");
    public static final String Exceptions_accordian_table_amount_field_xp = ("//*[@id='accordion-table']/tbody/tr[1]/td[13]");
    public static final String Exceptions_accordian_table_amount_field_xp1 = ("//*[@id='accordion-table']/tbody/tr[1]/td[4]");
    public static final String Exceptions_billing_request_slide_credit_reason_xp = ("//*[@id='creditReason']");
    public static final String Exceptions_billing_request_slide_invoice_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/fieldset/div[11]/div[1]/div/input");
    public static final String Exceptions_billing_request_slide_save_button_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/fieldset/div[15]/button");
    
    public static final String Exceptions_accordian_table_credit_right_click_edit_xp = ("//sp-accordion-table-view/sp-accordion-table/div/div[1]/ul/li[1]/a");
    public static final String Exceptions_accordian_table_deal_number_field_xp = ("//*[@id='accordion-table']/tbody/tr[1]/td[5]/span");
    public static final String Exceptions_billing_request_slide_out_other_reason_field_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/fieldset/div[12]/div/div/input");
    public static final String Exceptions_billing_request_slide_save_button_xp1 = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/fieldset/div[16]/button");
    public static final String Exceptions_accordian_table_amount_field_hover_xp = ("//*[@id='accordion-table']/tbody/tr[1]/td[13]/sp-exception-button");
    public static final String Exceptions_accordian_table_must_reject_request_xp = ("/html/body/div[1]/div/div/div/h3");
    public static final String Billing_ARC_transaction_table_xp = ("//sp-table-view-new/sp-table-new/table/tbody");
    public static final String Billing_draft_billing_search_deal_xp = ("//*[@id='collapse_261']/div/div/div[1]/div/input");
    public static final String Billing_draft_billing_click_deal_xp = ("//*[@id='collapse_261']/div/div/ul[2]/li/div/p[1]");
    public static final String Billing_draft_billing_bill_right_click_xp = ("//ul[@class='list-group accordion-double-button']//li[1]");
    public static final String Billing_draft_billing_bill_edit_click_xp = ("/html/body/main/section/div/div[3]/div[1]/ul/li/a");
    public static final String Billing_draft_billing_edit_save_xp = ("//button[@translate='DRAFT_BILLING.EDIT.SAVE' and text()='Save']");
    public static final String Billing_draft_billing_invoice_summary_page_header_xp = ("//edit-draft-bill/sp-sideview-modal/div/div[2]/div[1]/h1");
    //public static final String Billing_draft_billing_invoice_summary_page_header_xp1 = ("//edit-draft-bill/sp-sideview-modal/div/div[2]/div[1]/h1");
    public static final String Billing_draft_billing_invoice_page_send_to_ARC_button_xp = ("//edit-draft-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[7]/div/div/button[1]");
    public static final String Draft_Billing_Title_xp="//h3[@translate='DRAFT_BILLING.TITLE']";
    public static final String Billing_ARC_Search_Panel_xp = ("//div[@class='panel-collapse collapse in']/div/div/div[1]/div/input");
    public static final String Deal_link_xp = ("//div/span[@class='nav-menu-name ng-binding ng-scope'and text()='Deals']");
    public static final String Deal_search_xp = ("//sp-table-view-new/div[1]/div/ng-include/div/input");
    public static final String Deal_right_click_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]");
    public static final String Deal_view_order_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[5]/a");
    public static final String Deal_view_order_xp1 = ("//a[@class='ng-binding ng-scope' and text()='View Orders']");
    public static final String Create_order_xp = ("//span[@ng-click='ordersCtrl.showAddForm = true;']");
    public static final String Order_create_company_code_xp = ("//add-order/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[6]/div/div[6]/select");
    public static final String Order_create_territory_type_xp = ("//add-order/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[6]/div/div[4]/label");
    public static final String ARC_send_transasction_right_click_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr[1]/td[2]");
    public static final String ARC_send_transaction_link_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[4]/a");
    public static final String ARC_send_transaction_link_xp1 = ("//sp-table-view-new/sp-table-new/div/ul/li[2]/a");
    public static final String ARC_send_transaction_link_xp2 = ("//sp-table-view-new/sp-table-new/div/ul/li[4]/a");
    public static final String ARC_send_transaction_button_xp = ("//div[@class='message buttonContainer']//button[contains(.,'Send')]");
    public static final String Draft_billing_add_new_draft_bill_xp = ("//*[starts-with(@id,'collapse_')]/div/div/ul[1]/li");
    public static final String Draft_billing_add_new_draft_bill_description_box_xp = ("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[3]/div/input");
    public static final String Draft_billing_add_new_draft_bill_description_box_xp1 = ("//input[@ng-model='EditDraftBill.draftBill.invoiceName']");
    public static final String Draft_billing_add_new_draft_bill_invoice_format_xp = ("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[4]/div[1]/p");
    public static final String Draft_billing_add_new_draft_bill_invoice_format_xp1 = ("//p[contains(.,'DET - Detailed Invoice')]");
    public static final String Draft_billing_add_new_draft_bill_SAP_amount_xp = ("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[6]/div/div/div[3]/p");
    public static final String Draft_billing_add_new_draft_bill_DCS_amount_xp = ("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[7]/div[1]/div[2]/p[1]");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_xp = ("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[6]/div/div/div[1]/h4");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_cost_object_xp =("//*[@id='costObject']");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_cost_object_xp1 =("(//*[@id='costObject'])[2]");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_cost_object_xp2 =("(//*[@id='costObject'])[3]");
    
    
    public static final String Draft_billing_add_new_draft_bill_SAP_account_number_xp = ("//*[@id='accountNumber']");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_number_xp1 = ("(//*[@id='accountNumber'])[2]");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_number_xp2 = ("(//*[@id='accountNumber'])[3]");
    
    
    public static final String Draft_billing_add_new_draft_bill_SAP_account_percent_xp = ("//*[@id='0-percent']");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_percent_xp5 = ("//*[@id='1-percent']");
    public static final String Draft_billing_add_new_draft_bill_SAP_account_percent_xp2 = ("//*[@id='2-percent']");
    
    public static final String Draft_billing_add_new_draft_bill_SAP_account_percent_xp1 = ("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[6]/div/div[1]/div[4]");
    public static final String Draft_billing_add_new_draft_bill_Save_xp =("//edit-summary-bill/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/div[7]/div[2]/div/div/div/button");
    public static final String Draft_billing_add_new_draft_bill_delivery_method_xp = ("//*[@id='deliveryMethod']");
    public static final String Draft_billing_bill_number_search_xp = ("//*[[starts-with(@id,'collapse_')]/div/div/div[1]/div/input");
    public static final String Draft_billing_bill_click_xp = ("//*[starts-with(@id,'collapse_')]/div/div/ul[2]/li/div/div[2]/p[contains(.,'$80.01')]");
    public static final String Draft_billing_transactions_select_all_xp = ("//sp-table-view-new/sp-table-new/table/thead/tr/th[1]/input");
    public static final String Draft_billing_transactions_Bulk_actions_xp = ("//*[@id='bulkActions']");
    //public static final String Draft_billing_transactions_Bulk_actions_send_to_ARC_popup_xp = ("//div[@class='modal-dialog modal-md']/div[@class='modal-content']/div[@class='ui-notification confirm-template transaction-action-dialog ng-scope']");
    public static final String Draft_billing_transactions_Bulk_actions_send_to_ARC_popup_message_xp = ("/html/body/div[1]/div/div/div/div[2]/div/div[1]");
    public static final String Draft_billing_Bulk_actions_Send_to_ARC_link_xp = ("//sp-table-view-new/div[1]/div/sp-table-bulk-actions/div/div/ul/li[1]/a");
    public static final String Draft_billing_transactions_Bulk_actions_send_to_ARC_move_button_xp = ("//button[@translate='TRANSACTIONS.SEND_TO_ARC.DIALOG.SUBMIT']");
    public static final String ARC_transaction_table_xp = ("//sp-table-view-new/sp-table-new/table");
    public static final String ARC_transaction_table_data_xp1 = ("//sp-table-view-new/sp-table-new/table/tbody/tr[1]");
    public static final String ARC_transaction_table_data_xp2 = ("//sp-table-view-new/sp-table-new/table/tbody/tr[2]");
    public static final String Draft_billing_bill_click_xp1 = ("//*[starts-with(@id,'collapse_')]/div/div/ul[2]/li/div/div[2]/p[contains(.,'$80.01')]");
    public static final String ARC_transactions_bulk_actions_send_xp = ("//sp-table-view-new/div[1]/div/sp-table-bulk-actions/div/div/ul/li[3]/a");
    //public static final String Draft_billing_bill_click_xp2 = ("//*[starts-with(@id,'collapse_')]/div/div/ul[2]/li/div/div[2]/p[contains(.,'$80.01')]");
    public static final String Draft_billing_bill_click_xp2 = ("//ul[@class='list-group accordion-double-button']//li[1]");
    
  
    public static final String Draft_billing_bulk_actions_move_to_draft_bill_xp = ("//sp-table-view-new/div[1]/div/sp-table-bulk-actions/div/div/ul/li[2]/a");
    public static final String Draft_billing_bill_click_xp3 = ("//*[starts-with(@id,'collapse_')]/div/div/ul[2]/li/div/div[2]/p[contains(.,'$80.01')]");
    public static final String Draft_billing_bill_click_xp4 = ("//*[starts-with(@id,'collapse_')]/div/div/ul[2]/li/div/div[2]/p[contains(.,'$1,857.25')]");
    public static final String Deal_edit_header_xp = ("//edit-deal/sp-sideview-modal/div/div[2]/div[1]/h1");
    public static final String Deal_edit_deposit_tab_xp = ("//edit-deal/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/sp-multi-department-disable/div[1]/ul/li[2]/a");
    public static final String Deal_edit_deposit_customer_label_xp = ("//edit-deal/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/sp-multi-department-disable/div[1]/div/div[2]/div/div[1]/div/div/label");
    public static final String Deal_edit_information_tab_xp = ("//edit-deal/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/sp-multi-department-disable/div[1]/ul/li[1]/a");
    public static final String Deal_edit_information_tab_customer_name_xp = ("//sp-multi-department-disable/div[1]/div/div[1]/div[3]/sp-authorize-field/div/ng-transclude/div[1]/div/div[3]/div[2]/span/span[1]");
    public static final String Deal_edit_information_tab_customer_number_xp = ("//sp-multi-department-disable/div[1]/div/div[1]/div[3]/sp-authorize-field/div/ng-transclude/div[1]/div/div[3]/div[2]/span/span[2]");
    public static final String Deal_edit_deposit_tab_customer_name_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[1]/div/div/fieldset/div[1]/span");
    public static final String Deal_edit_deposit_tab_customer_number_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[1]/div/div/fieldset/div[2]/data/div");
    public static final String Deal_edit_deposit_tab_customer_status_xp =("//sp-multi-department-disable/div[1]/div/div[2]/div/div[1]/div/div/fieldset/div[1]/sp-status-color/i");
    public static final String Deal_edit_deposit_deposit_label_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/label");
    public static final String Deal_edit_deposit_tab_check_info_xp =("//h5[@class='mb-0 ng-binding']");
    public static final String Deal_edit_deposit_tab_remaining_amt_xp = ("//small[@class='ng-binding']");
    public static final String Deal_edit_deposit_tab_deposit_type_xp = ("//span[@class='badge ng-binding']");
    public static final String Deal_edit_deposit_tab_eye_icon_xp = ("//i[@class='fa fa-eye']");
    public static final String Deal_edit_deposit_tab_eye_icon_chk_date_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/label");
    public static final String Deal_edit_deposit_tab_eye_icon_chk_num_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[1]/div[2]/label");
    public static final String Deal_edit_deposit_tab_eye_icon_chk_amt_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[2]/div[1]/label");
    public static final String Deal_edit_deposit_tab_eye_icon_chk_rem_amt_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/label");
    public static final String Deal_edit_deposit_tab_eye_icon_deal_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[3]/div[1]/label");
    public static final String Deal_edit_deposit_tab_eye_icon_type_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/label	");
    public static final String Deal_edit_deposit_tab_eye_icon_check_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[2]/div[6]/div/a/i");
    public static final String Deal_edit_deposit_tab_eye_icon_record_highlight_xp = ("//sp-multi-department-disable/div[1]/div/div[2]/div/div[2]/div[1]/sp-deposit/div");
    public static final String Deal_click_xp = ("//div[@uib-tooltip='Deals']"); 
    public static final String Deal_edit_right_click_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]/sp-status-color[1]");
    public static final String Deal_edit_click_xp = ("//a[contains(.,'Edit/View Deal')]");
    public static final String Deal_order_right_click_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[2]");
    public static final String Deal_transaction_click_xp1 = ("//a[@class='ng-binding ng-scope'and text()='View Transactions']");
    public static final String Deal_transaction_click_xp = ("//sp-table-view-new/sp-table-new/div[2]/ul/li[3]/a");
    public static final String Deal_transaction_invoice_xp = ("//sp-table-view-new/sp-table-new/table/tbody/tr/td[14]/span");
    public static final String Deal_transaction_invoice_xp1 = ("//div[@id='invoiceNum']");
    public static final String Customer_edit_cost_object_label_xp = ("//label[contains(.,'Cost Object')]");
    public static final String Customer_edit_SAP_account_label_xp = ("//label[contains(.,'SAP Account Number')]");
    public static final String Customer_edit_header_xp = ("//edit-customer/sp-sideview-modal/div/div[2]/div[1]/h1/div");
    public static final String Add_transaction_xp = ("//div[@class='fixed-action-button']/span[contains(@href,'transaction')]");
    public static final String Transaction_order_field_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/form/div[4]/div/div/div/div[2]/div/input");
    public static final String Transaction_order_select_xp = ("//*[starts-with(@id,'typeahead')]");
    public static final String Transaction_date_field_xp = ("//input[@id='transactionDate']");
    public static final String Transaction_desc_field_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/form/div[9]/div/div/div[1]/div[1]/div/div/input");
    public static final String Transaction_qty_field_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/form/div[9]/div/div/div[1]/div[2]/div[1]/div/input");
    //public static final String Transaction_UM_field_xp = ("//*[@id='unitOfMeasure']");
    public static final String Transaction_rate_field_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/form/div[9]/div/div/div[1]/div[2]/div[3]/div/input");
    //public static final String Transaction_transactionType_id="transactionType";
    public static final String Transaction_save_xp = ("//sp-sideview-modal/div/div[2]/div[2]/ng-transclude/form/div[13]/button");
    public static final String Order_description_xp = ("//*[@id='orderDescription']");
    public static final String Transaction_save_xp_button = ("(//button[contains(text(),'Save')])[2]");
    public static final String Transaction_click_xp = ("//sp-table-view-new/sp-table-new/div/ul/li[3]/a");
    public static final String Order_cost_center_xp = ("//*[starts-with(@id,'ui-select-choices-row')]/span/span[2]");
    public static final String Order_cost_center_xp1 = ("//input[@placeholder='Select a cost center...']");
    public static final String Exceptions_must_reject_ok_button_xp = ("//button[@class='btn btn-small reject ng-scope'and text()='OK']");
    public static final String Close_order_xp = ("//i[@class='fa fa-times fa-2x fa-inverse']");
    public static final String Draft_billing_send_to_ARC = ("//button[@class='btn btn-default ng-binding'and text()='Send to ARC']");
    public static final String Draft_billing_send_to_ARC1 = ("//li[@nr-repeat='action in actions']/a[@class='ng-binding'and text()='Send To Arc']");
    public static final String Deals_select_all_xp = ("//input[@uib-tooltip='Select Current Page']");
    public static final String Deals_select_all_text_xp = ("//div[@class='tooltip-inner ng-binding'and text()='Select Current Page']");
    public static final String Deals_select_all_count_xp = ("//div[@class='selectedValues ng-scope']/span[contains(.,'items selected')]");
    public static final String Deals_next_page_xp = ("//sp-table-view-new/div[2]/div/div/ul/li[2]/a");
    public static final String Exceptions_billing_request_slide_save_button_xp2 = ("//edit-billing-exceptions/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/fieldset/div[16]/button");
    public static final String Error_msg_xp1 = ("//div[@class='ui-notification ng-scope error clickable']/div[@ng-bind-html='message']");
    public static final String Error_msg_xp = ("//edit-billing-exceptions/sp-sideview-modal/div/div[2]/div[2]/ng-transclude/ng-form/fieldset/div[15]");
    public static final String ARC_fetched_deal_xp = ("//div[@class='panel-content']/ul[2]/li[1]");
    public static final String ARC_fetched_deal_xp1 = ("//div[@class='panel-content']/ul/li");
    public static final String Exception_fetched_deal_xp = ("//*[@id='accordion-table']/tbody/tr[@ng-repeat-start='row in results']/td[@class='ng-scope dealOrder-deal-dealNumber']/span");
    public static final String Slide_expand_xp = ("//div[@class='toggleIcon toggleIconOnLeft']/i[@class='fa fa-angle-double-right fa-lg cursor-pointer-on-hover']");
	
    public static final String CustomersMaster_AddCustomer_Collector_id = "//select[@id='collector']/option[@selected='selected']";
    public static final String Sap_Validation_Screen_Manual_Funds_Commitment_CompanyFirstRow_xp ="//h2[contains(text(),'Manual Funds Commitment')]/../sp-table-view-new/sp-table-new/table/tbody/tr/td/span/span";
    public static final String Sap_Validation_Screen_Manual_Funds_Commitment_DocumentNumberItemFirstRow_xp ="//h2[contains(text(),'Manual Funds Commitment')]/../sp-table-view-new/sp-table-new/table/tbody/tr/td[2]/span/span";
    public static final String Deals_Validation_Screen_close_Managing_cost_center ="//span[@class='close ui-select-match-close']";		
    public static final String Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_Disabled ="//label[contains(text(),'WIP Charge Method')]/following-sibling::select[@disabled='disabled']/option[@label='Fixed Rate']";
    public static final String Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_DET_Enabled ="//label[contains(text(),'WIP Charge Method')]/following-sibling::select[@disabled='disabled']";
    public static final String Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_Enabled ="//label[contains(text(),'WIP Charge Method')]/following-sibling::select/option[contains(text(),'Cost Plus')]/following-sibling::option[contains(text(),'Fixed Rate')]";
    public static final String Orders_AddOrderComboInvoiceFormat_xp_WIP_ChargeMethod ="//label[contains(text(),'WIP Charge Method')]/following-sibling::select[@id='wipChargeMethod']";
    public static final String Orders_ViewCostPlusPercentage_WIP_ChargeMethod ="//span[contains(text(),'View Cost Plus %')]";
    public static final String Orders_CostPlusPercentage_ScreenHeader ="(//div[@class='sideview-form-container'])[2]/ng-transclude/ng-form/div/table/thead/tr/th";
    public static final String Orders_CostPlusPercentage_Screen ="//h1[contains(text(),'Cost Plus %')]";
    public static final String Orders_CostPlusPercentage_onexxlabor ="//td[contains(text(),'1XX - Labor')]";
    public static final String Orders_CostPlusPercentage_AP ="//td[contains(text(),'51X - AP')]";
    public static final String Orders_CostPlusPercentage_JournalEntries ="//td[contains(text(),'81X - Journal Entries')]";
    public static final String Orders_CostPlusPercentage_ScreenCloseButton ="//button[contains(text(),'OK')]";
    public static final String BillingApproval_TransactionDate ="//th[contains(text(),'Transaction Date')]";
    public static final String InvoiceStatement_DirectChargeSummary_DETTransaction_CostFlag ="//label[contains(text(),'SAP Account Numbers')]/..";
    public static final String InvoiceStatementInquiry_DealNumberFilter ="//li[contains(text(),'Deal Number')]";
    public static final String ARCScreen_PerCCFilter ="//li[contains(text(),'Performing CC')]";
    public static final String ARCScreen_MngCCFilter ="//li[contains(text(),'Deal Mng CC')]";
    
    public static final String InvoiceStatementInquiry_SearchDealNumberFilter ="//input[@placeholder='Search Deal Number...']";
    public static final String InvoiceStatementInquiry_ClickSearchDealNumberFilter ="(//span[@class='fa fa-square-o'])[1]";
    public static final String InvoiceStatementInquiry_ClickSearchDealNumberFilter2 ="(//span[@class='fa fa-square-o'])[1]";
    public static final String InvoiceStatementInquiry_selectfirstdeal ="//table[@class='table table-striped']//tbody//tr/td/input";
    
    public static final String HistoricalPage_DealNumberFilter ="//li[contains(text(),'Document Number')]";
    public static final String HistoricalPage_CustomerFilter ="//li[contains(text(),'Customer Number')]";
    public static final String HistoricalPage_DealMngCCFilter ="//li[contains(text(),'Deal Mng CC')]";
    public static final String HistoricalPage_DealMngCCSearchBox ="//input[@placeholder='Search Deal Mng CC...']";
    public static final String HistoricalPage_DealMngCC_Select265MngCC ="//span[contains(text(),'265 STUDIO POST')]/../span[1]";
    public static final String HistoricalPage_DealMngCC_SelectDocumentNumber ="(//span[@class='fa fa-circle-thin'])[1]";
    
    
    public static final String InvoiceStatementInquiry_Exit ="//i[@ng-click='sideviewModal.confirmFormExit()']";
    public static final String InvoiceStatementInquiry_tableHeader ="//i[@ng-click='sideviewModal.confirmFormExit()']";
    public static final String InvoiceStatementInquiry_Immediate ="//a[contains(text(),'Immediate')]";
    public static final String Transaction_DraftBilled ="(//span[contains(text(),'Draft Billed')])[1]";
    public static final String Transaction_DraftBilled_InvoiceStatement_Number ="//label[contains(text(),'Invoice/Statement #')]/following-sibling::div";
    public static final String Transaction_FinalBilled ="(//span[contains(text(),'Final Billed')])[1]";
    public static final String Transaction_Cancelbutton ="//span[@translate='FORM_CANCEL_BUTTON']";
    public static final String Deal_AlternateAddress_RadioButton  ="//input[@id='alternateAddress']";
    public static final String Deal_AlternateAddress_AddAddress  ="//div[@class='add']/span[contains(text(),'Add New Address')]";
    public static final String Deal_AlternateAddress_AddAddressbutton  ="(//div[@class = 'add']/i[@ng-click = 'addNew()'])[1]";
    public static final String Deal_AlternateAddress_AlternateAddressLine1  ="//label[@for='alternateAddressLine1']";
    public static final String Deal_AlternateAddress_AlternateAddressLine2  ="//label[@for='alternateAddressLine2']";
    public static final String Deal_AlternateAddress_AlternateAddressLine3  ="//label[@for='alternateAddressLine3']";
    public static final String Deal_AlternateAddress_AlternateCountry  ="//label[@for='alternateCountry']";
    public static final String Deal_AlternateAddress_AlternateCity  ="//label[@for='alternateCity']";
    public static final String Deal_AlternateAddress_AlternateState  ="//label[@for='alternateState']";
    public static final String Orders_ViewEditOrder_CancelButton ="//span[@translate = 'FORM_CANCEL_BUTTON']";
    public static final String ARC_Select_FirstRowCheckBox  ="(//input[@type='checkbox'])[2]";
    public static final String ARC_BulkActionsDropDown  ="//button[contains(text(),'Bulk Actions')]";
    public static final String ARC_BulkActionsPopUp_Continue  ="//button[contains(text(),'Continue')]";
     public static final String Transaction_rentalStartDate_Disabled  ="//input[@id='rentalStartDate']";
    public static final String Transaction_rentalEndDate_Disabled  ="//input[@id='rentalEndDate']";
    public static final String Transaction_Pricelist_Disabled  ="//select[@lookup-name='priceList' and @disabled = 'disabled']";
    public static final String Transaction_ItemCode_Disabled  ="//input[@name='itemCode']";
    public static final String Transaction_RequestDate_Disabled  ="//input[@name='requestDate']";
    public static final String Transaction_BillableYes_Disabled  ="//input[@id='billableYes']";
    public static final String Transaction_LineDescription_Disabled  ="//input[@id='lineDescription' and @disabled='disabled']";
    public static final String Transaction_quantity_Disabled  ="//input[@id='quantity' and @disabled='true']";
    public static final String Transaction_unitOfMeasure_Disabled  ="//select[@lookup-name='unitOfMeasure' and @disabled='disabled']";
   
    public static final String Transaction_transactionType_Disabled  ="//select[@lookup-name='transactionType' and @disabled='disabled']";
    public static final String Transaction_taxYes_Disabled  ="//input[@id='taxYes' and @disabled='true']";
    public static final String ARC_BulkActionsDropDown_Options_MakeNonBillable  ="//a[contains(text(),'Make Non-Billable')]";
    public static final String ARC_BulkActionsDropDown_Options_MakeBillable  ="//a[contains(text(),'Make Billable')]";
    public static final String Transaction_BillableFlag_No  ="//*[@id='billableNo']";
    public static final String Transaction_ApproveandSendBillableTransactions_Confirmpage  ="//div[@class = 'ui-notification confirm-template transaction-action-dialog ng-scope']";
    public static final String Transaction_ApproveandSend_ConfirmPageButton  ="//button[@translate= 'ARC.APPROVE_SEND.SUBMIT']";
    public static final String Transaction_SuccessMessage  ="//div[@class='ui-notification ng-scope success clickable']";
     public static final String Transaction_DeptSystemNumber  ="//label[@for='departmentSystemNumber']";
    public static final String Deal_Search  ="//input[@name='search']";
    public static final String Deal_Vieworderoption_Rightclick  ="//div[@class='intercept-menu-container']//ul//li//a[@ng-click='interceptMenuCtrl.clickAction(menu)' and text()='View Orders']";
    public static final String Orders_Orderstatus  ="//select[@lookup-name= 'orderStatus']";
    public static final String Transaction_Hub_ARC_Suspend = ("//sp-table-view-new/sp-table-new/div/ul/li/a[contains(text(), 'Suspend')]");
    public static final String Transaction_SuspendTransaction_Notes  ="//textarea[@name='notes']";
    public static final String Transaction_SuspendTransaction_SuccessMessage  ="//div[@class='ui-notification ng-scope success clickable']";
    public static final String Transaction_ErrorMessage_ClosedOrder  ="//div[contains(text(),'Order is not open')]";
    public static final String Transaction_SuspendTransaction_WarningMessage  ="//div[@class='alert alert-warning ng-scope']";
    public static final String Transaction_ErrorMessage_WithoutNotes  ="//div[contains(text(),'Please enter a note.')]";
    public static final String Suspensions_Searchbox  ="//input[@name='search']";
    public static final String Suspensions_SuspendedDeal  ="//th[contains(text(),'Deal')]/../../../tbody/tr/td[3]/span/span";
    public static final String Suspensions_SuspendedDeal1  ="(//th[contains(text(),'Deal')]/../../../tbody/tr/td[3]/span/span)[1]";
    public static final String Transaction_sapcostObject_Errormsg  ="//p[@ng-message= 'invalidCostObject']";
    public static final String ARC_SelectAll_Transactions  ="//input[@name='selectAll']";
    public static final String ARC_BulkActionsDropDown_Options_Suspend  ="//a[contains(text(),'Suspend')]";
    public static final String ARC_BulkActionsButton  ="//button[@id='bulkActions']";
    public static final String Exceptions_ClickFirstRow_xp  ="//td[@class='ng-scope departmentSystemNumber'][1]";
    public static final String ARC_ReassignTransactionPage_RemoveDealNumber="(//span[@class='close ui-select-match-close'])[1]";
    public static final String Common_AddEditModules_ListSearchedDealNumber_xp="//span[@class='ui-select-choices-row-inner']/span[2]";
    public static final String Common_AddEditModules_InputSearchOrderNumber_xp = "(//input[@type='search' and @role='combobox'])[2]";
    public static final String Common_AddEditModules_ListSearchedOrderNumber_xp="//span[@class='ui-select-choices-row-inner']/span[2]";
    public static final String ARC_Reassign_DeptSystmTransationInExceptionQue ="//p[contains(text(),'Dept system number(s)  has/have transactions that are in the Exception or Pending Admin Approval queue.')]";
    public static final String ARC_Reassign_DeptSystmTransationInExceptionQue_CancelBuuton = "//button[@translate = 'FORM_CANCEL_BUTTON']";
    public static final String ARC_Select_1stTransactions  ="(//input[@type='checkbox'])[2]";
    public static final String ARC_Select_2ndTransactions  ="(//input[@type='checkbox'])[3]";
    public static final String ARC_BulkActionsDropDown_Options_Unapprove  ="//a[contains(text(),'Unapprove')]";
    public static final String ARC_YesButton_UnApprove  ="//button[contains(text(),'Yes')]";
    public static final String ARC_Approvedlink = "//span[text()='Approved']";
    public static final String ARC_BulkActionsDropDown_Options_Send  ="//a[contains(text(),'Send')]";
    public static final String ARC_BulkActionsDropDown_Options_ApproveandSend  ="//a[contains(text(),'Approve & Send')]";
    
    
  
    public static final String ARC_SelectAllTransactions = "//input[@name='selectAll']";
    public static final String ARC_Reassign_Transactions_Message ="//div[@class='alert alert-warning ng-scope']";
    public static final String ARC_BulkActionsDropDown_Options_Reassign  =" (//a[contains(text(),'Reassign')])[1]";
    public static final String Transaction_ReassignTransactions_Confirmpage  ="//h3[contains(text(),'Reassign Transaction')]";
    public static final String Transaction_ReassignTransactions_RemoveDeal  ="(//span[@ng-click='$selectMultiple.removeChoice($index)'])[1]";
    public static final String Transaction_ReassignTransactions_SearchDeal  ="//input[@placeholder='Search Deal Number and Title']";
    public static final String Transaction_ReassignTransactions_FirstDeal  ="(//div[@role='option'])[1]";
    public static final String Transaction_ReassignTransactions_Removeorder  ="(//span[@ng-click='$selectMultiple.removeChoice($index)'])[2]";
    public static final String Transaction_ReassignTransactions_SearchOrder  ="//input[@placeholder='Search Order Number']";
    public static final String Transaction_ReassignTransactions_FirstOrder  ="(//div[@role='option'])[1]";
    public static final String Draft_billing_CreateButton  ="//button[contains(text(),'Create')]";
    
    public static final String Suspensions_ReassignandMovetoARC  ="(//a[contains(text(),'Reassign & Move to ARC')])[1]";
    public static final String Exceptions_Addbutton_FirstRow_xp  ="(//i[@data-toggle='collapse'])[1]";
    public static final String Exceptions_FirstRow_Addbutton_xp  ="(//td[@ng-click='options.onClick(row)'])[13]";
    public static final String Exceptions_RequestDate ="//input[@name='requestDate']";
   public static final String Administration_Roles_DealUser_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[1]";
    public static final String Administration_Roles_DepartmentAdmin_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[2]";
    public static final String Administration_Roles_DepartmentBilling_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[3]";
    public static final String Administration_Roles_DepartmentProjectAdmin_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[4]";
    public static final String Administration_Roles_FinanceAdmin_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[5]";
    public static final String Administration_Roles_FinanceUser_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[6]";
    public static final String Administration_Roles_ReportingUser_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[7]";
    public static final String Administration_Roles_SphereAdmin_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[8]";
    public static final String Administration_Roles_UnnamedRole_Invoice_StatementReversal  ="(//div[contains(text(),'Invoice/Statement Reversal')])[9]";
    public static final String ARC_Firstdeal  ="(//p[@class='ng-binding'])[2]";
    public static final String ARC_FirstdealName  ="(//p[@class='ng-binding'])[3]";
    
    
    public static final String ARC_InvoiceFormat_Mousehover  ="//i[@uib-tooltip='Can not change invoice format because there are transactions in Exception, Pending Admin Approval, ARC, and/or Draft Billing.']";
    public static final String Transaction_InvoiceFormat_Disabled  ="//select[@name='invoiceFormat' and @disabled = 'disabled']";
    public static final String Deals_cancel_button  ="(//span[@translate = 'FORM_CANCEL_BUTTON'])[4]";
    public static final String Exceptions_Firstdeal  ="(//td[@class='ng-scope order-deal-dealNumber'])[1]";
    public static final String Suspensions_Firstdeal  ="(//td[@ng-repeat='column in options.visibleColumns'])[2]";
    public static final String ARC_RevenueTax_Firstcolumn  ="(//td[@class='ng-binding'])[4]";
    public static final String ARC_Cost_Firstcolumn  ="//td[@class='ng-binding ng-scope']";
    public static final String ARC_TotalRevenueTax  ="(//div/div/div/div[@class='ng-binding'])[2]";
    public static final String ARC_TotalCost  ="(//div/div/div/div[@class='ng-binding'])[3]";
    public static final String Deals_FirstDeal  ="(//td[@ng-click='options.onClick(row)'])[1]";
    public static final String Deals_ViewOrder  ="//a[contains(text(), 'View Orders')]";
    public static final String Orders_Tablelist_Taxnotfound  ="(//table/thead/tr/th[contains(text(), 'Tax')])[2]";
    public static final String Orders_Tablelist_Taxnotfound_Righttable  ="(//table/thead/tr/th[contains(text(), 'Tax')])[1]";
    public static final String DraftBilling_RecievingContacts_ibutton  ="(//i[@tooltip-placement='right-top'])[3]";
    public static final String DraftBilling_Edit_Title_DirectChargsSummary_xp ="//div[contains(text() , 'Direct Charge Summary')]";
    public static final String DraftBilling_Draft_DCS_Summary_Field ="//label[contains(text() , 'Draft DCS Summary')]";
    public static final String Billing_DraftBilling_Edit_Create_Disabled ="//button[contains(text(), 'Create') and @disabled='disabled']";
    public static final String DraftBilling_Exitpage ="//i[@ng-click='sideviewModal.confirmFormExit()']";
    public static final String Arc_Reassign_FailureMessage ="//div[contains(text(), 'Failed! The transaction has not been moved.')]";
    public static final String Orders_Costplus_CancelButton = "(//a[@class='btn leftButton']/span[text()='Cancel'])[2]";
    public static final String ARC_view_Edit_transaction  =" (//a[contains(text(),'View/Edit Transaction')])[1]";
    public static final String Orders_Costplus_Close ="(//i[@ng-click='sideviewModal.confirmFormExit()'])[2]";
    public static final String Deal_SearchBox ="//input[@placeholder = 'Search ...']";
    public static final String Deal_CopyOrders ="//button[contains(text(), 'Copy Orders')]";
    public static final String Deal_CopyOrders_DealToCopy ="//input[@type= 'search' and @placeholder= 'Search Deal Number and Title']";
    public static final String Deal_CopyOrders_DealToCopy_FirstRow ="//ul[@repeat='item in CopyOrdersDialog.dealResults']";
    public static final String Deal_CopyOrders_OrdersToCopy_FirstRow ="//div/ul/li/input[@type='checkbox']";
    public static final String Deal_CopyOrders_ContinueButton ="//button[contains(text(), 'Continue')]";
    //public static final String Deal_First_Deal ="(//td[@ng-click='options.onClick(row)'])[1]";
    public static final String Deal_FirstDeal_ViewOrders ="//a[contains(text() ,'View Orders')]";
    public static final String ARC_Screen_Order_list_1_uploadFile ="(//div[@class='row ng-isolate-scope'])[2]/following-sibling::ul/li";
    public static final String ARC_View_Edit_Transaction_Remove_Costcenter = "//span[@ng-click = '$selectMultiple.removeChoice($index)']";
    public static final String ARC_View_Edit_Transaction_Costcenter = "//span[@placeholder= 'Select a cost center...']";
    public static final String Transaction_AddEditTransaction_Save_Btn_xp = "//button[@class='btn rightButton ng-scope' and @translate='FORM_SAVE_BUTTON']";
    public static final String ARC_Screen_Split_Percentage1 = "//input[@id='1-percent']";
    public static final String ARC_Screen_Split_Percentage2 = "//input[@id='2-percent']";
    public static final String ARC_Screen_Split_popUp_Button = "//button[contains(text(),'Split')]";
    public static final String ARC_BulkActionsDropDown_Options_NonBillable  ="(//a[contains(text(),'Non-Billable')])[2]";
    public static final String ARC_NonBillable_Notes  ="//textarea[@name= 'notes']";
    public static final String ARC_NonBillable_Continue  ="//button[contains(text(), 'Continue')]";
    public static final String Exception_SaveButton  ="//button[contains(text(), 'Save')]";
    public static final String Exception_DealSaveButton  ="(//button[contains(text(), 'Save')])[4]";
    public static final String Deals_UpdateDeal_SaveButton  ="(//button[contains(text(), 'Save')])[5]";
    
    
    public static final String Transaction_FinalBilled_Status ="(//span[contains(text(),'Final Billed')])[2]";
    public static final String Add_Order_Purpose  ="//textarea[@name='purpose']";
    public static final String Exception_ClickOnOrder ="(//tbody/tr/td[6])[1]";
    public static final String ARC_DepartmentalNo ="//label[contains(text(), 'Department System #')]/../div";
    public static final String ARC_CancelButton ="(//i[@ng-click='sideviewModal.confirmFormExit()'])";
    public static final String Exception_ClickOnCredit ="(//tbody/tr/td[13])[1]";
    public static final String Exception_ClickOnCredit_Transactions ="(//tbody/tr/td[13])[2]";
    public static final String Exception_ClickOnCashFlag ="(//tbody/tr/td[12])[1]";
    public static final String Exception_ClickOnOrderDosNotExist ="(//tbody/tr/td[6])";
    public static final String Exception_ClickOnOrderNotOpen ="(//tbody/tr/td[4])[1]";
    
     
    
    
    public static final String Exception_Transaction_CreditReason ="//select[@name='creditReason']";
    public static final String Orders_CostCentre_Disabled ="//input[@type='search' and @role='combobox' and @disabled = 'disabled']";
    public static final String Orders_OrderPurpose_Disabled ="//textarea[@name= 'purpose' and @disabled = 'disabled']";
    public static final String Orders_OrderDescription ="//input[@name= 'orderDescription']";
    public static final String Orders_OrderPOnumber ="//input[@name= 'orderPoNumber']";
    public static final String Orders_Location ="//input[@name= 'location']";
    public static final String Orders_episode ="//input[@name= 'episode']";
    public static final String Transaction_CashFlag  ="//select[@name='cashSaleIndicator']";
    public static final String ARC_Splitstatus ="(//span[contains(text(), 'Split')])[2]";
    public static final String Deal_ViewTransactions = ("//a[contains(text(), 'View Transactions')]");
    public static final String Transaction_View_Edit_Trasaction_Revenue_Costnumber = ("//label[contains(text(),'Revenue/Cost Account #')]");
    public static final String Transaction_billableNo = ("//input[@id='billableNo']");
    public static final String Transaction_billable = ("(//a[contains(text(),'Billable')])[3]");
    public static final String Transaction_billable_Continue = ("//button[contains(text(),'Continue')]");
    public static final String Transaction_billable_ApproveandSendPopup = ("//button[contains(text(),'Approve & Send')]");
    public static final String Reports_WinRecon_FringeDifference = ("//div/a[contains(text(), 'Fringe Difference')]/../../div[2]");
    public static final String Reports_WinRecon_FringeDifference_Header = ("//div/a[contains(text(), 'Fringe Difference')]");
    public static final String Reports_WipFringeDifference_Week_End_Date_Filter = ("//li[contains(text(), 'Week End Date')]");
    public static final String Reports_WipFringeDifference_Week_End_Date_Filter_Date =("(//div/div/div/ul/li/span[@class='ng-binding'])[1]");
    public static final String Reports_WipFringeDifference_Week_End_Date_Filter_Date2 =("(//div/div/div/ul/li/span[@class='ng-binding'])[2]");
    public static final String Reports_WipFringeDifference_Week_End_Date_Filter_Date_Checked = ("(//div/div/div/ul/li/span[@class='fa fa-check-square'])[1]");
    public static final String Reports_WipFringeDifference_Week_End_Date_Filter_Date2_Checked = ("(//div/div/div/ul/li/span[@class='ng-binding'])[2]");
    
    
    
    public static final String Transactions_ReferenceNumber = ("//input[@type='text' and @id= 'referenceInvoiceNumber']");
    public static final String Administration_Users_Roles = ("//th[contains(text(),'Role')]");
    public static final String Administration_Users_Department = ("//th[contains(text(),'Department')]");
    public static final String Customers_ParentCompany = ("//th[contains(text(),'Parent Company')]");
    public static final String Deals_Project_or_Production = ("//th[contains(text(),'Project or Production')]");
    public static final String Deals_Customer = ("//th[contains(text(),'Customer')]");
    public static final String Deals_CustomerType = ("//th[contains(text(),'Customer Type')]");
    public static final String Deals_CostCenter = ("//th[contains(text(),'Cost Center')]");
    public static final String Transaction_Details_Order = ("//th[contains(text(),'Order')]");
    public static final String Transaction_Details_PerfCC = ("//th[contains(text(),'Perf CC')]");
    public static final String Transaction_Details_InvoiceStatement = ("//th[contains(text(),'Invoice/Statement #')]");
    public static final String Transaction_Currentmonth_Deal = ("//th[contains(text(),'Deal')]");
    public static final String Transaction_Exceptions_DealMngCC = ("//th[contains(text(),'Deal Mng CC')]");
    public static final String Transaction_Exceptions_PerformingCC = ("//th[contains(text(),'Performing CC')]");
    public static final String Invoicestatement_Customer = ("//th[contains(text(),'Customer')]");
    public static final String Invoicestatement_Title = ("//th[contains(text(),'Title')]");
   
    public static final String Suspensions_Deal = ("(//th[contains(text(),'Deal')])[1]");
    public static final String Transactions_Currentmonth_Revenue_Expenses = ("//span[contains(text(),'Current Month ')]");
    public static final String Transactions_Details_Reverse = ("//button[contains(text(),'Reverse')]");
    public static final String Transactions_Details_Reverse_InvoiceStatement_Reversal = ("//a[contains(text(),'Invoice/Statement Reversal')]");
    //public static final String Transactions_Details_Deal_Search = ("//li[contains(text(),'Deal')]");
    public static final String Transactions_Details_Deal_Search = ("//li[contains(text(),'Deal')]/span");
    public static final String Transactions_Details_Reverse_Popup = ("(//button[contains(text(),'Reverse')])[1]");
    public static final String Transactions_Details_Deal_Searchbox = ("//input[@placeholder='Search Deal...']");
    public static final String Transactions_Details_Deal_Searchbox_FirstRow = ("(//span[@class='small ng-binding ng-scope'])");
    public static final String Orders_CostPlus_1xxlabor_defaultpercent = ("(//td[@class='sourceCodeGroupDefault ng-binding'])[1]");
    public static final String Orders_CostPlus_51XAP_defaultpercent = ("(//td[@class='sourceCodeGroupDefault ng-binding'])[2]");
    public static final String Orders_CostPlus_JournalEntries_defaultpercent = ("(//td[@class='sourceCodeGroupDefault ng-binding'])[3]");
    public static final String Deals_Customers_Edit_Pencilsign = ("(//a/span[@class='fa fa-pencil fa-lg ng-scope'])[1]");
    public static final String Customers_SaveButton = ("(//button[contains(text(), 'Save')])[6]");
    public static final String Orders_CostObect = ("//input[@id='costObject']");
    public static final String Orders_SAPAccount = ("//input[@id='accountNumber']");
    public static final String Orders_CostObect_ImvalidCostobject = ("//p[contains(text(),'Cost Object Invalid')]");
    public static final String DraftBilling_AddAccount = ("//h4[@class='add-account-button nbc-blue-text cursor-pointer-on-hover ng-scope']");
    public static final String DraftBilling_CostObect = ("//input[@id='costObject']");
    public static final String DraftBilling_SAPAccount = ("//input[@id='accountNumber']");
    public static final String DraftBilling_SendtoARC_Bulkactions = ("//a[contains(text(),'Send To Arc')]");
    public static final String DraftBilling_SendtoARC_Popup = ("//h3[@translate='TRANSACTIONS.SEND_TO_ARC.DIALOG.TITLE']");
    public static final String DraftBilling_SendtoARC_Popup_MoveButton = ("//button[contains(text(),'Move')]");
    public static final String DraftBilling_SendBacktoARC_SuccessMessage = ("//div[contains(text(),'Success! The transactions are moved back to ARC')]");
    public static final String Billing_DraftBilling_Delete_SendToARC=("(//div[@class='intercept-menu-container']/ul/li/a[@ng-click='interceptMenuCtrl.clickAction(menu)'])[2]");
    public static final String Billing_DraftBilling_Create_Invoice=("//button[@type='button' and contains(text(),'Create')]");
    public static final String Arc_Transaction_Save=("//button[contains(text(),'Save')]");
    public static final String Arc_Split_Success_message=("//div[contains(text(),'Transaction successfully split')]");
    public static final String Arc_Split_OriginStatus=("(//span[contains(text(),'Split')])[2]");
    public static final String WipRecon_Summary_Search=("//button[contains(text(),'Search')]");
    
    public static final String WipRecon_Summary_validateButton=("//button[contains(text(),'Validate')]");
    public static final String WipRecon_Summary_Next_Period_Adjustments=("//div[contains(text(),'Next Period Adjustments')]");
    public static final String Exception_Transaction_sapTerritory =("//input[@name='sapTerritory']");
    public static final String Exception_Transaction_Costobject_Invalid =("//p[contains(text(),'Cost Object Inactive')]");
    public static final String Exception_Transaction_Error_message =("//div[contains(text(),'Oops! Please complete and correct all the required fields')]");
    public static final String Suspensions_System_filter =("//li[contains(text(),'System')]");
    public static final String Suspensions_System_filter_SAP =("//li/span[contains(text(),'SAP')]");
    public static final String Suspensions_Rightclick_MoveToSAP =("(//a[contains(text(),'Move to SAP')])[3]");
    public static final String Suspensions_MoveToSAP_Popup =("//h3[contains(text(),'Move Non-labor Transaction to SAP')]");
    public static final String Suspensions_MoveToSAP_Popup_Confirm=("//button[contains(text(),'Confirm')]");
    public static final String Suspensions_MoveToSAP_Successmessage=("//div[contains(text(),'Success! The transaction has been moved to SAP.')]");
    public static final String Suspensions_Source_Code_Group_filter =("//li[contains(text(),'Source Code Group')]");
    public static final String Suspensions_Source_Code_Group_Labor =("//li/span[contains(text(),'1XX - Labor')]");
    public static final String Suspensions_MoveToSAP_Popup_Confirm_LaborAndFringe_TotalAmount =("//div/ng-form/div/label[contains(text(),'Total Amount')]");
    public static final String Suspensions_MoveToSAP_Popup_Labor_Fringe =("//span[contains(text(),'Labor & Fringe')]");
    public static final String DratfBilling_SapAccountnumber_AddAccount =("(//div/div/div/div/h4)[3]");
    public static final String Transaction_sapcostObject1  ="(//input[@id='costObject'])[2]";
    public static final String Transaction_sapaccountNumber1  ="(//input[@id='accountNumber'])[2]";
    public static final String Transaction_sapIndicator1  ="(//select[@lookup-id='sapIndicator'])[2]";
    public static final String Exception_Transaction_sapTerritory1 ="(//input[@name='sapTerritory'])[2]";
    public static final String DraftBilling_Percentage1 ="(//div/div/label[contains(text(),'%')]/../input)[2]";
    public static final String DraftBilling_Percentage ="(//div/div/label[contains(text(),'%')]/../input)[1]";
    public static final String Transaction_Costcenter ="(//span/span[@class='ng-scope'])[4]";
    public static final String InvoiceStatement_Status_Filter =("//li[contains(text(),'Status')]");
    public static final String InvoiceStatement_Status_Filter_FinalBilled =("//li/span[contains(text(),'Final Billed')]");
    public static final String InvoiceStatement_Status_Filter_Ready_to_Bill =("//li/span[contains(text(),'Ready to Bill')]");
    public static final String InvoiceStatement_BulkActions_Email_Original_To_Customer =("//a[contains(text(),'Email Original To Customer')]");
    public static final String InvoiceStatement_BulkActions_Email_Original_To_Me =("//a[contains(text(),'Email Original To Me')]");
    public static final String InvoiceStatement_BulkActions_Email_Reprint_To_Customer =("//a[contains(text(),'Email Reprint To Customer')]");
    public static final String InvoiceStatement_BulkActions_Email_Reprint_To_Me =("//a[contains(text(),'Email Reprint To Me')]");
    public static final String InvoiceStatement_BulkActions_Disabled =("//button[@class = 'btn btn-default dropdown-toggle ng-binding disabled']");
    public static final String WipRecon_Search_Table =("//div[@ng-if='wipRecon.totals']");
    public static final String Transactions_Submenu  ="//span[contains(text(),'Transactions')]";
    public static final String Transactions_CurrentMonth_Status_Approved  ="//li/span[contains(text(),'Approved')]";
    public static final String Transactions_CurrentMonth_Status_Draft_Billed  ="//li/span[contains(text(),'Draft Billed')]";
    public static final String Transactions_CurrentMonth_Status_Exception  ="//li/span[contains(text(),'Exception')]";
    public static final String Transactions_CurrentMonth_Status_Final_Billed  ="//li/span[contains(text(),'Final Billed')]";
    public static final String Transactions_CurrentMonth_Status_History  ="//li/span[contains(text(),'History')]";
    public static final String Transactions_CurrentMonth_Status_Match_And_Delete  ="//li/span[contains(text(),'Match And Delete')]";
    public static final String Transactions_CurrentMonth_Status_Pending_Admin_Approval  ="//li/span[contains(text(),'Pending Admin Approval')]";
    public static final String Transactions_CurrentMonth_Status_Rejected  ="//li/span[contains(text(),'Rejected')]";
    public static final String Transactions_CurrentMonth_Status_SAP_Pending  ="(//li/span[contains(text(),'SAP Pending')])[1]";
    public static final String Transactions_CurrentMonth_Status_SAP_Pending_ARC  ="//li/span[contains(text(),'SAP Pending (ARC)')]";
    public static final String Transactions_CurrentMonth_Status_Suspended  ="//li/span[contains(text(),'Suspended')]";
    public static final String Transactions_CurrentMonth_Status_Unapproved  ="//li/span[contains(text(),'Unapproved')]";
    public static final String Transactions_CurrentMonth_Status_BookedtoSAP  ="//th[contains(text(),'Booked to SAP')]";
    public static final String Transactions_CurrentMonth_Status_FinalBilledNotBooked  ="//th[contains(text(),'Final Billed Not Booked')]";
    public static final String Transactions_CurrentMonth_Status_Unbilled  ="//th[contains(text(),'Unbilled')]";
    public static final String Transactions_CurrentMonth_Status_NonBillableRevenue  ="//th[contains(text(),'Non Billable Revenue')]";
    public static final String Transactions_Reference_InvoiceNumber  ="//label[contains(text(),'Reference Invoice Number')]";
    public static final String Transactions_Reference_InvoiceNumber_Text  ="//input[@name = 'referenceInvoiceNumber']";
    public static final String Transactions_Details_Reverse_InvoiceStatementReversal_Disabled  ="//a[@ng-click='tableReversalActionsCtrl.isDisabled(action) || tableReversalActionsCtrl.clickAction(action)' and contains(text(),'Invoice/Statement Reversal')]";
    
    public static final String Transactions_CurrentMonth_Status_WIP_Upload_Pending  ="//li/span[contains(text(),'WIP Upload Pending')]";
    public static final String InvoiceStatement_MngCC_Filter =("//li[contains(text(),'Mng CC')]");
    public static final String InvoiceStatement_PerfCC_Filter_SetLightingCA =("(//div/div/ul/li/span[contains(text(),'SET LIGHTING - CA')])[1]");
    public static final String InvoiceStatement_PerfCC_Filter =("//li[contains(text(),'Perf CC')]");
    public static final String FiscalView_PerfCC_SetLighting_CA =("//span[contains(text(),'SET LIGHTING - CA')]");
    public static final String FiscalView_PerfCC_SetLighting_PA =("//span[contains(text(),'SET LIGHTING - PA')]");
    public static final String FiscalView_PerfCC_DUMPSTERS =("//span[contains(text(),'DUMPSTERS')]");
    public static final String FiscalView_PerfCC_GRIP_PA =("//span[contains(text(),'GRIP - PA')]");
    
    public static final String Transactions_CurrentMonth_firstrow_Status = ("(//td[@ng-click='options.onClick(row)'])[14]");
    public static final String Transactions_DetailPage_Status_Approved_Checked = ("//span[@class='fa fa-check-square']/../span[contains(text(),'Approved')]");
    public static final String Transactions_DetailPage_Status_Approved_UnChecked = ("//span[@class='fa fa-square-o']/../span[contains(text(),'Approved')]");
    public static final String Transactions_DetailPage_Status_Exception_Checked = ("//span[@class='fa fa-check-square']/../span[contains(text(),'Exception')]");
    public static final String Transactions_DetailPage_Status_Exception_UnChecked = ("//span[@class='fa fa-square-o']/../span[contains(text(),'Exception')]");
    public static final String Transactions_DetailPage_Status_PendingAdminApproval_Checked = ("//span[@class='fa fa-check-square']/../span[contains(text(),'Pending Admin Approval')]");
    public static final String Transactions_DetailPage_Status_PendingAdminApproval_UnChecked = ("//span[@class='fa fa-square-o']/../span[contains(text(),'Pending Admin Approval')]");
    public static final String Transactions_DetailPage_Status_Final_Billed = "(//span[@class='fa fa-check-square'])[2]";
    public static final String Transactions_DetailPage_Status_PendingAdminApproval = "(//span[@class='fa fa-check-square'])[3]";
    public static final String Transactions_DetailPage_Status_Exception_Unchecked = "(//span[@class='fa fa-square-o'])[8]";
    public static final String FiscalView_Filter =("//button[contains(text(),'Filter')]");
    public static final String FiscalView_Startmonth_Filter =("(//div/select)[1]");
    public static final String FiscalView_Endmonth_Filter =("(//div/select)[3]");
    public static final String Administration_UseAll_Checkbox =("//div/label/input[@class='ng-pristine ng-untouched ng-valid ng-not-empty']");
    public static final String FiscalView_TotalTable =("//sp-table-filters/../ng-transclude/div");
    
    public static final String Reports_WipRecon_FringeDifference_Indicator_A = ("(//td/span/span[contains(text(),'A')])[1]");
    public static final String Reports_WipRecon_FringeDifference_Indicator_K = ("(//td/span/span[contains(text(),'K')])[1]");
    public static final String Reports_WipRecon_FringeDifference_Book_Button = ("//button[contains(text(),'Book')]");
    public static final String Reports_WipRecon_FringeDifference_BookButton_Popup = ("//h3[contains(text(),'Book Correction Records')]");
    public static final String Reports_CancelButton = ("//button[contains(text(),'Cancel')]");
    public static final String ARC_Screen__ApproveAndSend_Popup_Title_xp="//h3[@translate='ARC.APPROVE_SEND.TITLE']";
    public static final String ARC_RightClick_Approve = "//a[text()='Approve']";
  
  
    public static final String Transactions_RevenueAmount_Righttable = ("(//tbody/tr/td)[1]");
    public static final String Transactions_CostAmount_Righttable = ("(//tbody/tr/td)[2]");	 
    public static final String Transactions_MarginAmount_Righttable = ("(//tbody/tr/td)[3]");
    public static final String Administration_Users_Roles_firstrow = ("(//td[@ng-click='options.onClick(row)'])[6]");
    public static final String Administration_Users_Roles_Department = ("(//td[@ng-click='options.onClick(row)'])[7]");
    public static final String Customers_ParentCompany_firstrow = ("(//td[@ng-click='options.onClick(row)'])[5]");
    public static final String Deals_Project_or_Production_firstrow = ("(//td[@ng-click='options.onClick(row)'])[3]");
    public static final String Deals_Customer_firstrow = ("(//td[@ng-click='options.onClick(row)'])[4]");
    public static final String Deals_CustomerType_firstrow = ("(//td[@ng-click='options.onClick(row)'])[5]");
    public static final String Deals_CostCenter_firstrow = ("(//td[@ng-click='options.onClick(row)'])[7]");
    public static final String Rejection_DealMngCC_firstrow = ("(//td[@ng-click='options.onClick(row)'])[8]");
    public static final String Rejection_PerfCC_firstrow = ("(//td[@ng-click='options.onClick(row)'])[9]");
    public static final String Suspensions_Deal_firstrow = ("(//td[@ng-click='options.onClick(row)'])[2]");
    public static final String InvoiceStatement_Status_ReadyToBill = ("(//td[@ng-click='options.onClick(row)'])[12]");
    public static final String InvoiceStatement_Checkbox = ("(//input[@type='checkbox'])[2]");
    public static final String FiscalView_FirstRow = ("(//td[@ng-click='options.onClick(row)'])[1]");
    public static final String Transactions_Details_Second_Transaction = ("(//td[@ng-click='options.onClick(row)'])[15]");
    public static final String Suspensions_SourceCode = ("//th[contains(text(),'Source Code')]");
    public static final String Deal_InvoiceFormat_MouseHover = ("//i[@uib-tooltip = 'Can not change invoice format because there are transactions in Exception, Pending Admin Approval, ARC, and/or Draft Billing.']");
	public static final String Exceptions_SelectCashFlag="cashSaleIndicator";
	public static final String Exceptions_SelectDealOpen="dealStatus";
	public static final String Exceptions_SelectOrderOpen="orderStatus";
	public static final String InvoiceStatement_FinalBilled_Status = ("//span/span[contains(text(),'Final Billed')]");	 
	public static final String DealPage_AddCustomerButton = ("//span[contains(text(), 'Add New Customer')]/../i");	 
	public static final String DealPage_AddCustomer_addressLine2 = ("//input[@name='addressLine2']");	 
	public static final String DealPage_AddCustomer_Country = ("//select[@name='country']");	 
	public static final String DealPage_AddCustomer_City = ("//input[@name='city']");	 
	public static final String DealPage_AddCustomer_state = ("//select[@name='state']");	 
	public static final String DealPage_AddCustomer_zip = ("//input[@name='zip']");	 
	public static final String DealPage_AddCustomer_creditLimit = ("//input[@name='creditLimit']");
	public static final String DealPage_AddCustomer_alternateRadio = ("//input[@name='alternateRadio']");
	public static final String QueueLogging_Deal_Status="//table[@class='table table-striped']/tbody/tr/td[2]/span/span";
	public static final String QueueLogging_DealSystemName="//table[@class='table table-striped']/tbody/tr/td[6]/span/span";

	
	public static final String Deals_CostCenterFilter="//div[@class='filter-titles rounded-bottom']/ul/li[6]";
	public static final String Deals_CostCenterFilter_SelectCostCenter="(//span[contains(text(),'265 STUDIO POST')]/../span)[1]";
	public static final String Deals_DealNumber="(//table[@class='table table-striped']/tbody/tr/td[2]/span/span)[1]";
	public static final String Deals_CustomerNumber="//label[@translate='DEALS.DEAL_FORM.CUSTOMER_LABEL']/../div/div/div[3]/div[2]/span/span[2]";
	public static final String Deals_CustomerTitle="(//table[@class='table table-striped']/tbody/tr/td[5]/span/span)[1]";
	public static final String Deals_DealTitle="(//table[@class='table table-striped']/tbody/tr/td[3]/span/span)[1]";
	public static final String Deals_CostCenterFilter_SelectCostCenter_280="(//span[contains(text(),'280 STAGE & BACKLOT OPERATIONS')]/../span)[1]";
	public static final String Deals_Open_Deals="//span[contains(text(),'Open')]";
	public static final String Deals_DealType="//select[@name='dealType']";
	public static final String Deals_CostCenterFilter_SelectCostCenter_434="(//span[contains(text(),'434 SPECIAL EVENTS')]/../span)[1]";
	public static final String Deals_CostCenterFilter_SelectCostCenter_368="(//span[contains(text(),'368 MARKETING')]/../span)[1]";
	public static final String Deals_CostCenterFilter_SelectCostCenter_265="(//span[contains(text(),'265 STUDIO POST')]/../span)[1]";
	public static final String Deals_CostCenterFilter_SelectCostCenter_240="(//span[contains(text(),'240 OFFICE SERVICES')]/../span)[1]";
	public static final String WipRecon_WipInARC_DraftBill="//a[contains(text(),'WIP in ARC & Draft Bill')]";
	public static final String Deal_NewCustomer_Number="//div/span/span[@class='small ng-binding']";
	public static final String Orders_WipChargeMethod_Options="//option[@label='Cost Plus']/../option[@label='Fixed Rate']";
	public static final String Orders_WipChargeMethod_Disabled_FixedRate="//select[@disabled='disabled']/option[@label='Fixed Rate' and @selected='selected']";
	public static final String Orders_WipChargeMethod="//select[@name='wipChargeMethod']";
	public static final String Transactions_DepartmentalSystemnumber ="//label[@for = 'departmentSystemNumber']";
	public static final String Administration_ssoidfilter_descendingOrder ="//th[contains(text(),'SSO')]/i";
	 public static final String ARC_unapproved_cost  ="(//table[@class='table table-striped'])[1]/tbody/tr/td[3]";
	 public static final String ARC_unapproved_revenue  ="(//table[@class='table table-striped'])[1]/tbody/tr/td[2]";
	 public static final String ARC_est_amount  ="(//table[@class='table table-striped'])[1]/tbody/tr/td";
	 public static final String Transactions_PerformingCC="(//span[@class='ng-binding ng-scope'])[6]";
	 public static final String Administration_LoggedInUser_xp="//a[@class='dropdown-toggle ng-binding']";
	 public static final String Users_Advanced_PerformingCC="//label[contains(text(),'Performing Cost Centers')]/../div[3]/div/div/div/span/span/span/span[2]/span";
	 public static final String Users_Advanced_xp="//a[contains(text(),'ADVANCED')]";
	
	 public static final String Rejections_DepartmentSystemNumber="//*[@id='accordion-table']/tbody/tr/td[2]/span";
	 public static final String Deals_AddDeal_BtnResend="(//button[contains(text(),'Save')])[4]";
	 public static final String Arc_ViewTransaction_Save="(//button[contains(text(),'Save')])[2]";
	 public static final String ARC_Screen_BulkOptions_SelectFirstDeal="(//table[@class='table table-striped']//tr/td/input)[1]";
	 public static final String ARC_Screen_BulkOptions_SelectAll="//table[@class='table table-striped']//tr/th/input";
	 public static final String ARC_Screen_Approved_BulkOption_MatchAndDelete_xp="//table[@class='table table-striped']//tr/th/input";
	 public static final String ARC_Screen_Approved_BulkOption_MatchAndDelete_xp1="//a[contains(text(),'Match & Delete')]";
	 public static final String ARC_Screen_Approved_BulkOption_emailoriginaltome="//a[contains(text(),'Email Original To Me')]";
	 
	 public static final String ARC_SelectAll="//input[@name='selectAll']";
	 public static final String ARC_RightClick_RejectOption="//a[contains(text(),'Reject')]";
	 public static final String Suspense_Screen_SAP_MoveToSAP_ConfirmBtn="//button[contains(text(),'Confirm')]";
	 public static final String Arc_SuspendTransactions_Cancel="//button[contains(text(),'Cancel')]";
		public static final String ARC_Screen_MatchAndDeleteTransactionForm_Title_xp="//h3[contains(text(),'Match & Delete Transaction')]";
	public static final String ARCScreen_MatchAndDeleteTransactionSuccessMessage="//div[contains(text(),'Match & Delete Successful.')]";
	public static final String ARC_Screen_MatchAndDeleteTransactionFailureMessage="//div[contains(text(),'Match & Delete failed.')]";
	public static final String ARC_Transaction_MatchAndDeleteAccordian_Table_xp="(//table[@class='table table-striped']//tr)[1]";
	public static final String ARC_Transaction_MatchAndDeleteAccordian_Table_xp_Failure="(//table[@class='table table-striped']//tr)[1]/th";
	public static final String ARC_Transaction_MatchAndDeleteAccordian_TableDetails_xp="(//table[@class='table table-striped']//tbody/tr)[1]";
	public static final String ARC_Transaction_MatchAndDeleteAccordian_TableDetails_xp_Failure="(//table[@class='table table-striped']//tbody/tr)[1]/td";
	public static final String ARC_Transaction_MatchAndDeleteAccordian_TableDetails_OK_Btn="//button[contains(text(),'OK')]";
	public static final String Billing_DraftBilling_createImmediate_PopUp_Name="//div[contains(text(),'Are you sure you want to create an immediate invoice?')]";
	public static final String DraftBilling_DETDeal_Immediate_SuccessMessage="//div[contains(text(),'Success!')]";
	public static final String Deals_costcenter_filter="//li[contains(text(),'Cost Center')]";
	public static final String Deals_costcenter_Select240CCfilter="(//span[contains(text(),'240')]/../span)[1]";
	
	
	public static final String Deals_costcenter_Selectfilter="(//span[contains(text(),'208 SET LIGHTING - CA')]/../span)[1]";
	public static final String Exception_Transaction_SapAccountNumber_Invalid="//p[contains(text(),'Account Number Invalid')]";
	public static final String Suspensions_SourceCodeGroup_filter="//li[contains(text(),'Source Code Group')]";
	public static final String Suspensions_System_filter_JournalEntries="//span[contains(text(),'81X - Journal Entries')]";
	public static final String Users_AddUser_ComboRole_xp1="//select[@name='role']";
	public static final String ARC_SaveBtn="//button[contains(text(),'Save')]";
	public static final String LoggedInDropDowm="//a[@role='button']/span";
	public static final String logoutButton="//a[contains(text(),'Log Out')]";
	public static final String Rejections_DateFilter="(//span[@ng-bind-html='option.name | translate'])[2]";
	public static final String Rejections_DateFilterRemovePill="(//span[@class='fa fa-close ng-scope'])[2]";
	public static final String Exceptions_DepartmentSystemNumber="//*[@id='accordion-table']/tbody/tr/td[3]/span";
	public static final String Exceptions_ExpandOnPlusSign="//*[@id='accordion-table']/tbody/tr[1]/td[2]/div/i";
	public static final String InvoiveStatement_Inquiry_SlideOut_Customer = "(//span[@class='synopsis-description ng-binding'])[1]";
	 public static final String InvoiveStatement_Inquiry_SlideOut_Deal = "(//span[@class='synopsis-description ng-binding'])[2]";
	    public static final String InvoiveStatement_Inquiry_SlideOut_BillingAddress = "//div[@class='address form-box']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_InvoiceDescription = "//input[@ng-model='EditDraftBill.draftBill.invoiceName']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_DeliveryMethod = "//select[@ng-disabled='(disableField || disabled)']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_InvoiceReceivingContacts = "//p[@ng-repeat='contact in EditDraftBill.draftBill.getReceivingContacts()']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_dcsInvoiceReceivingContacts = "//p[@ng-repeat='contact in EditSummaryBill.draftBill.getReceivingContacts()']";
	    public static final String Exceptions_ViewTransactionsTransactionType="//label[@class='required']";
	    public static final String InvoiveStatement_Inquiry_Status1="//th[contains(text(),'Status')]/../../../tbody/tr/td[13]/span/span";
	    public static final String InvoiveStatement_Inquiry_SlideOut_SAPAccountNumbersCaretDown = "//i[@class='fa fa-caret-right']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_SAPAccountNumbers_CostObject = "//*[@id='costObject']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_SAPAccountNumbers_SAPAccountNumber = "//*[@id='accountNumber']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_SAPAccountNumbers_SAPIndicator = "//*[@id='sapIndicator']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_SAPAccountNumbers_SAPTerritory = "//*[@id='sapTerritory']";
	    public static final String InvoiveStatement_Inquiry_SlideOut_SAPAccountNumbers_CompanyCode = "//select[@name='sapCompany']";
	public static final String   Transactions_PoNumber_Disabled="//*[@id='poLineNumber']";
		public static final String   Administration_Roles_Billing_Invoice="(//div[contains(text(),'Billing')])[2]/../following-sibling::div/div";
		public static final String   Administration_Roles__DefunctProjectAdmin_Billing_Invoice="(//div[contains(text(),'Billing')])[16]/../following-sibling::div/div";
		public static final String Administration_Roles_DefunctProjectAdmin  ="(//span[contains(text(),'Defunct Project Admin')]/../span)[1]";
		public static final String TransactionPage_TaxCheckBox  ="//input[@name= 'isTaxable']";
		public static final String Transaction_AddTransaction_Tax_xp  ="//input[@name=\"taxPercent\"]";
		public static final String Transactions_AddTransaction_ErrorMsg_Title_xp  ="//div[contains(text(),'Oops! Please complete and correct all the required fields')]";
		public static final String Transaction_AddTransactionTaxPercent_Tax_xp  ="//div[contains(text(),'Tax $ must be greater than zero')]";
		public static final String Draft_billing_add_new_draft_bill_SAP_account_xp1  ="//h4[@ng-click='EditSummaryBill.draftBill.addAccount()']";
		public static final String Billing_DraftBilling_CostObjectInvalidErrorMsg  ="//p[contains(text(),'Cost Object Invalid')]";
		public static final String ARC_Screen_SelectAllTransactions  ="//input[@name='selectAll']";
		
			
		
		public static final String WipRecord_PerspectiveDate_SearchBtn ="//button[contains(text(),'Search')]";
		 public static final String WipRecord_FringeDifference ="//a[contains(text(),'Fringe Difference')]";
		 public static final String Suspension_LaborAndFringe ="//span[contains(text(),'Labor & Fringe')]";
		 public static final String UsersRemove_OtherOccupancy_Percc ="//span[contains(text(),'313 OTHER OCCUPANCY')]/../../span[1]";
		 public static final String Users_Save_Btn ="//button[contains(text(),'Save')]";
		 public static final String Users_InformationTab ="//button[contains(text(),'Save')]";
		 public static final String Customers_AddAlternateAddress_PlusSymbol ="(//i[@class='fa fa-plus-circle cursor-pointer-on-hover'])[3]";
		 public static final String Customers_AddAlternateAddress_AddressLine1 ="//input[@id='customerAlternateAddressLine1']";
		 public static final String Customers_AddAlternateAddress_AddressLine2 ="//input[@id='customerAlternateAddressLine2']";
		 public static final String Customers_AddAlternateAddress_AlternateCity ="//input[@id='customerAlternateCity']";
		 public static final String Customers_AddAlternateAddress_AlternateState ="//select[@id='customerAlternateState']";
		 public static final String Customers_AddAlternateAddress_AlternateZip ="//input[@id='customerAlternateZip']";
		 public static final String Orders_Export_OrderNumber ="(//table[@class='table table-striped'])[2]/tbody/tr/td[2]/span/span";
		 public static final String Orders_Export_OrderCostCenter ="(//table[@class='table table-striped'])[2]/tbody/tr/td[3]/span/span";
		 public static final String Orders_Export_OrderCustomer ="//span[contains(text(),'Customer:')]/following-sibling::span";
		 public static final String Orders_Export_OrderDescription ="(//table[@class='table table-striped'])[2]/tbody/tr/td[4]/span/span";
		 public static final String Orders_Export_OrderPONumber ="(//table[@class='table table-striped'])[2]/tbody/tr/td[5]/span/span";
		 public static final String Orders_Export_OrderStatus ="orderStatus";
		 public static final String Orders_Export_OrderChargeMethod ="wipChargeMethod";
		 public static final String Orders_Export_OrderLocation ="location";
		 public static final String Orders_Export_Orderepisode ="episode";
		 public static final String Orders_Export_OrderRevenue ="(//table[@class='table table-striped'])[2]/tbody/tr/td[6]/span/span";
		 public static final String Orders_Export_OrderCost ="(//table[@class='table table-striped'])[2]/tbody/tr/td[7]/span/span";
		 public static final String Orders_Export_OrderMargin ="(//table[@class='table table-striped'])[2]/tbody/tr/td[8]/span/span";
		 public static final String ExceptionScreen_PlusSign ="//i[@class='fa fa-plus-circle ng-scope']";
		 public static final String Exceptions_LineDescription ="//table[@class='table table-striped']/tbody/tr[2]/td[2]/span/span";
		 public static final String Exceptions_TAX_Field_Check ="//table[@class='table table-striped']/tbody/tr[1]/td[7]/span/i";
		 public static final String Exceptions__AddPlusSign_ClickFirstRow_xp ="//table[@class='table table-striped']/tbody/tr/td[2]";
		 public static final String CustomerMasters_AddCustomer_AddressLinkPencil ="//span[@class='fa fa-pencil fa-lg']";
		 public static final String Rejections_DpetSysNumber ="//table[@id='accordion-table']/thead/tr/th[3]";
		 public static final String Rejections_TransactionDate ="//table[@id='accordion-table']/thead/tr/th[4]";
		 public static final String Rejections_TransactionDeal ="//table[@id='accordion-table']/thead/tr/th[5]";
		 public static final String Rejections_TransactionOrder ="//table[@id='accordion-table']/thead/tr/th[6]";
		 public static final String Rejections_TransactionDealMngCC ="//table[@id='accordion-table']/thead/tr/th[7]";
		 public static final String Rejections_TransactionDealPerCC ="//table[@id='accordion-table']/thead/tr/th[8]";
		 public static final String Rejections_TransactionDealSAPAccount ="//table[@id='accordion-table']/thead/tr/th[9]";
		 public static final String Rejections_TransactionDealCostObject ="//table[@id='accordion-table']/thead/tr/th[10]";
		 public static final String Rejections_TransactionDealOrderDescription ="//table[@id='accordion-table']/thead/tr/th[11]";
		 public static final String Rejections_TransactionCashFlag ="//table[@id='accordion-table']/thead/tr/th[12]";
		 public static final String Rejections_TransactionAmount ="//table[@id='accordion-table']/thead/tr/th[13]";
		 
														 	 
		 
		 
		 public static final String Orders_CostPlusPercentage_51XlaborValue ="//td[contains(text(),'51X - AP')]/../td[3]/input";
		 public static final String Orders_CostPlusPercentage_81XJournalEntries ="//td[contains(text(),'81X - Journal Entries')]/../td[3]/input";
		 public static final String ARC_Screen_BillableCategory_Filetr_BillableCost ="//span[contains(text(),'Billable Cost (CP)')]/../span";
		 public static final String Deals_MultiDepartmentDealStatus ="//span[contains(text(),'Multi-Department: ')]/../../span[contains(text(),'Yes')]";
		 public static final String Orders_OrderPurpose  ="//*[@id='order-purpose']";
		 public static final String Order_AddOrder_ErrormsgError_msg  ="//div[@class='nbc-alert-danger ng-binding']";
		 public static final String Order_AddTransaction_ErrormsgError_msg  ="//div[@class='nbc-alert-danger']";
		 public static final String Orders_Plus_Add_Sign_xp_two  ="//span[@ng-click='ordersCtrl.showAddForm = true;']/../span[2]";
		 public static final String Order_AddOrder_CostObjectInvalidErrormsgError_msg  ="//p[contains(text(),'Cost Object Invalid')]";
		 public static final String Order_AddOrder_SAPAccountNumberErrormsgError_msg  ="//p[contains(text(),'Account Number Invalid')]";
		 public static final String Transaction_FiscalView  ="//label[contains(text(),' Fiscal View ')]";
		 public static final String Transaction_FiscalView_PO_Number  ="//b[contains(text(),'Filters:')]/../../li[7]";
		 public static final String Transactions_FiscalView_percc  ="(//span[@class='fa fa-square-o'])[1]";
		 public static final String Transactions_FiscalView_Deal  ="(//li[contains(text(),'Deal')])[1]";
		 public static final String Transactions_FiscalViewFilter_SelectDeal  ="(//span[@class='fa fa-check-square'])[1]";
		 public static final String CustomersCreditLimit_id  ="creditLimit";
		 public static final String DraftBillingSapAccntNumber  ="//i[@class='fa fa-caret-right']";
		 public static final String DraftBillingSaveAndViewDraftBtn  ="//a[contains(text(),'Save and View Draft')]";
		 public static final String DraftBilling_Form_AletMessage_xp="//div[contains(text(),'Please fix the errors above')]";
		 public static final String ARCScreen_PreviousBtn_Disabled="//li[@ng-click='Arc.previousOrder()' and @disabled='disabled']";
		 public static final String ARCScreen_NextBtn_Disabled="//li[@ng-click='Arc.nextOrder()' and @disabled='disabled']";
		 public static final String ARCScreen_PreviousBtn="//li[@ng-click='Arc.previousOrder()']";
		 public static final String ARCScreen_NextBtn="//li[@ng-click='Arc.nextOrder()']";
		 public static final String Transactions_RevenueExpenseScreen="//label[contains(text(),' Revenue/Expense ')]";
		 public static final String SearchByTransactionDescription="//i[@uib-tooltip='Search by Transaction Description']";
		 public static final String Transactions_RevenueExpenseScreen_plsFilterByPerccLabel="//p[contains(text(),'Please filter by Perf CC')]";
		 public static final String Transactions_RevenueExpenseScreen_plsFilterByDealLabel="//div[@class='no-table-data']/p";
		 public static final String Transactions_RevenueExpenseScreen_RemovePill="(//span[@class='fa fa-close ng-scope'])[1]";
		 public static final String Transactions_RevenueExpenseScreen_RemovePill2="(//span[@class='fa fa-close ng-scope'])[2]";
		 public static final String Transactions_RevenueExpenseScreen_PerCc="(//table[@class='table table-striped']/tbody/tr/td[4])[1]";
		 public static final String Transactions_FiscalView_PerCc="(//table[@class='table table-striped']/tbody/tr/td[3]/span/span)[1]";
		 public static final String Transactions_RevenueExpenseScreen_ClearAllBtn="//span[contains(text(),'Clear All')]";
		 public static final String Transactions_RevenueExpenseScreen_Deal="//table[@class='table table-striped']/tbody/tr/td[2]";
		 public static final String Transactions_RevenueExpenseScreen_Status="//table[@class='table table-striped']/tbody/tr/td[15]";
		 public static final String Transactions_RevenueExpenseScreen_Description="//table[@class='table table-striped']/tbody/tr/td[7]";
		 public static final String Transactions_RevenueExpenseScreen_Order="(//li[contains(text(),'Order')])[1]";
		 public static final String TransactionsView_Deal="(//li[contains(text(),'Deal')])[1]";
		 
		 
		 public static final String Order_Departmentclosed="//span[contains(text(),'Department Closed')]";
		
		 public static final String OrderScreen_OrderValue="(//table[@class='table table-striped']/tbody/tr/td[2])[2]/span/span";
		 public static final String DealScreen_DealValue="(//table[@class='table table-striped']/tbody/tr/td[2]/span/span)[1]";
		 public static final String Exceptions_DealErrorMsg="(//div[@class='exception-btn-text ng-binding'])[1]";
		 public static final String Deal_CostCenter="//li[contains(text(),'Cost Center')]";
		 public static final String Deal_CostCenter_InactiveCostcenter="//span[contains(text(),'STORAGE')]/../span";
		 public static final String Deal_CostCenter_InactiveCostcenter_SaveBtn="(//button[contains(text(),'Save')])[4]";
		 public static final String Transactions_RevenueExpenseScreen_RevenueAmtUI="//table[@class='table table-striped']/tbody/tr/td[10]/span/span";
		 public static final String Transactions_RevenueExpenseScreen_RevenueAmtTotalGridUI="//table[@class='table table-striped']/tbody/tr/td[10]/span/span";
		 public static final String Transactions_RevenueExpenseScreen_CostAmtUI="//table[@class='table table-striped']/tbody/tr/td[10]/span/span";
		 public static final String Transactions_RevenueExpenseScreen_CostAmtTotalGridUI="//table[@class='table table-striped']/tbody/tr/td[10]/span/span";
		 public static final String Transactions_DetailScreen_Status="(//table[@class='table table-striped']/tbody/tr/td[13])[1]/span/span";
		 public static final String Transactions_RevenueExpenseScreen_ResetDefaultBtn="//span[contains(text(),'Reset Defaults')]";
		 public static final String Transactions_DetailScreen_SelectDeal ="(//span[@class='fa fa-circle-thin'])[1]";
		 public static final String Transactions_DetailScreen_SelectDocumentNumber ="(//span[@class='fa fa-circle-thin'])[2]";
		 public static final String Transactions_DetailScreen_SelectCustomer ="(//span[@class='fa fa-circle-thin'])[3]";
		 public static final String Transactions_PONumber ="//*[@id='poNumber']";
		 public static final String Transactions_LineDescription ="//input[@name='lineDescription']";
		 public static final String Transactions_CostCenter ="//div[@name='costCenter']";
		 public static final String Transactions_Amount ="//label[contains(text(),'Total')]";
		 public static final String Billing_DraftBilling_DraftBill_List_xp11="//ul[@class='list-group accordion-double-button']//li[1]//p[2]";
		 public static final String Billing_DraftBilling_DraftBill_Number1_xp="//ul[@class='list-group accordion-double-button']//li[1]//p[1]";
		 public static final String Deals_AddDeal_LinkAddPlusSign_xp_new="//div[@class='fixed-action-button']//span[@class='fa fa-plus-circle']";
		 public static final String Deals_Deposits_Tab_InvoiveNumber ="//table[@class='table table-striped inline-table']/tbody/tr/td";
		 public static final String Deals_DepositsDeal_Tab_Amount ="//label[contains(text(),'Amount')]/../p";
		 public static final String Deals_DepositsDeal_Tab_RemainingAmount ="//label[contains(text(),'Remaining Amount')]/../p";
		 public static final String Deals_DepositsDeal_Tab_TableAmount ="//table[@class='table table-striped inline-table']/tbody/tr/td[3]";
		 public static final String InvoicePage_InvoiceNumber ="//table[@class='table table-striped']/tbody/tr/td[2]/span/span";

		 public static final String InvoiceStatement_RePrintButtonInvoice ="(//a[contains(text(),'Reprint')])[3]";
		 public static final String transaction_selectdeal ="(//span[@class='fa fa-square-o'])[1]";
		 public static final String Suspensions_MoveToSAP_FringeAmt ="//label[contains(text(),'Total Amount')]/following-sibling::div";
		 public static final String SuspensionsExit_MoveToSAP_FringeAmt ="//i[@ng-click='confirmDialogCtrl.closeNotification()']";
		    public static final String Deal_FirstDeal="(//sp-table-new/table/tbody/tr/td[3])[1]";
		     //added
		    public static final String Detail_DealType_Filter  ="//li[contains(text(),'Deal')]";
		    public static final String   SetDetail_DealType_Filter="//input[@placeholder='Search Deal...']";
		    public static final String   SelectActiveDealDetail_DealType_Filter="(//span[@class='fa fa-circle-thin'])[1]";
		    public static final String   Detail_Status="//tbody/tr/td[13]";
		    public static final String Dashboard_SearchBy_Deal_xp_DealInquiry="//ng-form[@name='Tile.dealForm']//select";
			public static final String Dashboard_Deal_SearchBar_xp_DealInquiry="//ng-form[@name='Tile.dealForm']//input[@type='search']";
			public static final String Dashboard_Deal_SearchBar_FirstRow_xp_DealInquiry="//span[@class='ui-select-choices-row-inner']/span/span";
			public static final String Dashboard_Deal_Search_Go_Btn_xp_DealInquiry="//ng-form[@name='Tile.dealForm']//button[@class='btn btn-primary']";
			public static final String Dashboard_Deal_SearchBar_FirstRow_xp_DealPage="(//td[@ng-click='options.onClick(row)'])[1]";
			public static final String   SuspenseScreen_SystemFilter="//li[contains(text(),'System')]";
			public static final String   SuspenseScreenSAP_SystemFilter="(//span[@class='fa fa-square-o'])[2]";
			public static final String   SuspenseScreen_MoveToSAP="(//a[contains(text(),'Move to SAP')])[3]";
			public static final String   Suspense_Screen_CostObject_id="costObject";
			public static final String   Suspense_Screen_SAP_Account_Number_id="accountNumber";
		
			public static final String   SuspenseScreenSAP_DisabledFirstRow="//table[@class='table table-striped']/tbody/tr";
				 public static final String Administration_Roles_DepartmentBilling_Billing_Invoice  ="(//div[contains(text(),'Billing')])[18]/../following-sibling::div/div";
			 public static final String Administration_Roles_DepartmentProjectAdmin_Billing_Invoice  ="(//div[contains(text(),'Billing')])[46]/../following-sibling::div/div";
			 public static final String Administration_Roles_DepartmentProjectAdminNew_Billing_Invoice  ="(//div[contains(text(),'Billing')])[60]/../following-sibling::div/div";
			 public static final String Administration_Roles_DepartmentProjectAdminNew  ="(//span[contains(text(),'Department Project Admin New')]/../span)[1]";
			 public static final String Administration_Roles_FinanceAdmin_Billing_Invoice  ="(//div[contains(text(),'Billing')])[46]/../following-sibling::div/div";
			 public static final String Administration_Roles_FinanceUser_Billing_Invoice  ="(//div[contains(text(),'Billing')])[88]/../following-sibling::div/div";
			 public static final String Administration_Roles_ReportingUser_Billing_Invoice  ="(//div[contains(text(),'Billing')])[102]/../following-sibling::div/div";
			 public static final String Administration_Roles_SphereAdmin_Billing_Invoice  ="(//div[contains(text(),'Billing')])[116]/../following-sibling::div/div";
			 public static final String Administration_Roles_UnmanedRole_Billing_Invoice  ="(//div[contains(text(),'Billing')])[116]/../following-sibling::div/div";
			 public static final String Transaction_TransactionType_Disabled  ="//select[@lookup-id='transactionType' and @disabled = 'disabled']";
			 public static final String Transaction_Taxable_Disabled  ="//*[@id='taxYes' and 'disabled']";
			 public static final String ARC_billable  ="(//a[contains(text(),'Non-Billable')])[2]";
			 public static final String ARC_billable_Continue  ="//button[contains(text(),'Continue')]";
			 public static final String ARC_Screen_Billing_notes_id  ="//*[@id='notes']";
			 public static final String ARC_Screen_BillableCategory_Filetr ="//li[contains(text(),'Billable Category')]";
			 public static final String ARC_Screen_PerCC_FilteredData ="//span[contains(text(),'106 BC CONTROL ROOMS')]/../following-sibling::li/span[contains(text(),'208 SET LIGHTING - CA')]/../following-sibling::li/span[contains(text(),'209 PROPERTY')]/../following-sibling::li/span[contains(text(),'210 GRAPHICS/SIGN SERVICES')]";
			 public static final String ARC_Screen_MngCC_FilteredData ="(//span[contains(text(),'208 SET LIGHTING - CA')]/../following-sibling::li/span[contains(text(),'209 PROPERTY')]/../following-sibling::li/span[contains(text(),'213 COSTUME')]/../following-sibling::li/span[contains(text(),'214 COSTUME - NY')])[1]";
				
			 public static final String ARC_Screen_BillableCategory_Filetr_NonBillableCost ="//span[contains(text(),'Non-Billable Cost (FR)')]/../span";
			 public static final String Orders_CostPlusPercentage_onexxlaborValue ="//td[contains(text(),'1XX - Labor')]/../td[3]/input";
			    public static final String Transactions_FiscalView ="//span[contains(text(),'Fiscal View')]";
			    public static final String Transactions_Detail ="//span[contains(text(),'Detail')]";
			    public static final String Transactions_CurrentMonth ="//span[contains(text(),'Current Month')]";
			    public static final String Transactions_FiscalPeriodStartDate ="(//div[@class='date-selectors month-selectors'])[1]";
			    public static final String Transactions_FiscalPeriodStartDate_year ="(//div[@class='date-selectors year-selectors'])[1]";
			    public static final String Transactions_FiscalPeriodEndDate ="(//div[@class='date-selectors month-selectors'])[2]";
			    public static final String Transactions_FiscalPeriodEndDate_year ="(//div[@class='date-selectors year-selectors'])[2]";
			    public static final String Transactions_FiscalView_FilterButton ="//button[contains(text(),'GO')]";
			    public static final String Transactions_RevenueExpense_FilterPerCC ="//li[contains(text(),'Perf CC')]";
			    public static final String DashBoard_TransactionInquiryDetail_Dropdown ="//select[@ng-model='Tile.selectedPage']";
			    public static final String DashBoard_TransactionInquirySearchBy_Dropdown ="(//select[@ng-options='item as item for item in Tile.searchBy'])[1]";
			    public static final String DashBoard_PerformingCC_SearchBox ="//span[@class='ui-select-choices-row-inner']/span";
			    public static final String Deals_Deposits_Tab ="//a[normalize-space()='DEPOSITS']";
			    public static final String Deals_Deposits_Tab_Eye ="//i[@class='fa fa-eye']";
			    public static final String Deals_Deposits_Tab_Check_Date ="//label[contains(text(),'Check Date')]/../p";
			    public static final String Deals_Deposits_Tab_Amount ="//label[contains(text(),'Check Date')]/../p";
			    public static final String Deals_DepositsTab_DepositHistory_Plus ="//i[@class='fa fa-plus']";
			    public static final String Deals_Deposits_Tab_CopyOrdersButton ="//button[contains(text(),'Copy Orders')]";
			    public static final String Deals_Deposits_Tab_CopyButton ="//button[normalize-space()='Copy']";
			    public static final String Deals_Deposits_Tab_CancelButton ="(//span[contains(text(),'Cancel')])[4]";
			    public static final String Deals_Deposits_Tab_Deal ="//input[@ng-model='formObj.dealNumber']";
			    public static final String Suspensions_SuspendedDateFilter ="//li[contains(text(),'Suspended Date')]/span";
			    public static final String Suspensions_TranDateFilter ="//li[contains(text(),'Tran Date')]/span";
			    public static final String Deals_Deposits_Tab_CheckNumber ="//label[contains(text(),'Check Number')]/../p";
			    public static final String Deals_Deposits_Tab_RemainingAmount ="//label[contains(text(),'Remaining Amount')]/../p";
			    public static final String Deals_Deposits_Tab_Type ="(//label[contains(text(),'Type')]/../select)[2]";
			    public static final String Rejections_RejectionFilter ="//li[contains(text(),'Rejection Date')]/span";
			    public static final String Rejections_RejectionFilterButton ="//button[contains(text(),'Filter')]";
			    public static final String Rejections_RejectionFilterTable ="(//i[@class='glyphicon glyphicon-calendar'])[1]";
			    public static final String UsersCreatedBy ="//label[contains(text(),'Created By:')]/following-sibling::p";
			    public static final String QueueLogging_RequestTimeStamp_Filter ="//th[contains(text(),'Request Timestamp')]/i";
			    public static final String QueueLogging_RequestTimeStamp ="(//table[@class='table table-striped']//td/span[1]/span)[1]";
			    public static final String Transaction_FiscalViewTransactionDate ="//th[contains(text(),'Transaction Date')]";
			    public static final String Transaction_RevenueExpenseTransactionDate ="//th[contains(text(),'Transaction Date')]";
			    public static final String SSP_RequestTimeStamp_Filter ="//th[contains(text(),'Request Date/Time')]";
			    public static final String AdministrationUsers_PhoneNumber ="//input[@name='phone']";
			    public static final String Deals_DepositsTab_DepositHistory_InvoiceNumber ="//table[@class='table table-striped inline-table']/tbody/tr/td";
			    public static final String Deals_DepositsTab_DepositHistory_Date ="//table[@class='table table-striped inline-table']/tbody/tr/td[2]";
			    public static final String Deals_DepositsTab_DepositHistory_Amount ="//table[@class='table table-striped inline-table']/tbody/tr/td[3]";
			    public static final String Transactions_filter_percc ="//li[contains(text(),'Perf CC')]";
			    public static final String Transactions_filter_percc_select_firstcheckbox ="//span[contains(text(),'208 SET LIGHTING - CA')]";
			    public static final String Transactions_filter_percc_select_secondcheckbox ="//span[contains(text(),'209 PROPERTY')]";
			    public static final String Transactions_filter_SourceCode_Grp ="//li[contains(text(),'Source Code Grp')]";
			    public static final String Transactions_filter_SourceCode_Grp_select_firstcheckbox ="//span[contains(text(),'1XX - Labor')]/../span";
			    public static final String Transactions_filter_SourceCode_Grp_select_secondcheckbox ="//span[contains(text(),'51X - AP')]/../span";
			    public static final String Transactions_filter_Origin ="//li[contains(text(),'Origin')]";
			    public static final String Transactions_filter_Origin_select_firstcheckbox ="//span[contains(text(),'Original')]/../span";
			    public static final String Transactions_filter_Origin_select_secondcheckbox ="//span[contains(text(),'Moved')]/../span";
			    public static final String Transactions_filter_Customer_Type ="//li[contains(text(),'Customer Type')]";
			    public static final String Transactions_filter_Customer_Type_select_firstcheckbox ="//span[contains(text(),' FPS Cable TV')]/../span";
			    public static final String Transactions_filter_Customer_Type_select_secondcheckbox ="//span[contains(text(),'FPS External')]/../span";
			    public static final String Transactions_filter_Deal_Type ="//li[contains(text(),'Deal Type')]";
			    public static final String Transactions_filter_Deal_Type_select_firstcheckbox ="//span[contains(text(),'1 Hr Episodic TV Show')]/../span";
			    public static final String Transactions_filter_Deal_Type_select_secondcheckbox ="//span[contains(text(),' 1/2 Hr Episodic TV Show')]/../span";
			    public static final String Transactions_filter_Project_Production ="//li[contains(text(),'Project or Production')]";
			    public static final String Transactions_filter_Project_Production_select_firstcheckbox ="//span[contains(text(),'30 ROCK')]/../span";
			    public static final String Transactions_filter_Project_Production_select_secondcheckbox ="//span[contains(text(),'ACCESS HOLLYWOOD')]/../span";
			    public static final String Transactions_filter_Mngcc ="//li[contains(text(),'Mng CC')]";
			    public static final String Transactions_filter_Mngcc_select_firstcheckbox ="(//span[contains(text(),'SET LIGHTING - CA')])[2]/../span";
			    public static final String Transactions_filter_Mngcc_select_secondcheckbox ="(//span[contains(text(),' DUMPSTERS')])[2]/../span";
			    public static final String Transactions_filter_SourceCode_Grp_RE ="//li[contains(text(),'Source Code Grp')]";
			    public static final String Transactions_filter_SourceCode_Grp_select_firstcheckbox_RE ="((//span[contains(text(),'1XX - Labor')])[1]/../span)[1]";
			    public static final String Transactions_filter_SourceCode_Grp_select_secondcheckbox_RE ="(//span[contains(text(),'51X - AP')]/../span)[1]";
			    public static final String Transactions_filter_Origin_RE ="//li[contains(text(),'Origin')]";
			    public static final String Transactions_filter_Origin_select_firstcheckbox_RE ="(//span[contains(text(),'Original')]/../span)[1]";
			    public static final String Transactions_filter_Origin_select_secondcheckbox_RE ="(//span[contains(text(),'Moved')]/../span)[1]";
			    public static final String Transactions_filter_Status_RE ="//li[contains(text(),'Status')]";
			    public static final String Transactions_filter_Status_select_firstcheckbox_RE ="((//span[contains(text(),'Approved')])[3]/../span)[1]";
			    public static final String Transactions_filter_Status_select_secondcheckbox_RE ="//span[contains(text(),'Rejected')]/../span";
			    public static final String Transactions_filter_Customer_Type_RE ="//li[contains(text(),'Customer Type')]";
			    public static final String Transactions_filter_Customer_Type_select_firstcheckbox_RE ="(//span[contains(text(),' FPS Cable TV')]/../span)[1]";
			    public static final String Transactions_filter_Customer_Type_select_secondcheckbox_RE ="(//span[contains(text(),'FPS External')]/../span)[1]";
			    public static final String Transactions_RevenueExpense ="//label[contains(text(),'Revenue/Expense')]";
			    public static final String Transactions_SearchedValueFirstRow_RE ="(//span[@compile='table.getDisplayValue(column, row) | useFilter:table.getFilterValue(column, row):row'])[6]/span";
			    public static final String Reports_WIP_Recon_WIP_In_Suspense ="//a[contains(text(),'WIP in Suspense')]";
			    public static final String Reports_WIP_Aging_cc ="//th[contains(text(),'CC')]";
			    public static final String Reports_WIP_Aging_totals ="//th[contains(text(),'Totals')]";
			    public static final String Reports_WIP_Aging_Current ="//th[contains(text(),'Current')]";
			    public static final String Reports_WIP_Aging_1_to_30 ="//th[contains(text(),'1-30')]";
			    public static final String Reports_WIP_Aging_31_to_60 ="//th[contains(text(),'31-60')]";
			    public static final String Reports_WIP_Aging_61_to_90 ="//th[contains(text(),'61-90')]";
			    public static final String Reports_WIP_Aging_Over_91 ="//th[contains(text(),'Over 91')]";
			    public static final String Reports_WIP_Aging_Current_Value ="//table[@class='table table-striped']/tbody/tr/td[3]";
			    public static final String Reports_WIP_Aging_1_to_30_Value ="//table[@class='table table-striped']/tbody/tr/td[4]";
			    public static final String Reports_WIP_Aging_31_to_60_Value ="//table[@class='table table-striped']/tbody/tr/td[5]";
			    public static final String Reports_WIP_Aging_61_to_90_Value ="//table[@class='table table-striped']/tbody/tr/td[6]";
			    public static final String Reports_WIP_Aging_Over_91_Value ="//table[@class='table table-striped']/tbody/tr/td[7]";
			    public static final String Reports_WIP_Aging_totals_Value ="//table[@class='table table-striped']/tbody/tr/td[2]";
			    public static final String Transactions__FiscalPeriodStart_date ="(//select[@ng-model='periodSelectorsCtrl.month'])[1]/option";
			    public static final String Transactions__FiscalPeriodStart_year ="(//select[@ng-model='periodSelectorsCtrl.year'])[1]/option";
			    public static final String Transactions__FiscalPeriodEnd_date ="(//select[@ng-model='periodSelectorsCtrl.month'])[2]/option";
			    public static final String Transactions__FiscalPeriodEnd_year ="(//select[@ng-model='periodSelectorsCtrl.year'])[2]/option";
			    public static final String Transaction_FiscalViewStartDateEndDate_Error_xp ="//div[contains(text(),'Fiscal End Period must be greater or equal to Fiscal Start Period.')]";
			    public static final String Transactions__FiscalPeriodStart_date1 ="(//select[@ng-model='periodSelectorsCtrl.month'])[1]";
			    public static final String Transactions__FiscalPeriodStart_year1 ="(//select[@ng-model='periodSelectorsCtrl.year'])[1]";
			    public static final String Transactions__FiscalPeriodEnd_date1 ="(//select[@ng-model='periodSelectorsCtrl.month'])[2]";
			    public static final String Transactions__FiscalPeriodEnd_year1 ="(//select[@ng-model='periodSelectorsCtrl.year'])[2]";
			    public static final String TransactionsInquiryScreen_FiscalView_FilterButton ="//button[contains(text(),'Filter')]";
			    public static final String DraftBillingScreen_MoveToARC ="//a[contains(text(),'Move to Draft Bill')]";
			    public static final String Deal_Screen_ViewOrders ="//div[@class='intercept-menu-container']/ul/li[5]/a";
			    public static final String Exceptions_ClickFirstRow_xp1  ="//td[@class='ng-scope departmentSystemNumber'][1]";
			    public static final String Exceptions_DeptsystemNo_UniqueNumber  ="//td[@class='ng-scope departmentSystemNumber'][2]";
			    public static final String Exceptions_SearchBox  ="//input[@placeholder='Search ...']";
			    public static final String Transaction_Customer ="//span[contains(text(),'NBC TELEVISION')]";
			    public static final String Transaction_Deal ="//span[contains(text(),'AUTOTESTDEAL')]";
			    public static final String Transaction_Order ="//span[contains(text(),'AUTOTESTORDER')]";
			    public static final String Exceptions_Searchbox  ="//input[@name='search']";
			    public static final String Exceptions_DeptSystemNumber  ="//div[@id='departmentSystemNumber']";
			    public static final String Exceptions_rentalStartDate_Disabled  ="//input[@id='rentalStartDate' and 'disabled']";//changed
			    public static final String Exceptions_rentalEndDate_Disabled  ="//input[@id='rentalEndDate' and 'disabled']";
			    public static final String Exceptions_Pricelist_Disabled  ="//select[@lookup-name='priceList' and @disabled = 'disabled']";
			    public static final String Exceptions_RequestDate_Disabled  ="//input[@name='requestDate' and 'disabled']";
			    public static final String Exceptions_BillableYes_Disabled  ="//input[@id='billableYes' and 'disabled']";
			    public static final String Transactions_PerformingCC_Disabled  ="//div[@name='costCenter'and @disabled = 'disabled']";//change
			    public static final String Transaction_InterfaceCode_Disabled  ="//select[@name='interfaceCode' and @disabled = 'disabled']";
			    public static final String Transaction_CashFlag_Disabled  ="//select[@name='cashSaleIndicator' and @disabled = 'disabled']";
			    public static final String Transaction_PriceList_Disabled  ="//select[@lookup-id='priceList' and @disabled = 'disabled']";
			   // public static final String Transaction_ItemCode_id_Disabled  ="//select[@name='cashSaleIndicator' and @disabled = 'disabled']";
			    public static final String Transaction_description_Disabled  ="//input[@id='lineDescription' and @disabled = 'disabled']";
			    public static final String Transaction_Qty_Disabled  ="//*[@id='quantity' and 'disabled']";
			    public static final String Transaction_UM_Disabled  ="//select[@lookup-id='unitOfMeasure' and @disabled = 'disabled']";
			    public static final String Transaction_Rate_Disabled  ="//*[@id='rate' and 'disabled']";
			    public static final String Transaction_FiscalDateRangePill  ="//li[@ng-repeat='param in queryParameters.displayedParamPills track by $index']";
			    public static final String Transaction_FiscalDateRangePill_TotalRevenue  ="//table[@ng-if='fiscalViewCtrl.transactionMetaData && !fiscalViewCtrl.showMissingFilterMessage']/tbody/tr/td";
			    public static final String Transaction_FiscalDateRangePill_TotalCost  ="//table[@ng-if='fiscalViewCtrl.transactionMetaData && !fiscalViewCtrl.showMissingFilterMessage']/tbody/tr/td[2]";
			    public static final String Transaction_FiscalDateRangePill_TotalMargin  ="//table[@ng-if='fiscalViewCtrl.transactionMetaData && !fiscalViewCtrl.showMissingFilterMessage']/tbody/tr/td[3]";
			    public static final String Administration_Roles_DealUser  ="(//span[contains(text(),'Deal User')]/../span)[1]";
			    public static final String Administration_Roles_DepartmentAdmin  ="(//span[contains(text(),'Department Admin')]/../span)[1]";
			    public static final String Administration_Roles_DepartmentBilling  ="(//span[contains(text(),'Department Billing')]/../span)[1]";
			    public static final String Administration_Roles_DepartmentProjectAdmin  ="(//span[contains(text(),'Department Project Admin')]/../span)[1]";
			    public static final String Administration_Roles_FinanceAdmin  ="(//span[contains(text(),'Finance Admin')]/../span)[1]";
			    public static final String Administration_Roles_FinanceUser  ="(//span[contains(text(),'Finance User')]/../span)[1]";
			    public static final String Administration_Roles_ReportingUser  ="(//span[contains(text(),'Reporting User')]/../span)[1]";
			    public static final String Administration_Roles_SphereAdmin  ="(//span[contains(text(),'Sphere Admin')]/../span)[1]";
			    public static final String Administration_Roles_UnnamedRole  ="(//span[contains(text(),'Unnamed Role')]/../span)[1]";
			    public static final String Transaction_sapcostObject  ="//input[@id='costObject']";
			    public static final String Transaction_sapaccountNumber  ="//input[@id='accountNumber']";

			    public static final String Transaction_sapIndicator  ="//select[@lookup-id='sapIndicator']";
			    public static final String InvoiceStatement_SlideOutPage  ="//div[@class='sideview visible']";
			    public static final String Dashboard_Transaction_Inquiry_Go_Button  ="(//button[contains(text(),'GO')])[1]";
			    public static final String Transaction_InquiryPage_Title  ="//h3[@translate='REVENUE_EXPENSE.TITLE']";
			    public static final String DashBoard_Detail_SearchBy  ="(//select[@ng-model='Tile.searchData.searchBy'])[1]/option";
			    public static final String DashBoard_TransactionInquiry_SearchBox  ="(//input[@type='search'])[1]";
			    public static final String Administration_CloseForm  ="//i[@ng-click='sideviewModal.confirmFormExit()']";
			    public static final String Deals_filter_costcenter ="(//li[@ng-repeat='filter in tableFilters.filters'])[5]";
			    public static final String Deals_filter_costcenter_GMO ="/html/body/main/section/div/div[2]/sp-table-view-new/sp-table-filters/div/div[6]/div[2]/ul/li[39]/span";
			    public static final String Deals_Contacts_Disabled ="//input[@placeholder='Search Contacts...']";
			    public static final String Order_AddOrder_Managing_CC ="//input[@type='search' and @role='combobox']";
			    public static final String Orders_WIP_Charge_Method_Disabled ="//label[@translate='ORDERS.ADD_ORDER.WIP_CHARGE_METHOD']/../select";
			    public static final String Deals_OrderPurpose_Disabled ="//textarea[@id='order-purpose']";
			    public static final String InvoiceStatement_DealMng_CC ="(//li[@ng-repeat='filter in tableFilters.filters'])[6]";
			    public static final String InvoiceStatement_filter_costcenter_GMO ="/html/body/main/section/div/div[2]/sp-table-view-new/sp-table-filters/div/div[7]/div[2]/ul/li[39]/span[1]";
			    public static final String InvoiceStatement_filter_costcenter_GMO_Records_Table ="//table[@class='table table-striped']/tbody/tr";
			    public static final String Deals_AddDealBtnStatus_Disabled ="//select[@id='dealStatus']";
			    public static final String InvoiceStatement_ViewDraft  ="//a[contains(text(),'View Draft')]";
			    public static final String InvoiceStatement_PrintButton  ="//a[contains(text(),'Print')]";
			    public static final String InvoiceStatement_RePrintButton  ="(//a[contains(text(),'Reprint')])[3]";
			    public static final String InvoiceStatement_PrintAsOriginalButton  ="//a[contains(text(),'Print as Original')]";
			    //public static final String ARC_AddTransaction_PoNumber_id="                 //*[@id='poLineNumber']";
			    public static final String ARC_AddTransaction_PoNumber_id="(//input[@type ='text'])[7]";
			    public static final String Billing_ARC_View_transaction_Note="//a[contains(text(),'NOTES')]";
			    public static final String Billing_ARC_View_transaction_Note_Content="//table[@class='table table-striped note-info-table']/tbody/tr/td[4]";
			    public static final String Deal_view_Transaction_xp1="//a[@class='ng-binding ng-scope' and text()='View Transactions']";
			   // public static final String Deal_view_Transaction_xp1="//a[@class='ng-binding ng-scope' and text()='View Transactions']";
			    
			  
			    public static final String Billing_InvoiceStatement_Title_xp="//h3[@translate='INVOICES.TITLE']";
			    public static final String Transactions_NewExceptions_Title_xp="//h3[@translate='INVOICES.TITLE']";
			    public static final String Administration_Users_Title_xp="//h3[@translate='USERS.TITLE']";
			    public static final String ARC_ReassignTransactionPage_ReassignButton="//button[@translate='ARC.MOVE.DIALOG.SUBMIT']";
			    public static final String Exception_Screen_ReferenceInvoice_Number_xp="//input[@name='referenceInvoiceNumber']";
			    public static final String Exceptions_DealNumber="//*[@id='accordion-table']/tbody/tr/td[5]/span";
			    public static final String Exceptions_SaveButton_xp = "//button[@ng-click='editBillingExceptions.saveBillingRequest()']";
			    public static final String Exceptions_cashFlagValue = "//*[@id='cashSaleIndicator']";
			    public static final String InvoiveStatement_Inquiry_Status = "(//span[@class='ng-scope'])[32]/span";
			    public static final String ARC_Screen_Approved_BulkOption_Suspend_xp1 = "//a[contains(text(),'Suspend')]";
			    public static final String DeatilPage_Reversal_SuccessMessage = "//div[@class='message ng-binding']";
			    public static final String ARC_CannotSendTransactions_ErrorMessage = "//p[contains(text(),'Dept system number  has transactions that are in the Exception or Pending Admin Approval queue.')]";
			    public static final String Transactions_filter_percc_select_Dumpsters = "//span[contains(text(),'215 DUMPSTERS')]";
			    public static final String Transactions_DetailToggle = "//label[contains(text(),'Detail')]";
			    public static final String Transactions_filter_DeatilScreen_Deal_XBtn = "(//span[@ng-if='filter.showCloseIcon(optionIndex)'])[1]";
			    public static final String Transactions_RevenueExpenseToggle = "//label[contains(text(),'Revenue/Expense')]";
			    public static final String DraftBilling_SaveDraftBill = "//button[contains(text(),'Save')]";
			    public static final String DraftBillingScreen_addeddraftbill_new = "//ul[@class='list-group accordion-double-button']//li[2]";
			    public static final String Billing_DraftBilling_DraftBill_List_xp2 = "//ul[@class='list-group accordion-double-button']//li[2]";
			    
			    
			    public static final String ARC_Screen_MatchAndDeleteTransactionPartialFailureMessage = "//div[contains(text(),'Match & Delete Partially Successful.')]";
			    public static final String Deals_filter_costcenter_SelectGMO = "//span[contains(text(),'288 GMO')]";
			    public static final String Transaction_sapTerritory  ="//input[@id='sapTerritory']";
			    public static final String Deals_AddDealComboDealStatus_xp  ="//select[@name='dealStatus']";
			    public static final String Transactions_TaxableYes  ="//input[@name='isTaxable']";
			    public static final String Transactions_TaxableRate  ="//input[@name='taxPercent']";
			    public static final String Billing_draft_billing_invoice_page_send_to_ARC_button_xp1  ="//button[contains(text(),'Send to ARC')]";
			    public static final String Billing_DraftBilling_DirectCharge_sendToArc_Btn_xp  ="//button[contains(text(),'Send to ARC')]";
			    
			    
			    public static final String Draft_billing_clear_all_xp="//span[contains(text(),'Clear All')]";
			    public static final String Draft_billing_add_new_draft_bill_Save_xp1 = "//button[contains(text(),'Save')]";
			    public static final String ARC_approve_and_send_xp  ="//a[contains(text(),'Send')]";
			    public static final String Checkbox_displayed_draft_bill_xp  ="//input[@ng-if='!moveSelectMode']";
			    public static final String ARC_Notes_Note  ="(//td[@class='ng-binding'])[7]";
			    public static final String Orders_Firstrow_RightClick_View_Edit  ="//a[contains(text(),'View/ Edit')]";
			    public static final String Deals_AddCustomer_TaxID  ="//input[@name='taxId']";
			    public static final String Deals_AddCustomer_VATID  ="//input[@name='vatId']";
			    public static final String DraftBilling_DeliveryMethod  ="//select[@lookup-name='deliveryMethod']";
			    public static final String Exceptions_CashSale_Indicator  ="//label[contains(text(),'Cash Flag')]/../select/option";
			    public static final String Exceptions_cashFlagValueOnTable  ="(//table[@id='accordion-table']//td[12])[1]";
			    public static final String Exceptions_RightClick_Reject  ="(//a[contains(text(),'Reject')])[2]";
			    public static final String Exceptions_RightClick_RejectTransactionsPopUp  ="//h3[contains(text(),'Reject Transaction')]";
			    public static final String Exceptions_RejectTransactionsPopUp_RejectButton  ="//button[contains(text(),'Reject')]";
			    public static final String Exceptions_BulkActions_Reject ="(//a[contains(text(),'Reject')])[1]";
			    public static final String Orders_RevenueAmount ="(//span[contains(text(),'0.00')])[1]";
			    public static final String Orders_TotalRevenueAmount ="(//td[contains(text(),'0.00')])[1]";
			    public static final String Orders_RevenueAmount1 ="(//span[contains(text(),'10.00')])[1]";
			    public static final String Orders_TotalRevenueAmount1 ="(//td[contains(text(),'10.00')])[1]";
			    public static final String ARCScreen_PerformingCostCenter_Filter = "//li[contains(text(),'Performing CC')]";
			    public static final String ARCScreen_PerformingCostCenter_Filter_SearchField = "//input[@placeholder='Search Performing CC...']";
			    public static final String ARCScreen_PerformingCostCenter_Filter_SearchResultSetlighting = "(//span[contains(text(),'SET LIGHTING - CA')])[2]";
			    public static final String DraftBilling_TickMark_Orders = "(//i[@ng-if='selected'])[2]";
			    public static final String DraftBilling_InvoiceFormat_Filter = "//li[contains(text(),'Invoice Format')]";
			    public static final String DraftBilling_InvoiceFormat_Filter_DetInvoice = "//span[contains(text(),'DET - Detailed Invoice')]";
			    public static final String DealsPage_EditCustomerButton = "//a[@ng-click='edit(item);']";
			    public static final String DealsPage_EditCustomersPage_SaveButton = "//button[@ng-click='editCustomer.updateCustomer()']";
			    public static final String Orders_Costplus_OkButton ="//button[text()='OK']";
			    public static final String Exceptions_BulkActions_Resolve ="//a[contains(text(),'Resolve')]";
			    public static final String Exceptions_OrderExceptionHighlight ="//td[@class='ng-scope dealOrder-setNumber exception']";
			    public static final String Suspensions_Reassign_WarningMessage ="//div[contains(text(),\"One or more of the transactions have a Performing Cost Center that does not match the Order's Cost Center. Do you want to proceed?\")]";
			    public static final String Deals_Customers_NBCTELEVISION ="//span[contains(text(),'970329 NBC TELEVISION')]";
			    public static final String DraftBillingScreen_ViewEditPage_DeleteButton ="//button[contains(text(),'Delete')]";
			    public static final String Details_Reverse_Correction  ="(//span[contains(text(),'Correction')])[2]";
			    public static final String Details_Reverse_Reversal  ="(//span[contains(text(),'Reversal')])[2]";
			    public static final String Details_Status_PendingAdminApproval_unchecked  ="//span[contains(text(),'Pending Admin Approval')]/../span[@class='fa fa-square-o']";
			    public static final String Deals_Row_SeventhRow  ="(//tr[7]/td[@ng-click='options.onClick(row)'])[1]";
			    public static final String Orders_LastUpdatedDate ="//h4[contains(text(),'Last Updated On:')]/../div";
			    public static final String DraftBilling_Immediate_Disabled ="//button[@disabled='disabled']/span[contains(text(),'Toggle Dropdown')]";
			    public static final String DraftBilling_SendToARC_Disabled ="//button[contains(text(),'Send to ARC') and @ng-disabled='!canEdit']";
			    public static final String SAP_Validation_Description ="//input[@placeholder='Description (min 3 char)']";
			    public static final String SAP_Validation_AccCostObject ="//input[@placeholder='Acct/CostObject (min 3 char)']";
			    public static final String SAP_Validation_Company ="//input[@placeholder='Company']";
			    public static final String SAP_Validation_WBSElement_Checkbox ="(//span[@class='check fa fa-square-o'])[1]";
			    public static final String SAP_Validation_WBSElement_CostCenter_Checkbox ="(//span[@class='check fa fa-square-o'])[2]";
			    public static final String SAP_Validation_WBSElement_GLAccount_Checkbox ="(//span[@class='check fa fa-square-o'])[3]";
			    public static final String SAP_Validation_WBSElement_ProftCenters_Checkbox ="(//span[@class='check fa fa-square-o'])[4]";
			    public static final String SAP_Validation_WBSElement_ManualFundsCommitments_Checkbox ="(//span[@class='check fa fa-square-o'])[5]";
			    public static final String SAP_Validation_AccountNumber_firstRow ="(//tr[@ng-repeat='row in results']//span/span)[1]";
			    public static final String SAP_Validation_Company_firstRow ="(//tr[@ng-repeat='row in results']//span/span)[2]";
			    public static final String SAP_Validation_Description_firstRow ="(//tr[@ng-repeat='row in results']//span/span)[3]";
			    public static final String Transaction_Description_UI ="(//table[@class='table table-striped']//span/span)[4]";
			    public static final String SAP_Validation_ErrorMsg ="//div[contains(text(),'*** Search did not match any cost objects ***')]";
			    public static final String SAP_Validation_ClickFirstRow_xp = "(//sp-table-new/table/tbody/tr/td[3])[1]";
			    public static final String SAP_Validation_ClickFirstRow_xp_SlideOutTitle = "//h1[@translate='WBS Element']";
			    public static final String Deal_Screen_EditDealMaker ="//div[@class='intercept-menu-container']/ul/li[7]/a"; 
				public static final String Common_Historical_Table_xp="//table[@class='table table-striped']";
				public static final String FilteredResultsOn_HistoricalDocumentPage="(//tr[@ng-repeat='row in results']/td[2]//span/span)[1]";
				public static final String FilteredResultsOn_HistoricalDocumentPage_DealMngCC="(//tr[@ng-repeat='row in results']/td[6]//span/span)[1]";
				public static final String DealPage_PONumber="//input[@name= 'poNumber']";
				public static final String Deals_AddDealCurrencydropdown_Msg_xp="//*[text()='USD']";
			//	public static final String Deals_AddDealBtnCostcurrency_id="select[id='currency']";
			//	public static final String Deals_AddDealBtnCostcurrencytype_id="USD";
				public static final String Deals_AddDealCurrencydropdown_Msg="USD";
			  
}
