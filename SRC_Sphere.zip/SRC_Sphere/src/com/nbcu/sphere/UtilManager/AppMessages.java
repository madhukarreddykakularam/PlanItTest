package com.nbcu.sphere.UtilManager;

public class AppMessages {

	public static final String Common_LoginPage_ErrorMsgInvalidSSO_msg = "Not a valid email address";
	public static final String Common_LoginPage_ErrorMsgInvalidPassword_msg = "Incorrect User Id or Password";
	//public static final String Common_LoginPage_LoginMsgValidSSOUser_msg = "Welcome, Name (SSO)";
	//public static final String Common_LoginPage_Text_msg= "We appreciate your patience as we transition from ORBIT into Sphere";
	//public static final String Common_AddModule_Error_msg = "Oops! Please complete all the required fields";
	//public static final String Common_LoginPage_Text_msg="Deals";
	
	public static final String Common_LoginPage_Text_msg="Dashboard";
	public static final String Common_AddModule_Error_msg = "Oops! Please complete and correct all the required fields";
	
	public static final String Users_AddUser_LabelTitle_msg = "Add User";
	//public static final String Users_AddUser_Success_msg = "User added successfully";
	public static final String Users_AddUser_Success_msg = "Success! A new user has been created.";
	
	public static final String Users_AddUser_GenericError_msg = "Error with adding new user";
	public static final String Users_AddUser_DuplicateError_msg = "User with this SSO ID already exists";
	
	public static final String Users_AddUser_NullSSOError_msg = "SSO is a required field";
	public static final String Users_AddUser_NullFirstNameError_msg = "First Name is a required field";
	public static final String Users_AddUser_NullLastNameError_msg = "Last Name is a required field";
	
	public static final String Sap_Validation_Screen_Title_xp="SAP Validation";
	public static final String Sap_Validation_Screen_ChartOfAccount_Title_xp="Chart Of Account";
	
	public static final String Common_HomePage_MainMenuOptions_msg = "MainMenu:Administration,Dashboard,Customers Master,Deals,Transactions,SAP Validation,Billing,Invoice/Statement,Reports";
	public static final String Common_HomePage_SubMenuAdminUserOptions_msg = "SubMenu:Administration:Users,SSP Requests,Fiscal Year Settings,Roles,Queue Logging";
	public static final String Common_HomePage_SubMenuBillingOptions_msg = "SubMenu:Billing:Exceptions,Rejections,Suspensions,Pending Admin Approval,ARC,Draft Billing";
	public static final String Common_HomePage_SubMenuCustomerMastersOptions_msg ="SubMenu:Customers Master:Parent Companies,Customers,Credit Approved Customers"; 
	public static final String Common_HomePage_MainMenuItem_msg = "MainMenu:Dashboard";                                                
	public static final String Common_HomePage_SubMenuReportsOptions_msg="SubMenu:Reports:WIP Recon,Qlikview Reports";
	public static final String Common_HomePage_SubMenuTransactionsOptions_msg="SubMenu:Transactions:Fiscal View,Detail,Current Month Revenue/Expenses";
	
	public static final String Customers_CreditApprovalNotification_Title_msg = "Credit Approval Notification";
	public static final String Customers_AddNationalAccount_LabelTitle_msg = "Add Parent Company";
	public static final String Customers_AddNationalAccount_Success_msg = "Success! A new parent company has been created.";
	//public static final String Customers_AddNationalAccount_DuplicateError_msg = "Error with adding Parent Company";
	public static final String Customers_AddNationalAccount_DuplicateError_msg = "Parent Company with this name already exists";
	public static final String Customers_AddNationalAccount_NullNameError_msg = "Name is a required field";
	public static final String Customers_AddNationalAccount_NullCustomerTypeError_msg = "Customer Type is a required field";
	public static final String Customers_AddNationalAccount_NullProductionTypeError_msg = "Production Type is a required field";
	public static final String Customers_AddNationalAccount_NullAddressError_msg = "Address is a required field";
	
	public static final String Customers_EditNationalAccount_Success_msg = "Success! The parent company was updated.";
	public static final String Customers_EditNationalAccount_DeactivateConfirmation_msg = "Are you sure you want to deactivate account_name_param?";
	public static final String Customers_EditNationalAccount_DeactivateSuccess_msg = "Success! The parent company was deactivated.";
	public static final String Customers_EditCustomer_DeactivateSuccess_msg = "Success! The customer was deactivated.";
	public static final String Customers_EditCustomer_DeactivateSuccess_msg1 = "[Customer Number should be blank]";
	public static final String Customers_Edit_Customer_ReactivateSuccess_msg="Success! The customer was reactivated.";
	
	public static final String  CustomersMaster_AddCustomer_LabelTitle_msg = "Add Customer";
	public static final String CustomersMaster_AddCustomer_Success_msg = "Success! A new customer has been created.";
	public static final String CustomersMaster_EditCustomer_Success_msg = "Success! The customer was updated.";
	
	public static final String CustomersMaster_USPSValidationWindow_Title_msg = "Invalid Address";
	public static final String CustomersMaster_USPSValidationWindow_LabelResponse_msg = "Address Not Found.";
	
	public static final String Roles_EditRole_Success_msg = "Success! The role was updated.";
	public static final String Deals_AddDeal_Contact_ReceiveInvoice_Msg="There can be no more than 3 invoice recieving contacts in ORBIT. This restriction is temporary and will be removed once Sphere manages invoicing.";
	public static final String Deals_AddDeal__Success_msg="";
	public static final String Deals_AddDeal_LabelTitle_Msg="Add Deal";
	public static final String Deals_EditDeal_Success_msg="";
	public static final String Customers_EditCustomer_DeactivateConfirmation_msg = "Are you sure you want to deactivate customer_name_param?";
	public static final String Customers_EditCustomer_ActivateConfirmation_msg = "Are you sure you want to activate this customer?";
	public static final String Customers_EditCustomer_CannotDeactivate_Confirmation_msg="Customer 'customer_name_param' cannot be deactivated until its open deals are closed.";
	public static final String Customers_Deal_Customer_ToCloseDeals_Display_Text_msg="The following deals must be closed before deactivating customer_name_param"; 
	public static final String Deals_Export_Alert_Message_msg="You cannot export more than 2000 records.";
	public static final String Deals_AddDeal_NumberOfDeals_ToolTip_Msg="Using a value greater than 1 will result in multiple deals being created";
	public static final String Deals_AddDeal_NumberOfDeals_Error_Msg="# of deals has to be between 1 and 50";
	public static final String BulkDeals_Title_Length_ErrorMessage_Msg="Title cannot exceed 44 characters";
	public static final String SingleDeal_Title_Length_ErrorMessage_Msg="Title cannot exceed 50 characters";
	public static final String Deals_ExhaustedNumberofDeals_Error_Msg="Deal number range available for upto 0 deals. Contact a system admin to change the range";
	public static final String SSP_AccountStatementPage_InternalCustomer_MainMenuOptions_msg = "MainMenu:Account Statement,Account History,DCS Statement";
	public static final String SSP_AccountStatementPage_ExternalCustomer_MainMenuOptions_msg = "MainMenu:Account Statement,Account History";
	public static final String Order_AddOrder_LabelTitle_msg = "Add Order";
	public static final String Order_AddOrder_DuplicateOrderNumberError_msg="Oops! Please complete and correct all the required fields";
	public static final String SSP_AccountStatementPage_NBCU_Login_msg = "Click 'Login' to go to the NBC SSO login page";
	public static final String Ssp_Requests_User_PasswordNotMatchError_msg ="Passwords do not match";
	public static final String BillingRequest_PopupMessage_msg="This billing request must be rejected and reuploaded";
	public static final String Ssp_Requests_NotRegisteredUserError_msg = "Email address or password is incorrect";
	public static final String ARC_Screen_Reassign_Success_Msg="Success! The transaction has been moved";
	public static final String ARC_Screen_BulkReject_Error_Msg="Department System Number has transactions in the exception queue.";
	public static final String ARC_Screen_BulkReject_Error_Msg1="Cannot Reject Transactions";
	public static final String ARC_Screen_send_Errortext_Msg="Dept system number has transactions that are in exception queue";
	public static final String ARC_Screen_send_Errortext1_Msg="Cannot Send Transactions";
	public static final String AddTransaction_LabelTitle_Msg="Add Transaction(s)";
	public static final String Transaction_PageTitle_xp="//h3[@translate='TRANSACTION_RESEARCH.TITLE']";
	//public static final String Transaction_Order_Error_msg = "Order is not open";
	public static final String Transaction_Order_Error_msg = "Oops! Please complete and correct all the required fields\nOrder is not open";
	public static final String Transaction_Tax_Error_msg = "Oops! Please complete and correct all the required fields";
	public static final String Transaction_Tax1_Error_msg = "Tax $ must be greater than zero";
	public static final String DraftBilling_CostObject_Error_msg = "Cost Object Invalid";
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static final String Common_AddModule_ErrorMsgRequired_msg = "*This field is required";
	public static final String Common_AddModule_ErrorMsgPattern_msg = "*Doesn't match pattern";
	public static final String Common_AddModule_ErrorMsgMaxLength_msg = "*Name must be under 80 characters";
	public static final String Corporations_AddCorporation_ErrorMsgDuplicate_msg = "*Corporation exists";
	public static final String Regions_AddRegion_ErrorMsgDuplicate_msg = "*Region exists";
	public static final String Offices_AddOffice_ErrorMsgDuplicateOfficeName_msg = "*Office exists";
	public static final String Groups_AddGroup_ErrorMsgDuplicateGroupName_msg = "*Group exists";
	
	public static final String Common_AddModule_DialogBox_msg = "Record Added Successfully";
	public static final String Common_UpdateModule_DialogBox_msg = "Record Updated Successfully";
	public static final String Common_DeleteModule_DialogBox_msg = "Record Deleted Successfully";
	
	public static final String Common_ViewModule_DialogBoxOfficeCode_msg = "Please Select Office Code!";
	
	public static final String ProductTiers_AddProductTier_ErrorMsgDuplicate_msg = "*Product Tier exists";
	public static final String Property_AddProperty_ErrorMsgYearBuilt_msg = "*Year built must not be greater than current year";
	public static final String Property_AddProperty_ErrorMsgNumberBedrooms_msg = "*Must be a number";
	
	
	//soumya
	public static final String Deals_AddDealBtnCostcurrency_id="select[id='currency']";
	public static final String Deals_AddDealBtnCostcurrencytype_id="USD";
	public static final String Deals_AddDealCurrencydropdown_Msg="USD";
	
	
	//Sowmya
	public static final String Transaction_FiscalViewStartDateEndDate_Error_msg = "Fiscal End Period must be greater or equal to Fiscal Start Period.";
		
}
