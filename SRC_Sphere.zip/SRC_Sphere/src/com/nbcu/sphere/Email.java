package com.nbcu.sphere;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.util.logging.Level;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.nbcu.sphere.ConfigManager.FileLocSetter;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.SearchTerm;
    public class Email{
        public static  WebDriver driver;
         
     // public static void main(String[]args) throws InterruptedException {
    	  /*System.setProperty("webdriver.chrome.driver","C:\\Automation_Workspace\\Sphere_Automation1\\chromedriver.exe");
    	  driver=new ChromeDriver();
    	  driver.get("http://outlook.com/owa/inbcu.com");
    	  Thread.sleep(3000);
    	  driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys("206500871@tfayd.com");
    	  driver.findElement(By.xpath("//input[@type='submit']")).click();
    	  Thread.sleep(6000);
    	  driver.findElement(By.xpath("//input[@name='username']")).sendKeys("206500871");
    	  driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Varshu#44");
    	  driver.findElement(By.xpath("//button[@name='Submit']")).click();
    	  driver.findElement(By.xpath("//input[@type='submit']")).click();*/
    	  
       
        	 
            /**
             * Searches for e-mail messages containing the specified keyword in
             * Subject field.
             * @param host
             * @param port
             * @param userName
             * @param password
             * @param keyword
             */
            public void searchEmail(String host, String port, String userName,
                    String password, final String keyword) {
                Properties properties = new Properties();
         
                // server setting
                properties.put("mail.imap.host", host);
                properties.put("mail.imap.port", port);
         
                // SSL setting
                properties.setProperty("mail.imap.socketFactory.class",
                        "javax.net.ssl.SSLSocketFactory");
                properties.setProperty("mail.imap.socketFactory.fallback", "false");
                properties.setProperty("mail.imap.socketFactory.port",
                        String.valueOf(port));
         
                Session session = Session.getDefaultInstance(properties);
         
                try {
                    // connects to the message store
                    Store store = session.getStore("imap");
                    store.connect(userName, password);
         
                    // opens the inbox folder
                    Folder folderInbox = store.getFolder("INBOX");
                    folderInbox.open(Folder.READ_ONLY);
         
                    // creates a search criterion
                    SearchTerm searchCondition = new SearchTerm() {
                        @Override
                        public boolean match(Message message) {
                            try {
                                if (message.getSubject().contains(keyword)) {
                                    return true;
                                }
                            } catch (MessagingException ex) {
                                ex.printStackTrace();
                            }
                            return false;
                        }
                    };
         
                    // performs search through the folder
                    Message[] foundMessages = folderInbox.search(searchCondition);
         
                    for (int i = 0; i < foundMessages.length; i++) {
                        Message message = foundMessages[i];
                        String subject = message.getSubject();
                        System.out.println("Found message #" + i + ": " + subject);
                    }
         
                    // disconnect
                    folderInbox.close(false);
                    store.close();
                } catch (NoSuchProviderException ex) {
                    System.out.println("No provider.");
                    ex.printStackTrace();
                } catch (MessagingException ex) {
                    System.out.println("Could not connect to the message store.");
                    ex.printStackTrace();
                }
            }
         
            /**
             * Test this program with a Gmail's account
             */
            public static void main(String[] args) {
                String host = "https://outlook.office365.com/owa/TFAYD.com/";
                String port = "993";
                String userName = "206500871";
                String password = "Varshu#44";
                Email searcher = new Email();
                String keyword = "Asset";
                searcher.searchEmail(host, port, userName, password, keyword);
            
         
        }
 

        

    	    		}
    	  
    	
    	
      
 