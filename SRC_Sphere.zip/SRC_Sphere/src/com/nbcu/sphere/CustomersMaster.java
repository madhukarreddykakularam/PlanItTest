package com.nbcu.sphere;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nbcu.sphere.Common.BusinessFunctionLibrary;
import com.nbcu.sphere.Common.GenericFunctionLibrary;
import com.nbcu.sphere.ConfigManager.FileLocSetter;
import com.nbcu.sphere.ObjectRepository.SphereCommon;
import com.nbcu.sphere.ObjectRepository.SphereModules;
import com.nbcu.sphere.ReportManager.Reporter;
import com.nbcu.sphere.UtilManager.AppMessages;

public class CustomersMaster extends TestDriver {
	SphereModules objSphereModules = new SphereModules();
	SphereCommon objSphereCommon = new SphereCommon();
	AppMessages objAppMessages = new AppMessages();
	BusinessFunctionLibrary objBusinessLib = new BusinessFunctionLibrary();
	GenericFunctionLibrary objGenericFunctionLibrary = new GenericFunctionLibrary();

	//Sprint 2_TC023_ORB-335_Customer_NationalAccount
	@SuppressWarnings("static-access")
	public Reporter TC99(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC99 Started..");

		try {
					
			obj.repAddData( "Verifying headers list on View National Accounts page", "", "", "");
			
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
			Thread.sleep(4000);
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Name");
			fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
			fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
			fnVerifyHeaders(arrHeaderColumns,5,"Location");
						
			//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
			HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
			System.out.println("Hello");
			
			String sQuery = objSQLConfig.sCustomers_ViewAllNationalAccount_Query;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			System.out.println(mTableDataUI.size());
			Boolean bResultFlag = true;
			
			//mTableDataDB.equals(mTableDataDB);
			//for(int i=1;i<=mTableDataUI.size(); i++)
			for(int i=1;i<=mTableDataUI.size(); i++)
			{
				String sAccountname = mTableDataUI.get(i).get(2).toString();
				System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
				if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
				{
					bResultFlag = false;
					obj.repAddData( "Compare record for account name : "+ sAccountname, "Record on UI and DB should match for account name : "+ sAccountname, "Validation failed for account name : "+ sAccountname, "Fail");
				}
				//System.out.println(mTableDataUI.get(i).get(2));
				//System.out.println(mTableDataUI.get(i).get(3));
			}
			
			if(bResultFlag == true)
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" national account records displayed on the screen", "All national account records on UI should match with DB records", "UI and DB validation successful for all national account records", "Pass");
			}
			else
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" national account records displayed on the screen", "All national account records on UI should match with DB records", "UI and DB validation failed for national account records", "Fail");
			}
			
			
			}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC99 Failed!", e );
		}
		finally {
			fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/
			
			fnCloseOpenedForm();

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC99 Completed");
		}
		return obj;
	} //End of Script TC99		
	
	//Sprint 2_TC024_ORB-335_Customer_NationalAccount_Active
		@SuppressWarnings("static-access")
		public Reporter TC100(Reporter obj) throws Exception
		{
			//Boolean bLoginFlag = true;	
			log.info("Execution of Script TC100 Started..");

			try {
						
				obj.repAddData( "Verifying headers list on View National Accounts page", "", "", "");
				
				//objBusinessLib.fnClickMainMenuElement("Administration");
				objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
				WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewModules_LinkActive_xp)));
				Thread.sleep(4000);
			    ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			    fnLoadingPageWait();
			    Thread.sleep(4000);
			    
				WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
				List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
				System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
				fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
				fnVerifyHeaders(arrHeaderColumns,2,"Name");
				fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
				fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
				fnVerifyHeaders(arrHeaderColumns,5,"Location");
				
				obj.repAddData( "Verifying active list of National Accounts", "", "", "");
				//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
				HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
				System.out.println("Hello");
				
				String sQuery = objSQLConfig.sCustomers_ViewActiveNationalAccount_Query;
				TestDriver.conn = objDBUtility.fnOpenDBConnection();
				TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
				HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
				
				objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
				
				System.out.println(mTableDataUI.size());
				Boolean bResultFlag = true;
				
				//mTableDataDB.equals(mTableDataDB);
				for(int i=1;i<=mTableDataUI.size(); i++)
				{
					String sAccountname = mTableDataUI.get(i).get(2).toString();
					System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
					if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
					{
						bResultFlag = false;
						obj.repAddData( "Compare record for active account name : "+ sAccountname, "Record on UI and DB should match for active account name : "+ sAccountname, "Validation failed for active account name : "+ sAccountname, "Fail");
					}
					//System.out.println(mTableDataUI.get(i).get(2));
					//System.out.println(mTableDataUI.get(i).get(3));
				}
				
				if(bResultFlag == true)
				{
					obj.repAddData( "Compare all "+mTableDataUI.size()+" active national account records displayed on the screen", "All active national account records on UI should match with DB records", "UI and DB validation successful for all active national account records", "Pass");
				}
				else
				{
					obj.repAddData( "Compare all "+mTableDataUI.size()+" active national account records displayed on the screen", "All active national account records on UI should match with DB records", "UI and DB validation failed for national active account records", "Fail");
				}
				
				ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
				
				}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC100 Failed!", e );
			}
			finally {
				fnCloseOpenedForm();
				/*if((bLoginFlag==true && driver!=null) )
				{
					fnSignOut();
				}*/

				if(!testCaseStatus)
				{
					Reporter.iTotalFail++;	
				}
				else
				{
					Reporter.iTotalPass++;
				}
				log.info("Execution of Script TC100 Completed");
			}
			return obj;
		} //End of Script TC100		
		
		
		//Sprint 2_TC025_ORB-335_Customer_NationalAccount_Inactive
				@SuppressWarnings("static-access")
				public Reporter TC101(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC101 Started..");

					try {
								
						obj.repAddData( "Verifying headers list on View National Accounts page", "", "", "");
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewModules_LinkInactive_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
						fnLoadingPageWait();
					    Thread.sleep(4000);
					    
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Location");
						
						obj.repAddData( "Verifying inactive list of National Accounts", "", "", "");
						//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
						System.out.println("Hello");
						
						String sQuery = objSQLConfig.sCustomers_ViewInactiveNationalAccount_Query;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						System.out.println(mTableDataUI.size());
						Boolean bResultFlag = true;
						
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							String sAccountname = mTableDataUI.get(i).get(2).toString();
							System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
							if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
							{
								bResultFlag = false;
								obj.repAddData( "Compare record for inactive account name : "+ sAccountname, "Record on UI and DB should match for inactive account name : "+ sAccountname, "Validation failed for inactive account name : "+ sAccountname, "Fail");
							}
							//System.out.println(mTableDataUI.get(i).get(2));
							//System.out.println(mTableDataUI.get(i).get(3));
						}
						
						if(bResultFlag == true)
						{
							obj.repAddData( "Compare all "+mTableDataUI.size()+" inactive national account records displayed on the screen", "All inactive national account records on UI should match with DB records", "UI and DB validation successful for all inactive national account records", "Pass");
						}
						else
						{
							obj.repAddData( "Compare all "+mTableDataUI.size()+" inactive national account records displayed on the screen", "All inactive national account records on UI should match with DB records", "UI and DB validation failed for inactive national account records", "Fail");
						}
						
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC101 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC101 Completed");
					}
					return obj;
				} //End of Script TC101
	
	//Sprint 2_TC026_ORB-280_Customer_NationalAccount_Add new
	public Reporter TC102(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC102 Started..");

		try {
					
			obj.repAddData( "Adding a new national account", "", "", "");
			String sNationalAccount = objBusinessLib.fnAddNationalAccount();
			System.out.println(sNationalAccount);
			/*
			String sRandom = String.valueOf(fnRandomNum(10001, 99999));
			String sNameUI = "AutoTestAccountName_"+sRandom;
			String sEmailUI = "AutoEmail_"+sRandom+"@nbcuni.com";
			String sAddr1UI = "AutoAddr1_"+sRandom;
			String sAddr2UI = "AutoAddr2_"+sRandom;
			String sAddr3UI = "AutoAddr3_"+sRandom;
			
			String sCityUI = "AutoCity_"+sRandom;
			String sZipUI = sRandom;
		
			
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
		    
			ClickByXpath(SphereModules.Customers_AddNationalAccount_LinkAddPlusSign_xp, "Add Parent Company Link", true);
			fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_LabelTitle_msg, SphereModules.Customers_AddNationalAccount_LabelAddNationalAccountTitle_xp);
			
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, sNameUI, "Name");
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
		    
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
		    fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,"CA");
		    SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
		    fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"United States of America (USA)");
		   
		    					    
		    ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);
		    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgSuccess_xp)));
		    String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.Customers_AddNationalAccount_MsgSuccess_xp)).getText();
		    HighlightElementByXpath(SphereModules.Customers_AddNationalAccount_MsgSuccess_xp);
		    System.out.println(sSuccessMsg);
		    fnVerifyLabelMsgText(AppMessages.Customers_AddNationalAccount_Success_msg, sSuccessMsg.trim());
		    */
		    /*
		    String sQuery = objSQLConfig.sUsers_AddUser_Query;
		    sQuery = sQuery.replaceAll("sso_id_param",sRandom);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sSSOIdDB = mTableDataDB.get(1).get(1).toString();
			String sFirstNameDB = mTableDataDB.get(1).get(2).toString();
			String sLastNameDB = mTableDataDB.get(1).get(3).toString();
			String sRoleDB = mTableDataDB.get(1).get(6).toString();
			String sCostCenterDB = mTableDataDB.get(1).get(7).toString();
			
			if(sSSOIdUI.equalsIgnoreCase(sSSOIdDB) && sFirstNameUI.equalsIgnoreCase(sFirstNameDB) && sLastNameUI.equalsIgnoreCase(sLastNameDB) && sRoleUI.equalsIgnoreCase(sRoleDB) && sCostCenterUI.equalsIgnoreCase(sCostCenterDB))
			{	
				obj.repAddData( "Compare user record for SSO Id : "+ sSSOIdUI, "User record on UI and DB should match for SSO Id : "+ sSSOIdUI, "Validation successful for SSO Id : "+ sSSOIdUI, "Pass");
			}
			else
			{
				obj.repAddData( "Compare user record for SSO Id : "+ sSSOIdUI, "User record on UI and DB should match for SSO Id : "+ sSSOIdUI, "Validation failed for SSO Id : "+ sSSOIdUI, "Fail");
			}
			*/
									
			}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC102 Failed!", e );
		}
		finally {
			fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC102 Completed");
		}
		return obj;
	} //End of Script TC102		

	
	//Sprint 2_TC027_ORB-280_Customer_NationalAccount_Add_Existing
		public Reporter TC103(Reporter obj) throws Exception
		{
			//Boolean bLoginFlag = true;	
			log.info("Execution of Script TC103 Started..");

			try {
						
				obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
				String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
				System.out.println(sAccountNameUI);
				
				
				obj.repAddData( "Adding a duplicate national account", "", "", "");
							
				String [] arrNationalAccount = sAccountNameUI.split("_");
				String sRandom = arrNationalAccount[1].toString(); 
				
				/*String sQuery = objSQLConfig.sCustomers_AddNationalAccount_Query;
				sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);*/
				
				String sEmailUI = "AutoEmail_"+sRandom+"@nbcuni.com";
				
				/*String sAddr1UI = "AutoAddr1_"+sRandom;
				String sAddr2UI = "AutoAddr2_"+sRandom;
				String sAddr3UI = "AutoAddr3_"+sRandom;	
				String sCityUI = "AutoCity_"+sRandom;
				String sZipUI = sRandom;*/
				
				String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
				String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
				String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
				String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
				String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
				
				//String sStateUI = "CA";
				String sStateUI = mTestPhaseData.get(iTC_ID).get("State").trim();
				
				//String sCountryUI = "United States of America (USA)";
				String sCountryUI = mTestPhaseData.get(iTC_ID).get("Country").trim();
				String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
				String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
				
				//objBusinessLib.fnClickMainMenuElement("Administration");
				objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
				WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
			    
				ClickByXpath(SphereModules.Customers_AddNationalAccount_LinkAddPlusSign_xp, "Add Parent Company Link", true);
				fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_LabelTitle_msg, SphereModules.Customers_AddNationalAccount_LabelAddNationalAccountTitle_xp);
				
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, sAccountNameUI, "Name");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
				fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
				fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
			    
				//Below line is temporary 
				fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
				
				fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
				fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
				
			   
			    					    
			    ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);

			    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)));
				String sErrorMsg = driver.findElement(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)).getText();
				HighlightElementByXpath(SphereModules.Customers_AddNationalAccount_MsgError_xp);
				System.out.println(sErrorMsg);
				fnVerifyLabelMsgText(AppMessages.Customers_AddNationalAccount_DuplicateError_msg, sErrorMsg.trim());
				 		
				/*conn = objDBUtility.fnOpenDBConnection();
				rset = objDBUtility.fnGetDBData(conn,sQuery);
				int iTotalRows = 0;
				while(rset.next())
				{
					iTotalRows = iTotalRows+1;
				}
				
				System.out.println(String.valueOf(iTotalRows));
				if(iTotalRows==1)
				{
					obj.repAddData( "Verify duplicate record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record not added for national account : "+ sAccountNameUI, "Pass"); 
				}
				else
				{
					obj.repAddData( "Verify duplicate record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record added for national account : "+ sAccountNameUI, "Fail");
				}
				objDBUtility.fnCloseDBConnection(stmt, rset, conn);*/
				 
				ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnCancel_xp, "Cancel Button", true);
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
				ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
										
				}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC103 Failed!", e );
			}
			finally {
				fnCloseOpenedForm();
				/*if((bLoginFlag==true && driver!=null) )
				{
					fnSignOut();
				}*/

				if(!testCaseStatus)
				{
					Reporter.iTotalFail++;	
				}
				else
				{
					Reporter.iTotalPass++;
				}
				log.info("Execution of Script TC103 Completed");
			}
			return obj;
		} //End of Script TC103		
		
		public Reporter TC103_Backup(Reporter obj) throws Exception
		{
			//Boolean bLoginFlag = true;	
			log.info("Execution of Script TC103 Started..");

			try {
						
				obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
				String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
				System.out.println(sAccountNameUI);
				
				
				obj.repAddData( "Adding a duplicate national account", "", "", "");
							
				String [] arrNationalAccount = sAccountNameUI.split("_");
				String sRandom = arrNationalAccount[1].toString(); 
				
				String sQuery = objSQLConfig.sCustomers_AddNationalAccount_Query;
				sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);
				
				String sEmailUI = "AutoEmail_"+sRandom+"@nbcuni.com";
				
				/*String sAddr1UI = "AutoAddr1_"+sRandom;
				String sAddr2UI = "AutoAddr2_"+sRandom;
				String sAddr3UI = "AutoAddr3_"+sRandom;	
				String sCityUI = "AutoCity_"+sRandom;
				String sZipUI = sRandom;*/
				
				String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
				String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
				String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
				String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
				String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
				
				//String sStateUI = "CA";
				String sStateUI = mTestPhaseData.get(iTC_ID).get("State").trim();
				
				//String sCountryUI = "United States of America (USA)";
				String sCountryUI = mTestPhaseData.get(iTC_ID).get("Country").trim();
				String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
				String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
				
				//objBusinessLib.fnClickMainMenuElement("Administration");
				objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
				WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
			    
				ClickByXpath(SphereModules.Customers_AddNationalAccount_LinkAddPlusSign_xp, "Add Parent Company Link", true);
				fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_LabelTitle_msg, SphereModules.Customers_AddNationalAccount_LabelAddNationalAccountTitle_xp);
				
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, sAccountNameUI, "Name");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
				fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
				fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
			    
				//Below line is temporary 
				fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
				
				fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
				fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
				SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
				
			   
			    					    
			    ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);

			    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)));
				String sErrorMsg = driver.findElement(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)).getText();
				HighlightElementByXpath(SphereModules.Customers_AddNationalAccount_MsgError_xp);
				System.out.println(sErrorMsg);
				fnVerifyLabelMsgText(AppMessages.Customers_AddNationalAccount_DuplicateError_msg, sErrorMsg.trim());
				 		
				conn = objDBUtility.fnOpenDBConnection();
				rset = objDBUtility.fnGetDBData(conn,sQuery);
				int iTotalRows = 0;
				while(rset.next())
				{
					iTotalRows = iTotalRows+1;
				}
				
				System.out.println(String.valueOf(iTotalRows));
				if(iTotalRows==1)
				{
					obj.repAddData( "Verify duplicate record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record not added for national account : "+ sAccountNameUI, "Pass"); 
				}
				else
				{
					obj.repAddData( "Verify duplicate record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record added for national account : "+ sAccountNameUI, "Fail");
				}
				objDBUtility.fnCloseDBConnection(stmt, rset, conn);
				 
				ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnCancel_xp, "Cancel Button", true);
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
				ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
										
				}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC103 Failed!", e );
			}
			finally {
				fnCloseOpenedForm();
				/*if((bLoginFlag==true && driver!=null) )
				{
					fnSignOut();
				}*/

				if(!testCaseStatus)
				{
					Reporter.iTotalFail++;	
				}
				else
				{
					Reporter.iTotalPass++;
				}
				log.info("Execution of Script TC103 Completed");
			}
			return obj;
		} //End of Script TC103	
		//Sprint 2_TC028_ORB-280_Customer_NationalAccount_Add_MandatoryField
				public Reporter TC104(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC104 Started..");

					try {
								
						obj.repAddData( "Adding a national account with mandatory fields missing", "", "", "");
						
						String sRandom = String.valueOf(fnRandomNum(10001, 99999));
						String sAccountNameUI = "AUTOTESTACCOUNT_"+sRandom;
												
						String sEmailUI = "AutoEmail_"+sRandom+"@nbcuni.com";
						
						/*String sAddr1UI = "AutoAddr1_"+sRandom;
						String sAddr2UI = "AutoAddr2_"+sRandom;
						String sAddr3UI = "AutoAddr3_"+sRandom;
						String sCityUI = "AutoCity_"+sRandom;
						String sZipUI = sRandom;*/
						//String sStateUI = "CA";
						String sStateUI = mTestPhaseData.get(iTC_ID).get("State").trim();
						
						
						String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
						String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
						String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
						String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
						String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
						
						//String sCountryUI = "United States of America (USA)";
						String sCountryUI = mTestPhaseData.get(iTC_ID).get("Country").trim();
						
						String sQuery = objSQLConfig.sCustomers_AddNationalAccount_Query;
						sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
					    
						ClickByXpath(SphereModules.Customers_AddNationalAccount_LinkAddPlusSign_xp, "Add Parent Company Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_LabelTitle_msg, SphereModules.Customers_AddNationalAccount_LabelAddNationalAccountTitle_xp);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
						ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);
						WebElement ele=driver.findElement(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp));
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);    
					   // waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)));
					   
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullNameError_msg, SphereModules.Customers_AddNationalAccount_MsgNameError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullCustomerTypeError_msg, SphereModules.Customers_AddNationalAccount_MsgCustomerTypeError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullProductionTypeError_msg, SphereModules.Customers_AddNationalAccount_MsgProductionTypeError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullAddressError_msg, SphereModules.Customers_AddNationalAccount_MsgAddressError_xp);
						fnVerifyLabelMsgTextByXpath(AppMessages.Common_AddModule_Error_msg, SphereModules.Customers_AddNationalAccount_MsgError_xp);
						
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, "", "Name");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
					    
						//Below line is temporary 
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
						
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
						
					   
					    					    
					    ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);
					    
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)));
						fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullNameError_msg, SphereModules.Customers_AddNationalAccount_MsgNameError_xp);
						fnVerifyLabelMsgTextByXpath(AppMessages.Common_AddModule_Error_msg, SphereModules.Customers_AddNationalAccount_MsgError_xp);
												 		
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, sAccountNameUI, "Name");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, "", "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
					    
						//Below line is temporary 
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
						
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
						
					   
					    					    
					    ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);
					    
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)));
						fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullAddressError_msg, SphereModules.Customers_AddNationalAccount_MsgAddressError_xp);
						fnVerifyLabelMsgTextByXpath(AppMessages.Common_AddModule_Error_msg, SphereModules.Customers_AddNationalAccount_MsgError_xp);
											
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, "", "Name");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
					    
						//Below line is temporary 
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
						
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, "", "City");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
						
					   
					    					    
					    ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnAdd_xp, "Add Button", true);
					    
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_AddNationalAccount_MsgError_xp)));
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullNameError_msg, SphereModules.Customers_AddNationalAccount_MsgNameError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullAddressError_msg, SphereModules.Customers_AddNationalAccount_MsgAddressError_xp);
						fnVerifyLabelMsgTextByXpath(AppMessages.Common_AddModule_Error_msg, SphereModules.Customers_AddNationalAccount_MsgError_xp);
	
						conn = objDBUtility.fnOpenDBConnection();
						rset = objDBUtility.fnGetDBData(conn,sQuery);
						int iTotalRows = 0;
						while(rset.next())
						{
							iTotalRows = iTotalRows+1;
						}
						
						System.out.println(String.valueOf(iTotalRows));
						if(iTotalRows==1)
						{
							obj.repAddData( "Verify record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record added for national account : "+ sAccountNameUI, "Fail"); 
						}
						else
						{
							obj.repAddData( "Verify record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record not added for national account : "+ sAccountNameUI, "Pass");
						}
						objDBUtility.fnCloseDBConnection(stmt, rset, conn);
						 
						ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnCancel_xp, "Cancel Button", true);
							
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC104 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC104 Completed");
					}
					return obj;
				} //End of Script TC104		
	
				
				//Sprint 2_TC029_ORB-280_Customer_NationalAccount_Cancel
				public Reporter TC105(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC105 Started..");

					try {
								
						obj.repAddData( "Adding a national account with mandatory fields missing", "", "", "");
						
						String sRandom = String.valueOf(fnRandomNum(10001, 99999));
						String sAccountNameUI = "AUTOTESTACCOUNT_"+sRandom;
												
						String sEmailUI = "AutoEmail_"+sRandom+"@nbcuni.com";
						/*String sAddr1UI = "AutoAddr1_"+sRandom;
						String sAddr2UI = "AutoAddr2_"+sRandom;
						String sAddr3UI = "AutoAddr3_"+sRandom;
						
						String sCityUI = "AutoCity_"+sRandom;
						String sZipUI = sRandom;*/
						//String sStateUI = "CA";
						
						String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
						String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
						String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
						String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
						String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
						
						String sStateUI = mTestPhaseData.get(iTC_ID).get("State").trim();
						
						//String sCountryUI = "United States of America (USA)";
						String sCountryUI = mTestPhaseData.get(iTC_ID).get("Country").trim();
						String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
						String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
						
						String sQuery = objSQLConfig.sCustomers_AddNationalAccount_Query;
						sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
					    
						ClickByXpath(SphereModules.Customers_AddNationalAccount_LinkAddPlusSign_xp, "Add Parent Company Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_LabelTitle_msg, SphereModules.Customers_AddNationalAccount_LabelAddNationalAccountTitle_xp);
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputName_id, sAccountNameUI, "Name");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
					    
						//Below line is temporary 
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
						
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  
						
					   
					    					    
						ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnCancel_xp, "Cancel Button", true);
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
					    
					    conn = objDBUtility.fnOpenDBConnection();
						rset = objDBUtility.fnGetDBData(conn,sQuery);
						int iTotalRows = 0;
						while(rset.next())
						{
							iTotalRows = iTotalRows+1;
						}
						
						System.out.println(String.valueOf(iTotalRows));
						if(iTotalRows==1)
						{
							obj.repAddData( "Verify record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record added for national account : "+ sAccountNameUI, "Fail"); 
						}
						else
						{
							obj.repAddData( "Verify record for national account : "+ sAccountNameUI, "Record should not be added for national account : "+ sAccountNameUI, "Record not added for national account : "+ sAccountNameUI, "Pass");
						}
						objDBUtility.fnCloseDBConnection(stmt, rset, conn);
						 
						
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC105 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC105 Completed");
					}
					return obj;
				} //End of Script TC105	
				
				
				//Sprint 2_TC030_ORB-280_Customer_NationalAccount_Edit_Update
				public Reporter TC106(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC106 Started..");

					try {
					
						String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;

						obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
						String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
						System.out.println(sAccountNameUI);
						
						
						obj.repAddData( "Updating an existing national account", "", "", "");
									
						String [] arrNationalAccount = sAccountNameUI.split("_");
						String sRandom = arrNationalAccount[1].toString()+"_Updated"; 
						
						String sQuery = objSQLConfig.sCustomers_EditNationalAccount_Query;
						sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);
						
						String sEmailUI = "AutoEmail_"+sRandom+"@nbcuni.com";
						//String sCustomerTypeUI = "Internal - Corporate";
						//String sProductionTypeUI = "Major Studio";
						String sCustomerTypeUI = mTestPhaseData.get(iTC_ID).get("Customer_Type").trim();
						String sProductionTypeUI = mTestPhaseData.get(iTC_ID).get("Production_Type").trim();
					/*	String sAddr1UI = "AutoAddr1_"+sRandom;
						String sAddr2UI = "AutoAddr2_"+sRandom;
						String sAddr3UI = "AutoAddr3_"+sRandom;
						
						String sCityUI = "AutoCity_"+sRandom;
						String sZipUI = arrNationalAccount[1].toString();  //Not changing Zip

*/						
						String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
						String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
						String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
						String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
						String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
						
						String sStateUI = mTestPhaseData.get(iTC_ID).get("State").trim();
		
						String sCountryUI = mTestPhaseData.get(iTC_ID).get("Country").trim();
						
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sAccountNameUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sAccountNameUI, SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp);	
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id, sAddr3UI, "Address Line 3");
					    
						//Below line is temporary 
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"ARUBA");
						
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sCityUI, "City");
						//SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sZipUI, "Zip");  //Not changing Zip
										    
					    ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnSave_xp, "Save Button", true);
					    fnLoadingPageWait();

					    /*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp)));
							String sSuccessMsg = driver.findElement(By.xpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.Customers_EditNationalAccount_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						 		
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						
						String sAccountNameDB = mTableDataDB.get(1).get(1).toString().trim();
						String sEmailDB = mTableDataDB.get(1).get(2).toString().trim();
						String sAddr1DB = mTableDataDB.get(1).get(3).toString().trim();
						String sAddr2DB = mTableDataDB.get(1).get(4).toString().trim();
						String sAddr3DB = mTableDataDB.get(1).get(5).toString().trim();
						
						String sCityDB = mTableDataDB.get(1).get(6).toString().trim();
						String sStateDB = mTableDataDB.get(1).get(7).toString().trim();
						String sZipDB = mTableDataDB.get(1).get(8).toString().trim();
						String sCountryDB = mTableDataDB.get(1).get(9).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(1).get(10).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(1).get(11).toString().trim();
						/*
						sLookupQuery = sLookupQuery.replaceAll("lookup_code_param",sCustomerTypeIdDB); 
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sLookupQuery);
						mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						String sCustomerTypeDB = mTableDataDB.get(1).get(1).toString();
						
						sLookupQuery = sLookupQuery.replaceAll(sCustomerTypeIdDB,sProductionTypeIdDB); 
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sLookupQuery);
						mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						String sProductionTypeDB = mTableDataDB.get(1).get(1).toString();
						*/
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						if(sAccountNameUI.equalsIgnoreCase(sAccountNameDB) && sEmailUI.equalsIgnoreCase(sEmailDB) && sAddr1UI.equalsIgnoreCase(sAddr1DB) && sAddr2UI.equalsIgnoreCase(sAddr2DB) && sAddr3UI.equalsIgnoreCase(sAddr3DB) && sCityUI.equalsIgnoreCase(sCityDB) && sStateUI.equalsIgnoreCase(sStateDB) && sZipUI.equalsIgnoreCase(sZipDB) && sCountryUI.equalsIgnoreCase(sCountryDB) && sCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB) && sProductionTypeUI.equalsIgnoreCase(sProductionTypeDB))
						{	
							obj.repAddData( "Compare national account record for account name : "+ sAccountNameUI, "National account record on UI and DB should match for account name : "+ sAccountNameUI, "Validation successful for account name : "+ sAccountNameUI, "Pass");
						}
						else
						{
							obj.repAddData( "Compare national account record for account name : "+ sAccountNameUI, "National account record on UI and DB should match for account name : "+ sAccountNameUI, "Validation failed for account name : "+ sAccountNameUI, "Fail");
						}
						 
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC106 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC106 Completed");
					}
					return obj;
				} //End of Script TC106
				
				//Sprint 2_TC031_ORB-330_Customer_NationalAccount_Deactivate
				public Reporter TC107(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC107 Started..");

					try {
					
						
						obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
						String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
						System.out.println(sAccountNameUI);
						String sQuery = objSQLConfig.sCustomers_EditNationalAccount_DeactivateQuery;
						
						obj.repAddData( "Deactivating an existing national account", "", "", "");
														
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sAccountNameUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sAccountNameUI, SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp);	
					    ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnDeactivate_xp, "Deactivate Button", true);

					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateConfirmation_xp)));
						String sDeactivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateConfirmation_xp);
						System.out.println(sDeactivateConfirmationMsg);
						String sExpConfMsg = AppMessages.Customers_EditNationalAccount_DeactivateConfirmation_msg.replaceAll("account_name_param", sAccountNameUI);
						fnVerifyLabelMsgText(sExpConfMsg, sDeactivateConfirmationMsg.trim());
						
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboDeactNationalAccount_id, "Test Account");
						
						ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnDeactivateYes_xp, "Yes", true);
						Thread.sleep(4000);
					
						//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateSuccess_xp)));
						//fnVerifyLabelMsgTextByXpath(AppMessages.Customers_EditNationalAccount_DeactivateSuccess_msg,SphereModules.Customers_EditNationalAccount_MsgDeactivateSuccess_xp);
						//Thread.sleep(4000);
						//ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
							ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
						} catch (Exception e) {

						}*/
						
						/*String sDeactivateSuccessMsg = driver.findElement(By.xpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateSuccess_xp)).getText();
						HighlightElementByXpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateSuccess_xp);
						System.out.println(sDeactivateSuccessMsg);
						fnVerifyLabelMsgText(AppMessages.Customers_EditNationalAccount_DeactivateSuccess_msg, sDeactivateSuccessMsg.trim());
						*/
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery.replaceAll("account_name_param", sAccountNameUI));
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						if(mTableDataDB.get(1).get(1).toString().equalsIgnoreCase("0"))
						{
							obj.repAddData( "Deactivate national account : "+ sAccountNameUI, "National account : "+ sAccountNameUI+" should be deactivated", "National account : "+ sAccountNameUI+" deactivated successfully", "Pass");
						}
						else
						{
							obj.repAddData( "Deactivate national account : "+ sAccountNameUI, "National account : "+ sAccountNameUI+" should be deactivated", "National account : "+ sAccountNameUI+" not deactivated", "Fail");
						}
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC107 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC107 Completed");
					}
					return obj;
				} //End of Script TC107		
				
				//Sprint 2_TC032_ORB-330_Customer_NationalAccount_Deactivate_Cancel
				public Reporter TC108(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC108 Started..");

					try {
					
						
						obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
						String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
						System.out.println(sAccountNameUI);
						String sQuery = objSQLConfig.sCustomers_EditNationalAccount_DeactivateQuery;
						
						obj.repAddData( "Cancel deactivation of an existing national account", "", "", "");
														
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sAccountNameUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sAccountNameUI, SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp);	
						
						
										    
					    ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnDeactivate_xp, "Deactivate Button", true);

					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateConfirmation_xp)));
						String sDeactivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditNationalAccount_MsgDeactivateConfirmation_xp);
						System.out.println(sDeactivateConfirmationMsg);
						String sExpConfMsg = AppMessages.Customers_EditNationalAccount_DeactivateConfirmation_msg.replaceAll("account_name_param", sAccountNameUI);
						fnVerifyLabelMsgText(sExpConfMsg, sDeactivateConfirmationMsg.trim());
						
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboDeactNationalAccount_id, "Test Account");
						
						ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnDeactivateNo_xp, "No", true);
						
						try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
							ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
						} catch (Exception e) {

						}
						
					
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery.replaceAll("account_name_param", sAccountNameUI));
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						if(mTableDataDB.get(1).get(1).toString().equalsIgnoreCase("1"))
						{
							obj.repAddData( "Cancel deactivation of national account : "+ sAccountNameUI, "National account : "+ sAccountNameUI+" should not be deactivated", "National account : "+ sAccountNameUI+" not deactivated successfully", "Pass");
						}
						else
						{
							obj.repAddData( "Cancel deactivation of national account : "+ sAccountNameUI, "National account : "+ sAccountNameUI+" should not be deactivated", "National account : "+ sAccountNameUI+" deactivated", "Fail");
						}
						
											
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						 
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC108 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC108 Completed");
					}
					return obj;
				} //End of Script TC108		
				
				//TC030_ORB-67_Customer_ViewScreen
				@SuppressWarnings("static-access")
				public Reporter TC137(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC137 Started..");

					try {
								
						obj.repAddData( "Verifying fields on Add Customer page", "", "", "");
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						//objBusinessLib.fnSelectDynamicFilters("Credit","Credit Declined");
						///////////////////////
						
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Customer Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Parent Company");
						fnVerifyHeaders(arrHeaderColumns,6,"Location");
						
									
						//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
						String sQuery = objSQLConfig.sMasterCustomers_ViewAllCustomer_Query;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						System.out.println(mTableDataUI.size());
						Boolean bResultFlag = true;
						
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
							System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
							if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
							{
								bResultFlag = false;
								obj.repAddData( "Compare record for customer name : "+ sCustomerName, "Record on UI and DB should match for customer name : "+ sCustomerName, "Validation failed for customer name : "+ sCustomerName, "Fail");
							}
							//System.out.println(mTableDataUI.get(i).get(2));
							//System.out.println(mTableDataUI.get(i).get(3));
						}
						
						if(bResultFlag == true)
						{
							obj.repAddData( "Compare all "+mTableDataUI.size()+" customer records displayed on the screen", "All customer records on UI should match with DB records", "UI and DB validation successful for all customer records", "Pass");
						}
						else
						{
							obj.repAddData( "Compare all "+mTableDataUI.size()+" customer records displayed on the screen", "All customer records on UI should match with DB records", "UI and DB validation failed for customer records", "Fail");
						}
				
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC137 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC137 Completed");
					}
					return obj;
				} //End of Script TC137		
				
				//Sprint 4_TC036_ORB-Customers_Add Customer
				@SuppressWarnings("static-access")
				public Reporter TC1099(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1099 Started..");

					try {
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1099 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1099 Completed");
					}
					return obj;
				} //End of Script TC1099	
				
				public Reporter TC1110(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1099 Started..");

					try {
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver,60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"FMP External");
						objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ResendBtn, "Add Button", true);
						objGenericFunctionLibrary.fnLoadingPageWait();
						
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1099 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1099 Completed");
					}
					return obj;
				} //End 
				//TC015_ORB-279_Add Customer_UIValidation
				public Reporter TC138(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC138 Started..");

					try {
								
						obj.repAddData( "Verifying fields on add Customer page", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
						Thread.sleep(4000);
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
						
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name", true, true);
						fnCheckFieldDisplayById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id, "Customer Type", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id", true, true);
						fnCheckFieldDisplayById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id, "Production Type", true, true);
						
					
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id, "Parent Company", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id, "Collector", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id, "Legal Entity", true, true);
						
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_id, "Phone Number", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Permanent Customer - Yes Radio", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "Permanent Customer - No Radio", true, true);
						
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true, true);
						
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true);  //post-condition
						
						//Not rquired until user put any data
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/
						
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC138 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC138 Completed");
					}
					return obj;
				} //End of Script TC138		
				
				
				//TC016_ORB-279_Add Customer_UIValidation
				@SuppressWarnings("static-access")
				public Reporter TC139(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC139 Started..");

					try {
								
						obj.repAddData( "Verifying fields on add Customer page", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
						Thread.sleep(4000);
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
						
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name", true, true);
						fnCheckFieldDisplayById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id, "Customer Type", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id", true, true);
						fnCheckFieldDisplayById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id, "Production Type", true, true);
						
					
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id, "Parent Company", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id, "Collector", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id, "Legal Entity", true, true);
						
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_id, "Phone Number", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Permanent Customer - Yes Radio", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "Permanent Customer - No Radio", true, true);
						
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true, true);
						
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true);  //post-condition
						
						//Not required until user puts any data
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/
						
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC139 Failed!", e );
					}
					finally {
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC139 Completed");
					}
					return obj;
				} //End of Script TC139		
				
				
				
				
				
				
				
				
				//TC007_ORB-279_Add Customer_New
				public Reporter TC140(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC140 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC140 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC140 Completed");
					}
					return obj;
				} //End of Script TC140	
				
				
				//TC018_ORB-279_Add Customer_Cancel
				@SuppressWarnings("static-access")
				public Reporter TC141(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC141 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Canceling adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Cancel");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC141 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC141 Completed");
					}
					return obj;
				} //End of Script TC141	
				
				//TC019_ORB-279_Add Customer_Duplicate
				@SuppressWarnings("static-access")
				public Reporter TC142(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC142 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a duplicate new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Duplicate");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC142 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC142 Completed");
					}
					return obj;
				} //End of Script TC142	
				
				
				//TC010_ORB-279_Update Customer_CreditLimit Update
				@SuppressWarnings("static-access")
				public Reporter TC143(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC143 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
						System.out.println(sCustomer);
						//sCustomer="AUTOTESTCUSTOMER_28303";
						String sRandom = String.valueOf(fnRandomNum(1001, 9999));
						
						//String [] arrCustomer = sCustomer.split("_");
						//String sRandom = arrCustomer[1].toString(); 
						String sUpdatedCreditLimitUI = sRandom+"1";
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sRandom+"1", "Credit Limit Box");
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						fnLoadingPageWait();
						
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						//DB Validation to follow
					    
					    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
						
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
						String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
						sCreditLimitDB=sCreditLimitDB.replace("$","");
						sCreditLimitDB=sCreditLimitDB.replace(",","");
						sCreditLimitDB=sCreditLimitDB.replace(".00","");
							
						if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && 
							sUpdatedCreditLimitUI.equalsIgnoreCase(sCreditLimitDB)) //&& 
									//sCreditPermanentDB.equalsIgnoreCase("1"))
							{	
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeUI);
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							//objBusinessLib.fnClickSubMenuElement("Dashboard","");
							fnLoadingPageWait();
							Thread.sleep(4000);
						
						}
					    catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC143 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC143 Completed");
					}
					return obj;
				} //End of Script TC143	
				
				
				//TC011_ORB-279_Update Customer_ProductionStartUpdate
				@SuppressWarnings("static-access")
				public Reporter TC144(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC144 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						/*String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedCustomerTypeUI = "Internal Comcast Programming";
						String sUpdatedProductionTypeUI = "Feature";*/
						
						Date dTomorrow = DateUtils.addDays(new Date(), +1);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
						String sStartDateUI1 = sdf.format(dTomorrow);
						
						sdf.applyPattern("yyyy-MM-dd");
						String sStartDateUIDBpattern=sdf.format(dTomorrow);
											
						/*Date date = new Date();
						SimpleDateFormat sdftoday = new SimpleDateFormat("yyyy-MM-dd");
						String sStartDateUI2 = sdftoday.format(date);*/
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						/*fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						*/
						//ClickByXpath("//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]", "CreditLimit", true);	
						//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sUpdatedCreditLimitUI, "Credit Limit Box");
						
						//ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).clear();
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						fnLoadingPageWait();
						/*
						try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						//DB Validation to follow
					   /* 
					    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
						String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
						
						String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
						
						String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
						String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
						String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
						String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
						String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
						String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
						String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
						String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
						String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
						
						String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
						String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
															
							
							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && 
									sStartDateUIDBpattern.equalsIgnoreCase(sStartDateDB))
							{	
								//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
								TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
							    TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
								
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}*/
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							//objBusinessLib.fnClickSubMenuElement("Dashboard","");
							fnLoadingPageWait();
							Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC144 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC144 Completed");
					}
					return obj;
				} //End of Script TC144	
				
				public Reporter TC144_Backup(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC144 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						/*String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedCustomerTypeUI = "Internal Comcast Programming";
						String sUpdatedProductionTypeUI = "Feature";*/
						
						Date dTomorrow = DateUtils.addDays(new Date(), +1);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
						String sStartDateUI1 = sdf.format(dTomorrow);
						
						sdf.applyPattern("yyyy-MM-dd");
						String sStartDateUIDBpattern=sdf.format(dTomorrow);
											
						/*Date date = new Date();
						SimpleDateFormat sdftoday = new SimpleDateFormat("yyyy-MM-dd");
						String sStartDateUI2 = sdftoday.format(date);*/
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						/*fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						*/
						//ClickByXpath("//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]", "CreditLimit", true);	
						//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sUpdatedCreditLimitUI, "Credit Limit Box");
						
						//ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).clear();
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						fnLoadingPageWait();
						/*
						try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						//DB Validation to follow
					    
					    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
						String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
						
						String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
						
						String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
						String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
						String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
						String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
						String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
						String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
						String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
						String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
						String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
						
						String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
						String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
															
							
							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && 
									sStartDateUIDBpattern.equalsIgnoreCase(sStartDateDB))
							{	
								//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
								TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
							    TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
								
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							//objBusinessLib.fnClickSubMenuElement("Dashboard","");
							fnLoadingPageWait();
							Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC144 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC144 Completed");
					}
					return obj;
				} //End of Script TC144
				//TC012_ORB-279_Update Customer_Permanent Customer_ExpirationDate
				@SuppressWarnings("static-access")
				public Reporter TC145(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC145 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						//String sUpdatedCustomerTypeUI = "Internal Comcast Programming";
						//String sUpdatedProductionTypeUI = "Feature";
						
						Date dTomorrow = DateUtils.addDays(new Date(), +1);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
						String sStartDateUI1 = sdf.format(dTomorrow);
						
						sdf.applyPattern("yyyy-MM-dd");
						String sStartDateUIDBpattern=sdf.format(dTomorrow);
											
						/*Date date = new Date();
						SimpleDateFormat sdftoday = new SimpleDateFormat("yyyy-MM-dd");
						String sStartDateUI2 = sdftoday.format(date);*/
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						
						//ClickByXpath("//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]", "CreditLimit", true);	
						//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sUpdatedCreditLimitUI, "Credit Limit Box");
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_InputCreditExpDate_id, "Credit Expiration Date", true);
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputCreditExpDate_id)).clear();
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputCreditExpDate_id)).sendKeys(sStartDateUI1);
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						fnLoadingPageWait();	
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						//DB Validation to follow
					    /*
						  String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
					    	 int iRow = 1; //for add 
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sCreditExpDateDB = mTableDataDB.get(iRow).get(18).toString().trim();
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
							String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
							
							String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
							
							String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
							String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
							
							String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
							String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
									
								if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && 
										sCreditPermanentDB.equalsIgnoreCase("0") && 
										sStartDateUIDBpattern.equalsIgnoreCase(sCreditExpirationDB))
								{	
									//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
									TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
									TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
									obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
								}
								else
								{
									obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
								}
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							//objBusinessLib.fnClickSubMenuElement("Dashboard","");
							fnLoadingPageWait();*/
							Thread.sleep(4000);
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC145 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC145 Completed");
					}
					return obj;
				} //End of Script TC145	
				
				public Reporter TC145_Backup(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC145 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						//String sUpdatedCustomerTypeUI = "Internal Comcast Programming";
						//String sUpdatedProductionTypeUI = "Feature";
						
						Date dTomorrow = DateUtils.addDays(new Date(), +1);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
						String sStartDateUI1 = sdf.format(dTomorrow);
						
						sdf.applyPattern("yyyy-MM-dd");
						String sStartDateUIDBpattern=sdf.format(dTomorrow);
											
						/*Date date = new Date();
						SimpleDateFormat sdftoday = new SimpleDateFormat("yyyy-MM-dd");
						String sStartDateUI2 = sdftoday.format(date);*/
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						
						//ClickByXpath("//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]", "CreditLimit", true);	
						//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sUpdatedCreditLimitUI, "Credit Limit Box");
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_InputCreditExpDate_id, "Credit Expiration Date", true);
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputCreditExpDate_id)).clear();
						driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputCreditExpDate_id)).sendKeys(sStartDateUI1);
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						fnLoadingPageWait();	
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						//DB Validation to follow
					    
						  String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
					    	 int iRow = 1; //for add 
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							/*String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sCreditExpDateDB = mTableDataDB.get(iRow).get(18).toString().trim();*/
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
							String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
							
							String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
							
							String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
							String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
							
							String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
							String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
									
								if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && 
										sCreditPermanentDB.equalsIgnoreCase("0") && 
										sStartDateUIDBpattern.equalsIgnoreCase(sCreditExpirationDB))
								{	
									//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
									TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
									TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
									obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
								}
								else
								{
									obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
								}
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							//objBusinessLib.fnClickSubMenuElement("Dashboard","");
							fnLoadingPageWait();
							Thread.sleep(4000);
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC145 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC145 Completed");
					}
					return obj;
				} //End of Script TC145	
				//TC013_ORB-279_Update Customer_ProductionType_ParentCompany_Collector
				@SuppressWarnings("static-access")
				public Reporter TC146(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC146 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedCustomerTypeUI = "Universal Film";
						String sUpdatedProductionTypeUI = "Feature";
						String sCustomerTypeList = "";
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						sCustomerTypeList = fnComboBoxDataList(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id, "Customer Type", true, true);					
						String [] arrCustomerType = sCustomerTypeList.split(";");
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", false); 
						
						//Not required
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/

						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
//
					    /////Commented this piece of code because update customer type is no longer valid						    
						/*for(int i=0; i<arrCustomerType.length;i++)
						{	
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							sUpdatedCustomerTypeUI = arrCustomerType[i].toString().trim();
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
							fnLoadingPageWait();
							
							try {
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
								
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
								
								String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
								HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
								System.out.println(sSuccessMsg);
								fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
							} catch (Exception e) {
								obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						
						//DB Validation to follow
					    
					   
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
												
							
							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && sUpdatedCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB) && sUpdatedProductionTypeUI.equalsIgnoreCase(sProductionTypeDB) && sCreditPermanentDB.equalsIgnoreCase("1"))
							{	
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sUpdatedCustomerTypeUI);
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
						}//End of Customer Type list For loop 	
*/							
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC146 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC146 Completed");
					}
					return obj;
				} //End of Script TC146	

				//TC024_ORB-279_Update Customer_UI Validation
				@SuppressWarnings("static-access")
				public Reporter TC147(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC147 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						/*String sUpdatedCreditLimitUI = sRandom+"1";
						String sUpdatedCustomerTypeUI = "Internal Comcast Programming";
						String sUpdatedProductionTypeUI = "Feature";*/
						
						obj.repAddData( "Verifying fields on edit customer page", "", "", "");
						
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						fnCheckFieldDisplayById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id, "Customer Type", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id", true, true);
						fnCheckFieldDisplayById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id, "Production Type", true, true);
						
					
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id, "Parent Company", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id, "Collector", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id, "Legal Entity", true, true);
						
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true, true);
						//fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_id, "Phone Number", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number", true, true);
						fnCheckFieldDisplayByXpath("//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]", "Credit Limit", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Permanent Customer - Yes Radio", true, true);
						fnCheckFieldDisplayById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "Permanent Customer - No Radio", true, true);
						
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_EditCustomer_LabelCreatedBy_xp, "Created By", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_EditCustomer_LabelCreatedOn_xp, "Created On", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_EditCustomer_LabelCreditAvaliable_xp, "Credit Available", true, true);
						
					//	fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save Button", true, true);
						fnCheckFieldDisplayByXpath(SphereModules.CustomersMaster_EditCustomer_BtnDeactivate_xp, "Deactivate Button", true, true);
						
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true); //Post Condition
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp," " , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						//Not required
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/

						
						//DB Validation to follow
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC147 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC147 Completed");
					}
					return obj;
				} //End of Script TC147	

				//TC028_ORB-534_SuccessMessage_AddCustomer
				@SuppressWarnings("static-access")
				public Reporter TC148(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC148 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC148 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC148 Completed");
					}
					return obj;
				} //End of Script TC148	
				
				
				//TC029_ORB-534_SuccessMessage_EditCustomer
				@SuppressWarnings("static-access")
				public Reporter TC149(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC149 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						String sUpdatedCreditLimitUI = "123456";
						String sUpdatedCustomerTypeUI = "Internal Comcast Programming";
						String sUpdatedProductionTypeUI = "Feature";
						
						obj.repAddData( "Updating an existing customer", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						
						//ClickByXpath("//div[@class='btn creditLimit']/p[contains(@ng-click,'editCustomer.editCreditLimit')]", "CreditLimit", true);	
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sUpdatedCreditLimitUI, "Credit Limit Box");
						
						ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						fnLoadingPageWait();
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
					    
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
						String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
						
						TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
					    SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
					    //objBusinessLib.fnClickSubMenuElement("Dashboard","");
					    fnLoadingPageWait();
					    Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC149 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC149 Completed");
					}
					return obj;
				} //End of Script TC149	
				
				
				//TC011_ORB-533_Customer_Dynamic Search_Parent Company
				@SuppressWarnings("static-access")
				public Reporter TC150(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC150 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add"); //Remove comment after testing
						//sCustomer = "AutoTestCustomer_78884"; //Comment after testing
						System.out.println(sCustomer);
						
						//Added below lines to take care of refresh
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);
						//End Refresh check
						
						/*ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);*/
						
						
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						objBusinessLib.fnSelectDynamicFilters("Parent Company",mTestPhaseData.get(iTC_ID).get("Parent_Company").trim(),2); //2 is for clicking both filter type and selecting value checkbox);
						///////////////////////
												
						//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 10);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						
						Thread.sleep(5000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
									
						boolean bFlag = false;
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
							String sCustomerType = mTableDataUI.get(i).get(3).toString();
							String sProductionType = mTableDataUI.get(i).get(4).toString();
							String sParentCompany = mTableDataUI.get(i).get(5).toString();
							
							if(!sParentCompany.trim().equalsIgnoreCase(mTestPhaseData.get(iTC_ID).get("Parent_Company").trim()))
							{
								obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on Parent Company : "+mTestPhaseData.get(iTC_ID).get("Parent_Company").trim(), "Record for other Parent Company : "+sParentCompany+ " found.", "Fail");
								break;
							}
							
							if(sCustomerName.equalsIgnoreCase(sCustomer))
							{
								bFlag = true;
								obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " filtered successfully", "Pass");
								break;
							}
							
						}
						
						if(bFlag==false)
						{
							obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " not filtered", "Fail");
						}
						
						if(mTableDataUI.size()>0)
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Parent Company", "Pass");
						}
						else
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Parent Company", "Fail");
						}
						
						objBusinessLib.fnSelectDynamicFilters("Parent Company",mTestPhaseData.get(iTC_ID).get("Parent_Company").trim(),1); //1 for de-selecting checkbox - post condition
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC150 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC150 Completed");
					}
					return obj;
				} //End of Script TC150	
				
				//TC012_ORB-533_Customer_Dynamic Search_CustomerGroup  //Not implemented yet - earlier it was credit test
				@SuppressWarnings("static-access")
				public Reporter TC151(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC151 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						//Added below lines to take care of refresh
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);
						//End Refresh check
						
						//ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						//Thread.sleep(4000);
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						objBusinessLib.fnSelectDynamicFilters("Credit","Credit Declined",2); //2 is for clicking both filter type and selecting value checkbox
						///////////////////////
												
						//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 10);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						
						Thread.sleep(5000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
									
						boolean bFlag = false;
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
						/*	String sCustomerType = mTableDataUI.get(i).get(3).toString();
							String sProductionType = mTableDataUI.get(i).get(4).toString();
							String sParentCompany = mTableDataUI.get(i).get(5).toString();
							
							if(!sParentCompany.trim().equalsIgnoreCase(mTestPhaseData.get(iTC_ID).get("Parent_Company").trim()))
							{
								obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on Parent Company : "+mTestPhaseData.get(iTC_ID).get("Parent_Company").trim(), "Record for other Parent Company : "+mTestPhaseData.get(iTC_ID).get("Parent_Company").trim()+ " found.", "Fail");
								break;
							}*/
							
							if(sCustomerName.equalsIgnoreCase(sCustomer))
							{
								bFlag = true;
								obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " filtered successfully", "Pass");
								break;
							}
							
						}
						
						if(bFlag==false)
						{
							obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " not filtered", "Fail");
						}
						
						if(mTableDataUI.size()>0)
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Credit", "Pass");
						}
						else
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Credit", "Fail");
						}
						
						objBusinessLib.fnSelectDynamicFilters("Credit","Credit Declined",1); //1 for de-selecting checkbox - post condition
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC151 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC151 Completed");
					}
					return obj;
				} //End of Script TC151	
				
				
				//TC013_ORB-533_Customer_Dynamic Search_CustomerType
				@SuppressWarnings("static-access")
				public Reporter TC152(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC152 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						//Added below lines to take care of refresh
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);
						//End Refresh check
						
						//ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						//Thread.sleep(4000);
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						objBusinessLib.fnSelectDynamicFilters("Customer Type",mTestPhaseData.get(iTC_ID).get("Customer_Type").trim(),2); //2 is for clicking both filter type and selecting value checkbox);
						///////////////////////
												
						//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 10);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						
						Thread.sleep(5000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
									
						boolean bFlag = false;
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
							String sCustomerType = mTableDataUI.get(i).get(3).toString();
							String sProductionType = mTableDataUI.get(i).get(4).toString();
							String sParentCompany = mTableDataUI.get(i).get(5).toString();
							
							if(!sCustomerType.trim().equalsIgnoreCase(mTestPhaseData.get(iTC_ID).get("Customer_Type").trim()))
							{
								obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on Customer Type : "+mTestPhaseData.get(iTC_ID).get("Customer_Type").trim(), "Record for other Customer Type : "+sCustomerType+ " found.", "Fail");
								break;
							}
							
							if(sCustomerName.equalsIgnoreCase(sCustomer))
							{
								bFlag = true;
								obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " filtered successfully", "Pass");
								break;
							}
							
						}
						
						if(bFlag==false)
						{
							obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " not filtered", "Fail");
						}
						
						if(mTableDataUI.size()>0)
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Customer Type", "Pass");
						}
						else
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Customer Type", "Fail");
						}
						
						objBusinessLib.fnSelectDynamicFilters("Customer Type",mTestPhaseData.get(iTC_ID).get("Customer_Type").trim(),1); //1 for de-selecting checkbox - post condition
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC152 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC152 Completed");
					}
					return obj;
				} //End of Script TC152	
				
				
				//TC014_ORB-533_Customer_Dynamic Search_ProductionType
				@SuppressWarnings("static-access")
				public Reporter TC153(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC153 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						//Added below lines to take care of refresh
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);
						//End Refresh check
						//ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						//Thread.sleep(4000);
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						objBusinessLib.fnSelectDynamicFilters("Production Type",mTestPhaseData.get(iTC_ID).get("Production_Type").trim(),2); //2 is for clicking both filter type and selecting value checkbox);
						///////////////////////
												
						//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 10);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						
						Thread.sleep(5000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
									
						boolean bFlag = false;
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
							String sCustomerType = mTableDataUI.get(i).get(3).toString();
							String sProductionType = mTableDataUI.get(i).get(4).toString();
							String sParentCompany = mTableDataUI.get(i).get(5).toString();
							
							if(!sProductionType.trim().equalsIgnoreCase(mTestPhaseData.get(iTC_ID).get("Production_Type").trim()))
							{
								obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on Production Type : "+mTestPhaseData.get(iTC_ID).get("Production_Type").trim(), "Record for other Production Type : "+sProductionType+ " found.", "Fail");
								break;
							}
							
							if(sCustomerName.equalsIgnoreCase(sCustomer))
							{
								bFlag = true;
								obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " filtered successfully", "Pass");
								break;
							}
							
						}
						
						if(bFlag==false)
						{
							obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " not filtered", "Fail");
						}
						
						if(mTableDataUI.size()>0)
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Production Type", "Pass");
						}
						else
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Production Type", "Fail");
						}
						
						objBusinessLib.fnSelectDynamicFilters("Production Type",mTestPhaseData.get(iTC_ID).get("Production_Type").trim(),1); //1 for de-selecting checkbox - post condition
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC153 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC153 Completed");
					}
					return obj;
				} //End of Script TC153	
				
				//TC014a_ORB-533_Customer_Dynamic Search_Credit_CustomerType_ProductionType
				@SuppressWarnings("static-access")
				public Reporter TC155(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC155 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add"); //Delete comment after testing
						//sCustomer = "AutoTestCustomer_52229";  //Comment after testing
						System.out.println(sCustomer);
						
						
						//Added below lines to take care of refresh
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);
						//End Refresh check
						//ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						//Thread.sleep(4000);
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						
						//objBusinessLib.fnSelectDynamicFilters("Credit","Credit Declined",2);
						objBusinessLib.fnSelectDynamicFilters("Customer Type",mTestPhaseData.get(iTC_ID).get("Customer_Type").trim(),2); //2 is for clicking both filter type and selecting value checkbox
						objBusinessLib.fnSelectDynamicFilters("Production Type",mTestPhaseData.get(iTC_ID).get("Production_Type").trim(),2); //2 is for clicking both filter type and selecting value checkbox
						///////////////////////
												
						//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 10);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						
						Thread.sleep(5000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
									
						boolean bFlag = false;
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
							String sCustomerType = mTableDataUI.get(i).get(3).toString();
							String sProductionType = mTableDataUI.get(i).get(4).toString();
							String sParentCompany = mTableDataUI.get(i).get(5).toString();
							
							if(!sProductionType.trim().equalsIgnoreCase(mTestPhaseData.get(iTC_ID).get("Production_Type").trim()))
							{
								obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on Production Type : "+mTestPhaseData.get(iTC_ID).get("Production_Type").trim(), "Record for other Production Type : "+sProductionType+ " found.", "Fail");
								break;
							}
							
							if(sCustomerName.equalsIgnoreCase(sCustomer))
							{
								bFlag = true;
								obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " filtered successfully", "Pass");
								break;
							}
							
						}
						
						if(bFlag==false)
						{
							obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " not filtered", "Fail");
						}
						
						if(mTableDataUI.size()>0)
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Credit, Customer Type and Production Type", "Pass");
						}
						else
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Credit, Customer Type and Production Type", "Fail");
						}
						
						//objBusinessLib.fnSelectDynamicFilters("Credit","Credit Declined",2);  //post-condition
						objBusinessLib.fnSelectDynamicFilters("Customer Type",mTestPhaseData.get(iTC_ID).get("Customer_Type").trim(),2);  //post-condition 
						objBusinessLib.fnSelectDynamicFilters("Production Type",mTestPhaseData.get(iTC_ID).get("Production_Type").trim(),2);  //post-condition
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC155 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC155 Completed");
					}
					return obj;
				} //End of Script TC155	
				
				//Customer_Contacts_Validation 
				@SuppressWarnings("static-access")
				public Reporter TC1577(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1577 Started..");

					try {
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with Address", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1577 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1577 Completed");
					}
					return obj;
				} //End of Script TC1577	
				
				
				public Reporter TC1588(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1588 Started..");

					try {
					
						String sCustomerUI ="";
						String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
						obj.repAddData( "Pre-Condition: Adding a new customer with Address", "", "", "");
						
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add"); //Uncomment after testing
						//sCustomerUI = "AutoTestCustomer_90761"; //Comment after testing
						
						System.out.println(sCustomerUI);
						
						
						obj.repAddData( "Updating an existing customer with address", "", "", "");
									
						String [] arrCustomer = sCustomerUI.split("_");
						String sRandom = arrCustomer[1].toString()+"_Updated"; 
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
						sQuery = sQuery.replaceAll("customer_name_param",sCustomerUI);
						
						/*String sAddr1UI = "AutoAddr1_"+sRandom;
						String sAddr2UI = "AutoAddr2_"+sRandom;
						String sAddr3UI = "AutoAddr3_"+sRandom;
						
						String sCityUI = "AutoCity_"+sRandom;
						String sZipUI = arrCustomer[1].toString();  //Not changing Zip
						
*/						
						String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
						String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
						String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
						String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
						String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
						
						String sStateUI = mTestPhaseData.get(iTC_ID).get("State").trim();
						
						String sCountryUI = mTestPhaseData.get(iTC_ID).get("Country").trim();
						
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(5000);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);	
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditAddress_xp, "Edit Address button", true);
												
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id, sAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
					    
						//Below line is temporary 
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"ARUBA");
						
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sCountryUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboState_id,sStateUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, sCityUI, "City");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, sZipUI, "Zip");  //Not changing Zip
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
					   
										    
					    //ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnSave_xp, "Save Button", true);
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
					    fnLoadingPageWait();

					   /* try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomerUI+",Update");
							
							String sSuccessMsg = driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						conn = objDBUtility.fnOpenDBConnection();
						rset = objDBUtility.fnGetDBData(conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
						
												
						String sAddr1DB = mTableDataDB.get(1).get(10).toString().trim();
						String sAddr2DB = mTableDataDB.get(1).get(11).toString().trim();
						String sAddr3DB = mTableDataDB.get(1).get(12).toString().trim();
						String sCountryDB = mTableDataDB.get(1).get(13).toString().trim();
						String sStateDB = mTableDataDB.get(1).get(14).toString().trim();
						String sCityDB = mTableDataDB.get(1).get(15).toString().trim();
						String sZipDB = mTableDataDB.get(1).get(16).toString().trim();
						String sMultEmailDB = mTableDataDB.get(1).get(16).toString().trim();
						String sOrbitCustNumberDB = mTableDataDB.get(1).get(17).toString().trim();
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						//Verify Address
						//Add sMultEmailDB.equalsIgnoreCase("1"))  once the bug of saving this is fixed
						if(sAddr1UI.trim().equalsIgnoreCase(sAddr1DB) && 
								sAddr2UI.equalsIgnoreCase(sAddr2DB) && 
								sAddr3UI.equalsIgnoreCase(sAddr3DB) && 
								sCountryUI.equalsIgnoreCase(sCountryDB) && 
								sStateUI.equalsIgnoreCase(sStateDB) && 
								sCityUI.equalsIgnoreCase(sCityDB) && 
								sZipUI.equalsIgnoreCase(sZipDB)) // && sMultEmailDB.equalsIgnoreCase("1"))
						{	
							TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomerUI+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeUI);
							obj.repAddData( "Verify customer address for customer name : "+ sCustomerUI, "Customer address on UI and DB should match for customer name : "+ sCustomerUI, "Address validation successful for customer name : "+ sCustomerUI, "Pass");
						}
						else
						{
							obj.repAddData( "Verify customer address for customer name : "+ sCustomerUI, "Customer address on UI and DB should match for customer name : "+ sCustomerUI, "Address Validation failed for customer name : "+ sCustomerUI, "Fail");
						}
						 
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1588 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1588 Completed");
					}
					return obj;
				} //End of Script TC1588
				
			/*	//TC022_ORB-533_DynamicFilters_ParentCompany  //Now TC150
				@SuppressWarnings("static-access")
				public Reporter TC159(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC159 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer", "", "", "");
						
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add"); //Remove comment after testing
						//sCustomer = "AutoTestCustomer_78884"; //Comment after testing
						System.out.println(sCustomer);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						///////////////////////
						//objBusinessLib.fnSelectDynamicFilters("Customer Type", "Internal - Corporate");
						objBusinessLib.fnSelectDynamicFilters("Parent Company",mTestPhaseData.get(iTC_ID).get("Parent_Company").trim(),2); //2 is for clicking both filter type and selecting value checkbox);
						
						
						///////////////////////
												
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 10);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						
						Thread.sleep(5000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						
									
						boolean bFlag = false;
						//mTableDataDB.equals(mTableDataDB);
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							String sCustomerName = mTableDataUI.get(i).get(2).toString();
							
							if(sCustomerName.equalsIgnoreCase(sCustomer))
							{
								bFlag = true;
								obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " filtered successfully", "Pass");
								break;
							}
							
						}
						
						if(bFlag==false)
						{
							obj.repAddData( "Verify filtered record for customer name : "+ sCustomer, "Record on UI should be filtered for customer name : "+ sCustomer, "Customer Record for customer name : "+ sCustomer+ " not filtered", "Fail");
						}
						
						if(mTableDataUI.size()>0)
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Parent Company", "Pass");
						}
						else
						{
							obj.repAddData( "Verify all filtered records on Customer page", "Records should be filtered based on filter criteria", "Total " + mTableDataUI.size()+ " records found for filter condition : Parent Company", "Fail");
						}
						
						objBusinessLib.fnSelectDynamicFilters("Parent Company",mTestPhaseData.get(iTC_ID).get("Parent_Company").trim(),1); //1 for de-selecting checkbox - post condition
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC159 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC159 Completed");
					}
					return obj;
				} //End of Script TC159	
				
				
*/
				
		
				
				//TC031_ORB-531_Search_Customer
				public Reporter TC156(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC156 Started..");

					try {
							String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
							String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();					
							String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
							String sCustomer ="";
							String sLocation = "";
							
							obj.repAddData( "Adding a new customer", "", "", "");
							sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add"); //Remove comment after testing
							//sCustomer = "AutoTestCustomer_24205"; //Delete after testing
							System.out.println(sCustomer);
							
							String [] arrCustomer = sCustomer.split("_");
							String sRandom = arrCustomer[1].toString(); 
							
							
							//String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
							//String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
							//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
							String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
							//String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
							
							sLocation = sCityUI;   ///+", "+sStateUI;  //Lookups like State are not part of Search  
							
							String sQuery = objSQLConfig.sMasterCustomers_ViewCustomer_Query;
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							conn = objDBUtility.fnOpenDBConnection();
							rset = objDBUtility.fnGetDBData(conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);

							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNubmerDB = mTableDataDB.get(1).get(1).toString().trim();
							
							
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							String sTableXPath = SphereModules.Common_ViewCustomersModule_Table_xp;
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sTableXPath)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							Thread.sleep(4000);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomerNubmerDB,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomerNubmerDB.substring(3),sCustomer,2);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomer,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomer.substring(8),sCustomer,2);
							
							/*objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomerTypeUI,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomerTypeUI.substring(3),sCustomer,2);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sProductionTypeUI,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sProductionTypeUI.substring(3),sCustomer,2);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sParentCompanyUI,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sParentCompanyUI.substring(3),sCustomer,2);*/
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sLocation,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sLocation.substring(3),sCustomer,2);
							//objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,"City_"+sRandom,sCustomer,2);
							
													
							
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC156 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC156 Completed");
					}
					return obj;
				} //End of Script TC156	
				
				public Reporter TC737(Reporter obj) throws Exception
				{
				
					log.info("Execution of Script TC156 Started..");

					try {
							String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
							String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();					
							String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
							String sCustomer ="";
							String sLocation = "";
							
							obj.repAddData( "Adding a new customer", "", "", "");
							sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add"); //Remove comment after testing
							
							System.out.println(sCustomer);
							
							String [] arrCustomer = sCustomer.split("_");
							String sRandom = arrCustomer[1].toString(); 
							
							
							String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
							
							sLocation = sCityUI;   ///+", "+sStateUI;  //Lookups like State are not part of Search  
							
							String sQuery = objSQLConfig.sMasterCustomers_ViewCustomer_Query;
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							conn = objDBUtility.fnOpenDBConnection();
							rset = objDBUtility.fnGetDBData(conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);

							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNubmerDB = mTableDataDB.get(1).get(1).toString().trim();
							
							
							String sRandom1 = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 14999));
							String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
							System.out.println(sDealTitleRandom);
							String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;
						
							String sPoNumberUI = "AutoPONumber_"+sRandom;
							
							String sProjectName= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Project").trim();
					
							String sFirstName="AutoTestFirstName"+sRandom;
							String sLastName="AutoTestLastName"+sRandom;
							String sContactTitleUI="AutoTitle"+sRandom;
							String sEmailAddressUI="AutoTestEmail"+"sRandom+@nbcuni.com";
							String sphoneRandom= String.valueOf(objGenericFunctionLibrary.fnRandomNum(2222222, 9999999));
							String sContactPhone ="248"+sphoneRandom;
							String sCustomerUI= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Customer").trim();
							String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
						    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
						    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
						  
						    Date date = new Date();
						    String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);//not using SimpleDateFormat
							Date dexpiredday = DateUtils.addDays(new Date(), +5);
							SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
							String sEndDateUI2 = sdf.format(dexpiredday);
							
							objBusinessLib.fnClickMainMenuElement("Deals");
							WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
							Thread.sleep(10000); 

							objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
							objGenericFunctionLibrary.fnLoadingPageWait();
							objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
						    String sCostCenterUIOrder =TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center_Order");
							objBusinessLib.fnSelectCostCenter(1, sCostCenterUIOrder);
										
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
							objGenericFunctionLibrary.fnLoadingPageWait();
							
							objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
							objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
						
							
							objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
							objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
							objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
							
							
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
							objGenericFunctionLibrary.fnLoadingPageWait();
							objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
							
							
							objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_AddNewContact_xp,"Add Contact",true);
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_FirstName_xp, "Test First Name", "First Name ");
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_LastName_xp, "Test Last Name", "Last Name");
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_Title_xp, "AutoTitle", "Title");
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_PhoneNumber_xp, sContactPhone, "Phone Number");
						
							objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddDeal_EmailAddress_xp, "test@email.com", "Email Address");
							objGenericFunctionLibrary.ClickById(SphereModules. Deals_AddDeal_MainContact_id, "Main Contact", true);
							objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDeal_ReceivesInvoice_id, "Receives Invoice", true);
							objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_AddNewContact_save_xp,"Check", true);
							objGenericFunctionLibrary.fnLoadingPageWait();
								objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
							objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
							objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
							objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
							
							objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
							objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
							objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
							objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,sEndDateUI2,"Insurance Expiration");
							Thread.sleep(3000);
							objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
							objGenericFunctionLibrary.fnLoadingPageWait();
							
							String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
							sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
							    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
							    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();	
							    
							    objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
								 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
								 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
								 Thread.sleep(3000); 
								 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
								 String Deal_StatusUI= Deal_Status.getText();
								 Thread.sleep(3000); 
								  if(Deal_StatusUI.contains("COMPLETE"))
								    	{
								    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
								    		return obj;
								    	}else
									
								    	
								    	{
								    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
								    	
								    	}
								   
							    
							
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC156 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC156 Completed");
					}
					return obj;
				} //End of Script TC156	
				
				//TC032_ORB-531_Search_ParentCompany
				public Reporter TC157(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC157 Started..");

					try {
							
						
							/*String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
							String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();					
							String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();*/
							String sLocation = "";
							String sNationalAccount = "";
							
							obj.repAddData( "Adding a new national account", "", "", "");
							sNationalAccount = objBusinessLib.fnAddNationalAccount();  //Remove comment after testing
							//sNationalAccount = "AutoTestAccountName_66150"; //Delete after testing
							System.out.println(sNationalAccount);

							String [] arrNationalAccount = sNationalAccount.split("_");
							String sRandom = arrNationalAccount[1].toString(); 
							
							sLocation = "AutoCity_"+sRandom;   ///+", "+sStateUI;  //Lookups like State are not part of Search  
							
							String sQuery = objSQLConfig.sCustomers_ViewNationalAccount_Query;
						    sQuery = sQuery.replaceAll("account_name_param",sNationalAccount);
							conn = objDBUtility.fnOpenDBConnection();
							rset = objDBUtility.fnGetDBData(conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);

							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sAccountNubmerDB = mTableDataDB.get(1).get(1).toString().trim();
							//String sAccountNubmerDB="PC001173";
							//sNationalAccount="AUTOTESTACCOUNT_87588";
							objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							String sTableXPath = SphereModules.Common_ViewNationalAccountModule_Table_xp;
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sTableXPath)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							Thread.sleep(4000);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sAccountNubmerDB,sNationalAccount,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sAccountNubmerDB.substring(3),sNationalAccount,2);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sNationalAccount,sNationalAccount,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sNationalAccount.substring(8),sNationalAccount,2);
							
							/*objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomerTypeUI,sNationalAccount,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sCustomerTypeUI.substring(3),sNationalAccount,2);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sProductionTypeUI,sNationalAccount,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sProductionTypeUI.substring(3),sNationalAccount,2);
							
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sParentCompanyUI,sCustomer,2);
							objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sParentCompanyUI.substring(3),sCustomer,2);*/
							
							//objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,sLocation,sNationalAccount,2);  //Not part main parent company
							//objBusinessLib.fnVerifyCustSearchFilterData(sTableXPath,"AutoCity",sNationalAccount,2); //Not part main parent company
							
						
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC157 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC157 Completed");
					}
					return obj;
				} //End of Script TC157	
				
				
				//TC025_ORB-530_Customer_Form_Validation_AddCust_Dropdown List
				public Reporter TC158(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC158 Started..");

					try {
						
						String sExpCustomerTypeList = mTestPhaseData.get(iTC_ID).get("Customer_Type_List").trim();
						String sExpProductionTypeList = mTestPhaseData.get(iTC_ID).get("Production_Type_List").trim();
						String sExpCollectorList = mTestPhaseData.get(iTC_ID).get("Collector_List").trim();
						String sExpLegalEntityList = mTestPhaseData.get(iTC_ID).get("Legal_Entity_List").trim();
								
						obj.repAddData( "Verifying fields on add Customer page", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
						Thread.sleep(4000);
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
						
						
						String sActCustomerTypeList = fnComboBoxDataList(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id, "Customer Type", true, true);
						String sActProductionTypeList = fnComboBoxDataList(SphereModules.Customers_EditNationalAccount_ComboProductionType_id, "Production Type", true, true);
						
						//Collector and Legal Entity not implemented yet
						String sActCollectorList = fnComboBoxDataList(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id, "Collector", true, true);
						//String sActLegalEntityList = fnComboBoxDataList(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id, "Legal Entity", true, true);
						
						
						//Data changed -- should be updated in Test Data and then uncomment below code
						/*fnVerifyTextAndReport(sExpCustomerTypeList,sActCustomerTypeList, "Customer Type List");
						fnVerifyTextAndReport(sExpProductionTypeList,sActProductionTypeList, "Production Type List");*/
						
						//Collector and Legal Entity not implemented yet
						fnVerifyTextAndReport(sExpCollectorList,sActCollectorList, "Collector List");
						//fnVerifyTextAndReport(sExpLegalEntityList,sActLegalEntityList, "Legal Entity List");
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true);  //post-condition
						
						//Not required until user changes anything on the form
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/
						
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC158 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC158 Completed");
					}
					return obj;
				} //End of Script TC158		
				
				
				//TC025_ORB-530_Customer_Form_Validation_AddCust_Dropdown List
				public Reporter TC159(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC159 Started..");

					try {
						
						String sExpCustomerTypeList = mTestPhaseData.get(iTC_ID).get("Customer_Type_List").trim();
						String sExpProductionTypeList = mTestPhaseData.get(iTC_ID).get("Production_Type_List").trim();
						String sExpCollectorList = mTestPhaseData.get(iTC_ID).get("Collector_List").trim();
						String sExpLegalEntityList = mTestPhaseData.get(iTC_ID).get("Legal_Entity_List").trim();
								
						obj.repAddData( "Verifying fields on add Customer page", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);

						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						
						String sActCustomerTypeList = fnComboBoxDataList(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id, "Customer Type", true, true);
						String sActProductionTypeList = fnComboBoxDataList(SphereModules.Customers_EditNationalAccount_ComboProductionType_id, "Production Type", true, true);
						
						//Collector and Legal Entity not implemented yet
						String sActCollectorList = fnComboBoxDataList(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id, "Collector", true, true);
						//String sActLegalEntityList = fnComboBoxDataList(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id, "Legal Entity", true, true);
						
						
						//Data changed -- should be updated in Test Data and then uncomment below code
						/*fnVerifyTextAndReport(sExpCustomerTypeList,sActCustomerTypeList, "Customer Type List");
						fnVerifyTextAndReport(sExpProductionTypeList,sActProductionTypeList, "Production Type List");*/
						
						//Collector and Legal Entity not implemented yet
						fnVerifyTextAndReport(sExpCollectorList,sActCollectorList, "Collector List");
						//fnVerifyTextAndReport(sExpLegalEntityList,sActLegalEntityList, "Legal Entity List");
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true); //Post Condition
						
						
						//Not required until user changes anything on the form
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/

						
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC159 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC159 Completed");
					}
					return obj;
				} //End of Script TC159		
				
				
				//Sprint 2_TC028_ORB-280_Customer_NationalAccount_Add_MandatoryField
				public Reporter TC160(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC160 Started..");

					try {
								
						obj.repAddData( "Adding a customer with mandatory fields missing", "", "", "");

						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
						Thread.sleep(4000);
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, "TEST", "Address Line 1");
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
						//Using national account messages as both are same    
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_AddCustomer_MsgError_xp)));
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullNameError_msg, SphereModules.CustomersMaster_AddCustomer_MsgNameError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullCustomerTypeError_msg, SphereModules.CustomersMaster_AddCustomer_MsgCustomerTypeError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullProductionTypeError_msg, SphereModules.CustomersMaster_AddCustomer_MsgProductionTypeError_xp);
					    fnVerifyLabelMsgTextByXpath(AppMessages.Customers_AddNationalAccount_NullAddressError_msg, SphereModules.CustomersMaster_AddCustomer_MsgAddressError_xp);
						fnVerifyLabelMsgTextByXpath(AppMessages.Common_AddModule_Error_msg, SphereModules.CustomersMaster_AddCustomer_MsgError_xp);
					
						 
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true);  //post-condition
						
						//Not required until user changes anything on the form
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC104 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC104 Completed");
					}
					return obj;
				} //End of Script TC104		
				
				
				//TC033_ORB-1273_Change_LegalEntityfieldtotextfield_NewCustomer
				public Reporter TC165(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC165 Started..");

					try {
								
						obj.repAddData( "Verify Legal Entity and Collector", "", "", "");
						
						String sExpCustomerTypeList = mTestPhaseData.get(iTC_ID).get("Customer_Type_List").trim();
						String sExpProductionTypeList = mTestPhaseData.get(iTC_ID).get("Production_Type_List").trim();
						String sExpCollectorList = mTestPhaseData.get(iTC_ID).get("Collector_List").trim();
						String sExpLegalEntityList = mTestPhaseData.get(iTC_ID).get("Legal_Entity_List").trim();
						
						String sQuery = objSQLConfig.sMasterCustomers_LookupCodeMapping_Query;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						System.out.println(mTableDataDB.size());
					/*	Boolean bResultFlag = true;
						
						//mTableDataDB.equals(mTableDataDB);
						//for(int i=1;i<=mTableDataUI.size(); i++)
						for(int i=1;i<=mTableDataDB.size(); i++)
						{
							String sAccountname = mTableDataDB.get(i).get(2).toString();
							System.out.println(mTableDataDB.get(i).equals(mTableDataDB.get(i)));
							if(!mTableDataDB.get(i).equals(mTableDataDB.get(i)))
							{
								bResultFlag = false;
								obj.repAddData( "Compare record for account name : "+ sAccountname, "Record on UI and DB should match for account name : "+ sAccountname, "Validation failed for account name : "+ sAccountname, "Fail");
							}
							//System.out.println(mTableDataUI.get(i).get(2));
							//System.out.println(mTableDataUI.get(i).get(3));
						}*/
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
						Thread.sleep(4000);
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
						fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
						
						String [] arrExpCustomerTypeList = sExpCustomerTypeList.split(";");
						for(int i=0;i<arrExpCustomerTypeList.length; i++)
						{
							String sCustomerType = arrExpCustomerTypeList[i].toString().trim();
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerType);
							Thread.sleep(500);
							String sExpLegalEntityDB = 	fnGetDestinationLookupCode(mTableDataDB, sCustomerType);
							sExpLegalEntityDB = "Legal Entity: "+ sExpLegalEntityDB;
							sExpLegalEntityDB = sExpLegalEntityDB.replace("- ","-");
							fnVerifyLabelMsgTextByXpath(sExpLegalEntityDB, SphereModules.CustomersMaster_AddCustomer_LabelLegalEntity_xp );
						//CustomersMaster_AddCustomer_LabelLegalEntity_xp
						
						}
						
						String [] arrExpProductionTypeList = sExpProductionTypeList.split(";");
						for(int i=0;i<arrExpProductionTypeList.length; i++)
						{
							String sProductionType = arrExpProductionTypeList[i].toString().trim();
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionType);
							
							String sExpCollectorDB = fnGetDestinationLookupCode(mTableDataDB, sProductionType);
							
							Select select = new Select(driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id)));
							String sActCollectorUI = select.getFirstSelectedOption().getText().trim();

							fnVerifyLabelMsgText(sExpCollectorDB, sActCollectorUI);
						//CustomersMaster_AddCustomer_LabelLegalEntity_xp
						
						}
						
						
						
						/*objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id,sCollectorUI);
						objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id,sLegalEntityUI);*/
					    
						/*objGenericFunctionLibrary.fnSelectFromJSComboBox(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id,sCollectorUI);
						objGenericFunctionLibrary.fnSelectFromJSComboBox(SphereModules.CustomersMaster_AddCustomer_ComboLegalEntity_id,sLegalEntityUI);*/
						
						
						 
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true);  //post-condition
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC165 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC165 Completed");
					}
					return obj;
				} //End of Script TC165		

				
				//TC034_ORB-1273_Change_LegalEntityfieldtotextfield_ExistingCustomer
				public Reporter TC167(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC167 Started..");

					try {
								
						obj.repAddData( "Verify Legal Entity and Collector", "", "", "");
						
						String sExpCustomerTypeList = mTestPhaseData.get(iTC_ID).get("Customer_Type_List").trim();
						String sExpProductionTypeList = mTestPhaseData.get(iTC_ID).get("Production_Type_List").trim();
						String sExpCollectorList = mTestPhaseData.get(iTC_ID).get("Collector_List").trim();
						String sExpLegalEntityList = mTestPhaseData.get(iTC_ID).get("Legal_Entity_List").trim();
						
						String sQuery = objSQLConfig.sMasterCustomers_LookupCodeMapping_Query;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						System.out.println(mTableDataDB.size());
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 15);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);

						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						
						String [] arrExpCustomerTypeList = sExpCustomerTypeList.split(";");
						for(int i=0;i<arrExpCustomerTypeList.length; i++)
						{
							String sCustomerType = arrExpCustomerTypeList[i].toString().trim();
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerType);
							Thread.sleep(500);
							String sExpLegalEntityDB = 	fnGetDestinationLookupCode(mTableDataDB, sCustomerType);
							sExpLegalEntityDB = "Legal Entity: "+ sExpLegalEntityDB;
							sExpLegalEntityDB = sExpLegalEntityDB.replace("- ","-");
							System.out.println("DB Value : "+sExpLegalEntityDB);
							fnVerifyLabelMsgTextByXpath(sExpLegalEntityDB, SphereModules.CustomersMaster_AddCustomer_LabelLegalEntity_xp );
						
							//CustomersMaster_AddCustomer_LabelLegalEntity_xp
						
						}
						
						String [] arrExpProductionTypeList = sExpProductionTypeList.split(";");
						for(int i=0;i<arrExpProductionTypeList.length; i++)
						{
							String sProductionType = arrExpProductionTypeList[i].toString().trim();
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionType);
							
							String sExpCollectorDB = fnGetDestinationLookupCode(mTableDataDB, sProductionType);
							
							Select select = new Select(driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id)));
							String sActCollectorUI = select.getFirstSelectedOption().getText().trim();

							fnVerifyLabelMsgText(sExpCollectorDB, sActCollectorUI);
						//CustomersMaster_AddCustomer_LabelLegalEntity_xp
						
						}			
						 
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnCancel_xp, "Cancel Button", true);  //post-condition
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC165 TC167!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC167 Completed");
					}
					return obj;
				} //End of Script TC167		
				
				
				//Integration Testing - Add Customer with International Address - India
				public Reporter TC1299(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1299 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with an international address - India", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1299 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1299 Completed");
					}
					return obj;
				} //End of Script TC1299
				
				//Multi Address Contact Scenario
				public Reporter TC1399(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1399 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with multi contacts and addresses", "", "", "");
						//sCustomer = objBusinessLib.fnAddCustomerMultiAddressesContacts(sCustomer, "Add",true, 2, true, 2);
						sCustomer = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomer, "Add",true, 2, true, 2);
						
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1399 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1399 Completed");
					}
					return obj;
				} //End of Script TC1399	
				
				//Multi Contact Scenario
				public Reporter TC1499(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1499 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with multi contacts", "", "", "");
						//sCustomer = objBusinessLib.fnAddCustomerMultiAddressesContacts(sCustomer, "Add",true, 2, false, 0);
						sCustomer = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomer, "Add",true, 2, false, 0);
						
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1499 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1499 Completed");
					}
					return obj;
				} //End of Script TC1499
				
				
				
				//Multi Address Scenario
				public Reporter TC1599(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1599 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with multi addresses", "", "", "");
						//sCustomer = objBusinessLib.fnAddCustomerMultiAddressesContacts(sCustomer, "Add",false, 0, true, 2);
						sCustomer = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomer, "Add",false, 0, true, 2);
						
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1599 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1599 Completed");
					}
					return obj;
				} //End of Script TC1599
				
				
				//USPS Validation with SAVE option
				public Reporter TC1699(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1699 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Verifying USPS address validation response with SAVE option", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomerAddressValidation(sCustomer, "Add","SAVE");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1699 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1699 Completed");
					}
					return obj;
				} //End of Script TC1699
				
				
				//USPS Validation with EDIT option
				public Reporter TC1799(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1799 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Verifying USPS address validation response with EDIT option", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomerAddressValidation(sCustomer, "Add","EDIT");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1799 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1799 Completed");
					}
					return obj;
				} //End of Script TC1799
				//Integration_Testing_Update Customer_ProductionType
				@SuppressWarnings("static-access")
				public Reporter TC1501(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1501 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//sCustomer = "AUTOTESTCUSTOMER_59982";  //Comment after testing
						String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedCustomerTypeUI = "Universal Film";
						String sUpdatedProductionTypeUI = "Feature";
						//String sCustomerTypeList = "";
						String sProductionTypeList = "";
						
						obj.repAddData( "Updating an existing customer with different Production Type", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						sProductionTypeList = fnComboBoxDataList(SphereModules.Customers_EditNationalAccount_ComboProductionType_id, "Production Type", true, true);					
						String [] arrProductionType = sProductionTypeList.split(";");
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", false); 
						
						//Not required
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/
						
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						    
						for(int i=0; i<arrProductionType.length;i++)
						{	
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							sUpdatedProductionTypeUI = arrProductionType[i].toString().trim();
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
							//Adding below line on temporary purpose
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
							fnLoadingPageWait();
							
							/*try {
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
								
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
								
								String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
								HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
								System.out.println(sSuccessMsg);
								fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
							} catch (Exception e) {
								obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/
						
							//DB Validation to follow
					    
					   
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
												
							
							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && sUpdatedProductionTypeUI.equalsIgnoreCase(sProductionTypeDB) && sCreditPermanentDB.equalsIgnoreCase("1"))
							{	
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sUpdatedCustomerTypeUI);
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
						}//End of Customer Type list For loop 	
							
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1501 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1501 Completed");
					}
					return obj;
				} //End of Script TC1501	
				
				
				//Integration_Testing_Update Customer_Collector
				@SuppressWarnings("static-access")
				public Reporter TC1502(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1502 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//sCustomer = "AutoTestCustomer_26599";  //Comment after testing
						System.out.println(sCustomer);
						String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedCustomerTypeUI = "Universal Film";
						String sUpdatedCollectorUI = "Portfolio 1";
						//String sCustomerTypeList = "";
						String sCollectorList = "";
						
						obj.repAddData( "Updating an existing customer with different Collector", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						sCollectorList = fnComboBoxDataList(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id, "Collector", true, true);					
						String [] arrCollector = sCollectorList.split(";");
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", false); 
						
						//Not required under user changes anything
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/

						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						    
						for(int i=0; i<arrCollector.length;i++)
						{	
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							sUpdatedCollectorUI = arrCollector[i].toString().trim();
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCollector_id,sUpdatedCollectorUI);
							//Adding below line on temporary purpose
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ResendBtn1, "Save", true);
							fnLoadingPageWait();
							
							/*try {
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
								
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
								
								String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
								HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
								System.out.println(sSuccessMsg);
								fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
							} catch (Exception e) {
								obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/
						
									   
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sCollectorDB = mTableDataDB.get(iRow).get(20).toString().trim();
												
							System.out.println("sUpdatedCollectorUI>>>"+sUpdatedCollectorUI);
							System.out.println("sCollectorDB>>>"+sCollectorDB);
							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && sUpdatedCollectorUI.equalsIgnoreCase(sUpdatedCollectorUI) && sCreditPermanentDB.equalsIgnoreCase("1"))
							{	
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sUpdatedCustomerTypeUI);
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
						}//End of Customer Type list For loop 	
							
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1502 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1502 Completed");
					}
					return obj;
				} //End of Script TC1502	
				
				
				//Integration_Testing_Update Customer_ParentCompany
				@SuppressWarnings("static-access")
				public Reporter TC1503(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1503 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//sCustomer = "AutoTestCustomer_26599";  //Comment after testing
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim(); //"UCS TV";
						String sUpdatedParentCompanyUI = "SA1";
						//String sCustomerTypeList = "";
						String sParentCompanyList = "";
						
						obj.repAddData( "Updating an existing customer with different Parent Comapny", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						sParentCompanyList = fnComboBoxDataList(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id, "Parent Company", true, true);					
						String [] arrParentCompany = sParentCompanyList.split(";");
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", false);
						
						//Not required until user changes anything
						/*waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp)));
						ClickByXpath(SphereModules.Common_AddEditModules_BtnFormExitConfirmation_xp, "Confirmation Button", false);*/

						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						    
						for(int i=0; i<5;i++)  //Only 5 parent companies tests required
						{	
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							sUpdatedParentCompanyUI = arrParentCompany[i].toString().trim();
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sUpdatedParentCompanyUI);
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
							fnLoadingPageWait();
							
							/*try {
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
								
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
								
								String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
								HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
								System.out.println(sSuccessMsg);
								fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
							} catch (Exception e) {
								obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/
						
									   
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sParentCompanyDB = mTableDataDB.get(iRow).get(8).toString().trim();
												
							System.out.println("sUpdatedParentCompanyUI>>>"+sUpdatedParentCompanyUI);
							System.out.println("sParentCompanyDB>>>"+sParentCompanyDB);
							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && sUpdatedParentCompanyUI.equalsIgnoreCase(sParentCompanyDB) && sCreditPermanentDB.equalsIgnoreCase("1"))
							{	
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sUpdatedCustomerTypeUI);
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
						}//End of Customer Type list For loop 	
							
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1503 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1503 Completed");
					}
					return obj;
				} //End of Script TC1503	
				
				
				//Integration_Testing - Add Customer with International Address -Canada
				public Reporter TC1504(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1504 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with an international address - Canada", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1504 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1504 Completed");
					}
					return obj;
				} //End of Script TC1504
				
				
				//Integration_Testing - Add Customer with International Address - Germany
				public Reporter TC1505(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1505 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with an international address - Germany", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1505 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1505 Completed");
					}
					return obj;
				} //End of Script TC1505
				
				
				//Integration_Testing - Add Customer with International Address - UK
				public Reporter TC1506(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1506 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with an international address - UK", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1506 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1506 Completed");
					}
					return obj;
				} //End of Script TC1506
				
				
				//Integration_Testing - Add Customer with International Address - Australia
				public Reporter TC1507(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1507 Started..");

					try {
						
						String sCustomer ="";
						obj.repAddData( "Adding a new customer with an international address - Australia", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1507 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1507 Completed");
					}
					return obj;
				} //End of Script TC1507

				//Integration_Testing - Add Customer - Multi Countries
				@SuppressWarnings("static-access")
				public Reporter TC1514(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1514 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//sCustomer = "AUTOTESTCUSTOMER_86038";  //Comment after testing
						
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						//String sUpdatedCustomerTypeUI = "";
						String sUpdatedCountryUI = "";
						//String sCustomerTypeList = "";
						String sCountryList = "";
						
						obj.repAddData( "Updating an existing customer with different countries", "", "", "");
						
						sCountryList = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country_List").trim();				
						String [] arrCountry = sCountryList.split(";");
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", false); 
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
					    
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						/*ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						*/
						
						    
						for(int i=1; i<arrCountry.length;i++)
						{	
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
							
							sUpdatedCountryUI = arrCountry[i].toString().trim();
							String sAddr1UI = "AUTOADDR1_"+sUpdatedCountryUI;
							String sAddr2UI = "AUTOADDR2_"+sUpdatedCountryUI;
							String sAddr3UI = "AUTOADDR3_"+sUpdatedCountryUI;
							
							String sStateUI = "";
							String sCityUI = "AUTOCITY_"+sUpdatedCountryUI;
							String sZipUI = String.valueOf(fnRandomNum(10000, 99999));
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditAddress_xp, "Edit Address button", true);
							//fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdatedCountryUI);
							
							/////////////////Adding Customer Address Start//////////////////
							//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, sEmailUI, "Email");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id, sAddr2UI, "Address Line 2");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
						    
							/*//Below line is temporary 
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"ARUBA");*/
							
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdatedCountryUI);
							//if(!sStateUI.equalsIgnoreCase(""))
							if(sUpdatedCountryUI.equalsIgnoreCase("UNITED STATES") || sUpdatedCountryUI.equalsIgnoreCase("CANADA"))
							{
								if(sUpdatedCountryUI.equalsIgnoreCase("CANADA"))
								{
									sStateUI = "ALBERTA";
								}
								else
								{
									sStateUI = "CALIFORNIA";
								}
									
								fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboState_id,sStateUI);
							}
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, sCityUI, "City");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, sZipUI, "Zip");
							
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
							fnLoadingPageWait();
							
							/*try {
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
								
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
								
								String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
								HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
								System.out.println(sSuccessMsg);
								fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
							} catch (Exception e) {
								obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/
						
							//DB Validation to follow
					    	/*				   
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();			
							
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							
							
							String sAddr1DB = mTableDataDB.get(iRow).get(9).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(15).toString().trim();
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
							String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
							
							String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
							
							String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
							String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
							
							String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
							String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
							
							

							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && sAddr1UI.contains(sAddr1DB) && sAddr2UI.contains(sAddr2DB) && sAddr3UI.contains(sAddr3DB) && sUpdatedCountryUI.equalsIgnoreCase(sCountryDB) && sStateUI.equalsIgnoreCase(sStateDB) && sCityUI.toUpperCase().contains(sCityDB) && sZipUI.equalsIgnoreCase(sZipDB)) // && sMultEmailDB.equalsIgnoreCase("1"))
							{	
								if(sCountryDB.contains(","))
								{
									sAddr1DB = "\""+sAddr1DB+"\"";
									sAddr2DB = "\""+sAddr2DB+"\"";
									sAddr3DB = "\""+sAddr3DB+"\"";
									sCityDB = "\""+sCityDB+"\"";
									sCountryDB = "\""+sCountryDB+"\"";
								}
							
								//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
								TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
								TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address Validation failed for customer name : "+ sCustomer, "Fail");
							}
							*/
						}//End of Customer Type list For loop 	
							
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
						}
					     catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1514 Failed!", e );
					}
					finally
					{
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1514 Completed");
					}
					return obj;
				} //End of Script TC1514	
				
				
				public Reporter TC1514_Backup(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC1514 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//sCustomer = "AUTOTESTCUSTOMER_86038";  //Comment after testing
						
						System.out.println(sCustomer);
						
						String [] arrCustomer = sCustomer.split("_");
						String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						//String sUpdatedCustomerTypeUI = "";
						String sUpdatedCountryUI = "";
						//String sCustomerTypeList = "";
						String sCountryList = "";
						
						obj.repAddData( "Updating an existing customer with different countries", "", "", "");
						
						sCountryList = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country_List").trim();				
						String [] arrCountry = sCountryList.split(";");
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", false); 
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
					    
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						fnLoadingPageWait();
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						/*ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						*/
						
						    
						for(int i=1; i<arrCountry.length;i++)
						{	
							//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
							
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
							
							sUpdatedCountryUI = arrCountry[i].toString().trim();
							String sAddr1UI = "AUTOADDR1_"+sUpdatedCountryUI;
							String sAddr2UI = "AUTOADDR2_"+sUpdatedCountryUI;
							String sAddr3UI = "AUTOADDR3_"+sUpdatedCountryUI;
							
							String sStateUI = "";
							String sCityUI = "AUTOCITY_"+sUpdatedCountryUI;
							String sZipUI = String.valueOf(fnRandomNum(10000, 99999));
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditAddress_xp, "Edit Address button", true);
							//fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdatedCountryUI);
							
							/////////////////Adding Customer Address Start//////////////////
							//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, sEmailUI, "Email");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id, sAddr2UI, "Address Line 2");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
						    
							/*//Below line is temporary 
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"ARUBA");*/
							
							fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdatedCountryUI);
							//if(!sStateUI.equalsIgnoreCase(""))
							if(sUpdatedCountryUI.equalsIgnoreCase("UNITED STATES") || sUpdatedCountryUI.equalsIgnoreCase("CANADA"))
							{
								if(sUpdatedCountryUI.equalsIgnoreCase("CANADA"))
								{
									sStateUI = "ALBERTA";
								}
								else
								{
									sStateUI = "CALIFORNIA";
								}
									
								fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboState_id,sStateUI);
							}
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, sCityUI, "City");
							SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, sZipUI, "Zip");
							
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
							fnLoadingPageWait();
							
							/*try {
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
								
								TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
								
								String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
								HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
								System.out.println(sSuccessMsg);
								fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
							} catch (Exception e) {
								obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/
						
							//DB Validation to follow
					    					   
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							/*String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();			
							
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							
							
							String sAddr1DB = mTableDataDB.get(iRow).get(9).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(15).toString().trim();*/
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
							String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
							String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
							String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
							String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
							String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
							String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
							
							String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
							
							String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
							String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
							
							String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
							String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
							
							

							if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && sAddr1UI.contains(sAddr1DB) && sAddr2UI.contains(sAddr2DB) && sAddr3UI.contains(sAddr3DB) && sUpdatedCountryUI.equalsIgnoreCase(sCountryDB) && sStateUI.equalsIgnoreCase(sStateDB) && sCityUI.toUpperCase().contains(sCityDB) && sZipUI.equalsIgnoreCase(sZipDB)) // && sMultEmailDB.equalsIgnoreCase("1"))
							{	
								if(sCountryDB.contains(","))
								{
									sAddr1DB = "\""+sAddr1DB+"\"";
									sAddr2DB = "\""+sAddr2DB+"\"";
									sAddr3DB = "\""+sAddr3DB+"\"";
									sCityDB = "\""+sCityDB+"\"";
									sCountryDB = "\""+sCountryDB+"\"";
								}
							
								//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB);
								TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
								TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address Validation failed for customer name : "+ sCustomer, "Fail");
							}
							
						}//End of Customer Type list For loop 	
							
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						//objBusinessLib.fnClickSubMenuElement("Dashboard","");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
						}
					     catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1514 Failed!", e );
					}
					finally
					{
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC1514 Completed");
					}
					return obj;
				} //End of Script TC1514	
				
				
				
				
				/*@SuppressWarnings("static-access")
				public Reporter TC182(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC182 Started..");

					try {
								
						obj.repAddData( " Verifying  Department Admin Cannot Update an existing national account", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp)));
						fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_InputEmail_id,"email");
						fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
						fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,"ProductionType");
						
						//fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, "Address Line 1");
						//fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id,"Address Line 2");
						//fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id,"Address Line 3");
					    
						//fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_ComboCountry_id,"Country");
						//fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_ComboState_id,"State");
						//fnCheckfieldDisbleById(SphereModules.Customers_AddNationalAccount_InputCity_id, "City");
						
						//ClickByXpath(SphereModules.Customers_NationalAccount_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
				       // Thread.sleep(2000);
						//fnCheckfieldDisbleById(SphereModules.Customers_NationalAccount_AddDesc_id,"Alternate Address Description");
						
				        //fnCheckfieldDisbleById(SphereModules.Customers_NationalAccount_InputAddnlInfo1_id, "Alternate Additional Info 1");
				        //fnCheckfieldDisbleById(SphereModules.Customers_NationalAccount_InputAddnlInfo2_id,"Alternate Additional Info 2");
						
						fnCheckFieldDisplayByXpath(SphereModules.Customers_EditNationalAccount_BtnSave_xp,"save",true,false);
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Customers_EditNationalAccount_DepartmentAdmin_BtnDeactivate_xp,"Deactivate",true,false);
						ClickByXpath(SphereModules.Customers_AddNationalAccount_BtnClose_xp,"Close Button",true);
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC182 Failed!", e );
					}
					finally {
						
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC182Completed");
					}
					return obj;
				} //End of Script TC1686*/
				
					
				@SuppressWarnings("static-access")
				public Reporter TC184(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC184 Started..");

					try {
								
						obj.repAddData( "View  Customer page As Department Admin", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Customer Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Parent Company");
						fnVerifyHeaders(arrHeaderColumns,6,"Location");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						System.out.println(mTableDataUI.size());
						int RecordsSize=20;
						if(mTableDataUI.size()==RecordsSize){
							obj.repAddData( "Verifying Records are displayed on the page",  RecordsSize+ " records should be displayed on the page ", RecordsSize+  " records displayed on the page", "Pass");	
						}else
						{
							obj.repAddData( "Verifying Records are displayed on the page", RecordsSize+  " records should be displayed on the page ", RecordsSize+   " records not displayed on the page", "Fail");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC184Failed!", e );
					}
					finally {
						fnCloseOpenedForm();

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC184 Completed");
					}
					return obj;
				} //End of Script TC184

				public Reporter TC185(Reporter obj) throws Exception
				{
				
					log.info("Execution of Script TC185 Started..");
						try {
							
							String sCustomer ="";
							obj.repAddData( "Adding a new customer As Department Admin", "", "", "");
							sCustomer = objBusinessLib.fnAddCustomerMultiAddressesContactsDeptAdminBiller(sCustomer, "Add",true,1,true,1);
							//sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
							System.out.println(sCustomer);
							
							}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC185 Failed!", e );
						}
					finally {
						
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC185 Completed");
					}
					return obj;
				} //End of Script TC185
				
				@SuppressWarnings("static-access")
				public Reporter TC186(Reporter obj) throws Exception
				{	
					log.info("Execution of Script TC186 Started..");
						try {
							obj.repAddData( " Verifying  Department Admin is not allowed to update an existing customer", "", "", "");
							//String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							String sCustomerUI="AUTOTESTCUSTOMER_72410";
							
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							fnLoadingPageWait();
							Thread.sleep(1000);
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,"ProductionType");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,"ParentCompany");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "Email");
							
							/*ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddPlusLink_xp,"Add Contact Link",true);
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputFirstName_xp, "First Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputLastName_xp, "Last Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputTitle_xp,"Title");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputPhone_xp,"Phone");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputEmail_xp,"Email");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxMainContact_xp,"Main Contact Checkbox");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxRecInvoice_xp,"Receive Invoice Checkbox");*/
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditAddress_xp,"Edit link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, "Address Line 1");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id,  "Address Line 2");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id,  "Address Line 3");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"Country");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboState_id,"state");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, "City");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, "Zip");
							
							ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddrDesc_id,"Address Description");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddnlInfo1_id, " Additional Info 1");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddnlInfo2_id,"Additional Info 2");
							
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							
							/*ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_BtnAddPlusLink_xp,"Add Link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id,"Alternate Address Line1 ");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, "Alternate Address Line2");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id,"Alternate Address Line3");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,"Country");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,"state");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id, "City");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, "Zip");
					        
					        ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
					        
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id,"Alternate Address Description");
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo1_id, "Alternate Additional Info 1");
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo2_id,"Alternate Additional Info 2");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp, "Group Name");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button", true);
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp,"Group Name");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupSave_xp,"Group Save");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel");*/
							//fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Yes radio button");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id,"No radio button");
							//ClickById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, "Credit Expiration", true);
							//fnCheckfieldDisbleById(SphereModules.CustomerMaster_Customer_CreditExpiration_id,"Credit Expiration");
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,"Credit Limit");
							
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,false);
							fnCheckFieldDisplayByXpath(objSphereModules. CustomerMaster_Customer_DepartmentAdmin_Deactivate_xp,"Deactivate",true,false);
							//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp,"Close Button",true);
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Deactivate",true,false);
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"save",true);
							fnCheckEnableByXPath(SphereModules.Customers_Edit_Copy_xp,"Copy");
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
							fnLoadingPageWait();
						}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC186 Failed!", e );
						}
					finally {
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC186 Completed");
					}
					return obj;
				} //End of Script TC186
				
				
				@SuppressWarnings("static-access")
				public Reporter TC187(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC187 Started..");

					try {
								
						String CustomerNumber1 = "";
						String CustomerNumber2 = "";
						String Text="Deactivate";
						List<String> lsCustomerNumber = new ArrayList<String>();
						obj.repAddData( "Verifying Department Admin Cannot Deactive Customer Records ", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						CustomerNumber1=driver.findElement(By.xpath(objSphereModules.CustomerMaster_firstRow)).getText();
						CustomerNumber2=driver.findElement(By.xpath(objSphereModules.CustomerMaster_secondRow)).getText();
						lsCustomerNumber.add(0,CustomerNumber1);
						lsCustomerNumber.add(1,CustomerNumber2);
						for(int i=0;i<lsCustomerNumber.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewCustomersModule_Table_xp, 1, lsCustomerNumber.get(i));
						}
						
						ClickById(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						String EleText=driver.findElement(By.xpath(SphereModules.Customers_ViewCustomer_ComboDeactivate_xp)).getText();
						if(EleText.equalsIgnoreCase(Text)){
							
							obj.repAddData("Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list", " Deactivate displayed in bulk actions list : ", "Fail");
						}else
						{
							obj.repAddData( "Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list" , "Deactivate not displayed in bulk options list : ", "Pass");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC187 Failed!", e );
					}
					finally {
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC187 Completed");
					}
					return obj;
				} //End of Script TC187
				
				@SuppressWarnings("static-access")
				public Reporter TC204(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC204 Started..");

					try {
								
						obj.repAddData( "View  Customer page As Department Biller", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Customer Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Parent Company");
						fnVerifyHeaders(arrHeaderColumns,6,"Location");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						System.out.println(mTableDataUI.size());
						int RecordsSize=20;
						if(mTableDataUI.size()==RecordsSize){
							obj.repAddData( "Verifying Records are displayed on the page",  RecordsSize+ " records should be displayed on the page ", RecordsSize+ "  records displayed on the page", "Pass");	
						}else
						{
							obj.repAddData( "Verifying Records are displayed on the page", RecordsSize+ " records should be displayed on the page ", RecordsSize+ "  records not displayed on the page", "Fail");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC204Failed!", e );
					}
					finally {
						fnCloseOpenedForm();

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC204 Completed");
					}
					return obj;
				} //End of Script TC204

				public Reporter TC205(Reporter obj) throws Exception
				{
				
					log.info("Execution of Script TC205 Started..");
						try {
							
							String sCustomer ="";
							obj.repAddData( "Adding a new customer As Department Biller", "", "", "");
							sCustomer = objBusinessLib.fnAddCustomerDepartmentBiller(sCustomer, "Add",true,1,true,1);
							System.out.println(sCustomer);
							
							}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC205 Failed!", e );
						}
					finally {
						
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC205 Completed");
					}
					return obj;
				} //End of Script TC205
				
				@SuppressWarnings("static-access")
				public Reporter TC206(Reporter obj) throws Exception
				{	
					log.info("Execution of Script TC206 Started..");
						try {
							obj.repAddData( " Verifying  Department Biller is not allowed to update an existing customer", "", "", "");
							//String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							//String sCustomerUI="AUTODEALSTESTCUSTOMER";
							
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							fnLoadingPageWait();
							//Thread.sleep(1000);
							//SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
							//fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,"ProductionType");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,"ParentCompany");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "Email");
							
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddPlusLink_xp,"Add Contact Link",true);
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputFirstName_xp, "First Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputLastName_xp, "Last Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputTitle_xp,"Title");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputPhone_xp,"Phone");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputEmail_xp,"Email");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxMainContact_xp,"Main Contact Checkbox");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxRecInvoice_xp,"Receive Invoice Checkbox");
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditAddress_xp,"Edit link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, "Address Line 1");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id,  "Address Line 2");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id,  "Address Line 3");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"Country");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboState_id,"state");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, "City");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, "Zip");
							
							ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddrDesc_id,"Address Description");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddnlInfo1_id, " Additional Info 1");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddnlInfo2_id,"Additional Info 2");
							
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							
							ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_BtnAddPlusLink_xp,"Add Link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id,"Alternate Address Line1 ");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, "Alternate Address Line2");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id,"Alternate Address Line3");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,"Country");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,"state");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id, "City");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, "Zip");
					        
					        ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
					        
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id,"Alternate Address Description");
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo1_id, "Alternate Additional Info 1");
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo2_id,"Alternate Additional Info 2");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp, "Group Name");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button", true);
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp,"Group Name");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupSave_xp,"Group Save");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel");
							//fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Yes radio button");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id,"No radio button");
							//ClickById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, "Credit Expiration", true);
							fnCheckfieldDisbleById(SphereModules.CustomerMaster_Customer_CreditExpiration_id,"Credit Expiration");
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,"Credit Limit");
							
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,false);
							fnCheckFieldDisplayByXpath(objSphereModules. CustomerMaster_Customer_DepartmentAdmin_Deactivate_xp,"Deactivate",true,false);
							//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp,"Close Button",true);
							fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Deactivate",true,false);
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"save",true);
						}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC206 Failed!", e );
						}
					finally {
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC206 Completed");
					}
					return obj;
				} //End of Script TC206
				@SuppressWarnings("static-access")
				public Reporter TC730(Reporter obj) throws Exception
				{	
					log.info("Execution of Script TC730 Started..");
						try {
							obj.repAddData( " Verifying  Department Biller is not allowed to update an existing customer", "", "", "");
							//String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							//String sCustomerUI="AUTOTESTCUSTOMER_99191";
							
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							fnLoadingPageWait();
							//Thread.sleep(1000);
							//SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
							//fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,"ProductionType");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,"ParentCompany");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "Email");
							
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddPlusLink_xp,"Add Contact Link",true);
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputFirstName_xp, "First Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputLastName_xp, "Last Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputTitle_xp,"Title");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputPhone_xp,"Phone");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputEmail_xp,"Email");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxMainContact_xp,"Main Contact Checkbox");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxRecInvoice_xp,"Receive Invoice Checkbox");
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditAddress_xp,"Edit link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, "Address Line 1");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id,  "Address Line 2");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id,  "Address Line 3");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"Country");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_ComboState_id,"state");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, "City");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, "Zip");
							
							ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddrDesc_id,"Address Description");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddnlInfo1_id, " Additional Info 1");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_Address_InputAddnlInfo2_id,"Additional Info 2");
							
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							
							ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_BtnAddPlusLink_xp,"Add Link",true);
							
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id,"Alternate Address Line1 ");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, "Alternate Address Line2");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id,"Alternate Address Line3");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,"Country");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,"state");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id, "City");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, "Zip");
					        
					        ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
					        
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id,"Alternate Address Description");
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo1_id, "Alternate Additional Info 1");
					        fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo2_id,"Alternate Additional Info 2");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp, "Group Name");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button", true);
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp,"Group Name");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupSave_xp,"Group Save");
							fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel");
							//fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Yes radio button");
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id,"No radio button");
							//ClickById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, "Credit Expiration", true);
							fnCheckfieldDisbleById(SphereModules.CustomerMaster_Customer_CreditExpiration_id,"Credit Expiration");
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
							fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,"Credit Limit");
							
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,false);
							fnCheckFieldDisplayByXpath(objSphereModules. CustomerMaster_Customer_DepartmentAdmin_Deactivate_xp,"Deactivate",true,false);
							//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp,"Close Button",true);
							fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Deactivate",true,false);
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"save",true);
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
							fnLoadingPageWait();
						
						}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC730 Failed!", e );
						}
					finally {
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC730 Completed");
					}
					return obj;
				} //End of Script TC730
				@SuppressWarnings("static-access")
				public Reporter TC731(Reporter obj) throws Exception
				{
					log.info("Execution of Script TC731 Started..");


						try {
									
							obj.repAddData( "Verifying User has no access to add Customer As Finance User", "", "", "");
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						
							obj.repAddData( "Verifying Add Link is displayed to add Customer As Finance User", "", "", "");
							fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp,"Add Customer Link",true,false);
							
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC731 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC731 Completed");
					}
					return obj;
				} //End of Script TC731	
				
				@SuppressWarnings("static-access")
				public Reporter TC732(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC732 Started..");

					try {
								
						String CustomerNumber1 = "";
						String CustomerNumber2 = "";
						String Text="Deactivate";
						List<String> lsCustomerNumber = new ArrayList<String>();
						obj.repAddData( "Verifying Finance User has no access to Deactive Customer Records ", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						CustomerNumber1=driver.findElement(By.xpath(objSphereModules.CustomerMaster_firstRow)).getText();
						CustomerNumber2=driver.findElement(By.xpath(objSphereModules.CustomerMaster_secondRow)).getText();
						lsCustomerNumber.add(0,CustomerNumber1);
						lsCustomerNumber.add(1,CustomerNumber2);
						for(int i=0;i<lsCustomerNumber.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewCustomersModule_Table_xp, 1, lsCustomerNumber.get(i));
						}
						
						ClickById(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						String EleText=driver.findElement(By.xpath(SphereModules.Customers_ViewCustomer_ComboDeactivate_xp)).getText();
						if(EleText.equalsIgnoreCase(Text)){
							
							obj.repAddData("Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list", " Deactivate displayed in bulk actions list : ", "Fail");
						}else
						{
							obj.repAddData( "Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list" , "Deactivate not displayed in bulk options list : ", "Pass");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC732 Failed!", e );
					}
					finally {
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC732 Completed");
					}
					return obj;
				} //End of Script TC732
				
				@SuppressWarnings("static-access")
				public Reporter TC733(Reporter obj) throws Exception
				{
					log.info("Execution of Script TC733 Started..");


						try {
									
							obj.repAddData( "Verifying User has no access to add parent company As Finance User", "", "", "");
							objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
							Thread.sleep(4000);
						
							obj.repAddData( "Verifying Add Link is displayed to add Parent company As Finance User", "", "", "");
							fnCheckFieldDisplayByXpath(objSphereModules.Customers_AddNationalAccount_LinkAddPlusSign_xp,"Add Parent Company Link",true,false);
							
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC733 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC733 Completed");
					}
					return obj;
				} //End of Script TC733	
				
				
				
				@SuppressWarnings("static-access")
				public Reporter TC207(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC207 Started..");

					try {
								
						String CustomerNumber1 = "";
						String CustomerNumber2 = "";
						String Text="Deactivate";
						List<String> lsCustomerNumber = new ArrayList<String>();
						obj.repAddData( "Verifying Department Biller Cannot Deactive Customer Records ", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						CustomerNumber1=driver.findElement(By.xpath(objSphereModules.CustomerMaster_firstRow)).getText();
						CustomerNumber2=driver.findElement(By.xpath(objSphereModules.CustomerMaster_secondRow)).getText();
						lsCustomerNumber.add(0,CustomerNumber1);
						lsCustomerNumber.add(1,CustomerNumber2);
						for(int i=0;i<lsCustomerNumber.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewCustomersModule_Table_xp, 1, lsCustomerNumber.get(i));
						}
						
						ClickById(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						String EleText=driver.findElement(By.xpath(SphereModules.Users_ViewUser_ComboDeactivateChangeRole_xp)).getText();
						if(EleText.equalsIgnoreCase(Text)){
							
							obj.repAddData("Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list", " Deactivate displayed in bulk actions list : ", "Fail");
						}else
						{
							obj.repAddData( "Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list" , "Deactivate not displayed in bulk options list : ", "Pass");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC207 Failed!", e );
					}
					finally {
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC207 Completed");
					}
					return obj;
				} //End of Script TC207	
				@SuppressWarnings("static-access")
				public Reporter TC304(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC304 Started..");

					try {
								
						obj.repAddData( "View  Customer page As Finance Admin", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Customer Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Parent Company");
						fnVerifyHeaders(arrHeaderColumns,6,"Location");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						System.out.println(mTableDataUI.size());
						int RecordsSize=20;
						if(mTableDataUI.size()==RecordsSize){
							obj.repAddData( "Verifying Records are displayed on the page",  RecordsSize+ " records should be displayed on the page ", RecordsSize+ "  records displayed on the page", "Pass");	
						}else
						{
							obj.repAddData( "Verifying Records are displayed on the page", RecordsSize+ " records should be displayed on the page ", RecordsSize+ "  records not displayed on the page", "Fail");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC304Failed!", e );
					}
					finally {
						fnCloseOpenedForm();

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC304 Completed");
					}
					return obj;
				} //End of Script TC304
				public Reporter TC305(Reporter obj) throws Exception
				{
				
					log.info("Execution of Script TC305 Started..");
						try {
							
							String sCustomer ="";
							obj.repAddData( "Adding a new customer As Finance Admin", "", "", "");
							//sCustomer = objBusinessLib.fnAddCustomerMultiAddressesContacts(sCustomer, "Add",true,1,true,1);
							sCustomer = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomer, "Add",true,1,true,1);
							System.out.println(sCustomer);
							
							}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC305 Failed!", e );
						}
					finally {
						
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC305 Completed");
					}
					return obj;
				} //End of Script TC305
				
				@SuppressWarnings("static-access")
				public Reporter TC306(Reporter obj) throws Exception
				{	
					log.info("Execution of Script TC306 Started..");
						try {
							obj.repAddData( " Verifying Customer fields to update an  existing customer", "", "", "");
							//String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							String sCustomerUI="AUTOTESTFINANCEUSER";
							
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							fnLoadingPageWait();
							Thread.sleep(1000);
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id");
							fnCheckfieldEnableById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,"ProductionType");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,"ParentCompany");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "Email");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_BtnAddPlusLink_xp,"Add Contact Link");
							ClickByXpath(SphereModules.CustomerMaster_EditContact_Pencil,"Edit Contact Link",true);
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputFirstName_xp, "First Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputLastName_xp, "Last Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputTitle_xp,"Title");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputPhone_xp,"Phone");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputEmail_xp,"Email");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxMainContact_xp,"Main Contact Checkbox");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxRecInvoice_xp,"Receive Invoice Checkbox");
							ClickByXpath(SphereModules.	Deals_Edit_Customer_Contact_BtnCancel_xp,"cancel",true);
							Thread.sleep(2000);
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditMainAddress_xp,"Edit Address",true);
							
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, "Address Line 1");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id,  "Address Line 2");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id,  "Address Line 3");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"Country");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_ComboState_id,"state");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, "City");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, "Zip");
							
							ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Link",true);
							
							fnCheckfieldEnableById(SphereModules.CustomersMaster_Address_InputAddrDesc_id,"Address Description");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_Address_InputAddnlInfo1_id, " Additional Info 1");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_Address_InputAddnlInfo2_id,"Additional Info 2");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddAltAddress_BtnAddPlusLink_xp,"Add Link");
							ClickByXpath(SphereModules.CustomerMaster_EditAltAddress_Pencil,"Edit Address",true);
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id,"Alternate Address Line1 ");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, "Alternate Address Line2");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id,"Alternate Address Line3");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,"Country");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,"state");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id, "City");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, "Zip");
					        
					        ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
					        
					        fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id,"Alternate Address Description");
					        fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo1_id, "Alternate Additional Info 1");
					        fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo2_id,"Alternate Additional Info 2");
					        fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp, "Group Name");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button", true);
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp,"Group Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupSave_xp,"Group Save");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel",true);
							//fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Yes radio button");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id,"No radio button");
							//ClickById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, "Credit Expiration", true);
							fnCheckfieldEnableById(SphereModules.CustomerMaster_Customer_CreditExpiration_id,"Credit Expiration");
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
							//fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,"Credit Limit");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp,"Credit Limit Button");
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,false);
							fnCheckEnableByXPath(SphereModules. CustomerMaster_Customer_FinanceAdmin_Deactivate_xp,"Deactivate");
							//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp,"Close Button",true);
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,true);
							fnCheckEnableByXPath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save");
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"save",true);
							//fnCheckFieldDisplayByXpath(SphereModules.Customers_Edit_Copy_xp,"Copy",true,true);
							fnCheckEnableByXPath(objSphereModules.Customers_Edit_Copy_xp,"Copy");
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, " " , "Search Box");
						
						}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC306 Failed!", e );
						}
					finally {
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC306 Completed");
					}
					return obj;
				} //End of Script TC306
				//TC013_ORB-279_Update Customer_ProductionType_ParentCompany_Collector
				@SuppressWarnings("static-access")
				public Reporter TC313(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC313 Started..");
				
					try {
						
						String sCustomer ="";
						//obj.repAddData( "Pre-Condition : Adding a new customer as Finance Admin", "", "", "");
						//sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//System.out.println(sCustomer);
						sCustomer = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomer, "Add",true,1,true,1);
						System.out.println(sCustomer);
						
						//String sCustomer="AUTOTESTCUSTOMER_25284";
						obj.repAddData( "Updating an existing customer contact address and group", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						String sAltContact = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedContact").trim();
						String [] arrContact = sAltContact.split(";");
						String sUpdAltFirstNameUI= arrContact[0].toString();
						String sUpdAltLastNameUI= arrContact[1].toString();
						String sUpdAltContactTypeUI= arrContact[2].toString();
						String sUpdAltContactPhoneUI = arrContact[3].toString();
						String sUpdAltContactEmailUI= arrContact[4].toString();
						
						ClickByXpath(SphereModules.CustomerMaster_EditContact_Pencil, "Edit link", true);
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_FirstName_xp, sUpdAltFirstNameUI, "First Name ");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_LastName_xp,sUpdAltLastNameUI, "Last Name");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_Title_xp, sUpdAltContactTypeUI, "Title");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_Phone_xp, sUpdAltContactPhoneUI, "Phone Number");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_email_xp, sUpdAltContactEmailUI, "Email Address");
						///objGenericFunctionLibrary.ClickById(SphereModules. Deals_AddDeal_MainContact_id, "Main Contact", true);
						//ClickById(SphereModules.Deals_AddDeal_ReceivesInvoice_id, "Receives Invoice", true);
						ClickByXpath(SphereModules.Deals_AddDeal_AddNewContact_save_xp,"Check", true);
						Thread.sleep(4000);
						fnLoadingPageWait();
						String sUpdMainAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedMainAddr").trim();
						String [] arrMainAddress = sUpdMainAddress.split(";");
						
						String sMainUpdDescription="MainUpdtDescription";
						String sUpdAddr1UI= arrMainAddress[0].toString();
						String sUpdAddr2UI= arrMainAddress[1].toString();
						String sUpdAddr3UI= arrMainAddress[2].toString();
						String sUpdCountryUI = arrMainAddress[3].toString();
						String sUpdStateUI= arrMainAddress[4].toString();
						String sUpdCityUI= arrMainAddress[5].toString();
						String sUpdZipUI= arrMainAddress[6].toString();
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditMainAddress_xp, "Edit link", true);
						ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Button",true);
						SendKeyById(SphereModules.CustomersMaster_Address_InputAddrDesc_id, sMainUpdDescription, "Alternate Address Description");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sUpdAddr1UI, "Alternate Address Line 1");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id, sUpdAddr2UI, "Alternate Address Line 2");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sUpdAddr3UI, "Alternate Address Line 3");
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdCountryUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboState_id,sUpdStateUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, sUpdCityUI, "Alt City");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputZip_id,sUpdZipUI, "Alt Zip");
						
						String sAltAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedAltAddr").trim();
						String [] arrAddress = sAltAddress.split(";");
						String sUpdAltDescription="UpdtAltDescription";
						String sUpdAltAddr1UI= arrAddress[0].toString();
						String sUpdAltAddr2UI= arrAddress[1].toString();
						String sUpdAltAddr3UI= arrAddress[2].toString();
						String sUpdAltCountryUI= arrAddress[3].toString();
						String sUpdAltStateUI= arrAddress[4].toString();
						String sUpdAltCityUI= arrAddress[5].toString();
						String sUpdAltZipUI= arrAddress[6].toString();
						ClickByXpath(SphereModules. CustomerMaster_EditAltAddress_Pencil," Altenate Address Edit Link",true);
						ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id, sUpdAltDescription, "Alternate Address Description");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id, sUpdAltAddr1UI, "Alternate Address Line 1");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, sUpdAltAddr2UI, "Alternate Address Line 2");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id, sUpdAltAddr3UI, "Alternate Address Line 3");
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,sUpdAltCountryUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,sUpdAltStateUI);
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id,sUpdAltCityUI, "Alt City");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, sUpdAltZipUI, "Alt Zip");
						ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_BtnAdd_xp,"Add Alternate Address Button",true);
						fnLoadingPageWait();
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
				    	 int iRow = 1; //for add 
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							//String sAddr1DB = mTableDataDB.get(iRow).get(9).toString().trim();
							String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
							//String sMultEmailDB = mTableDataDB.get(iRow).get(16).toString().trim();
							//String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							
							//Verify Address  //Include  sMultEmailDB.equalsIgnoreCase("1")) in If condition once it's implemented
							if(sUpdAddr1UI.equalsIgnoreCase(sAddr1DB) && 
									sUpdAddr2UI.equalsIgnoreCase(sAddr2DB) && 
									sUpdAddr3UI.equalsIgnoreCase(sAddr3DB) && 
									sUpdCountryUI.equalsIgnoreCase(sCountryDB) && 
									sUpdStateUI.equalsIgnoreCase(sStateDB) && 
									sUpdCityUI.equalsIgnoreCase(sCityDB) && 
									sUpdZipUI.equalsIgnoreCase(sZipDB)) // && sMultEmailDB.equalsIgnoreCase("1"))
							{	
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address Validation failed for customer name : "+ sCustomer, "Fail");
							}

					    ///////////////////////////////////////Verifying Contacts Start//////////////////////////////////////////////////////
					  					    
					    String sQuery1 = objSQLConfig.sMasterCustomers_MultiContacts_Query;
					    sQuery1 = sQuery1.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
						HashMap<Integer, HashMap<Integer, String>> mContactTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						String sContactFirstNameDB = mContactTableDataDB.get(1).get(1).toString().trim();
						String sContactLastNameDB =mContactTableDataDB.get(1).get(2).toString().trim();
						String sContactTypeDB =mContactTableDataDB.get(1).get(3).toString().trim();
						String sContactPhoneDB = mContactTableDataDB.get(1).get(4).toString().trim();
						String sContactEmailDB = mContactTableDataDB.get(1).get(5).toString().trim();
						
						if(	sUpdAltFirstNameUI.equalsIgnoreCase(sContactFirstNameDB) && 
								sUpdAltLastNameUI.equalsIgnoreCase(sContactLastNameDB) &&
								sUpdAltContactTypeUI.equalsIgnoreCase(sContactTypeDB ) &&
								sUpdAltContactPhoneUI.equalsIgnoreCase  (sContactPhoneDB) &&
								sUpdAltContactEmailUI.equalsIgnoreCase (sContactEmailDB))
								//&&sInvoiceRecipient.equalsIgnoreCase("1"))
						{	
							//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sDealTitleDB+",\'"+sDealNumberDB+",Update,Deal");
							obj.repAddData( "Compare customer contact record for : "+ sCustomer, "Customer contact record on UI and DB should match for : "+ sCustomer, "Contact Validation successful for : "+ sCustomer, "Pass");
						}
						else
						{
							obj.repAddData( "Compare customer account contact record for : "+ sCustomer, "Customer contact record on UI and DB should match for : "+ sCustomer, "Contact Validation failed for : "+ sCustomer, "Fail");
						}
						
						/////////////////////////////////////Verifying Contacts End//////////////////////////////////////////////////////
						
						///////////////////////////////////////Verifying Alternate Addresses Start//////////////////////////////////////////////////////
						String sQuery2 = objSQLConfig.sMasterCustomers_MultiAddresses_Query;
						sQuery2 = sQuery2.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery2);
						HashMap<Integer, HashMap<Integer, String>> mAltAddressTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sAltDescDB=mAltAddressTableDataDB.get(1).get(1).toString().trim();
						String sAltAddr1DB=mAltAddressTableDataDB.get(1).get(2).toString().trim();
						String sAltAddr2DB=mAltAddressTableDataDB.get(1).get(3).toString().trim();
						String sAltAddr3DB=mAltAddressTableDataDB.get(1).get(4).toString().trim();
						String sAltCountryDB=mAltAddressTableDataDB.get(1).get(5).toString().trim();
						String sAltStateDB=mAltAddressTableDataDB.get(1).get(6).toString().trim();
						String sAltCityDB=mAltAddressTableDataDB.get(1).get(7).toString().trim();
						String sAltZipDB=mAltAddressTableDataDB.get(1).get(8).toString().trim();
						
						if(sUpdAltDescription.equalsIgnoreCase(sAltDescDB)&&sUpdAltAddr1UI.equalsIgnoreCase(sAltAddr1DB)&&
							sUpdAltAddr2UI.equalsIgnoreCase(sAltAddr2DB)&&sUpdAltAddr3UI.equalsIgnoreCase(sAltAddr3DB)&&
							sUpdAltCountryUI.equalsIgnoreCase(sAltCountryDB)&&sUpdAltStateUI.equalsIgnoreCase(sAltStateDB)&&
							sUpdAltCityUI.equalsIgnoreCase(sAltCityDB)&&sUpdAltZipUI.equalsIgnoreCase(sAltZipDB))
						{
							obj.repAddData( "Compare customer Alternate Address record for  : "+ sCustomer, "Customer Alternate Address record on UI and DB should match for : "+ sCustomer, "Address Validation successful for : "+ sCustomer, "Pass");	
						}
						else
						{
							obj.repAddData( "Compare customer Alternate Address record for : "+ sCustomer, "Customer Alternate Address record on UI and DB should match for : "+ sCustomer, "Address Validation failed for : "+ sCustomer, "Fail");
						}
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						fnLoadingPageWait();
						Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC313 Failed!", e );
					}
					finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC313 Completed");
					}
					return obj;
				} //End of Script TC313	
		
				//TC013_ORB-279_Update Customer_ProductionType_ParentCompany_Collector
				@SuppressWarnings("static-access")
				public Reporter TC314(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC314 Started..");
				
					try {
						
						String sCustomer ="";
						obj.repAddData( "Pre-Condition : Adding a new customer as Finance User", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						String sTaxIdUI = String.valueOf(fnRandomNum(100000001, 999999999));
						//String [] arrCustomer = sCustomer.split("_");
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						//String sRandom = arrCustomer[1].toString(); 
						//String sUpdatedCreditLimitUI = sRandom+"1"+".00";
						String sUpdatedCreditLimitUI = sRandom+".00";
						//String sUpdatedCustomerTypeUI = "UCS Film";
						String sUpdatedProductionTypeUI = "Feature";
						//String sCreditExpirationDate="11/11/2016";
						String sUpdatedParentCompanyUI ="NBC";
						//String sCustomer ="AUTOTESTCUSTOMER_99473";
						obj.repAddData( "Updating an existing customer main info", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						//fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sUpdatedParentCompanyUI);

						//ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "11/28/2016", "Production Start Date");
						
						//production start date
						SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2486758787", "Phone Number");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,  sRandom, "Credit Limit Box");
						
						//ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						//SendKeyById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, sCreditExpirationDate, "Credit Limit");
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						//DB Validation to follow
					    
					    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	 int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
						String sParentCompanyDB= mTableDataDB.get(iRow).get(9).toString();
						String sCreditExpirationDB=mTableDataDB.get(iRow).get(18).toString();						
							
						if(sCustomer.equalsIgnoreCase(sCustomerNameDB) &&// sUpdatedCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB)&&
						sTaxIdUI.equalsIgnoreCase(sTaxIDDB)&&
						sUpdatedProductionTypeUI.equalsIgnoreCase(sProductionTypeDB) && 
						sCreditPermanentDB.equalsIgnoreCase("1")&&
						sUpdatedCreditLimitUI.equalsIgnoreCase(sCreditLimitDB)&&
						sUpdatedParentCompanyUI.equalsIgnoreCase(sParentCompanyDB)) //&&sCreditExpirationDate.equalsIgnoreCase(sCreditExpirationDB))// include once the date issue is resolved
						{	
						obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
						}
						else
						{
						obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
						}
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							fnLoadingPageWait();
							Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC314 Failed!", e );
					}
					finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC314 Completed");
					}
					return obj;
				} //End of Script TC314	
				@SuppressWarnings("static-access")
				public Reporter TC307(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC307 Started..");

					try {
								
						String sCustomer= " ";
						List<String> lsCustomer = new ArrayList<String>();
						//int iBulkDeactivationCount = Integer.valueOf(TestDriver.prop.getProperty("BulkDeactivationCount").toString().trim());
						int iBulkDeactivationCount=1;
						//lsSSOIds.add("307087130");   //delete after testing
						for(int iCount=0;iCount<iBulkDeactivationCount;iCount++)
						{
							obj.repAddData( "Adding user "+String.valueOf(iCount+1) +" (Pre-Condition)", "", "", "");
							sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
							System.out.println(sCustomer);
							lsCustomer.add(sCustomer);
							Thread.sleep(2000);
						}
						obj.repAddData( "Verifying Finance Admin Can Deactive Customer Records ", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						//sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//System.out.println(sCustomer);
						Thread.sleep(2000);
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						//String bulkAccount_Title=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Bulk_Title").trim();
						
						for(int i=0;i<lsCustomer.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewCustomersModule_Table_xp, 2, lsCustomer.get(i));
						}
						
						ClickById(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						objBusinessLib.fnSelectDeactivateChangeRoleOption(0, "Deactivate");
						ClickByXpath(SphereModules.Users_ViewUser_ConfirmDeactivateYesBtn_xp, "Yes button", true);
						Thread.sleep(3000);
						for(int j=0;j<lsCustomer.size();j++)
						{
							objBusinessLib.fnVerifyCustomerDeactivatedRecord(lsCustomer.get(j).toString());
						}
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC307 Failed!", e );
					}
					finally {
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC307 Completed");
					}
					return obj;
				} //End of Script TC307
				@SuppressWarnings("static-access")
				public Reporter TC320(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC320 Started..");

					try {
							
						obj.repAddData( "Verifying headers list and records on National Accounts page as Finance Admin", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
						Thread.sleep(4000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Location");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
						System.out.println("Hello");
						System.out.println(mTableDataUI.size());
						int RecordsSize=20;
						if(mTableDataUI.size()==RecordsSize){
							obj.repAddData( "Verifying Records are displayed on the page",  RecordsSize+ " records should be displayed on the page ", RecordsSize+  " records displayed on the page", "Pass");	
						}else
						{
							obj.repAddData( "Verifying Records are displayed on the page", RecordsSize+  " records should be displayed on the page ", RecordsSize+   " records not displayed on the page", "Fail");	
						}
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC320 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
						
						fnCloseOpenedForm();

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC320 Completed");
					}
					return obj;
				} //End of Script TC320			
				//Sprint 2_TC026_ORB-280_Customer_NationalAccount_Add new
				public Reporter TC300(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC300 Started..");

					try {
								
						obj.repAddData( "Adding a new national account as Finance Admin", "", "", "");
						String sNationalAccount = objBusinessLib.fnAddNationalAccount();
						System.out.println(sNationalAccount);
						fnCloseOpenedForm();
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC300 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC300 Completed");
					}
					return obj;
				} //End of Script TC321		
				//Sprint 2_TC030_ORB-280_Customer_NationalAccount_Edit_Update
				
				
				//public Reporter TC322(Reporter obj) throws Exception
				public Reporter TC600(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC600 Started..");

					try {
					
						String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;

						obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
						String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
						System.out.println(sAccountNameUI);
						
						
						obj.repAddData( "Updating an existing national account as Finance Admin", "", "", "");
									
						String [] arrNationalAccount = sAccountNameUI.split("_");
						String sRandom = arrNationalAccount[1].toString()+"_Updated"; 
						String sCustomerTypeUI="UCS Cable TV";
						String sProductionTypeUI="Commercial";
						String sQuery = objSQLConfig.sCustomers_EditNationalAccount_Query;
						sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);
						
						String sEmailUI = "AutoEmail_12"+"@nbcuni.com";
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sAccountNameUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						//String sEditTitleXPath = SphereModules.Deals_EditDeal_LabelEditDealTitle_xp.toString().replace("deal_number", sAccountNameUI);
						//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sEditTitleXPath)));
						
						//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp)));
						//fnVerifyLabelMsgTextByXpath(sAccountNameUI, SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp);	
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
						
						String sUpdAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedMainAddr").trim();
						String [] arrAddress = sUpdAddress.split(";");
						System.out.println(arrAddress[0].toString());
						System.out.println(arrAddress[1].toString());
						System.out.println(arrAddress[2].toString());
						System.out.println(arrAddress[3].toString());
						System.out.println(arrAddress[4].toString());
						System.out.println(arrAddress[5].toString());
						System.out.println(arrAddress[6].toString());
						
						String sUpdAddr1UI= arrAddress[0].toString();
						String sUpdAddr2UI= arrAddress[1].toString();
						String sUpdAddr3UI= arrAddress[2].toString();
						String sUpdCountryUI = arrAddress[3].toString();
						String sUpdStateUI= arrAddress[4].toString();
						String sUpdCityUI= arrAddress[5].toString();
						String sUpdZipUI= arrAddress[6].toString();
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sUpdAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sUpdAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id,sUpdAddr3UI , "Address Line 3");
					    
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sUpdCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sUpdStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sUpdCityUI, "City");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sUpdZipUI, "Zip");  //Not changing Zip
										    
					    ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnSave_xp, "Save Button", true);

					   /* try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp)));
							String sSuccessMsg = driver.findElement(By.xpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.Customers_EditNationalAccount_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						 		
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						
						String sAccountNameDB = mTableDataDB.get(1).get(1).toString().trim();
						String sEmailDB = mTableDataDB.get(1).get(2).toString().trim();
						String sAddr1DB = mTableDataDB.get(1).get(3).toString().trim();
						String sAddr2DB = mTableDataDB.get(1).get(4).toString().trim();
						String sAddr3DB = mTableDataDB.get(1).get(5).toString().trim();
						
						String sCityDB = mTableDataDB.get(1).get(6).toString().trim();
						String sStateDB = mTableDataDB.get(1).get(7).toString().trim();
						String sZipDB = mTableDataDB.get(1).get(8).toString().trim();
						String sCountryDB = mTableDataDB.get(1).get(9).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(1).get(10).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(1).get(11).toString().trim();
						/*
						sLookupQuery = sLookupQuery.replaceAll("lookup_code_param",sCustomerTypeIdDB); 
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sLookupQuery);
						mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						String sCustomerTypeDB = mTableDataDB.get(1).get(1).toString();
						
						sLookupQuery = sLookupQuery.replaceAll(sCustomerTypeIdDB,sProductionTypeIdDB); 
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sLookupQuery);
						mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						String sProductionTypeDB = mTableDataDB.get(1).get(1).toString();
						*/
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						if(sAccountNameUI.equalsIgnoreCase(sAccountNameDB) && sEmailUI.equalsIgnoreCase(sEmailDB) &&
								sUpdAddr1UI.equalsIgnoreCase(sAddr1DB) && sUpdAddr2UI.equalsIgnoreCase(sAddr2DB) &&
								sUpdAddr3UI.equalsIgnoreCase(sAddr3DB) && sUpdCityUI.equalsIgnoreCase(sCityDB) &&
								sUpdStateUI.equalsIgnoreCase(sStateDB) && sUpdZipUI.equalsIgnoreCase(sZipDB) &&
								sUpdCountryUI.equalsIgnoreCase(sCountryDB) && sCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB) &&
								sProductionTypeUI.equalsIgnoreCase(sProductionTypeDB))
						{	
							obj.repAddData( "Compare national account record for account name : "+ sAccountNameUI, "National account record on UI and DB should match for account name : "+ sAccountNameUI, "Validation successful for account name : "+ sAccountNameUI, "Pass");
						}
						else
						{
							obj.repAddData( "Compare national account record for account name : "+ sAccountNameUI, "National account record on UI and DB should match for account name : "+ sAccountNameUI, "Validation failed for account name : "+ sAccountNameUI, "Fail");
						}
						 
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC600 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC600 Completed");
					}
					return obj;
				} //End of Script TC600
				
					
				@SuppressWarnings("static-access")
				public Reporter TC323(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC323 Started..");

					try {
								
						String ParentCompanyAccount1 = "";
						String ParentCompanyAccount2 = "";
						String Text="Deactivate";
						List<String> lsParentCompanyAccount = new ArrayList<String>();
						obj.repAddData( "Verifying Finance Admin Cannot Deactive Parent Accounts  ", "", "", "");
					
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						Thread.sleep(3000);
						ParentCompanyAccount1=driver.findElement(By.xpath(objSphereModules.CustomerMaster_firstRow)).getText();
						ParentCompanyAccount2=driver.findElement(By.xpath(objSphereModules.CustomerMaster_secondRow)).getText();
						lsParentCompanyAccount.add(0, ParentCompanyAccount1);
						lsParentCompanyAccount.add(1, ParentCompanyAccount2);
						for(int i=0;i<lsParentCompanyAccount.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewNationalAccountModule_Table_xp, 1, lsParentCompanyAccount.get(i));
						}
						
						ClickByXpath(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						String EleText=driver.findElement(By.xpath(SphereModules.Users_ViewUser_ComboDeactivateChangeRole_xp)).getText();
						if(EleText.equalsIgnoreCase(Text)){
							
							obj.repAddData("Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list", " Deactivate displayed in bulk actions list : ", "Fail");
						}else
						{
							obj.repAddData( "Verify Deactive is displayed: ", "Deactivate should not appear in bulk actions list" , "Deactivate not displayed in bulk options list : ", "Pass");	
						}
						
						}
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC323 Failed!", e );
					    }
					    finally {
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC323 Completed");
					}
					return obj;
				} //End of Script TC323
				
				@SuppressWarnings("static-access")
				public Reporter TC404(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC404 Started..");

					try {
								
						obj.repAddData( "View  Customer page As Finance User", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Customer Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Parent Company");
						fnVerifyHeaders(arrHeaderColumns,6,"Location");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
						System.out.println("Hello");
						System.out.println(mTableDataUI.size());
						int RecordsSize=20;
						if(mTableDataUI.size()==RecordsSize){
							obj.repAddData( "Verifying Records are displayed on the page",  RecordsSize+ " records should be displayed on the page ", RecordsSize+ "  records displayed on the page", "Pass");	
						}else
						{
							obj.repAddData( "Verifying Records are displayed on the page", RecordsSize+ " records should be displayed on the page ", RecordsSize+ "  records not displayed on the page", "Fail");	
						}
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC404Failed!", e );
					}
					finally {
						fnCloseOpenedForm();

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC404 Completed");
					}
					return obj;
				} //End of Script TC404
				public Reporter TC405(Reporter obj) throws Exception
				{
				
					log.info("Execution of Script TC405 Started..");
						try {
							
							String sCustomer ="";
							obj.repAddData( "Adding a new customer As Finance User", "", "", "");
							//sCustomer = objBusinessLib.fnAddCustomerMultiAddressesContacts(sCustomer, "Add",true,1,true,1);
							sCustomer = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomer, "Add",true,1,true,1);
							System.out.println(sCustomer);
							
							}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC405 Failed!", e );
						}
					finally {
						
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC405 Completed");
					}
					return obj;
				} //End of Script TC405
				
				@SuppressWarnings("static-access")
				public Reporter TC406(Reporter obj) throws Exception
				{	
					log.info("Execution of Script TC406 Started..");
						try {
							obj.repAddData( " Verifying Edit Customer fields are enabled to update an  existing customer", "", "", "");
							//String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
							String sCustomerUI="AUTOTESTFINANCEUSER";
							
							objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
							WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
							Thread.sleep(3000);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							fnLoadingPageWait();
							Thread.sleep(1000);
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
							fnLoadingPageWait();
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
							fnLoadingPageWait();
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputName_id, "Name");
							fnCheckfieldDisbleById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, "Tax Id");
							fnCheckfieldEnableById(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,"ProductionType");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,"ParentCompany");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "Phone Number");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "Email");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddPlusLink_xp,"Add Contact Link",true);
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputFirstName_xp, "First Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputLastName_xp, "Last Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputTitle_xp,"Title");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputPhone_xp,"Phone");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_InputEmail_xp,"Email");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxMainContact_xp,"Main Contact Checkbox");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddContact_CheckboxRecInvoice_xp,"Receive Invoice Checkbox");
							
							ClickByXpath(SphereModules.	Deals_Edit_Customer_Contact_BtnCancel_xp,"cancel",true);
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnEditMainAddress_xp,"Edit link",true);
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, "Address Line 1");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id,  "Address Line 2");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id,  "Address Line 3");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,"Country");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_ComboState_id,"state");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, "City");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, "Zip");
							
							ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Link",true);
							
							fnCheckfieldEnableById(SphereModules.CustomersMaster_Address_InputAddrDesc_id,"Address Description");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_Address_InputAddnlInfo1_id, " Additional Info 1");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_Address_InputAddnlInfo2_id,"Additional Info 2");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddAltAddress_BtnAddPlusLink_xp,"Add Link");
							ClickByXpath(SphereModules.CustomerMaster_EditAltAddress_Pencil,"Edit Address",true);
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id,"Alternate Address Line1 ");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, "Alternate Address Line2");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id,"Alternate Address Line3");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,"Country");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,"state");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id, "City");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, "Zip");
					        
					        ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
					        
					        fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id,"Alternate Address Description");
					        fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo1_id, "Alternate Additional Info 1");
					        fnCheckfieldEnableById(SphereModules.CustomersMaster_AddAltAddress_InputAddnlInfo2_id,"Alternate Additional Info 2");
					        fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button");
							//fnCheckfieldDisbleByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp, "Group Name");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddGroup_xp, "Add Group button", true);
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_InputGroupName_xp,"Group Name");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupSave_xp,"Group Save");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel");
							ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnGroupCancel_xp,"Group Cancel",true);
							//fnCheckfieldDisbleById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, "Credit Limit");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Yes radio button");
							fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id,"No radio button");
							//ClickById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, "Credit Expiration", true);
							fnCheckfieldEnableById(SphereModules.CustomerMaster_Customer_CreditExpiration_id,"Credit Expiration");
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
							//fnCheckfieldEnableById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,"Credit Limit");
							fnCheckEnableByXPath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp,"Credit Limit Button");
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,false);
							//fnCheckFieldDisplayByXpath(objSphereModules. CustomerMaster_Customer_FinanceAdmin_Deactivate_xp,"Deactivate",true,false);
							fnCheckEnableByXPath(SphereModules.CustomerMaster_Customer_FinanceAdmin_Deactivate_xp,"Deactivate");
							//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp,"Close Button",true);
							//fnCheckFieldDisplayByXpath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save",true,true);
							fnCheckEnableByXPath(objSphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"Save");
							//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"save",true);
							//fnCheckFieldDisplayByXpath(SphereModules.Customers_Edit_Copy_xp,"Copy",true,true);
							fnCheckEnableByXPath(objSphereModules.Customers_Edit_Copy_xp,"Copy");
						}
						catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC406 Failed!", e );
						}
					finally {
						fnCloseOpenedForm();
						
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC406 Completed");
					}
					return obj;
				} //End of Script TC406
				public Reporter TC413(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC413 Started..");
				
					try {
						
						//String sCustomer ="";
						//obj.repAddData( "Pre-Condition : Adding a new customer as Finance User", "", "", "");
						//sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//System.out.println(sCustomer);
						String sCustomer="AUTOTESTFINANCEUSER";
						obj.repAddData( "Updating an existing customer contact address and group", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						String sAltContact = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedContact").trim();
						String [] arrContact = sAltContact.split(";");
						String sUpdAltFirstNameUI= arrContact[0].toString();
						String sUpdAltLastNameUI= arrContact[1].toString();
						String sUpdAltContactTypeUI= arrContact[2].toString();
						String sUpdAltContactPhoneUI = arrContact[3].toString();
						String sUpdAltContactEmailUI= arrContact[4].toString();
						
						ClickByXpath(SphereModules.CustomerMaster_EditContact_Pencil, "Edit link", true);
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_FirstName_xp, sUpdAltFirstNameUI, "First Name ");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_LastName_xp,sUpdAltLastNameUI, "Last Name");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_Title_xp, sUpdAltContactTypeUI, "Title");
						SendKeyByXpath(SphereModules.Deals_AddDeal_PhoneNumber_xp, sUpdAltContactPhoneUI, "Phone Number");
						SendKeyByXpath(SphereModules.Deals_AddDeal_EmailAddress_xp, sUpdAltContactEmailUI, "Email Address");
						///objGenericFunctionLibrary.ClickById(SphereModules. Deals_AddDeal_MainContact_id, "Main Contact", true);
						//ClickById(SphereModules.Deals_AddDeal_ReceivesInvoice_id, "Receives Invoice", true);
						ClickByXpath(SphereModules.Deals_AddDeal_AddNewContact_save_xp,"Check", true);
						Thread.sleep(4000);
						fnLoadingPageWait();
						String sUpdMainAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedMainAddr").trim();
						String [] arrMainAddress = sUpdMainAddress.split(";");
						
						String sMainUpdDescription="MainUpdtDescription";
						String sUpdAddr1UI= arrMainAddress[0].toString();
						String sUpdAddr2UI= arrMainAddress[1].toString();
						String sUpdAddr3UI= arrMainAddress[2].toString();
						String sUpdCountryUI = arrMainAddress[3].toString();
						String sUpdStateUI= arrMainAddress[4].toString();
						String sUpdCityUI= arrMainAddress[5].toString();
						String sUpdZipUI= arrMainAddress[6].toString();
						ClickByXpath(SphereModules.CustomerMaster_EditContact_Pencil, "Edit link", true);
						ClickByXpath(SphereModules.CustomersMaster_Address_ButtonAddDesc_xp,"Add Desc Button",true);
						SendKeyById(SphereModules.CustomersMaster_Address_InputAddrDesc_id, sMainUpdDescription, "Alternate Address Description");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sUpdAddr1UI, "Alternate Address Line 1");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id, sUpdAddr2UI, "Alternate Address Line 2");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sUpdAddr3UI, "Alternate Address Line 3");
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdCountryUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboState_id,sUpdStateUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCity_id, sUpdCityUI, "Alt City");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputZip_id,sUpdZipUI, "Alt Zip");
						
						String sAltAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedAltAddr").trim();
						String [] arrAddress = sAltAddress.split(";");
						String sUpdAltDescription="UpdtAltDescription";
						String sUpdAltAddr1UI= arrAddress[0].toString();
						String sUpdAltAddr2UI= arrAddress[1].toString();
						String sUpdAltAddr3UI= arrAddress[2].toString();
						String sUpdAltCountryUI= arrAddress[3].toString();
						String sUpdAltStateUI= arrAddress[4].toString();
						String sUpdAltCityUI= arrAddress[5].toString();
						String sUpdAltZipUI= arrAddress[6].toString();
						ClickByXpath(SphereModules. CustomerMaster_EditAltAddress_Pencil," Altenate Address Edit Link",true);
						ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_ButtonAddDesc_xp,"Add Desc Button",true);
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrDesc_id, sUpdAltDescription, "Alternate Address Description");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id, sUpdAltAddr1UI, "Alternate Address Line 1");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, sUpdAltAddr2UI, "Alternate Address Line 2");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id, sUpdAltAddr3UI, "Alternate Address Line 3");
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,sUpdAltCountryUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,sUpdAltStateUI);
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id,sUpdAltCityUI, "Alt City");
						SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, sUpdAltZipUI, "Alt Zip");
						ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_BtnAdd_xp,"Add Alternate Address Button",true);
						fnLoadingPageWait();
						ClickByXpath(SphereModules.Deals_Add_Address_Save_xp,"Add Address Button",true);
						fnLoadingPageWait();	
							
							
							ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						
						try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
				    	 int iRow = 1; //for add 
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
							String sAddr1DB = mTableDataDB.get(iRow).get(9).toString().trim();
							String sAddr2DB = mTableDataDB.get(iRow).get(10).toString().trim();
							String sAddr3DB = mTableDataDB.get(iRow).get(11).toString().trim();
							String sCountryDB = mTableDataDB.get(iRow).get(12).toString().trim();
							String sStateDB = mTableDataDB.get(iRow).get(13).toString().trim();
							String sCityDB = mTableDataDB.get(iRow).get(14).toString().trim();
							String sZipDB = mTableDataDB.get(iRow).get(15).toString().trim();
							//String sMultEmailDB = mTableDataDB.get(iRow).get(16).toString().trim();
							//String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(17).toString().trim();
							
							//Verify Address  //Include  sMultEmailDB.equalsIgnoreCase("1")) in If condition once it's implemented
							if(sUpdAddr1UI.equalsIgnoreCase(sAddr1DB) && sUpdAddr2UI.equalsIgnoreCase(sAddr2DB) && sUpdAddr3UI.equalsIgnoreCase(sAddr3DB) && sUpdCountryUI.equalsIgnoreCase(sCountryDB) && sUpdStateUI.equalsIgnoreCase(sStateDB) && sUpdCityUI.equalsIgnoreCase(sCityDB) && sUpdZipUI.equalsIgnoreCase(sZipDB)) // && sMultEmailDB.equalsIgnoreCase("1"))
							{	
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address validation successful for customer name : "+ sCustomer, "Pass");
							}
							else
							{
								obj.repAddData( "Verify customer address for customer name : "+ sCustomer, "Customer address on UI and DB should match for customer name : "+ sCustomer, "Address Validation failed for customer name : "+ sCustomer, "Fail");
							}

					    ///////////////////////////////////////Verifying Contacts Start//////////////////////////////////////////////////////
					  					    
					    String sQuery1 = objSQLConfig.sMasterCustomers_MultiContacts_Query;
					    sQuery1 = sQuery1.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
						HashMap<Integer, HashMap<Integer, String>> mContactTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						String sContactFirstNameDB = mContactTableDataDB.get(1).get(1).toString().trim();
						String sContactLastNameDB =mContactTableDataDB.get(1).get(2).toString().trim();
						String sContactTypeDB =mContactTableDataDB.get(1).get(3).toString().trim();
						String sContactPhoneDB = mContactTableDataDB.get(1).get(4).toString().trim();
						String sContactEmailDB = mContactTableDataDB.get(1).get(5).toString().trim();
						
						if(	sUpdAltFirstNameUI.equalsIgnoreCase(sContactFirstNameDB) && 
								sUpdAltLastNameUI.equalsIgnoreCase(sContactLastNameDB) &&
								sUpdAltContactTypeUI.equalsIgnoreCase(sContactTypeDB ) &&
								sUpdAltContactPhoneUI.equalsIgnoreCase  (sContactPhoneDB) &&
								sUpdAltContactEmailUI.equalsIgnoreCase (sContactEmailDB))
								//&&sInvoiceRecipient.equalsIgnoreCase("1"))
						{	
							//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sDealTitleDB+",\'"+sDealNumberDB+",Update,Deal");
							obj.repAddData( "Compare customer contact record for : "+ sCustomer, "Customer contact record on UI and DB should match for : "+ sCustomer, "Contact Validation successful for : "+ sCustomer, "Pass");
						}
						else
						{
							obj.repAddData( "Compare customer account contact record for : "+ sCustomer, "Customer contact record on UI and DB should match for : "+ sCustomer, "Contact Validation failed for : "+ sCustomer, "Fail");
						}
						
						/////////////////////////////////////Verifying Contacts End//////////////////////////////////////////////////////
						
						///////////////////////////////////////Verifying Alternate Addresses Start//////////////////////////////////////////////////////
						String sQuery2 = objSQLConfig.sMasterCustomers_MultiAddresses_Query;
						sQuery2 = sQuery2.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery2);
						HashMap<Integer, HashMap<Integer, String>> mAltAddressTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sAltDescDB=mAltAddressTableDataDB.get(1).get(1).toString().trim();
						String sAltAddr1DB=mAltAddressTableDataDB.get(1).get(2).toString().trim();
						String sAltAddr2DB=mAltAddressTableDataDB.get(1).get(3).toString().trim();
						String sAltAddr3DB=mAltAddressTableDataDB.get(1).get(4).toString().trim();
						String sAltCountryDB=mAltAddressTableDataDB.get(1).get(5).toString().trim();
						String sAltStateDB=mAltAddressTableDataDB.get(1).get(6).toString().trim();
						String sAltCityDB=mAltAddressTableDataDB.get(1).get(7).toString().trim();
						String sAltZipDB=mAltAddressTableDataDB.get(1).get(8).toString().trim();
						
						if(sUpdAltDescription.equalsIgnoreCase(sAltDescDB)&&sUpdAltAddr1UI.equalsIgnoreCase(sAltAddr1DB)&&
							sUpdAltAddr2UI.equalsIgnoreCase(sAltAddr2DB)&&sUpdAltAddr3UI.equalsIgnoreCase(sAltAddr3DB)&&
							sUpdAltCountryUI.equalsIgnoreCase(sAltCountryDB)&&sUpdAltStateUI.equalsIgnoreCase(sAltStateDB)&&
							sUpdAltCityUI.equalsIgnoreCase(sAltCityDB)&&sUpdAltZipUI.equalsIgnoreCase(sAltZipDB))
						{
							obj.repAddData( "Compare customer Alternate Address record for  : "+ sCustomer, "Customer Alternate Address record on UI and DB should match for : "+ sCustomer, "Address Validation successful for : "+ sCustomer, "Pass");	
						}
						else
						{
							obj.repAddData( "Compare customer Alternate Address record for : "+ sCustomer, "Customer Alternate Address record on UI and DB should match for : "+ sCustomer, "Address Validation failed for : "+ sCustomer, "Fail");
						}
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						fnLoadingPageWait();
						Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC413 Failed!", e );
					}
					finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC413 Completed");
					}
					return obj;
				} //End of Script TC413	
		
				//TC013_ORB-279_Update Customer_ProductionType_ParentCompany_Collector
				@SuppressWarnings("static-access")
				public Reporter TC414(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC414 Started..");
				
					try {
						
						//String sCustomer ="";
						//obj.repAddData( "Pre-Condition : Adding a new customer as Finance User", "", "", "");
						//sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						//System.out.println(sCustomer);
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						String sTaxIdUI = String.valueOf(fnRandomNum(100000001, 999999999));
						//String [] arrCustomer = sCustomer.split("_");
						//String sRandom = arrCustomer[1].toString(); 
						String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						//String sUpdatedCustomerTypeUI = "Universal Film";
						String sUpdatedProductionTypeUI = "Feature";
						//String sCreditExpirationDate="11/11/2016";
						String sUpdatedParentCompanyUI ="NBC";
						String sCustomer="AUTOTESTFINANCEUSER";
						obj.repAddData( "Updating an existing customer main info", "", "", "");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						
						//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sUpdatedParentCompanyUI);

						//ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "11/28/2016", "Production Start Date");
						
						//production start date
						SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2486758787", "Phone Number");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,  sRandom, "Credit Limit Box");
						
						//ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						//SendKeyById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, sCreditExpirationDate, "Credit Limit");
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						
						try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)));
							
							//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+",Update");
							
							String sSuccessMsg = TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.CustomersMaster_EditCustomer_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.CustomersMaster_EditCustomer_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						//DB Validation to follow
					    
					    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	 int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString();
						String sParentCompanyDB= mTableDataDB.get(iRow).get(8).toString();
						String sCreditExpirationDB=mTableDataDB.get(iRow).get(18).toString();						
							
						if(sCustomer.equalsIgnoreCase(sCustomerNameDB) && 
						sTaxIdUI.equalsIgnoreCase(sTaxIDDB)&&sUpdatedProductionTypeUI.equalsIgnoreCase(sProductionTypeDB) && 
						sCreditPermanentDB.equalsIgnoreCase("0")&&sUpdatedCreditLimitUI.equalsIgnoreCase(sCreditLimitDB)&&
						sUpdatedParentCompanyUI.equalsIgnoreCase(sParentCompanyDB)) //&&sCreditExpirationDate.equalsIgnoreCase(sCreditExpirationDB))// include once the date issue is resolved
						{	
						obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
						}
						else
						{
						obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
						}
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							fnLoadingPageWait();
							Thread.sleep(4000);
						
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC414 Failed!", e );
					}
					finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC414 Completed");
					}
					return obj;
				} //End of Script TC414	
				
				@SuppressWarnings("static-access")
				public Reporter TC430(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC430 Started..");

					try {
							
						obj.repAddData( "Verifying headers list and records on National Accounts page as Finance user", "", "", "");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
						Thread.sleep(4000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Location");
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
						System.out.println("Hello");
						System.out.println(mTableDataUI.size());
						int RecordsSize=20;
						if(mTableDataUI.size()==RecordsSize){
							obj.repAddData( "Verifying Records are displayed on the page",  RecordsSize+ " records should be displayed on the page ", RecordsSize+  " records displayed on the page", "Pass");	
						}else
						{
							obj.repAddData( "Verifying Records are displayed on the page", RecordsSize+  " records should be displayed on the page ", RecordsSize+   " records not displayed on the page", "Fail");	
						}
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC430 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
						
						fnCloseOpenedForm();

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC430 Completed");
					}
					return obj;
				} //End of Script TC320			
				//Sprint 2_TC026_ORB-280_Customer_NationalAccount_Add new
				public Reporter TC431(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC431 Started..");

					try {
								
						obj.repAddData( "Adding a new national account as Finance User", "", "", "");
						String sNationalAccount = objBusinessLib.fnAddNationalAccount();
						System.out.println(sNationalAccount);
						fnCloseOpenedForm();
												
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC431 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC431 Completed");
					}
					return obj;
				} //End of Script TC431		
				//Sprint 2_TC030_ORB-280_Customer_NationalAccount_Edit_Update
				public Reporter TC432(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC432 Started..");

					try {
					
						String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;

						obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
						String sAccountNameUI = objBusinessLib.fnAddNationalAccount();
						System.out.println(sAccountNameUI);
						
						
						obj.repAddData( "Updating an existing national account as Finance User", "", "", "");
									
						String [] arrNationalAccount = sAccountNameUI.split("_");
						String sRandom = arrNationalAccount[1].toString()+"_Updated"; 
						String sCustomerTypeUI="UCS Cable TV";
						String sProductionTypeUI="Commercial";
						String sQuery = objSQLConfig.sCustomers_EditNationalAccount_Query;
						sQuery = sQuery.replaceAll("account_name_param",sAccountNameUI);
						
						String sEmailUI = "AutoEmail_12"+"@nbcuni.com";
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sAccountNameUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sAccountNameUI, SphereModules.Customers_EditNationalAccount_LabelEditNationalAccountTitle_xp);	
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputEmail_id, sEmailUI, "Email");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
						
						String sUpdAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedMainAddr").trim();
						String [] arrAddress = sUpdAddress.split(";");
						System.out.println(arrAddress[0].toString());
						System.out.println(arrAddress[1].toString());
						System.out.println(arrAddress[2].toString());
						System.out.println(arrAddress[3].toString());
						System.out.println(arrAddress[4].toString());
						System.out.println(arrAddress[5].toString());
						System.out.println(arrAddress[6].toString());
						
						String sUpdAddr1UI= arrAddress[0].toString();
						String sUpdAddr2UI= arrAddress[1].toString();
						String sUpdAddr3UI= arrAddress[2].toString();
						String sUpdCountryUI = arrAddress[3].toString();
						String sUpdStateUI= arrAddress[4].toString();
						String sUpdCityUI= arrAddress[5].toString();
						String sUpdZipUI= arrAddress[6].toString();
						
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine1_id, sUpdAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine2_id, sUpdAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputAddressLine3_id,sUpdAddr3UI , "Address Line 3");
					    
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboCountry_id,sUpdCountryUI);
						fnSelectFromComboBoxId(SphereModules.Customers_AddNationalAccount_ComboState_id,sUpdStateUI);
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputCity_id, sUpdCityUI, "City");
						SendKeyById(SphereModules.Customers_AddNationalAccount_InputZip_id, sUpdZipUI, "Zip");  //Not changing Zip
										    
					    ClickByXpath(SphereModules.Customers_EditNationalAccount_BtnSave_xp, "Save Button", true);

					    try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp)));
							String sSuccessMsg = driver.findElement(By.xpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp)).getText();
							HighlightElementByXpath(SphereModules.Customers_EditNationalAccount_MsgSuccess_xp);
							System.out.println(sSuccessMsg);
							fnVerifyLabelMsgText(AppMessages.Customers_EditNationalAccount_Success_msg, sSuccessMsg.trim());
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 		
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						
						String sAccountNameDB = mTableDataDB.get(1).get(1).toString().trim();
						String sEmailDB = mTableDataDB.get(1).get(2).toString().trim();
						String sAddr1DB = mTableDataDB.get(1).get(3).toString().trim();
						String sAddr2DB = mTableDataDB.get(1).get(4).toString().trim();
						String sAddr3DB = mTableDataDB.get(1).get(5).toString().trim();
						
						String sCityDB = mTableDataDB.get(1).get(6).toString().trim();
						String sStateDB = mTableDataDB.get(1).get(7).toString().trim();
						String sZipDB = mTableDataDB.get(1).get(8).toString().trim();
						String sCountryDB = mTableDataDB.get(1).get(9).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(1).get(10).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(1).get(11).toString().trim();
						/*
						sLookupQuery = sLookupQuery.replaceAll("lookup_code_param",sCustomerTypeIdDB); 
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sLookupQuery);
						mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						String sCustomerTypeDB = mTableDataDB.get(1).get(1).toString();
						
						sLookupQuery = sLookupQuery.replaceAll(sCustomerTypeIdDB,sProductionTypeIdDB); 
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sLookupQuery);
						mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						String sProductionTypeDB = mTableDataDB.get(1).get(1).toString();
						*/
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						if(sAccountNameUI.equalsIgnoreCase(sAccountNameDB) && sEmailUI.equalsIgnoreCase(sEmailDB) &&
								sUpdAddr1UI.equalsIgnoreCase(sAddr1DB) && sUpdAddr2UI.equalsIgnoreCase(sAddr2DB) &&
								sUpdAddr3UI.equalsIgnoreCase(sAddr3DB) && sUpdCityUI.equalsIgnoreCase(sCityDB) &&
								sUpdStateUI.equalsIgnoreCase(sStateDB) && sUpdZipUI.equalsIgnoreCase(sZipDB) &&
								sUpdCountryUI.equalsIgnoreCase(sCountryDB) && sCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB) &&
								sProductionTypeUI.equalsIgnoreCase(sProductionTypeDB))
						{	
							obj.repAddData( "Compare national account record for account name : "+ sAccountNameUI, "National account record on UI and DB should match for account name : "+ sAccountNameUI, "Validation successful for account name : "+ sAccountNameUI, "Pass");
						}
						else
						{
							obj.repAddData( "Compare national account record for account name : "+ sAccountNameUI, "National account record on UI and DB should match for account name : "+ sAccountNameUI, "Validation failed for account name : "+ sAccountNameUI, "Fail");
						}
						 
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);					
						}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC432 Failed!", e );
					}
					finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC432 Completed");
					}
					return obj;
				} //End of Script TC432
				
					
				@SuppressWarnings("static-access")
				public Reporter TC433(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC433 Started..");

					try {
						String ParentCompanyAccount =" ";		
						List<String> lsParentCompanyAccount = new ArrayList<String>();
						obj.repAddData( "Verifying User Can Deactive Parent Accounts  ", "", "", "");
						
						obj.repAddData( "Adding a new national account (Pre-requisite)", "", "", "");
						 //ParentCompanyAccount = objBusinessLib.fnAddNationalAccount();
						//System.out.println(ParentCompanyAccount);
						//lsParentCompanyAccount.add(ParentCompanyAccount);
						String bulkAccount_Title=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Bulk_Title").trim();
						//lsParentCompanyAccount.add(0,"AutoTestAccountName_40252");//for testing added parent account with out creating
						lsParentCompanyAccount.add(0,bulkAccount_Title);
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						Thread.sleep(3000);
						for(int i=0;i<lsParentCompanyAccount.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewNationalAccountModule_Table_xp, 2, lsParentCompanyAccount.get(i));
						}
						ClickById(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						objBusinessLib.fnSelectDeactivateChangeRoleOption(0, "Deactivate");
						ClickByXpath(SphereModules.Users_ViewUser_ConfirmDeactivateYesBtn_xp, "Yes button", true);
						Thread.sleep(3000);
						for(int j=0;j<lsParentCompanyAccount.size();j++)
						{
							objBusinessLib.fnVerifyParentcompanyDeactivatedRecord(lsParentCompanyAccount.get(j).toString());
						}
				
						}
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC433 Failed!", e );
					   }
					   finally {
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC433 Completed");
					}
					return obj;
				} //End of Script TC433
		
				
				@SuppressWarnings("static-access")
				public Reporter TC1500(Reporter obj) throws Exception
				{
					try {
						obj.repAddData( "Verifying pagination on  Parent Companies page", "", "", "");
								
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));		
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_groupText_xp, "Showing items" , true,true);
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_dropDown_xp,"20 per page",true,true);
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_numbersequence_xp,"page number sequence",true,true);
						
						obj.repAddData( "Verifying number of records on  Parent Companies page", "", "", "");
                        
						objBusinessLib.fnVerifyPaginationNumberOptionfields(SphereModules.Common_ViewNationalAccountModule_Table_xp, SphereModules.Common_View_pagination_dropDown50_xp,50,50);
						objBusinessLib.fnVerifyPaginationNumberOptionfields(SphereModules.Common_ViewNationalAccountModule_Table_xp, SphereModules.Common_View_pagination_dropDown100_xp,100,100);	
						objBusinessLib.fnVerifyPaginationNumberOptionfields(SphereModules.Common_ViewNationalAccountModule_Table_xp, SphereModules.Common_View_pagination_dropDown20_xp,20,20);
						
						obj.repAddData( "Verifying Page Navigation on  Parent Companies page", "", "", "");
						
						objBusinessLib.fnVerifyPageNavigation(SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,68,74); 
					  
					    }
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC1500 Failed!", e );
					}			

			       finally
			       {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Script TC1500 Completed");
				}
				return obj;
				} //End of Script TC1500
				
				@SuppressWarnings("static-access")
				public Reporter TC279(Reporter obj) throws Exception
				{
					try {
						obj.repAddData( "Verifying pagination on  Customers page", "", "", "");
								
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));		
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_groupText_xp, "Showing items" , true,true);
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_dropDown_xp,"20 per page",true,true);
						Thread.sleep(1000);
						fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_numbersequence_xp,"page number sequence",true,true);

						obj.repAddData( "Verifying number of records on Customers page", "", "", "");
						
						objBusinessLib.fnVerifyPaginationNumberOptionfields(SphereModules.Common_ViewCustomersModule_Table_xp, SphereModules.Common_View_pagination_dropDown50_xp, 50, 50);
						objBusinessLib.fnVerifyPaginationNumberOptionfields(SphereModules.Common_ViewCustomersModule_Table_xp, SphereModules.Common_View_pagination_dropDown100_xp, 100, 100);	
						objBusinessLib.fnVerifyPaginationNumberOptionfields(SphereModules.Common_ViewCustomersModule_Table_xp, SphereModules.Common_View_pagination_dropDown20_xp,20,20);
				
                        obj.repAddData( "Verifying Page Navigation on Customers page", "", "", "");
						
						objBusinessLib.fnVerifyPageNavigation(SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,62,68); 
						
					   }
					    catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC279 Failed!", e );
					}			

			        finally {
					
					/*if((bLoginFlag==true && driver!=null) )
					{
						fnSignOut();
					}*/

					if(!testCaseStatus)
					{
						Reporter.iTotalFail++;	
					}
					else
					{
						Reporter.iTotalPass++;
					}
					log.info("Execution of Script TC279 Completed");
				}
				return obj;
				} //End of Script TC279
				
				
				
				
				@SuppressWarnings("static-access")
				public Reporter TC281(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC281 Started..");

					try {
								
						obj.repAddData( "Verifying  Sorting Functionality", "", "", "");
						
						//objBusinessLib.fnClickMainMenuElement("Administration");
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(4000);
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Customer Number",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sMasterCustomers_ViewDescCustomer_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Customer Number",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc", objSQLConfig.sMasterCustomers_ViewAscCustomer_Query,"");
						objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Name",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sMasterCustomers_ViewDesc_CustomerName_Query,"");
						objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Name",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sMasterCustomers_ViewAsc_CustomerName_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Customer Type",4,objSphereModules.Common_Btn_Sorting_Column_4,"Desc",objSQLConfig.sMasterCustomers_ViewDesc_CustomerType_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Customer Type",4,objSphereModules.Common_Btn_Sorting_Column_4,"Asc",objSQLConfig.sMasterCustomers_ViewAsc_CustomerType_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Production Type",5,objSphereModules.Common_Btn_Sorting_Column_5,"Desc",objSQLConfig.sMasterCustomers_ViewDesc_ProductionType_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Production Type",5,objSphereModules.Common_Btn_Sorting_Column_5,"Asc",objSQLConfig.sMasterCustomers_ViewAsc_ProductionType_Query,"");
						
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Location",7,objSphereModules.Common_Btn_Sorting_Column_7,"Desc",objSQLConfig.sMasterCustomers_ViewDesc_Location_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewCustomersModule_Table_xp,"Location",7,objSphereModules.Common_Btn_Sorting_Column_7,"Asc",objSQLConfig.sMasterCustomers_ViewAsc_Location_Query,"");
					             ////no need to add sorting by location///////////
					}
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC281 Failed!", e );
					}
					finally {
						
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC281 Completed");
					}
					return obj;
				} //End of Script TC281
				
				@SuppressWarnings("static-access")
				public Reporter TC282(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC282 Started..");

					try {
								
						obj.repAddData( "Verifying  Sorting Functionality", "", "", "");
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						Thread.sleep(4000);
				        objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Account Number",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sCustomers_ViewAllNationalAccount_Query,"");
						objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Account Number",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc", objSQLConfig.sCustomers_ViewAscNationalAccount_Query,"");
						objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Name",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sCustomers_ViewDescAccountName_Query,"");
						objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Name",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sCustomers_ViewAscAccountName_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Customer Type",4,objSphereModules.Common_Btn_Sorting_Column_4,"Desc",objSQLConfig.sCustomers_ViewDesc_CustomerType_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Customer Type",4,objSphereModules.Common_Btn_Sorting_Column_4,"Asc",objSQLConfig.sCustomers_ViewAsc_CustomerType_Query,"");
					   // objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Production Type",5,objSphereModules.Common_Btn_Sorting_Column_5,"Desc",objSQLConfig.sCustomers_ViewDesc_ProductionType_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Production Type",5,objSphereModules.Common_Btn_Sorting_Column_5,"Asc",objSQLConfig.sCustomers_ViewAsc_ProductionType_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Location",6,objSphereModules.Common_Btn_Sorting_Column_6,"Desc",objSQLConfig.sCustomers_ViewDesc_Location_Query,"");
						//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_ViewNationalAccountModule_Table_xp,"Location",6,objSphereModules.Common_Btn_Sorting_Column_6,"Asc",objSQLConfig.sCustomers_ViewAsc_Location_Query,"");
					  ////////////////// production type is sorting by the production type code id and we don't  need  sorting functionality for location any more  /////////
					
					    }
					    catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC282 Failed!", e );
					 }
					 finally {
						
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC282 Completed");
					}
					return obj;
				} //End of Script TC282


				
				@SuppressWarnings("static-access")
				public Reporter TC407(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC407 Started..");

					try {
						
						String sCustomer= " ";
						
						obj.repAddData( "Verifying  Finance user can Deactive Customer Records ", "", "", "");
						
						List<String> lsCustomer = new ArrayList<String>();
						//int iBulkDeactivationCount = Integer.valueOf(TestDriver.prop.getProperty("BulkDeactivationCount").toString().trim());
						int iBulkDeactivationCount=1;
						for(int iCount=0;iCount<iBulkDeactivationCount;iCount++)
						{
							obj.repAddData( "Adding user "+String.valueOf(iCount+1) +" (Pre-Condition)", "", "", "");
							sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
							System.out.println(sCustomer);
							Thread.sleep(2000);
							lsCustomer.add(sCustomer);
						}
						
						Thread.sleep(2000);
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						for(int i=0;i<lsCustomer.size();i++)
						{
							Thread.sleep(5000);
							objBusinessLib.fnSelectCheckBoxInTable(objSphereModules.Common_ViewCustomersModule_Table_xp, 2, lsCustomer.get(i));
						}
						
						ClickById(objSphereModules.Users_ViewUser_BtnBulkActions_id, "Bulk Actions Option", true);
						Thread.sleep(5000);
						objBusinessLib.fnSelectDeactivateChangeRoleOption(0, "Deactivate");
						ClickByXpath(SphereModules.Users_ViewUser_ConfirmDeactivateYesBtn_xp, "Yes button", true);
						Thread.sleep(5000);
						for(int j=0;j<lsCustomer.size();j++)
						{
							objBusinessLib.fnVerifyCustomerDeactivatedRecord(lsCustomer.get(j).toString());
						}
						
					  }
					    
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC407 Failed!", e );
					   }
					  
					    finally {
					    	fnCloseOpenedForm();
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC407 Completed");
					}
					return obj;
				} //End of Script TC407
				
				public Reporter TC512(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC512 Started..");

					try {
					
						String sCustomer="";
						obj.repAddData( "Deacivating and Reactivating an existing Customer", "", "", "");
						
						obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
					    sCustomer= objBusinessLib.fnAddCustomer(sCustomer,"Add");
						System.out.println(sCustomer);
						// sCustomer="AUTOTESTCUSTOMER_70860";
						//String sCustomer= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_UI").trim();
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						
						
						//////////////Deactivating Steps/////////////////
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnDeactivate_xp, "Deactivate Button", true);
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp)));
						
					    String sDeactivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp);
						System.out.println(sDeactivateConfirmationMsg);
						String sExpConfMsg = AppMessages.Customers_EditCustomer_DeactivateConfirmation_msg.replaceAll("customer_name_param",  sCustomer );
						fnVerifyLabelMsgText(sExpConfMsg, sDeactivateConfirmationMsg.trim());
						
						ClickByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_Yes_xp, "Yes,I'm Sure", true);
						/*
						try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateSuccess_xp)));
							fnVerifyLabelMsgTextByXpath(AppMessages.Customers_EditCustomer_DeactivateSuccess_msg ,SphereModules.Customers_EditCustomer_MsgDeactivateSuccess_xp);
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						
						objBusinessLib.fnVerifyCustomerDeactivatedRecord(sCustomer);
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);					
						
						/////////////////////Activating steps started///////////////////// 
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
					    
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnActivate_xp, "Activate Button", true);
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgReactivateConfirmation_xp)));
						
					    String sActivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditCustomer_MsgReactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditCustomer_MsgReactivateConfirmation_xp);
						System.out.println(sActivateConfirmationMsg);
						String sExpReactivateConfMsg = AppMessages.Customers_EditCustomer_ActivateConfirmation_msg.replaceAll("customer_name_param",  sCustomer );;
						fnVerifyLabelMsgText(sExpReactivateConfMsg, sActivateConfirmationMsg.trim());
	                    ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnActivate_Yes_xp, "Yes", true);
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgReactivateSuccess_xp)));
							fnVerifyLabelMsgTextByXpath(AppMessages.Customers_Edit_Customer_ReactivateSuccess_msg,SphereModules.Customers_EditCustomer_MsgReactivateSuccess_xp);
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						objBusinessLib.fnVerifyCustomerActivatedRecord(sCustomer);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);					
					   }
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC512 Failed!", e );
					   }
					   finally {
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC512 Completed");
					}
					return obj;
				} //End of Script TC512									
				
				

				public Reporter TC513(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC513 Started..");

					try {
						
						String sCustomerUI ="";
						
						obj.repAddData( "Validate that user is not able to  deactivate customers associated with deals ", "", "", "");
						
						obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add");
						System.out.println(sCustomerUI);
						String sDealTitle ="";

                        String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			            System.out.println(sDealTitleRandom);
			
			            String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
						String sProjectName="SCRIPTED WORLD";
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						//sDealTitleUI = "AutoTestDeal_"+sRandom;
						String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
					    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
					    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
					    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
					    String sQuery1 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
						
						
						objBusinessLib.fnClickMainMenuElement("Deals");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
						Thread.sleep(10000); 
						ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
						fnLoadingPageWait();
						fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
						objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
						SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
						fnLoadingPageWait();
						ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
						ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
						SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
						SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
						SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
						fnLoadingPageWait();
						ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
						//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
						//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
						ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
						ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
						///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
					    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
						ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
						
						//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
						
						ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
						SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
						ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
						fnLoadingPageWait();
					   
						sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
					    sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);//use Deal Number here instead of DealTitle;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sDealNumberDB = mTableDataDB.get(1).get(1).toString().trim();
						String sDealTitleDB = mTableDataDB.get(1).get(2).toString().trim();
						String sDealTypeDB = mTableDataDB.get(1).get(3).toString().trim();
						String sCustomerNameDB = mTableDataDB.get(1).get(4).toString().trim();
						
						if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&
								sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB) &&
								sCustomerUI.equalsIgnoreCase(sCustomerNameDB))
						{	
							//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+",\'"+sDealNumberDB+"/"+sDealTitleDB+",Create");
							obj.repAddData( "Compare deal account record for Deal Title : "+ sDealTitleUI, "Deal account record on UI and DB should match for Deal Title : "+ sDealTitleUI +" and Deal Number : "+sDealNumberDB, "Validation successful for deal title : "+ sDealTitleUI+" and Deal Number : "+sDealNumberDB, "Pass");
						}
						else
						{
							obj.repAddData( "Compare deal account record for Deal Title : "+ sDealTitleUI, "Deal account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI, "Fail");
						}
						
						obj.repAddData( "Validating user cannot deactivate an existing Customer associated with deals", "", "", "");
				
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						//fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);	
					    ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnDeactivate_xp, "Deactivate Button", true);

					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_Deal_Customer_Cannot_Be_Deactivated_xp)));
					    HighlightElementByXpath(SphereModules.Customers_Deal_Customer_View_Title_Btn_xp);
					    HighlightElementByXpath(SphereModules.Customers_Deal_Customer_Cannot_Be_Deactivated_xp);
					    Thread.sleep(3000);
					    String sCloseDealsTextMsg = driver.findElement(By.xpath(SphereModules.Customers_Deal_Customer_ToCloseDeals_Display_Text_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_Deal_Customer_ToCloseDeals_Display_Text_xp);
						Thread.sleep(3000);
						System.out.println(sCloseDealsTextMsg);
						String sExpConfMsg = AppMessages.Customers_Deal_Customer_ToCloseDeals_Display_Text_msg.replaceAll("customer_name_param",  sCustomerUI );
						fnVerifyLabelMsgText(sExpConfMsg, sCloseDealsTextMsg.trim());
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboDeactNationalAccount_id, "Test Account");
						String DealNumber=driver.findElement(By.xpath(SphereModules.Customers_Deal_Customer_Deals_Display_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_Deal_Customer_Deals_Display_xp);
						Thread.sleep(3000);
						System.out.println(DealNumber);
						fnVerifyLabelMsgText(sDealNumberDB,DealNumber);
						ClickByXpath(SphereModules.Customers_Deal_Customer_View_Open_Deals_Btn_xp, "View Open Deals", true);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
						Thread.sleep(3000);
						String UIDealNumber=driver.findElement(By.xpath(objSphereModules.CustomerMaster_firstRow_secondCol)).getText();
						fnVerifyLabelMsgText(sDealNumberDB,UIDealNumber);
						
						ClickByXpath(objSphereModules.CustomerMaster_firstRow,"DealTitle",true);
						//fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealBtnStatusClosed_xp,"Closed");
						fnSelectFromComboBoxId(SphereModules.Deals_AddDealBtnStatus_id,"Closed");
						ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
						Thread.sleep(3000);
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
					    waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						//fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);	
					    ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnDeactivate_xp, "Deactivate Button", true);
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp)));
						String sDeactivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp);
						System.out.println(sDeactivateConfirmationMsg);
						String sExpAppConfMsg = AppMessages.Customers_EditCustomer_DeactivateConfirmation_msg.replaceAll("customer_name_param",  sCustomerUI );
						fnVerifyLabelMsgText(sExpAppConfMsg, sDeactivateConfirmationMsg.trim());
						ClickByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_Yes_xp, "Yes,I'm Sure", true);
						/*try {
							waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateSuccess_xp)));
							fnVerifyLabelMsgTextByXpath(AppMessages.Customers_EditCustomer_DeactivateSuccess_msg ,SphereModules.Customers_EditCustomer_MsgDeactivateSuccess_xp);
							Thread.sleep(4000);
							ClickByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateSuccess_xp, "success", true);
						} catch (Exception e) {
							obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
							// TODO Auto-generated catch block
							e.printStackTrace();
						}*/
						String sQuery = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery.replaceAll("customer_name_param",  sCustomerUI));
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						String sCustomerDB = mTableDataDB1.get(1).get(1).toString();
						//String sDealTitleDB = mTableDataDB.get(1).get(2).toString();
						String sDealNumber = mTableDataDB1.get(1).get(2).toString();
						String sStatusDB = mTableDataDB1.get(1).get(3).toString();
						String sActiveDB= mTableDataDB1.get(1).get(4).toString();
						//String sStatus="Open Deal";
						String sStatus="Closed-Accept No New Cost/Chrg";
						String sActive="0";
						if(sCustomerUI.equalsIgnoreCase(sCustomerDB)&&
						   sDealNumber.equalsIgnoreCase(sDealNumber)&&
						   sStatusDB.equalsIgnoreCase(sStatus)&&
						   sActiveDB.equalsIgnoreCase(sActive))
						{
							obj.repAddData( "Verify deactivation for customer : "+ sCustomerUI, "Customer : "+ sCustomerUI+" should be deactivated", "customer : "+ sCustomerUI+" deactivated successfully", "Pass");

						}
						else
						{
							obj.repAddData( "Verify deactivation for customer : "+ sCustomerUI, "Customer : "+ sCustomerUI+" should be deactivated", "customer : "+ sCustomerUI+" not deactivated", "Fail");
						}
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);					
						}
					    catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC513 Failed!", e );
					    }
					    finally {
						fnCloseOpenedForm();
						if(ElementFound(SphereModules.Customers_Deal_Customer_Cannot_Be_Deactivated_xp)){
							ClickByXpath(SphereModules.Customers_Deal_Customer_View_Close_Btn_xp, "Close button", true);	
						}
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC513 Completed");
					}
					return obj;
				} //End of Script TC513	
			
				public Reporter TC515(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC515 Started..");

					try {
					
						String sCustomerUI ="";
												
						obj.repAddData( "updating customer type as finance admin", "", "", "");
						
						obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
						
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add");
						System.out.println(sCustomerUI);
					   // sCustomerUI ="AutoTestCustomer_48504";
						String sUpatedCustomerType="UCS Cable TV";
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI, "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
						Thread.sleep(3000);	
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						
						fnCheckfieldEnableById(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"CustomerType");
						
						fnVerifyCombolist("Customer_Type_List","Customer Type" ,SphereModules.Customers_EditNationalAccount_ComboCustomerType_id);
						//fnVerifyDropdownValues(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,"Customer_Type_List", "001 - Universal City Studios","Customer Type");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpatedCustomerType);
						////////////////////////////////Verifying legal entity text/////////////////////////////
						//String ExpLegalentity="001 - Universal City Studios";
						//String ActualLegalentity=TestDriver.driver.findElement(By.xpath(SphereModules.Customers_CustomerType_LegalEntity_xp)).getText().trim();
						//fnVerifyLabelMsgText(ExpLegalentity, ActualLegalentity.trim());
								
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp,"save",true);
						fnLoadingPageWait();
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
					  	int iRow = 1; //for add 
						sQuery = sQuery.replaceAll("customer_name_param",sCustomerUI);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
						String sParentCompanyDB = mTableDataDB.get(iRow).get(8).toString().trim();
							
						if(sCustomerUI.equalsIgnoreCase(sCustomerNameDB) && sUpatedCustomerType.equalsIgnoreCase(sCustomerTypeDB)) 
								
						{	
								//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNameUI+",Create");
							obj.repAddData( "Compare customer record for customer name : "+ sCustomerUI, "Customer record on UI and DB should match for customer name : "+ sCustomerUI, "Validation successful for customer name : "+ sCustomerUI, "Pass");
						}
						else
						{
							obj.repAddData( "Compare customer record for customer name : "+ sCustomerUI, "Customer record on UI and DB should match for customer name : "+ sCustomerUI, "Validation failed for customer name : "+ sCustomerUI, "Fail");
						}
							
					   }
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC515 Failed!", e );
					    }
					    finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC515 Completed");
					}
					return obj;
				} //End of Script TC515	
				
				public Reporter TC517(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC517 Started..");

					try {
						String sCustomerUI ="";
						
						obj.repAddData( "Validate that user is able to cancel deactivating customers associated with deals ", "", "", "");
						
						obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add");
						System.out.println(sCustomerUI);
						
						obj.repAddData( "Adding a new deal account ", "", "", "");///// included add deal steps here instead of function
						//String sDealTitle = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
						//System.out.println(sDealTitleUI);
						String sProjectName="SCRIPTED WORLD";
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	
						String sDealTitleUI = "AUTOTESTDEAL_"+sRandom;
						String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
					    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
					    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
						String sQuery = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
						//String sCustomer="DEALCUSTOMER";
						//String sCustomer= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Customer").trim();						
						//String sDealNumber=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_UI").trim();	
						String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
						objBusinessLib.fnClickMainMenuElement("Deals");
						WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
						Thread.sleep(10000); 
						ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
						fnLoadingPageWait();
						
						fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
						objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
						
						SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
						fnLoadingPageWait();
						
						ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
						ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
						SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
						
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
						
						SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
						SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
						fnLoadingPageWait();
						ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
						//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
						//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
						ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
						ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
						///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
					    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
						ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
						
						//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
						
						ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
						SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
						ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
						fnLoadingPageWait();
					    String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
					    sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);//use Deal Number here instead of DealTitle;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sDealNumberDB = mTableDataDB.get(1).get(1).toString().trim();
						String sDealTitleDB = mTableDataDB.get(1).get(2).toString().trim();
						String sDealTypeDB = mTableDataDB.get(1).get(3).toString().trim();
						String sCustomerNameDB = mTableDataDB.get(1).get(4).toString().trim();
						
						if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB) && sCustomerUI.equalsIgnoreCase(sCustomerNameDB))
						{	
							//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+",\'"+sDealNumberDB+"/"+sDealTitleDB+",Create");
							obj.repAddData( "Compare deal account record for Deal Title : "+ sDealTitleUI, "Deal account record on UI and DB should match for Deal Title : "+ sDealTitleUI +" and Deal Number : "+sDealNumberDB, "Validation successful for deal title : "+ sDealTitleUI+" and Deal Number : "+sDealNumberDB, "Pass");
						}
						else
						{
							obj.repAddData( "Compare deal account record for Deal Title : "+ sDealTitleUI, "Deal account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI, "Fail");
						}
						
						
						obj.repAddData( "Validating user cannot deactivate an existing Customer associated with deals", "", "", "");
														
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						//fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);	
					    ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnDeactivate_xp, "Deactivate Button", true);

					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_Deal_Customer_Cannot_Be_Deactivated_xp)));
					    HighlightElementByXpath(SphereModules.Customers_Deal_Customer_View_Title_Btn_xp);
					    HighlightElementByXpath(SphereModules.Customers_Deal_Customer_Cannot_Be_Deactivated_xp);
					    Thread.sleep(3000);
					    String sCloseDealsTextMsg = driver.findElement(By.xpath(SphereModules.Customers_Deal_Customer_ToCloseDeals_Display_Text_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_Deal_Customer_ToCloseDeals_Display_Text_xp);
						Thread.sleep(3000);
						System.out.println(sCloseDealsTextMsg);
						String sExpConfMsg = AppMessages.Customers_Deal_Customer_ToCloseDeals_Display_Text_msg.replaceAll("customer_name_param",  sCustomerUI );
						fnVerifyLabelMsgText(sExpConfMsg, sCloseDealsTextMsg.trim());
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboDeactNationalAccount_id, "Test Account");
						String DealNumber=driver.findElement(By.xpath(SphereModules.Customers_Deal_Customer_Deals_Display_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_Deal_Customer_Deals_Display_xp);
						Thread.sleep(3000);
						System.out.println(DealNumber);
						fnVerifyLabelMsgText(sDealNumberDB,DealNumber);
						ClickByXpath(SphereModules.Customers_Deal_Customer_View_Close_Btn_xp, "Cancel", true);
						fnCloseOpenedForm();
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
					    }
					    catch (Exception e){
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC517 Failed!", e );
					    }
					    finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC517 Completed");
					}
					return obj;
				} //End of Script TC517
			
				public Reporter TC518(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC518 Started..");

					try {
					
						String sCustomerUI ="";
						String sCustomerLabel="";
						String ActualTitle="";
						String[] arrCustomer;
						obj.repAddData( "Viewing Credit approval notification page ", "", "", "");
						
						sCustomerUI = objBusinessLib.fnAddCustomerwithCreditExpirationdate(sCustomerUI, "Add");
						
						//System.out.println(sCustomerUI);
						//String sCustomerUI ="TEST15678";
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI, "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
						Thread.sleep(3000);	
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
										
						
						ClickByXpath(SphereModules.Customers_CreditApprovalNotification_View_Btn_xp,"View",true);
						fnCloseOpenedForm();
						fnLoadingPageWait();
						Thread.sleep(3000);
						objBusinessLib.fnGetCreditTableData(objSphereModules.Customers_CreditApprovalNotification_View_table_xp,sCustomerUI);
						System.out.println("Hello");
						
						//SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
					   }
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC518 Failed!", e );
					    }
					    finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC518 Completed");
					}
					return obj;
				} //End of Script TC518
      
				public Reporter TC519(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC519 Started..");

					try {
						String sCustomerUI ="";
						
						obj.repAddData( "Creating deal through Credit approval notification page ", "", "", "");
						
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add");
						System.out.println(sCustomerUI);
						//String sCustomerUI ="AUTOTESTCUSTOMER_28809";
						String sProjectName="SCRIPTED WORLD";
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						String sDealTitleUI = "AUTOCREDITAPPROVALDEAL_"+sRandom;
						String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
					    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
					    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
					    String sCostCenterUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
					    int iCostCenter=1;
					    objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI, "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
						Thread.sleep(3000);	
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
												
						
						ClickByXpath(SphereModules.Customers_CreditApprovalNotification_View_Btn_xp,"View",true);
						fnLoadingPageWait();
						fnCloseOpenedForm();
						WebElement ele =TestDriver.driver.findElement(By.xpath(SphereCommon.Customers_CreditApprovalNotification_Title_xp));
						HighlightElement(ele);
						Thread.sleep(2000);
						String sCreditApprovalTitleMessage = AppMessages.Customers_CreditApprovalNotification_Title_msg.toString().trim();
						if(CheckTextOnPage(sCreditApprovalTitleMessage))
						{
							obj.repAddData( "Verify Credit Approval notification page", "Credit Approval notification page should be loaded", "Credit Approval notification page loaded successfully with Title : "+sCreditApprovalTitleMessage, "Pass");
						}
						ClickByXpath(objSphereModules.Customers_CreditApprovalNotification_CreateDeal_xp,"Create Deal",true);				
						System.out.println("Hello");
						fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
						
						objBusinessLib.fnSelectCostCenter(iCostCenter,sCostCenterUI);	
						
						String CustText = TestDriver.driver.findElement(By.xpath(SphereModules.Customers_CreditApprovalNotification_Deal_customer_xp)).getText().trim();
						String [] arrlist = CustText.split(" ");
	        			//System.out.println(arrAddress[0].toString());
	        			String CustName= arrlist[0].toString();
	        			String sCustNumber= arrlist[1].toString();
	        			fnCheckFieldDisplayByXpath(objSphereModules.Customers_CreditApprovalNotification_Deal_customer_xp,sCustomerUI,true,true);
	        			Thread.sleep(3000);
	        			String sCustomer=sCustomerUI.substring(0, 25);// since customer name is too long full name is not appearing in UI so used this line of code to handle this
	        			fnVerifyLabelMsgTextByXpath(sCustomer, objSphereModules.Customers_CreditApprovalNotification_Deal_customer_xp);
	        			//fnVerifyLabelMsgText(sCustomerUI, CustName);
						SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
						Thread.sleep(2000);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
					    SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
						SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
						fnLoadingPageWait();
						ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
						ClickByXpath(SphereModules.Deals_AddDeal_AddNewContact_xp,"Add Contact",true);
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_FirstName_xp, "Test First Name", "First Name ");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_LastName_xp, "Test Last Name", "Last Name");
						SendKeyByXpath(SphereModules.Deals_AddDeal_AddNewContact_Title_xp, "Test Title Name", "Title");
						SendKeyByXpath(SphereModules.Deals_AddDeal_PhoneNumber_xp, "2484621245", "Phone Number");
						SendKeyByXpath(SphereModules.Deals_AddDeal_EmailAddress_xp, "test@email.com", "Email Address");
						///objGenericFunctionLibrary.ClickById(SphereModules. Deals_AddDeal_MainContact_id, "Main Contact", true);
						///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDeal_ReceivesInvoice_id, "Receives Invoice", true);
					    ClickByXpath(SphereModules.Deals_AddDeal_AddNewContact_save_xp,"Check", true);
						fnLoadingPageWait();
						ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
						ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
						ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
						ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
						fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
						//ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
						SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"02/12/2021","Insurance Expiration");
						ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
						fnLoadingPageWait();
						String sQuery = objSQLConfig.sDeals_AddDeal_Query;
						sQuery = sQuery.replaceAll("deal_title_param",sDealTitleUI);//use Deal Number here instead of DealTitle;
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						String sDealNumberDB = mTableDataDB.get(1).get(1).toString().trim();
						String sDealTitleDB = mTableDataDB.get(1).get(2).toString().trim();
						String sDealTypeDB = mTableDataDB.get(1).get(3).toString().trim();
						String sCustomerNameDB = mTableDataDB.get(1).get(4).toString().trim();
						
								//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
						if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && 
								sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB) && 
								sCustomerUI.equalsIgnoreCase(sCustomerNameDB))
						{	
								//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+",\'"+sDealNumberDB+"/"+sDealTitleDB+",Create");
								obj.repAddData( "Compare deal account record for Deal Title : "+ sDealTitleUI, "Deal account record on UI and DB should match for Deal Title : "+ sDealTitleUI +" and Deal Number : "+sDealNumberDB, "Validation successful for deal title : "+ sDealTitleUI+" and Deal Number : "+sDealNumberDB, "Pass");
						}
						else
						{
							    obj.repAddData( "Compare deal account record for Deal Title : "+ sDealTitleUI, "Deal account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI, "Fail");
						}
					
					}
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC519 Failed!", e );
					    }
					    finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC519 Completed");
					}
					return obj;
				} //End of Script TC518

				public Reporter TC520(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC520 Started..");

					try {
						String sCustomerUI ="";
						
						obj.repAddData( "Validating that user can't create deal after selecting invalid costcenter for the customer ", "", "", "");
						
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add");
						System.out.println(sCustomerUI);
						//String sCustomerUI ="AUTOTESTCUSTOMER_28809";
						String sProjectName="SCRIPTED WORLD";
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						String sCostCenterUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
					    int iCostCenter=1;
					    objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI, "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
						Thread.sleep(3000);	
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
												
						ClickByXpath(SphereModules.Customers_CreditApprovalNotification_View_Btn_xp,"View",true);
						fnCloseOpenedForm();
						fnLoadingPageWait();
						Thread.sleep(3000);
						WebElement ele =TestDriver.driver.findElement(By.xpath(SphereCommon.Customers_CreditApprovalNotification_Title_xp));
						HighlightElement(ele);
						//fnCheckFieldDisplayByXpath(String sLocator, String sReportText, boolean bReportFlag, boolean bScenarioFlag) 
						Thread.sleep(2000);
						String sCreditApprovalTitleMessage = AppMessages.Customers_CreditApprovalNotification_Title_msg.toString().trim();
						if(CheckTextOnPage(sCreditApprovalTitleMessage))
						{
							obj.repAddData( "Verify Credit Approval notification page", "Credit Approval notification page should be loaded", "Credit Approval notification page loaded successfully with Title : "+sCreditApprovalTitleMessage, "Pass");
							
						}
						ClickByXpath(objSphereModules.Customers_CreditApprovalNotification_CreateDeal_xp,"Create Deal",true);				
						System.out.println("Hello");
						fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
						objBusinessLib.fnSelectCostCenter(iCostCenter,sCostCenterUI);	
						fnCheckFieldDoesNotExistByXpath(objSphereModules.Customers_CreditApprovalNotification_Deal_customer_xp,sCustomerUI,true);
	        			Thread.sleep(3000);
					   }
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC520 Failed!", e );
					    }
					    finally {
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC520 Completed");
					}
					return obj;
				} //End of Script TC520
				
				@SuppressWarnings("static-access")
				public Reporter TC801(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC801 Started..");
				
					try {
						String sCustomerUI="";
						
						obj.repAddData( "Adding Customer through Copy", "", "", "");
						
						sCustomerUI= objBusinessLib.fnAddCustomer(sCustomerUI,"Add");
						System.out.println(sCustomerUI);
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						String sTaxIdUI = String.valueOf(fnRandomNum(100000001, 999999999));
						//String sCustomerUI="AUTOTESTFINANCEUSER";
						String sCustomerNameUI="AUTOCOPYCUSTOMER_"+sRandom;
						String sProductionTypeUI="Subrentals";
						
						Date date = new Date();
						//String sStartDateUI1= new SimpleDateFormat("MMddyyyy").format(date);
						String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
						
						Date dYesterday = DateUtils.addDays(new Date(), -1);
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						String sStartDateUI2 = sdf.format(dYesterday);
						
						//String sStartDateUI2= new SimpleDateFormat("yyyy-MM-dd").format(date);
						//String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
						String sParentCompanyUI="HBO";
						String sCustomerTypeUI="UCS Film";
						
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
						fnLoadingPageWait();
						Thread.sleep(3000);
												
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
																	
						ClickByXpath(SphereModules.Customers_Edit_Copy_xp, "Copy Link", true);
						Thread.sleep(4000);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
						//ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, " ", "Production Start Date");
						//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
						//SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
						//fnAddCustomerMultiAddressesContacts( sCustomerNameUI,  sOperation, false, 1, false, 0);
						String sCreditLimitUI=sRandom+".00";
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id, sRandom, "Credit Limit");
						//objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxFirstGroup_xp, "Select First Group", true);
						ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerYes_id, "Yes radio button", true);
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
						fnLoadingPageWait();
					 
					    	    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
					    	    int iRow = 1; //for add 
							    sQuery = sQuery.replaceAll("customer_name_param",sCustomerNameUI);
								TestDriver.conn = objDBUtility.fnOpenDBConnection();
								TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
								HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
								
								objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
								String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
								String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
								String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
								String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
								String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
								String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
								String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
								String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
								
								String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
								String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
								String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
								String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
								String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
								String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
								String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
								String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
								String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
								
								if(sCustomerNameUI.equalsIgnoreCase(sCustomerNameDB) && 
								   sCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB) &&
								   sTaxIdUI.equalsIgnoreCase(sTaxIDDB) && 
								   sProductionTypeUI.equalsIgnoreCase(sProductionTypeDB) && //sCreditLimitUI.equalsIgnoreCase(sCreditLimitDB)&& 
								   sParentCompanyUI.equalsIgnoreCase(sParentCompanyDB))
								{	
									//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNameUI+",Create");
									obj.repAddData( "Compare customer record for customer name : "+ sCustomerNameUI, "Customer record on UI and DB should match for customer name : "+ sCustomerNameUI, "Validation successful for customer name : "+ sCustomerNameUI, "Pass");
								}
								else
								{
									obj.repAddData( "Compare customer record for customer name : "+ sCustomerNameUI, "Customer record on UI and DB should match for customer name : "+ sCustomerNameUI, "Validation failed for customer name : "+ sCustomerNameUI, "Fail");
								}
					   
					    objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
					    SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						fnLoadingPageWait();
						Thread.sleep(4000);
						
						}
					   catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC801 Failed!", e );
					   }
					   finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC801 Completed");
					}
					return obj;
				} //End of Script TC801
				

				@SuppressWarnings("static-access")
				public Reporter TC900(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC900 Started..");
				
					try {

						String sCustomerUI ="";
						
						obj.repAddData( "Adding new customer through Intercept Menu Copy", "", "", "");
						
						obj.repAddData( "Adding a new customer", "", "", "");
						sCustomerUI = objBusinessLib.fnAddCustomer(sCustomerUI, "Add");
						System.out.println(sCustomerUI);
						
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						String sTaxIdUI = String.valueOf(fnRandomNum(100000001, 999999999));
						//sCustomerUI="AUTOTESTFINANCEUSER";
						String sCustomerNameUI="AUTOCOPYCUSTOMER_"+sRandom;
					    //sCustomerUI= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_UI").trim();
						Date date = new Date();
						String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
						Date dYesterday = DateUtils.addDays(new Date(), -1);
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						String sStartDateUI2 = sdf.format(dYesterday);
						String sNewCustomerTypeUI="UCS Film";
						
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Customer_InterceptMenu_Copy_Link_xp, "Copy", true);
						Thread.sleep(4000);
						
						
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sNewCustomerTypeUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
						//SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
						String sUpdMainAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedMainAddr").trim();
						String [] arrMainAddress = sUpdMainAddress.split(";");
						
						//String sMainUpdDescription="MainUpdtDescription";
						String sUpdAddr1UI= arrMainAddress[0].toString();
						String sUpdAddr2UI= arrMainAddress[1].toString();
						String sUpdAddr3UI= arrMainAddress[2].toString();
						String sUpdCountryUI = arrMainAddress[3].toString();
						String sUpdStateUI= arrMainAddress[4].toString();
						String sUpdCityUI= arrMainAddress[5].toString();
						String sUpdZipUI= arrMainAddress[6].toString();
						ClickByXpath(SphereModules.CustomerMasters_AddCustomer_AddressLinkPencil, "click pencil icon", true);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sUpdAddr1UI, "Address Line 1");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine2_id, sUpdAddr2UI, "Address Line 2");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sUpdAddr3UI, "Address Line 3");
					    
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboCountry_id,sUpdCountryUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboState_id,sUpdStateUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCity_id,sUpdCityUI, "City");
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputZip_id, sUpdZipUI, "Zip");
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
						              /////////////////Adding Customer Address End//////////////////
						
						ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
						fnLoadingPageWait();
					 
					    	 String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
					    	 int iRow = 1; //for add 
							    sQuery = sQuery.replaceAll("customer_name_param",sCustomerNameUI);
								TestDriver.conn = objDBUtility.fnOpenDBConnection();
								TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
								HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
								
								objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
								String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
								String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
								String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
								String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
								String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
								String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
								String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
								String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
								
								String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
								String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
								String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
								String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
								String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
								String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
								String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
								String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
								String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
								
								if(sCustomerNameUI.equalsIgnoreCase(sCustomerNameDB) && 
									sNewCustomerTypeUI.equalsIgnoreCase(sCustomerTypeDB) &&
									sTaxIdUI.equalsIgnoreCase(sTaxIDDB)) 
								{	
									//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNameUI+",Create");
									obj.repAddData( "Compare customer record for customer name : "+ sCustomerNameUI, "Customer record on UI and DB should match for customer name : "+ sCustomerNameUI, "Validation successful for customer name : "+ sCustomerNameUI, "Pass");
								}
								else
								{
									obj.repAddData( "Compare customer record for customer name : "+ sCustomerNameUI, "Customer record on UI and DB should match for customer name : "+ sCustomerNameUI, "Validation failed for customer name : "+ sCustomerNameUI, "Fail");
								}
								
								//Verify Address  //Include  sMultEmailDB.equalsIgnoreCase("1")) in If condition once it's implemented
								if(sUpdAddr1UI.equalsIgnoreCase(sAddr1DB) && 
										sUpdAddr2UI.equalsIgnoreCase(sAddr2DB) && 
										sUpdAddr3UI.equalsIgnoreCase(sAddr3DB) && 
										sUpdCountryUI.equalsIgnoreCase(sCountryDB) && 
										sUpdStateUI.equalsIgnoreCase(sStateDB) && sUpdCityUI.equalsIgnoreCase(sCityDB) && sUpdZipUI.equalsIgnoreCase(sZipDB)) // && sMultEmailDB.equalsIgnoreCase("1"))
								{	
									obj.repAddData( "Verify customer address for customer name : "+ sCustomerNameUI, "Customer address on UI and DB should match for customer name : "+ sCustomerNameUI, "Address validation successful for customer name : "+ sCustomerNameUI, "Pass");
								}
								else
								{
									obj.repAddData( "Verify customer address for customer name : "+ sCustomerNameUI, "Customer address on UI and DB should match for customer name : "+ sCustomerNameUI, "Address Validation failed for customer name : "+ sCustomerNameUI, "Fail");
								}
					   
					    objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
					    SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
						fnLoadingPageWait();
						Thread.sleep(4000);
						
						}
					    catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC900 Failed!", e );
					    }
					    finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
					//	fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC900 Completed");
					}
					return obj;
				} //End of Script TC900			
				
				@SuppressWarnings("static-access")
				public Reporter TC901(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC901 Started..");
				
					try {
						
						String sCustomer ="";
						
						obj.repAddData( "Updating an existing customer main info", "", "", "");
						
						obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
						sCustomer = objBusinessLib.fnAddCustomer(sCustomer, "Add");
						System.out.println(sCustomer);
						String sRandom = String.valueOf(fnRandomNum(10001, 14999));
						String sTaxIdUI = String.valueOf(fnRandomNum(100000001, 999999999));
						String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
						String sUpdatedProductionTypeUI = "Feature";
						String sUpdatedParentCompanyUI ="NBC";
						//String sUpdatedCustomerTypeUI = "Universal Film";
						//String sCreditExpirationDate="11/11/2016";
						//String sCustomer="AUTOTESTFINANCEUSER";
						//String sCustomer= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_UI").trim();///can take customer from test data
												
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
						Thread.sleep(3000);
						
						ClickByXpath(SphereModules.Customer_InterceptMenu_ViewEdit_Link_xp, "View/Edit", true);
						Thread.sleep(4000);
						
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
						fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
						
						//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
						fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sUpdatedProductionTypeUI);
						fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sUpdatedParentCompanyUI);
						
						SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
						
						//ClickByXpath(SphereModules.CustomersMaster_EditCustomer_ButtonCreditLimit_xp, "Credit Limit Button", true);
						//SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputCreditLimit_id,  sRandom, "Credit Limit Box");
						//ClickById(SphereModules.CustomersMaster_AddCustomer_RadioPermCustomerNo_id, "No radio button", true);
						//SendKeyById(SphereModules.CustomerMaster_Customer_CreditExpiration_id, sCreditExpirationDate, "Credit Limit");
						
						ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
						
						   ///////////////////////////DB Validation to follow//////////////////////////////////
					    
					    String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
				    	 int iRow = 1; //for add 
					    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
						TestDriver.conn = objDBUtility.fnOpenDBConnection();
						TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
						HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
						
						objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
						
						String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
						String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
						String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
						String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
						String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
						String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
						String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
						String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
						
						String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
						String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
						String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
						String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
						String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
						String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
						String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
						String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
						String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();						
							
						if(sCustomer.equalsIgnoreCase(sCustomerNameDB)&& 
						sTaxIdUI.equalsIgnoreCase(sTaxIDDB)&&
						sUpdatedProductionTypeUI.equalsIgnoreCase(sProductionTypeDB) && 
						sUpdatedParentCompanyUI.equalsIgnoreCase(sParentCompanyDB)) //&&sCreditExpirationDate.equalsIgnoreCase(sCreditExpirationDB))// include once the date issue is resolved
						{	
						obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
						}
						else
						{
						obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
						}
							
							SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
							fnLoadingPageWait();
							Thread.sleep(4000);
						
						}
					    catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC901 Failed!", e );
					   }
					   finally {
						
						//ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnClose_xp, "Close", true);
						//ClickByXpath(SphereModules.CustomerMaster_EXit_Confirm_page_xp, "yes I'm sure", true);
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/
				
						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC901 Completed");
					}
					return obj;
				} //End of Script TC901			
                
				@SuppressWarnings("static-access")
				public Reporter TC902(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
				 log.info("Execution of Script TC902 Started..");

				 try {
						String sCustomer="";

						obj.repAddData( "Deactivating and Reactivating of an existing Customer through Intercept Menu ", "", "", "");
						
						obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
					    sCustomer= objBusinessLib.fnAddCustomer(sCustomer,"Add");
						System.out.println(sCustomer);
						String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;
						    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
							TestDriver.conn = objDBUtility.fnOpenDBConnection();
							TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
							HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
							
							objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
							String sCustomerNameDB = mTableDataDB.get(1).get(1).toString().trim();
							String sOrbitCustNumberDB = mTableDataDB.get(1).get(18).toString().trim();
							
						
						String sQuery1 = objSQLConfig.sCustomer_DeactivateUser_Query;
						//String sCustomer="AUTOTESTCUSTOMER_83567";
						//String sCustomer= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_UI").trim();
						objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sOrbitCustNumberDB , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_InterceptMenu_Deactivate_Link_xp, "Deactivate", true);
						Thread.sleep(4000);
					    waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp)));
						
					    String sDeactivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_xp);
						System.out.println(sDeactivateConfirmationMsg);
						String sExpConfMsg = AppMessages.Customers_EditCustomer_DeactivateConfirmation_msg.replaceAll("customer_name_param",  sCustomer );
						fnVerifyLabelMsgText(sExpConfMsg, sDeactivateConfirmationMsg.trim());
						ClickByXpath(SphereModules.Customers_EditCustomer_MsgDeactivateConfirmation_Yes_xp, "Yes,I'm Sure", true);
						
						objBusinessLib.fnVerifyCustomerDeactivatedRecord(sCustomer);
						
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sOrbitCustNumberDB , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(3000);
						RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
						Thread.sleep(3000);
						ClickByXpath(SphereModules.Common_InterceptMenu_Activate_Link_xp, "Activate", true);
						Thread.sleep(4000);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgReactivateConfirmation_xp)));
						String sActivateConfirmationMsg = driver.findElement(By.xpath(SphereModules.Customers_EditCustomer_MsgReactivateConfirmation_xp)).getText().trim();
						HighlightElementByXpath(SphereModules.Customers_EditCustomer_MsgReactivateConfirmation_xp);
						System.out.println(sActivateConfirmationMsg);
						String sExpReactivateConfMsg = AppMessages.Customers_EditCustomer_ActivateConfirmation_msg.replaceAll("customer_name_param",  sCustomer );;
					    fnVerifyLabelMsgText(sExpReactivateConfMsg, sActivateConfirmationMsg.trim());
		                ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnActivate_Yes_xp, "Yes", true);
						/*try {
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Customers_EditCustomer_MsgReactivateSuccess_xp)));
							fnVerifyLabelMsgTextByXpath(AppMessages.Customers_Edit_Customer_ReactivateSuccess_msg,SphereModules.Customers_EditCustomer_MsgReactivateSuccess_xp);
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Customers_EditCustomer_MsgReactivateSuccess_xp, "success", true);
						} catch (Exception e) {
						obj.repAddData( "Verify Success Message", "Success message should be displayed", "Success message not displayed", "Fail");
								//TODO Auto-generated catch block
								e.printStackTrace();
						}*/
						
						objBusinessLib.fnVerifyCustomerActivatedRecord(sCustomer);
						SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box");
						fnLoadingPageWait();
						Thread.sleep(4000);
					
				    }
					catch (Exception e) {
						e.printStackTrace();
						testCaseStatus = false;
						//bLoginFlag=false;
						obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
						log.error( "Script TC902 Failed!", e );
					}
					finally {
						
						fnCloseOpenedForm();
						/*if((bLoginFlag==true && driver!=null) )
						{
							fnSignOut();
						}*/

						if(!testCaseStatus)
						{
							Reporter.iTotalFail++;	
						}
						else
						{
							Reporter.iTotalPass++;
						}
						log.info("Execution of Script TC902 Completed");
					}
				    return obj;
				} //End of Script TC902		
				
				@SuppressWarnings("static-access")
				public Reporter TC392(Reporter obj) throws Exception
				{
					//Boolean bLoginFlag = true;	
					log.info("Execution of Script TC392 Started..");
					
					obj.repAddData( "Validate that user is able to export parent company grid list to excel file", "", "", "");
					try {	
						
						WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
						objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewNationalAccountModule_Table_xp)));
						Thread.sleep(4000);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
						Thread.sleep(3000);
						WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
						List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
						System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
						fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
						fnVerifyHeaders(arrHeaderColumns,2,"Name");
						fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
						fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
						fnVerifyHeaders(arrHeaderColumns,5,"Location");
						
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
						Thread.sleep(4000);
						
						obj.repAddData( "Verifying All filter grid list export", "", "", "");
						objBusinessLib.fnVerifyParentCompanyExportData("All");
						
						obj.repAddData( "Verifying Active filter grid list export", "", "", "");
						ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active", true);
						Thread.sleep(3000);
						
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
						System.out.println("Hello");
						Boolean bResultFlag=false;
						int failedrecords=0;
						String sTablexpath=objSphereModules.Common_ViewNationalAccountModule_Table_xp;
						for(int i=1;i<=mTableDataUI.size(); i++)
						{
							bResultFlag = false;
							String sDealNumber = mTableDataUI.get(i).get(1).toString();
							String ActualColor=TestDriver.driver.findElement(By.xpath(sTablexpath+"/tr["+i+"]/td["+2+"]"+"/sp-status-color/i")).getAttribute("class");
							String [] arrClassName = ActualColor.split(" ");
					        String sStatus = arrClassName[arrClassName.length-1].toString().trim();
					        
					        if(sStatus.equalsIgnoreCase("activeRecord"))
					        {
					        	bResultFlag = true;
					        	obj.repAddData("Verify active record is displayed ", "Active record should display in the table","Active record is displayed success fully", "Pass");
					        }				  
					        if(bResultFlag == false)
					        {
					        	failedrecords++;
					        	obj.repAddData("Verify active record is displayed ", "Active record should display in the table","Active record is not displayed", "Fail");
					        }
					    
					    }
						
						if(failedrecords==0)
						{
							{
								obj.repAddData( "Compare all "+mTableDataUI.size()+" filtered records displayed on the screen", "All active records on UI should be displayed", "All active records displayed successfully on the screen", "Pass");

								
								objBusinessLib.fnVerifyParentCompanyExportData("Active");
							
							}
							
						}
						
						
						obj.repAddData( "Verifying Inactive filter grid list export", "", "", "");
						ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive", true);
						Thread.sleep(3000);
						HashMap<Integer, HashMap<Integer, String>> mTableDataUI1 = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
						System.out.println("Hello");
						boolean bResultFlag1 = false;
						int failedrecords1=0;
						for(int i=1;i<=mTableDataUI1.size(); i++)
						{
							bResultFlag1 = false;
							String sDealNumber = mTableDataUI1.get(i).get(1).toString();
							//String ActualColor=TestDriver.driver.findElement(By.xpath(SphereModules.Deals_AddDeal_GreenColor_xp)).getAttribute("class");
							String ActualColor=TestDriver.driver.findElement(By.xpath(sTablexpath+"/tr["+i+"]/td["+2+"]"+"/sp-status-color/i")).getAttribute("class");
							String [] arrClassName = ActualColor.split(" ");
					        String sStatus = arrClassName[arrClassName.length-1].toString().trim();
					        
					        if(sStatus.equalsIgnoreCase("inactiveRecord"))
					        {
					        	bResultFlag1 = true;
					        	obj.repAddData("Verify closed filtered record is displayed ", "closed filtered record should display in the table","closed filtered record is displayed successfully", "Pass");
					        }				  
					        if(bResultFlag1 == false)
					        {
					        	failedrecords1++;
					        	obj.repAddData("Verify closed filtered record is displayed ", "closed filtered record should display in the table","closed filtered record is not displayed", "Fail");
					        }
					    
					    }
						
						if(failedrecords1==0)
						{
							{
								obj.repAddData( "Compare all "+mTableDataUI1.size()+" filtered records displayed on the screen", "All closed filtered records on UI should be displayed", "All closed filtered records displayed successfully on the screen", "Pass");
								
								objBusinessLib.fnVerifyParentCompanyExportData("Inactive");
							}
							
						}
						
						
						
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
						Thread.sleep(4000);
						
					  }
						    catch (Exception e) {
							e.printStackTrace();
							testCaseStatus = false;
							//bLoginFlag=false;
							obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
							log.error( "Script TC392 Failed!", e );
						}
					
						   finally {
							   
							fnCloseOpenedForm();

							if(!testCaseStatus)
							{
								Reporter.iTotalFail++;	
							}
							else
							{
								Reporter.iTotalPass++;
							}
							log.info("Execution of Script TC392 Completed");
						}
						
					return obj;
				}//End of Script TC392    
			      

@SuppressWarnings("static-access")
public Reporter TC400(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC400 Started..");
	String sCustomerUI="";
	
	String sRandom = String.valueOf(fnRandomNum(10001, 99999));
	
	obj.repAddData( "Validate that UPM contact is not counted as Accounting Contact", "", "", "");
	try {	
		
		obj.repAddData( "Adding a new customer", "", "", "");
		sCustomerUI = objBusinessLib.fnRegAddCustomerMultiAddressesContacts(sCustomerUI, "Add",true,1,false,0);
		System.out.println(sCustomerUI);
	    //sCustomerUI="AUTOTESTCUSTOMER_81753";
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI , "Search Box");
		fnLoadingPageWait();
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
		fnLoadingPageWait();
		
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
		fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
				
        String sContactPhone ="7346788899";
        ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAddPlusLink_xp,"Add Contact Link",true);
		SendKeyByXpath(SphereModules.CustomersMaster_AddContact_InputFirstName_xp, "AutoContactFirstName_"+sRandom, "First Name");
		SendKeyByXpath(SphereModules.CustomersMaster_AddContact_InputLastName_xp, "AutoContactLastName_"+sRandom, "Last Name");
		SendKeyByXpath(SphereModules.CustomersMaster_AddContact_InputTitle_xp, "UPM", "Title");
		SendKeyByXpath(SphereModules.CustomersMaster_AddContact_InputPhone_xp, sContactPhone, "Phone");
		
		SendKeyByXpath(SphereModules.CustomersMaster_AddContact_InputEmail_xp, "AutoEmail"+"@nbcuni.com", "Email");
		ClickByXpath(SphereModules.CustomersMaster_AddContact_BtnAdd_xp,"Add Contact Button",true);
		fnLoadingPageWait();
		ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save Button", true);
		fnLoadingPageWait();
		SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "", "Search Box");
		fnLoadingPageWait();
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerUI, "Search Box");
		fnLoadingPageWait();
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
		Thread.sleep(3000);	
		
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
		fnVerifyLabelMsgTextByXpath(sCustomerUI, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
				
		ClickByXpath(SphereModules.Customers_CreditApprovalNotification_View_Btn_xp,"View",true);
		fnCloseOpenedForm();
		fnLoadingPageWait();
		Thread.sleep(3000);
		
		waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Customers_CreditApprovalNotification_Title_xp)));
		WebElement ele =TestDriver.driver.findElement(By.xpath(SphereCommon.Customers_CreditApprovalNotification_Title_xp));
		HighlightElement(ele);
		Thread.sleep(2000);
		WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Customers_CreditApprovalNotification_View_Logo_xp));
		HighlightElement(Logoele);
		Thread.sleep(2000);
		
		fnCheckFieldDisplayByXpath(objSphereModules.Customers_CreditApprovalNotification_UPM_Contact_xp,"UPM Label",true,true);
		String ActualUPMLabel=driver.findElement(By.xpath(SphereModules.Customers_CreditApprovalNotification_UPM_Contact_xp)).getText().trim();
		String ExpUPMcontactLabel="UPM";
		fnVerifyLabelMsgText(ExpUPMcontactLabel, ActualUPMLabel.trim());
		
		fnCheckFieldDisplayByXpath(objSphereModules.Customers_CreditApprovalNotification_UPM_Contact_Name_xp,"UPM Contact Name",true,true);
		String ActualUPMContactName=driver.findElement(By.xpath(SphereModules.Customers_CreditApprovalNotification_UPM_Contact_Name_xp)).getText().trim();
		System.out.println(ActualUPMContactName);
		String ExpUPMContactName="AutoContactFirstName_"+sRandom+" AutoContactLastName_"+sRandom;
		System.out.println(ExpUPMContactName);
		fnVerifyLabelMsgText(ExpUPMContactName, ActualUPMContactName.trim());
		//String ActualUPMContactName="AutoContactFirstName_98325 AutoContactLastName_98325";
		//sCustomerUI="AUTOTESTCUSTOMER_89974";
		//////////////Contact DB Validation/////////////////
		String sQuery = objSQLConfig.scustomer_UPM_Contact_Query;
		sQuery = sQuery.replaceAll("customer_name_param",sCustomerUI);
		TestDriver.conn = objDBUtility.fnOpenDBConnection();
		TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
		HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
		boolean bFlag = false;
		
		//String ContactNameDB=mTableDataDB.get(1).get(1).toString().trim();
		objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
		for(int i=1;i<=mTableDataDB.size();i++){
			//System.out.println(mTableDataDB.get(i).get(i).toString().trim());
			String ContactNameDB = mTableDataDB.get(i).get(1).toString().trim();
			if(ActualUPMContactName.equals(ContactNameDB))
		{
			bFlag = true;
			obj.repAddData( "Compare contact details on credit approval  page", "contact details on UI and DB should match", "customer contact details validation successful", "Pass");
		}
		
		}
		
		if(bFlag == false)
		{
			obj.repAddData( "Compare contact details on credit approval  page", "contact details on UI and DB should match", "customer contact details validation failed", "Fail");
		}
	
		
	  }
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC400 Failed!", e );
		}
	
		   finally {
			   
			fnCloseOpenedForm();

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC400 Completed");
		}
		
	return obj;
}//End of Script TC400    

@SuppressWarnings("static-access")
public Reporter TC401(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC401 Started..");
	String sCustomerUI="";
	
	String sRandom = String.valueOf(fnRandomNum(10001, 99999));
	
	obj.repAddData( "Validate that customers and deals associated with alternate address is displayed", "", "", "");
	try {	
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
	   // sCustomerUI="AUTOTESTCUSTOMER_92143";
		List<String> arrsUINumberlist = new ArrayList<String>();
		
		String sAltAddressLine1=objBusinessLib.fnAltAddressPresearchForAssociated("Customers");///provide new address from test data each time you run test
	   
	    String sDealTitleUI = objBusinessLib.fnAddDealAccountWithAddressSearch(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"),sAltAddressLine1);
		System.out.println(sDealTitleUI);
		String sQuery1 = objSQLConfig.sDeals_AddressDeal_Query;
		sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
		TestDriver.conn = objDBUtility.fnOpenDBConnection();
		TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
		HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	    String DealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	    arrsUINumberlist.add(DealNumberDB);
	  
	    obj.repAddData( "Adding a new customer", "", "", "");
		int AddCustomerCount=2;
		
		for(int i=1;i<=AddCustomerCount; i++)
		{
		
		sCustomerUI = objBusinessLib.fnAddCustomerWithAltAddressSearch(sCustomerUI, "Add",sAltAddressLine1);
		System.out.println(sCustomerUI);
		//arrsCustomerUIlist.add(sCustomerUI);
		String sQuery2 = objSQLConfig.sMasterCustomers_ViewCustomer_Query;
		sQuery2 = sQuery2.replaceAll("customer_name_param",sCustomerUI);
		TestDriver.conn = objDBUtility.fnOpenDBConnection();
		TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery2);
		HashMap<Integer, HashMap<Integer, String>> mTableDataDB2 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	    String CustomerNumber=mTableDataDB2.get(1).get(1).toString().trim();
	    arrsUINumberlist.add(CustomerNumber);
		}
		
		//arrsCustomerNumberlist.add(0,"906903");
		//arrsCustomerNumberlist.add(1,"906904");
		//arrsCustomerNumberlist.add(2,"671395");
		String DealNumber = arrsUINumberlist.get(0).toString().trim();
		String FirstCustomer = arrsUINumberlist.get(1).toString().trim();
		String SecondCustomer=arrsUINumberlist.get(2).toString().trim();
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		fnLoadingPageWait();
		//WebDriverWait wait = new WebDriverWait(TestDriver.driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, SecondCustomer, "Search Box");
		fnLoadingPageWait();
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
		Thread.sleep(3000);	
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
		fnVerifyLabelMsgTextByXpath(SecondCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
				
		ClickByXpath(SphereModules.CustomerMaster_EditAltAddress_Pencil, "Edit Pencil",true);
		Thread.sleep(3000);	
		String sAltAddress = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UpdatedAltAddr").trim();
		String [] arrAddress = sAltAddress.split(";");
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd.HH.mm.ss").format(new java.util.Date());
        System.out.println(timeStamp);
		String sUpdAltAddr1UI= arrAddress[0].toString()+timeStamp;//add date time stamp to address line 1
		String sUpdAltAddr2UI= arrAddress[1].toString();
		String sUpdAltAddr3UI= arrAddress[2].toString();
		String sUpdAltCountryUI = arrAddress[3].toString();
		String sUpdAltStateUI= arrAddress[4].toString();
		String sUpdAltCityUI= arrAddress[5].toString();
		String sUpdAltZipUI= arrAddress[6].toString();
		
		SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id, sUpdAltAddr1UI, "Alternate Address Line 1");
		SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id, sUpdAltAddr2UI, "Alternate Address Line 2");
		SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id, sUpdAltAddr3UI, "Alternate Address Line 3");
		
		fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddAltAddress_ComboCountry_id,sUpdAltCountryUI);
		fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddAltAddress_ComboState_id,sUpdAltStateUI);
		SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputCity_id, sUpdAltCityUI, "Alt City");
		SendKeyById(SphereModules.CustomersMaster_AddAltAddress_InputZip_id, sUpdAltZipUI, "Alt Zip");
			
		ClickByXpath(SphereModules.CustomersMaster_AddAltAddress_BtnAdd_xp,"Add Alternate Address Button",true);
		fnLoadingPageWait();
		//objBusinessLib.fnUSPSValidation("SAVE");
		
		ClickByXpath(SphereModules.CustomerMaster_EditAltAddress_Pencil, "Edit Pencil",true);
		Thread.sleep(3000);
		
		obj.repAddData( "Verifying Customer updated alternate address", "", "", "");
		
		ClickByXpath(SphereModules.Customers_Edit_Customer_Associated_Item_Btn_xp,"Associated Items Button",true);
		fnLoadingPageWait();
		List<WebElement> eleSpanList =TestDriver.driver.findElements(By.xpath(SphereModules.Customers_AltAddress_AssociatedItems_list_xp));
		for (WebElement element : eleSpanList)
		{
			if (element.getText().trim().contains(FirstCustomer))
			{
				Thread.sleep(500);
				HighlightElement(element);
				ClickByElement(element, FirstCustomer, true);
				Thread.sleep(2000);
				fnLoadingPageWait();
				break;
			}
		}
		//ClickByXpath(SphereModules.Customers_AltAddress_AssociatedItems_FirstCustomer_xp,"First Customer",true);
		//fnLoadingPageWait();
		
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
		fnVerifyLabelMsgTextByXpath(FirstCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
		       
        WebElement ele =TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp));
		System.out.println("Displayed>>>"+ele.isDisplayed());
		((JavascriptExecutor)TestDriver.driver).executeScript("arguments[0].scrollIntoView(true);", ele);
		
		ClickByXpath(SphereModules.CustomerMaster_EditAltAddress_Pencil, "Edit Pencil",true);
		Thread.sleep(3000);	
		String AddressLine1=TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine1_id)).getAttribute("value");
		fnVerifyLabelMsgText(sUpdAltAddr1UI,AddressLine1);
		String AddressLine2=TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine2_id)).getAttribute("value");
		fnVerifyLabelMsgText(sUpdAltAddr2UI,AddressLine2);
		String AddressLine3=TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddAltAddress_InputAddrLine3_id)).getAttribute("value");
	    fnVerifyLabelMsgText(sUpdAltAddr3UI,AddressLine3);
		String Country=TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_AddAltAddress_ComboSelectedCountry_xp)).getText().trim();
		fnVerifyLabelMsgText(sUpdAltCountryUI,Country);
		String StateUI=TestDriver.driver.findElement(By.xpath(SphereModules.CustomersMaster_AddAltAddress_ComboSelectedState_xp)).getText().trim();
	    fnVerifyLabelMsgText(sUpdAltStateUI,StateUI);
	    String city=TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddAltAddress_InputCity_id)).getAttribute("value");
	    fnVerifyLabelMsgText(sUpdAltCityUI,city);	
	    String Zip=TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddAltAddress_InputZip_id)).getAttribute("value");
	    fnVerifyLabelMsgText(sUpdAltZipUI,Zip);
	    Thread.sleep(4000);
		
	    obj.repAddData( "Verifying Deal updated  alternate address", "", "", "");
	    
	    ClickByXpath(SphereModules.Customers_Edit_Customer_Associated_Item_Btn_xp,"Associated Items Button",true);
		fnLoadingPageWait();
		Thread.sleep(3000);
		
		List<WebElement> eleSpanList2 =TestDriver.driver.findElements(By.xpath(SphereModules.Customers_AltAddress_AssociatedItems_list_xp));
		for (WebElement ele1 : eleSpanList2)
		{
			if (ele1.getText().trim().contains(DealNumber))
			{
				Thread.sleep(500);
				HighlightElement(ele1);
				ClickByElement(ele1, DealNumber, true);
				Thread.sleep(2000);
				fnLoadingPageWait();
				break;
			}
		}
		
		
		//String sEditTitleXPath = SphereModules.Deals_EditDeal_LabelEditDealTitle_xp.toString().replace("deal_number", sDealTitleUI);
		//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sEditTitleXPath)));
		HighlightElement(TestDriver.driver.findElement(By.xpath(SphereModules.Deals_EditDeal_LabelEditDealTitle_xp)));
		Thread.sleep(2000);
		
		ClickByXpath(SphereModules.Deals_EditDeal_EditAltAddress_Pencil_xp, "Edit Pencil",true);
		Thread.sleep(3000);	
		AddressLine1=TestDriver.driver.findElement(By.id(SphereModules.Deals_AddDeal_InputAddressLine1_id)).getAttribute("value");
		fnVerifyLabelMsgText(sUpdAltAddr1UI,AddressLine1);
		AddressLine2=TestDriver.driver.findElement(By.id(SphereModules.Deals_AddDeal_InputAddressLine2_id)).getAttribute("value");
		fnVerifyLabelMsgText(sUpdAltAddr2UI,AddressLine2);
		AddressLine3=TestDriver.driver.findElement(By.id(SphereModules.Deals_AddDeal_InputAddressLine3_id)).getAttribute("value");
	    fnVerifyLabelMsgText(sUpdAltAddr3UI,AddressLine3);
		Country=TestDriver.driver.findElement(By.xpath(SphereModules.Deals_AddDeal_ComboSelected_Country_xp)).getText().trim();;
		fnVerifyLabelMsgText(sUpdAltCountryUI,Country);
		StateUI=TestDriver.driver.findElement(By.xpath(SphereModules.Deals_AddDeal_ComboSelected_State_xp)).getText().trim();;
	    fnVerifyLabelMsgText(sUpdAltStateUI,StateUI);
	    city=TestDriver.driver.findElement(By.id(SphereModules.Deals_AddDeal_InputCity_xp)).getAttribute("value");
	    fnVerifyLabelMsgText(sUpdAltCityUI,city);	
	    Zip=TestDriver.driver.findElement(By.id(SphereModules.Deals_AddDeal_InputZipId_id)).getAttribute("value");
	    fnVerifyLabelMsgText(sUpdAltZipUI,Zip);
	    Thread.sleep(4000);
	    ClickByXpath(SphereModules.Deals_Add_Address_Close_xp,"Cancel", true);
		Thread.sleep(2000);
		fnCloseOpenedForm();
		
		
	  }
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC401 Failed!", e );
		}
	
		   finally {
			   
			fnCloseOpenedForm();

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC401 Completed");
		}
		
	return obj;
}//End of Script TC401   
//TC030_ORB-67_Customer_ViewScreen
@SuppressWarnings("static-access")
public Reporter TC422(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC422 Started..");

	try {
				
		obj.repAddData( "Verifying credit approved customers on the customer page", "", "", "");
		
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		
		WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
		fnVerifyHeaders(arrHeaderColumns,1,"Customer Number");
		fnVerifyHeaders(arrHeaderColumns,2,"Name");
		fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
		fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
		fnVerifyHeaders(arrHeaderColumns,5,"Parent Company");
		fnVerifyHeaders(arrHeaderColumns,6,"Location");
		
		Thread.sleep(4000);
		ClickByXpath(SphereModules.CustomersMaster_CreditToggle_ON_xp, "Credit ON button",true);
		
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		
		WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp));
		List<WebElement> arrHeaderColumns1 = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
		System.out.println("Rows Size>>>>"+arrHeaderColumns1.size());
		fnVerifyHeaders(arrHeaderColumns1,1,"Customer Number");
		fnVerifyHeaders(arrHeaderColumns1,2,"Name");
		fnVerifyHeaders(arrHeaderColumns1,3,"Customer Type");
		fnVerifyHeaders(arrHeaderColumns1,4,"Production Type");
		fnVerifyHeaders(arrHeaderColumns1,5,"Parent Company");
		fnVerifyHeaders(arrHeaderColumns1,6,"Credit Limit");
		fnVerifyHeaders(arrHeaderColumns1,7,"Exp Date");
		
	//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
	HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewCustomersModule_Table_xp);
	System.out.println("Hello");
	
	String sQuery = objSQLConfig.sCustomers_CreditApproved_Query;
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
	//HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteCreditpageResultSet(rset);
	objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
	
	System.out.println(mTableDataUI.size());
	//Boolean bResultFlag = true;
	int failedsystems=0;
	/*for(int i=1;i<=mTableDataUI.size(); i++)
	{
		String sCustomerNumber = mTableDataUI.get(i).get(1).toString();
		String sCustomerName = mTableDataUI.get(i).get(2).toString();
		String sCustomertype = mTableDataUI.get(i).get(3).toString();
		String sProductiontype = mTableDataUI.get(i).get(4).toString();
		String sParentcompany = mTableDataUI.get(i).get(5).toString();
		String sCreditlimit = mTableDataUI.get(i).get(6).toString();
		String sExpdate = mTableDataUI.get(i).get(7).toString().toUpperCase();
		//System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
		System.out.println(mTableDataUI.get(i));
		System.out.println(mTableDataDB.get(i));
		if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
		{
			bResultFlag = false;
			obj.repAddData( "Compare record for customer name : "+ sCustomerName, "Record on UI and DB should match for customer name : "+ sCustomerName, "Validation failed for customer name : "+ sCustomerName, "Fail");
		}
		//System.out.println(mTableDataUI.get(i).get(2));
		//System.out.println(mTableDataUI.get(i).get(3));
	}
	
	if(bResultFlag == true)
	{
		obj.repAddData( "Compare all "+mTableDataUI.size()+" user records displayed on the screen", "All user records on UI should match with DB records", "UI and DB validation successful for all user records", "Pass");
	}
	else
	{
		obj.repAddData( "Compare all "+mTableDataUI.size()+" user records displayed on the screen", "All user records on UI should match with DB records", "UI and DB validation failed for user records", "Fail");
	}
	*/
	boolean bResultFlag = false;
	for(int i=1;i<=mTableDataUI.size(); i++)
	{
		
		String sCustomerNumber = mTableDataUI.get(i).get(1).toString();
		String sCustomerName = mTableDataUI.get(i).get(2).toString();
		String sCustomertype = mTableDataUI.get(i).get(3).toString();
		String sProductiontype = mTableDataUI.get(i).get(4).toString();
		String sParentcompany = mTableDataUI.get(i).get(5).toString();
		String sCreditlimit = mTableDataUI.get(i).get(6).toString();
		String sExpdate = mTableDataUI.get(i).get(7).toString().toLowerCase();
		
		for(int j=1; j<=mTableDataDB.size();j++)
      {
			String sCustomerNumberDB = mTableDataDB.get(j).get(1).toString().trim();
			System.out.println("DB sCustomerNumberDB\t:"+ sCustomerNumberDB);
			
			String sCustomerNameDB = mTableDataDB.get(j).get(2).toString().trim();
			System.out.println("DB sCustomerNameDB\t:"+ sCustomerNameDB);
			
			String sCustomertypeDB = mTableDataDB.get(j).get(3).toString().trim();
			System.out.println("DB sCustomertypeDB\t:"+ sCustomertypeDB);
			
			String sProductiontypeDB=mTableDataDB.get(j).get(4).toString();
			System.out.println("DB sProductiontypeDB\t:"+ sProductiontypeDB);
			
			//String sParentcompanyDB = mTableDataDB.get(j).get(5).toString().trim();
			//System.out.println("DB sParentcompanyDB\t:"+ sParentcompanyDB);
			
			String sCreditlimitDB = mTableDataDB.get(j).get(6).toString().trim();
			System.out.println("DB sParentcompanyDB\t:"+ sCreditlimitDB);
			
			String sExpdateDB = mTableDataDB.get(j).get(7).toString().trim();
			System.out.println("DB sExpdateDB\t:"+ sExpdateDB);
			
			System.out.println(mTableDataUI.get(i));
			System.out.println(mTableDataDB.get(j));
			
			if((sCustomerNumber.equalsIgnoreCase(sCustomerNumberDB))
					&&(sCustomerName.equalsIgnoreCase(sCustomerNameDB))
					&&(sCustomertype.equalsIgnoreCase(sCustomertypeDB))
					&&(sProductiontype.equalsIgnoreCase(sProductiontypeDB))
					//&&(sParentcompany.equalsIgnoreCase(sParentcompanyDB))
				    &&(sCreditlimit.contains(sCreditlimitDB))
				    &&(sExpdate.equalsIgnoreCase(sExpdateDB)))
				//if((!sSystemDealUI.equals(sDealnumberDB))||(!sSystemnameUI.equals(sSystemnameDB)))
			{
				bResultFlag = true;
			    System.out.println(i+" record matched");
			    obj.repAddData( "Compare record for customer name : "+ sCustomerName, "Record on UI and DB should match for customer name : "+ sCustomerName, "Validation successful for customer name : "+ sCustomerName, "Pass");
			    break;
			}
      
       } //End of i loop
		//break;
		if(bResultFlag == false)
		{
			failedsystems++;
			System.out.println(i+" record not matched");
			System.out.println(sCustomerNumber+ " "+ sExpdate);
			obj.repAddData( "Compare record for customer name : "+ sCustomerName, "Record on UI and DB should match for customer name : "+ sCustomerName, "Validation failed for customer name : "+ sCustomerName, "Fail");
		}
	} //End of j loop
	
		
	if(failedsystems==0)
	{
		
	if(bResultFlag == true)
	{
		obj.repAddData( "Compare all "+mTableDataUI.size()+" customer records displayed on the screen", "All customer records on UI should match with DB records", "UI and DB validation successful for all customer records", "Pass");
	}
	
	}
	else
	{
		obj.repAddData( "Compare all "+mTableDataUI.size()+" customer records displayed on the screen", "All customer records on UI should match with DB records", "UI and DB validation failed for customer records", "Fail");
	}

		}
	catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC422 Failed!", e );
	}
	finally {
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC422 Completed");
	}
	return obj;
} //End of Script TC422				
public Reporter TC1899(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1899 Started..");

	try {
		
		String sCustomer ="";
		obj.repAddData( "Adding a new customer with Creditexpirationdate", "", "", "");
		sCustomer = objBusinessLib.fnAddCustomerwithCreditExpirationdate(sCustomer,"Add");
		System.out.println(sCustomer);
		
		}
	catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1899 Failed!", e );
	}
	finally {
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC1899 Completed");
	}
	return obj;
} //End of Script TC1899
//Integration_Testing_Update Customer_ParentCompany
@SuppressWarnings("static-access")
public Reporter TC1999(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1999 Started..");

	try {
		
		String sCustomer ="";
		obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
		sCustomer = objBusinessLib.fnAddCustomerwithCreditExpirationdate(sCustomer,"Add");
		//sCustomer = "AUTOTESTCUSTOMER_84069";  //Comment after testing
		System.out.println(sCustomer);
		
		String [] arrCustomer = sCustomer.split("_");
		String sRandom = arrCustomer[1].toString(); 
		//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
		String sUpdatedCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim(); //"UCS TV";
		String sUpdatedParentCompanyUI = "NBC";
		
		obj.repAddData( "Updating an existing customer with different Parent Comapny", "", "", "");
		
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		fnLoadingPageWait();
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
																		    
			SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
			fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
			//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
			
			fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sUpdatedParentCompanyUI);
			
			ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
			fnLoadingPageWait();
			
			/*String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
	    	int iRow = 1; //for add 
		    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
					   
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
			String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
			String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
			String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
			String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
			String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
			String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
			String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
			
			String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
			
			String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
			String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
			String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
			String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
			String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
			String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
			String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
			String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
			String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
			
			String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
			String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
			
			System.out.println("sUpdatedParentCompanyUI>>>"+sUpdatedParentCompanyUI);
			System.out.println("sParentCompanyDB>>>"+sParentCompanyDB);
			
			if(sCustomer.equalsIgnoreCase(sCustomerNameDB) &&
					sUpdatedParentCompanyUI.equalsIgnoreCase(sParentCompanyDB) &&
					sCreditPermanentDB.equalsIgnoreCase("0"))
			{	
				//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sUpdatedCustomerTypeUI);
				TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
				TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
				obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
			}
			else
			{
				obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
			}
										
		
		SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
		//objBusinessLib.fnClickSubMenuElement("Dashboard","");
		fnLoadingPageWait();
		Thread.sleep(4000);*/
	
		}
	    catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1999 Failed!", e );
	}
	
	finally 
	{
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC1999 Completed");
	}
	return obj;
} //End of Script TC1999

public Reporter TC1999_Backup(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1999 Started..");

	try {
		
		String sCustomer ="";
		obj.repAddData( "Pre-Condition : Adding a new customer", "", "", "");
		sCustomer = objBusinessLib.fnAddCustomerwithCreditExpirationdate(sCustomer,"Add");
		//sCustomer = "AUTOTESTCUSTOMER_84069";  //Comment after testing
		System.out.println(sCustomer);
		
		String [] arrCustomer = sCustomer.split("_");
		String sRandom = arrCustomer[1].toString(); 
		//String sUpdatedCreditLimitUI = sRandom+"1"+".00";;
		String sUpdatedCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim(); //"UCS TV";
		String sUpdatedParentCompanyUI = "NBC";
		
		obj.repAddData( "Updating an existing customer with different Parent Comapny", "", "", "");
		
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		fnLoadingPageWait();
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		Thread.sleep(4000);
		//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
																		    
			SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomer , "Search Box");
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp)));
			fnVerifyLabelMsgTextByXpath(sCustomer, SphereModules.CustomersMaster_EditCustomer_LabelEditCustomerTitle_xp);
			//fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sUpdatedCustomerTypeUI);
			
			fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sUpdatedParentCompanyUI);
			
			ClickByXpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp, "Save", true);
			fnLoadingPageWait();
			
			String sQuery = objSQLConfig.sMasterCustomers_AddCustomer_Query;  //Same queries will be used for update
	    	int iRow = 1; //for add 
		    sQuery = sQuery.replaceAll("customer_name_param",sCustomer);
					   
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			String sCustomerNameDB = mTableDataDB.get(iRow).get(1).toString().trim();
			String sCustomerTypeDB = mTableDataDB.get(iRow).get(2).toString().trim();
			String sTaxIDDB = mTableDataDB.get(iRow).get(3).toString().trim();
			String sProductionTypeDB = mTableDataDB.get(iRow).get(4).toString().trim();
			String sStartDateDB = mTableDataDB.get(iRow).get(5).toString().trim();
			String sCreditLimitDB = mTableDataDB.get(iRow).get(6).toString().trim();
			String sCreditPermanentDB = mTableDataDB.get(iRow).get(7).toString().trim();
			String sCreditExpirationDB = mTableDataDB.get(iRow).get(8).toString().trim();
			
			String sParentCompanyDB = mTableDataDB.get(iRow).get(9).toString().trim();
			
			String sAddr1DB = mTableDataDB.get(iRow).get(10).toString().trim();
			String sAddr2DB = mTableDataDB.get(iRow).get(11).toString().trim();
			String sAddr3DB = mTableDataDB.get(iRow).get(12).toString().trim();
			String sCountryDB = mTableDataDB.get(iRow).get(13).toString().trim();
			String sStateDB = mTableDataDB.get(iRow).get(14).toString().trim();
			String sCityDB = mTableDataDB.get(iRow).get(15).toString().trim();
			String sZipDB = mTableDataDB.get(iRow).get(16).toString().trim();
			String sMultEmailDB = mTableDataDB.get(iRow).get(17).toString().trim();
			String sOrbitCustNumberDB = mTableDataDB.get(iRow).get(18).toString().trim();
			
			String sCustomerStatusDB = mTableDataDB.get(iRow).get(24).toString().trim();//isactive field in DB
			String sCustomerPhoneNumberDB = mTableDataDB.get(iRow).get(25).toString().trim();
			
			System.out.println("sUpdatedParentCompanyUI>>>"+sUpdatedParentCompanyUI);
			System.out.println("sParentCompanyDB>>>"+sParentCompanyDB);
			
			if(sCustomer.equalsIgnoreCase(sCustomerNameDB) &&
					sUpdatedParentCompanyUI.equalsIgnoreCase(sParentCompanyDB) &&
					sCreditPermanentDB.equalsIgnoreCase("0"))
			{	
				//TestDriver.bw.append("\n"+sTest_Case_ID+","+sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sUpdatedCustomerTypeUI);
				TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomer+","+sOrbitCustNumberDB+",Update,Customer,"+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sCountryDB+","+sZipDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
				TestDriver.bw2.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sOrbitCustNumberDB+","+sCustomerNameDB+",,"+sCustomerStatusDB+","+sCustomerTypeDB+","+sAddr1DB+","+sAddr2DB+","+sCityDB+","+sStateDB+","+sZipDB+","+sCountryDB+","+sCustomerPhoneNumberDB+","+sCreditPermanentDB+","+sCreditExpirationDB+","+sCreditLimitDB);
				obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation successful for customer name : "+ sCustomer, "Pass");
			}
			else
			{
				obj.repAddData( "Compare customer record for customer name : "+ sCustomer, "Customer record on UI and DB should match for customer name : "+ sCustomer, "Validation failed for customer name : "+ sCustomer, "Fail");
			}
										
		
		SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
		//objBusinessLib.fnClickSubMenuElement("Dashboard","");
		fnLoadingPageWait();
		Thread.sleep(4000);
	
		}
	    catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1999 Failed!", e );
	}
	
	finally 
	{
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC1999 Completed");
	}
	return obj;
} //End of Script TC1999
public Reporter TC907(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC907 Started..");

	try {
				
		
		obj.repAddData( "Verifying user has no access to deactivate parent company", "", "", "");
	   
		objBusinessLib.fnClickSubMenuElement("Customers Master","Parent Companies");
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp)));
		Thread.sleep(4000);
		WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewNationalAccountModule_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
		fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
		fnVerifyHeaders(arrHeaderColumns,2,"Name");
		fnVerifyHeaders(arrHeaderColumns,3,"Customer Type");
		fnVerifyHeaders(arrHeaderColumns,4,"Production Type");
		fnVerifyHeaders(arrHeaderColumns,5,"Location");
		HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp);
		System.out.println("Hello");
		System.out.println(mTableDataUI.size());
		ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row", true);
		fnLoadingPageWait();
		Thread.sleep(4000);
		fnCheckFieldDoesNotExistByXpath(SphereModules.Customers_EditNationalAccount_BtnDeactivate_xp,"Deactivate",true);
		
	
	}
	catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC907 Failed!", e );
	}
	finally {
		
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC907 Completed");
	}
	return obj;
} //End of Script TC901

@SuppressWarnings("static-access")
public Reporter TC600012(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC600012 Started..");

	try {
		
		String sCustomerTitleUI ="";
		String sCustomerNumberUI ="";
		String sCostObjectUI ="";
		String sAccountNumberUI="";
		String sUpdateFlag="";
		
		String sCustomerTypeUI = "";
		String sReason = "";
		System.out.println(sCustomerTitleUI);
		
		obj.repAddData( "Pre-Condition : Search for an existing customer", "", "", "");
		
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		fnLoadingPageWait();
		
		WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
		fnLoadingPageWait();
		
		waitForTableLoad = new WebDriverWait(driver, 60);
		mCustomerSAPData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"CustomerSAPData", "");
		
		for(int i=1;i<=mCustomerSAPData.size();i++)
		{
			System.out.println("Customer SAP update in progress : "+i);

			sCustomerNumberUI = TestDriver.mCustomerSAPData.get(i).get("Orbit_Customer_Number").trim();
			sCostObjectUI = TestDriver.mCustomerSAPData.get(i).get("SAP_Cost_Object").trim();
			sAccountNumberUI = TestDriver.mCustomerSAPData.get(i).get("SAP_Account_Number").trim();
			sReason = "";
			
			obj.repAddData( "updating customer SAP informatio : "+ sCustomerNumberUI, "", "", "");
			
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewCustomersModule_Table_xp)));
			Thread.sleep(2000);

			SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, sCustomerNumberUI , "Search Box");

			fnLoadingPageWait();
			Thread.sleep(3000);

			String sCustomerNumberDB = "";
			String sCustomerTitleDB = "";
			String sFormattedDeal = "";
			String sMsg="";
			String sAlertMsg="";
			//sFormattedDeal = "\""+sDealTitleUI+"\"";
			boolean alert=false;
			
			try {
				try
				{
					waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_ClickFirstRow_xp)));
				} 
				catch (Exception e) 
				{
					sReason = "Customer not found";
					TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",Not Saved"+sReason);
					obj.repAddData( "Verify Customer record row on UI", "Customer row should be displayed on UI", "Customer not found in the system", "Fail");
				}

				ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Customer Row", true);
				fnLoadingPageWait();

				/*WebElement ele1;
				ele1 = driver.findElement(By.id(SphereModules.Customers_CostObject_id));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele1);*/
				
				if(ElementFoundById(SphereModules.Customers_CostObject_id))
				{
				SendKeyById(SphereModules.Customers_CostObject_id, sCostObjectUI , "Cost Object");
				Thread.sleep(3000);
				SendKeyById(SphereModules.Customers_AccountNumber_id, sAccountNumberUI , "Account Number");
				Thread.sleep(3000);
				
				WebElement ele;
				ele = driver.findElement(By.xpath(SphereModules.CustomersMaster_EditCustomer_BtnSave_xp));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
				
				if(ele.isDisplayed() && ele.isEnabled())
				{
					//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
					HighlightElement(ele);
					ele.click();
					Thread.sleep(3000);
					ele.click();
					Thread.sleep(3000);
					fnLoadingPageWait();
					
				}

				if(ElementFound(SphereModules.Deals_Form_AletMessage_xp))
				{
					alert=true;
					sAlertMsg = TestDriver.driver.findElement(By.xpath(SphereModules.Deals_Form_AletMessage_xp)).getText();
					HighlightElementByXpath(SphereModules.Deals_Form_AletMessage_xp);
					System.out.println(sAlertMsg);
					sReason=sAlertMsg+" displayed on the form";
					TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",Not Saved,"+sReason);									
				}

				if(ElementFound(SphereModules.Common_AddEditModules_MsgSuccess_xp))
				{

					sMsg = TestDriver.driver.findElement(By.xpath(SphereModules.Common_AddEditModules_MsgSuccess_xp)).getText();
					HighlightElementByXpath(SphereModules.Common_AddEditModules_MsgSuccess_xp);
					System.out.println(sMsg);

					if (sMsg.contains("Success!")||sMsg.contains("failed"))
					{
						sReason = sMsg;
						if(sReason.contains("failed to update in Orbit"))
						{
							sReason = "Failed to update in Orbit";
						}else
						{
							sReason = sMsg;
						}
						//TestDriver.bw.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sFormattedDeal+",\'"+sDealNumberDB+",Update,Deal,,,,,"+sReason);
						//ClickByXpath(SphereModules.Common_AddEditModules_MsgSuccess_xp,"Success Message", true);
						//ele1.click();
						fnVerifyClickSuccessMessage();
						TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",Saved,"+sReason);
						obj.repAddData( "Verify Customer is updated : "+ sCustomerNumberUI, "Customer should be updated for : "+sCustomerNumberUI, "Update is successful for Customer Number : "+sCustomerNumberUI, "Pass");

					}

				}
				else 
				{
					if(alert==false)
					{

						sReason = "Success message not displayed on clicking save";
						TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",not Updated,"+sReason);
						obj.repAddData( "Verify Customer is updated : "+ sCustomerNumberUI, "Customer should be updated for : "+sCustomerNumberUI, "Update is not successful for Customer Number : "+sCustomerNumberUI, "Fail");
					}

				}

				fnLoadingPageWait();
				boolean bOpenFormAvailable = fnCloseOpenedFormStage();

				if(bOpenFormAvailable==true)
				{
					sReason = "Oops! customer Form not closed on clicking save displayed";
					//ClickByXpath(SphereModules.Common_AddEditModules_MsgSuccess_xp,"Success Message", true);
					TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",Not Updated,"+sReason);

				}
				}else
				{
					sReason = "SAP Objects not displayed on the form";
					obj.repAddData( "Verify Customer is updated : "+ sCustomerNumberUI, "Customer should be saved for : "+sCustomerNumberUI, "SAP fields not displayed for Customer Number : "+sCustomerNumberUI, "Fail");
					TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",Not Updated,"+sReason);
				}	
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					obj.repAddData( "","Exception occured while updating customer number" +sCustomerNumberUI ,"", "Fail");
					sReason = "Exception occured";
					TestDriver.bw3.append("\n"+TestDriver.sTest_Case_ID+","+TestDriver.sTest_Case_Name+","+sCustomerNumberUI+",Failed to Update,"+sReason);
				}
		
			}
			
			fnCloseOpenedForm();
		
			SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp, "" , "Search Box"); //post-condition
			fnLoadingPageWait();
			Thread.sleep(4000);
		
		}
	    catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC600012 Failed!", e );
	}
	
	finally
	{
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC600012 Completed");
	}
	return obj;
} //End of Script TC600012	

@SuppressWarnings("static-access")
public Reporter TC385(Reporter obj) throws Exception
{
	log.info("Execution of Script TC21199 Started..");
try {
	
	objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
	WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
    ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customers", true);
	fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
	String sProductionType="Feature";
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.CustomersMaster_AddCustomer_ProductionType_id,sProductionType);
	String sCollectorUI = driver.findElement(By.xpath(SphereModules.CustomersMaster_AddCustomer_Collector_id)).getText().trim();
	String collectorType="Portfolio 2";
	if(sCollectorUI.equalsIgnoreCase(collectorType))
	{
		obj.repAddData( "Verify default Value in the collector field ", 
				"Default value in the collector field should be "+collectorType+" ",
				"Default value in the collector field is "+sCollectorUI+"", "Pass");
	}
	
	else
	{
		obj.repAddData( "Verify default Value in the collector field ", 
				"Default value in the collector field should be "+collectorType+" ",
				"Default value in the collector field is "+sCollectorUI+"", "Fail");
	}
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "Exit", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
}

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	e.printStackTrace();
	testCaseStatus = false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC21199 Failed!", e );
}			

finally {
	
if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC21199 Completed");
}
return obj;
}


public Reporter TC1040(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1040 Started..");

	try {
		
		String sCustomerUI ="";
		
		obj.repAddData( "Validate that user is not able to  deactivate customers associated with deals ", "", "", "");
		
		obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
		sCustomerUI = objBusinessLib.fnAddCustomerName(sCustomerUI, "Add");
		System.out.println(sCustomerUI);
		String sDealTitle ="";

        String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
        System.out.println(sDealTitleRandom);

        String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
		String sProjectName="SCRIPTED WORLD";
		String sRandom = String.valueOf(fnRandomNum(10001, 14999));
		//sDealTitleUI = "AutoTestDeal_"+sRandom;
		String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
	    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
	    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
	    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
	    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
		
		
		objBusinessLib.fnClickMainMenuElement("Deals");
		WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
		Thread.sleep(10000); 
		ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
		fnLoadingPageWait();
		fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
		objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
		SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
		ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
		SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
		fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
		SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
		SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
		//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
		//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
		ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
		ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
		///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
	    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
		ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
		
		//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
		fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
		fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
		
		ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
		SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
		ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
		fnLoadingPageWait();





		String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
		sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
		TestDriver.conn = objDBUtility.fnOpenDBConnection();
		TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
		HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
	    
	    String sDescriptionUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Description").trim();
	    String sUM=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UM").trim();
	    String sRateUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Rate").trim();
	    String sTranType=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("TranType").trim();
	    String sQty=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Qty").trim();
	   
	    Date date = new Date();
		String sTransactionDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
		String sCurrentDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
		
		String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
		
		Date dexpiredday = DateUtils.addDays(new Date(), +5);
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
		String sEndDateUI2 = sdf.format(dexpiredday); 
	    
	    
	    
	    String UIorderNumber="999";
		//String sRandom = String.valueOf(fnRandomNum(1001, 9999));
		String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
		String sPoNumberUI = "AutoPONumber_"+sRandom;
		String sTotalEstimateAmountUI=sRandom+".00";
		String sEpisodeNumber="AutoEpNumber_"+sRandom;
		String sRequestorName="AutoRequestorName_"+sRandom;
		String sApproverName="AutoApproverName_"+sRandom;

		//String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
		String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
	   
		obj.repAddData( "Verifying unique order number creation", "", "", "");
		//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		
		objBusinessLib.fnClickMainMenuElement("Dashboard");
		waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
		WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
		HighlightElement(Titleele);
	    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
		
		
		SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
		fnLoadingPageWait();
		Thread.sleep(4000);
		List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
		System.out.println(options.size());
	    for(int i=0;i<=options.size();i++){
	    String optionName = options.get(i).getText();
	    System.out.println(optionName);
	    String DealNumUI = optionName.substring(0, 6);
	    System.out.println(DealNumUI);
	    if(DealNumUI.equals(sExpDealNumberDB))
	    {

	   options.get(i).click();
	    break;
	    }
	    }
		
		//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
		fnLoadingPageWait();
		Thread.sleep(4000);
		ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
		fnLoadingPageWait();
		fnLoadingPageWait();
		fnLoadingPageWait();
		Thread.sleep(9000);
		/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
		WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
		HighlightElement(Titleele1);*/
		

	    
		WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

		ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
		fnLoadingPageWait();
		fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
		 
		SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
		SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
		SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
		SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
		SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
		SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
		//SendKeyById(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod, sEpisodeNumber, "Episode Number");
		ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
		fnLoadingPageWait();
		
		RightClickByXpath(objSphereModules.Common_ViewModules_ClickFirstRow_xp,"First Row");
		
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_InterceptMenu_ViewTransactions_Link_xp, "View Transactions", true);
		Thread.sleep(3000);
		
		  ClickByXpath(SphereModules.Transactions_AddTransaction_LinkAddTransaction_Sign_xp, "Add Transaction Link", true);
			fnLoadingPageWait();
			
			fnVerifyLabelMsgTextByXpath(AppMessages.AddTransaction_LabelTitle_Msg, SphereModules.Transactions_AddTransaction_LabelAddTransaction_Title_xp);
		    			
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_SearchOrder_xp, "999", "Search order");
			Thread.sleep(2000);
			fnLoadingPageWait();
			ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
			//ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
			SendKeyById(SphereModules.Transaction_AddTransaction_PoNumber_id, ponumberDB, "PO Number");
			
			SendKeyById(SphereModules.Transaction_AddTransaction_TransactionDate_id, sTransactionDateUI, "Transaction Date");
			SendKeyById(SphereModules.Transaction_AddTransaction_RentalStartDate_id, sStartDateUI1, "Rental Start Date");
			SendKeyById(SphereModules.Transaction_AddTransaction_RentalEndDate_id, sEndDateUI2, "Rental End Date");
			
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_Description_xp, sDescriptionUI, "Description");
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_Qty_xp, sQty, "Quantity");
			fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_UnitofMeasure_id,sUM);
			fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_TransactionType_id,sTranType);
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_Rate_xp, sRateUI, "Rate");
			
			
			ClickByXpath(SphereModules.Transaction_AddTransaction_Save_Btn_xp, "Save", true);
			Thread.sleep(30000);
			
			waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);

			
			
			
			objBusinessLib.fnClickSubMenuElement("Billing","ARC");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.ARC_Title_xp)));
			WebElement ArcTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Title_xp));
		    HighlightElement(ArcTitle);
		    
		    ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "Clear All Button", true);
			Thread.sleep(4000);
			
			SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,"","Deal Number");
			SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			if(ElementFound(SphereModules.ARC_Screen_Deal_list_1))
			{
				ClickByXpath(SphereModules.ARC_Screen_Deal_list_1, "Deal", true);
				fnLoadingPageWait();
				Thread.sleep(4000);
				if(ElementFound(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp))
				{

					SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,UIorderNumber,"Order Number");
					fnLoadingPageWait();
					Thread.sleep(6000);
					if(ElementFound(SphereModules.ARC_Screen_Order_list_1))
					{

						ClickByXpath(SphereModules.ARC_Screen_Order_list_1, "Order", true);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						//ClickByXpath(sFilterBtn, "Filter btn", true);
						Thread.sleep(4000);
						WebElement ArcTable = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));

						if(TestDriver.driver.findElements(By.xpath(SphereModules.Order_Table_Col4_xp)).size()>0==true)
						{
							obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
									"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation successful for  : \t Order Number: "+UIorderNumber, "Pass");  
							System.out.println("Transactions exist");	

						}
						else
						{
							obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
									"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation failed for  : \t Order Number: "+UIorderNumber, "Fail");

						}

					}

				}

			}
			
			
			WebElement ArcTable = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));
			List<WebElement> arrTableRows = ArcTable.findElements(By.xpath("./tr"));  //Get the table data rows
			System.out.println("Data Rows Size>>>>"+arrTableRows.size());
			
			//objBusinessLib.fnSelectDynamicFilters("Billable Category","Billable Revenue",2);
					
			RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
		    Thread.sleep(3000);
		    ClickByXpath(SphereModules.ARC_Screen_InterceptMenu_Send_Btn_xp, "Send btn", true);
		    fnLoadingPageWait();
		    Thread.sleep(4000); 
	 		ClickByXpath(SphereModules.ARC_Screen__Send_Popup_Title_xp, "Send Poupup Title", true);
	 		Thread.sleep(4000);
	 		ClickByXpath(SphereModules.ARC_Screen__Send_Btn_xp, "Send button", true);
	 		Thread.sleep(4000);
			
	 		objBusinessLib.fnClickSubMenuElement("Billing","Draft Billing");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Billing_DraftBilling_Title_xp)));
			WebElement DraftBillingTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.Billing_DraftBilling_Title_xp));
	        HighlightElement(DraftBillingTitle);
	        

	        ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "Clear All Button", true);
			Thread.sleep(4000);
	        
	        SendKeyByXpath(SphereModules.Billing_DraftBilling_DealSearchBar_xp,"","Deal Number");
			//SendKeyByXpath(SphereModules.Billing_DraftBilling_DealSearchBar_xp,sDealNumberUI,"Deal Number");
	        
	        SendKeyByXpath(SphereModules.Billing_DraftBilling_DealSearchBar_xp,sExpDealNumberDB,"Deal Number");

			fnLoadingPageWait();
			Thread.sleep(4000);
			if(ElementFound(SphereModules.Billing_DraftBilling_Deal_list_1))
				{
					ClickByXpath(SphereModules.Billing_DraftBilling_Deal_list_1, "Deal", true);
					fnLoadingPageWait();
					Thread.sleep(4000);
					
					if(ElementFound(SphereModules.Billing_DraftBilling_DraftBill_List_xp))
						
					{
						String sDraftBillNumber =driver.findElement(By.xpath(SphereModules.Billing_DraftBilling_DraftBill_Number_xp)).getText().trim();                  
						System.out.println(sDraftBillNumber);
						Thread.sleep(3000);
						String sExpTitle="Direct Charge Summary";
						RightClickByXpath(SphereModules.Billing_DraftBilling_DraftBill_List_xp, "Draft Bill");
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Billing_DraftBilling_Intercept_View_Edit_DraftBill_xp, "View Edit", true);
						Thread.sleep(3000);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Billing_DraftBilling_Edit_Title_xp)));
						//fnVerifyLabelMsgTextByXpath(sExpTitle, SphereModules.Billing_DraftBilling_Edit_Title_xp);
						WebElement DirectChargePageTitle=TestDriver.driver.findElement(By.xpath(SphereModules.Billing_DraftBilling_Edit_Title_xp));
						HighlightElement(DirectChargePageTitle);
						//SendKeyById(SphereModules.Billing_DraftBilling_percent_id, "" , "Search Box");
						//TestDriver.driver.findElement(By.id(SphereModules.Billing_DraftBilling_percent_id)).click();
						
						//TestDriver.driver.findElement(By.id(SphereModules.Billing_DraftBilling_percent_id)).sendKeys(Keys.HOME);
						//TestDriver.driver.findElement(By.id(SphereModules.Billing_DraftBilling_percent_id)).sendKeys("10");
		 				Thread.sleep(3000);
		 				
		 				ClickByXpath(SphereModules.Billing_DraftBilling_Edit_Create_xp, "immeadiate", true);
						Thread.sleep(3000);
						ClickByXpath(SphereModules.InvoiceStatementInquiry_Immediate, "immeadiate", true);
						//ClickByXpath(SphereModules.Billing_DCS_DraftBilling_immediate_xp, "immeadiate", true);
						Thread.sleep(3000);
						
						WebElement PopupTitle1 = TestDriver.driver.findElement(By.xpath(objSphereModules.Billing_DraftBilling_createImmediate_PopUp_Title_xp));
						HighlightElement(PopupTitle1);
						Thread.sleep(3000);
						
						ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
						Thread.sleep(3000);
						
						
						
						if(ElementFound(SphereModules.Billing_DraftBilling_DraftBill_List_xp)==false)
						{
							obj.repAddData( "Verify  Draft Bill disappeared after creating immediate: ",
									"Draft Bill list should not be dispalyed", "Draft Bill list is not displayed", "Pass");
						}
						else
						{
							obj.repAddData( "Verify  Draft Bill disappeared after creating immediate: ", "Draft Bill list should not be dispalyed", "Draft Bill list is still displayed", "Fail");
						}
	                      
						Thread.sleep(5000);
						
					}
				}
						objBusinessLib.fnClickMainMenuElement("Invoice/Statement");
						Thread.sleep(5000);
						/*ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "click", true);
						Thread.sleep(3000);*/
						
						ClickByXpath(SphereModules.InvoiceStatementInquiry_DealNumberFilter, "click", true);
						Thread.sleep(3000);

						SendKeyByXpath(SphereModules.InvoiceStatementInquiry_SearchDealNumberFilter,sExpDealNumberDB,"Deal Number");
						fnLoadingPageWait();
						Thread.sleep(6000);
						ClickByXpath(SphereModules.InvoiceStatementInquiry_ClickSearchDealNumberFilter2, "click", true);
						Thread.sleep(3000);
						
						
						if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
						{
							obj.repAddData( "Verify Status of the Transaction ",
									"Status of the Transaction should be dispalyed as Final Billed", "Status of the Transaction is dispalyed as Final Billed", "Pass");
						}
						else
						{
							obj.repAddData( "Verify Status of the Transaction ",
									"Status of the Transaction should be dispalyed as Final Billed", "Status of the Transaction is not dispalyed as Final Billed", "Fail");
						}
	                      
			
	}
	catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1040 Failed!", e );
	}			

	finally {
		/*ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);*/
	if(!testCaseStatus)
	{
		Reporter.iTotalFail++;	
	}
	else
	{
		Reporter.iTotalPass++;
	}
	log.info("Execution of Script TC1040 Completed");
	}
	return obj;
	}


public Reporter TC1041(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1041 Started..");

	try {
		
		String sCustomerUI ="";
		
		/*obj.repAddData( "Validate that user is not able to  deactivate customers associated with deals ", "", "", "");
		
		obj.repAddData( "Adding a new customer (Pre-requisite)", "", "", "");
		sCustomerUI = objBusinessLib.fnAddCustomerName(sCustomerUI, "Add");
		System.out.println(sCustomerUI);*/
		String sDealTitle ="";

        String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
        System.out.println(sDealTitleRandom);

        String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
		String sProjectName="SCRIPTED WORLD";
		String sRandom = String.valueOf(fnRandomNum(10001, 14999));
		//sDealTitleUI = "AutoTestDeal_"+sRandom;
		String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
	    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
	    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
	    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
	    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
		
		
		objBusinessLib.fnClickMainMenuElement("Deals");
		WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
		Thread.sleep(10000); 
		ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
		fnLoadingPageWait();
		fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
		objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
		ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
		fnLoadingPageWait();
		
		//String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 99999));

        String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
		System.out.println(sCustomerTitleRandom);
		

		String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
		
		String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
		/*if(!sOperation.equalsIgnoreCase("Duplicate"))
		{
		
			sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
		}
		*/
		String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
		String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
		
		//Date date = new Date();
		//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
		
		Date dTomorrow = DateUtils.addDays(new Date(), +1);
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String sStartDateUI1 = sdf.format(dTomorrow);
		
		sdf.applyPattern("yyyy-MM-dd");
		String sStartDateUIDBpattern=sdf.format(dTomorrow);
	/*	Date dYesterday = DateUtils.addDays(new Date(), -1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String sStartDateUI2 = sdf.format(dYesterday);*/
		
		String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
		String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
		String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
		//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
		String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
		String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
		String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
		String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();
	
		/*objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		objGenericFunctionLibrary.fnLoadingPageWait();
		//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
		Thread.sleep(4000);
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
		objGenericFunctionLibrary.fnLoadingPageWait();*/
		objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
		objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
		objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
		//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
		objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
		//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
		//objGenericFunctionLibrary.ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
		//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
		objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
		objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
		
		/////////////////Adding Customer Address Start//////////////////
		
		objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
		objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
		//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
	    
		objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
		objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
		objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
		objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
		
		String sCreditLimitUI=sRandom+".00";
		objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
		objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
		
			objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
			objGenericFunctionLibrary.fnLoadingPageWait();
			
		
		/*SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);*/
		ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
		SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
		fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
		SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
		SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
		//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
		//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
		ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
		ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
		///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
	    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
		ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
		
		//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
		fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
		fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
		
		ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
		SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
		ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
		fnLoadingPageWait();





		String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
		sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
		TestDriver.conn = objDBUtility.fnOpenDBConnection();
		TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
		HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
	    
	    String sDescriptionUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Description").trim();
	    String sUM=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UM").trim();
	    String sRateUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Rate").trim();
	    String sTranType=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("TranType").trim();
	    String sQty=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Qty").trim();
	   
	    Date date = new Date();
		String sTransactionDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
		String sCurrentDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
		
		//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
		
		Date dexpiredday = DateUtils.addDays(new Date(), +5);
		//SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
		String sEndDateUI2 = sdf.format(dexpiredday); 
	    
	    
	    
	    String UIorderNumber="999";
		//String sRandom = String.valueOf(fnRandomNum(1001, 9999));
		String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
		String sPoNumberUI = "AutoPONumber_"+sRandom;
		String sTotalEstimateAmountUI=sRandom+".00";
		String sEpisodeNumber="AutoEpNumber_"+sRandom;
		String sRequestorName="AutoRequestorName_"+sRandom;
		String sApproverName="AutoApproverName_"+sRandom;

		//String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
		String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
	   
		obj.repAddData( "Verifying unique order number creation", "", "", "");
		//WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		
		objBusinessLib.fnClickMainMenuElement("Dashboard");
		waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
		WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
		HighlightElement(Titleele);
	    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
		
		
		SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
		fnLoadingPageWait();
		Thread.sleep(4000);
		List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
		System.out.println(options.size());
	    for(int i=0;i<=options.size();i++){
	    String optionName = options.get(i).getText();
	    System.out.println(optionName);
	    String DealNumUI = optionName.substring(0, 6);
	    System.out.println(DealNumUI);
	    if(DealNumUI.equals(sExpDealNumberDB))
	    {

	   options.get(i).click();
	    break;
	    }
	    }
		
		//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
		fnLoadingPageWait();
		Thread.sleep(4000);
		ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
		fnLoadingPageWait();
		fnLoadingPageWait();
		fnLoadingPageWait();
		Thread.sleep(9000);
		/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
		WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
		HighlightElement(Titleele1);*/
		

	    
		WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

		ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
		fnLoadingPageWait();
		fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
		 
		SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
		SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
		SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
		SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
		SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
		SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
		//SendKeyById(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod, sEpisodeNumber, "Episode Number");
		ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
		fnLoadingPageWait();
		
		RightClickByXpath(objSphereModules.Common_ViewModules_ClickFirstRow_xp,"First Row");
		
		Thread.sleep(3000);
		ClickByXpath(SphereModules.Common_InterceptMenu_ViewTransactions_Link_xp, "View Transactions", true);
		Thread.sleep(3000);
		
		  ClickByXpath(SphereModules.Transactions_AddTransaction_LinkAddTransaction_Sign_xp, "Add Transaction Link", true);
			fnLoadingPageWait();
			
			fnVerifyLabelMsgTextByXpath(AppMessages.AddTransaction_LabelTitle_Msg, SphereModules.Transactions_AddTransaction_LabelAddTransaction_Title_xp);
		    			
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_SearchOrder_xp, "999", "Search order");
			Thread.sleep(2000);
			fnLoadingPageWait();
			ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
			//ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
			SendKeyById(SphereModules.Transaction_AddTransaction_PoNumber_id, ponumberDB, "PO Number");
			
			SendKeyById(SphereModules.Transaction_AddTransaction_TransactionDate_id, sTransactionDateUI, "Transaction Date");
			/*SendKeyById(SphereModules.Transaction_AddTransaction_RentalStartDate_id, sStartDateUI1, "Rental Start Date");
			SendKeyById(SphereModules.Transaction_AddTransaction_RentalEndDate_id, sEndDateUI2, "Rental End Date");*/
			
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_Description_xp, sDescriptionUI, "Description");
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_Qty_xp, sQty, "Quantity");
			fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_UnitofMeasure_id,sUM);
			fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_TransactionType_id,sTranType);
			SendKeyByXpath(SphereModules.Transaction_AddTransaction_Rate_xp, sRateUI, "Rate");
			
			
			ClickByXpath(SphereModules.Transaction_AddTransaction_Save_Btn_xp, "Save", true);
			Thread.sleep(30000);
			
			waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);

			
			
			
			objBusinessLib.fnClickSubMenuElement("Billing","ARC");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.ARC_Title_xp)));
			WebElement ArcTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Title_xp));
		    HighlightElement(ArcTitle);
		    
		    ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "Clear All Button", true);
			Thread.sleep(4000);
			
			SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,"","Deal Number");
			SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			if(ElementFound(SphereModules.ARC_Screen_Deal_list_1))
			{
				ClickByXpath(SphereModules.ARC_Screen_Deal_list_1, "Deal", true);
				fnLoadingPageWait();
				Thread.sleep(4000);
				if(ElementFound(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp))
				{

					SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,UIorderNumber,"Order Number");
					fnLoadingPageWait();
					Thread.sleep(6000);
					if(ElementFound(SphereModules.ARC_Screen_Order_list_1))
					{

						ClickByXpath(SphereModules.ARC_Screen_Order_list_1, "Order", true);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						//ClickByXpath(sFilterBtn, "Filter btn", true);
						Thread.sleep(4000);
						WebElement ArcTable = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));

						if(TestDriver.driver.findElements(By.xpath(SphereModules.Order_Table_Col4_xp)).size()>0==true)
						{
							obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
									"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation successful for  : \t Order Number: "+UIorderNumber, "Pass");  
							System.out.println("Transactions exist");	

						}
						else
						{
							obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
									"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation failed for  : \t Order Number: "+UIorderNumber, "Fail");

						}

					}

				}

			}
			
			
			WebElement ArcTable = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));
			List<WebElement> arrTableRows = ArcTable.findElements(By.xpath("./tr"));  //Get the table data rows
			System.out.println("Data Rows Size>>>>"+arrTableRows.size());
			
			//objBusinessLib.fnSelectDynamicFilters("Billable Category","Billable Revenue",2);
					
			RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
		    Thread.sleep(3000);
		    ClickByXpath(SphereModules.ARC_Screen_InterceptMenu_Send_Btn_xp, "Send btn", true);
		    fnLoadingPageWait();
		    Thread.sleep(4000); 
	 		ClickByXpath(SphereModules.ARC_Screen__Send_Popup_Title_xp, "Send Poupup Title", true);
	 		Thread.sleep(4000);
	 		ClickByXpath(SphereModules.ARC_Screen__Send_Btn_xp, "Send button", true);
	 		Thread.sleep(4000);
			
	 		objBusinessLib.fnClickSubMenuElement("Billing","Draft Billing");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Billing_DraftBilling_Title_xp)));
			WebElement DraftBillingTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.Billing_DraftBilling_Title_xp));
	        HighlightElement(DraftBillingTitle);
	        

	        ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "Clear All Button", true);
			Thread.sleep(4000);
	        
	        SendKeyByXpath(SphereModules.Billing_DraftBilling_DealSearchBar_xp,"","Deal Number");
			//SendKeyByXpath(SphereModules.Billing_DraftBilling_DealSearchBar_xp,sDealNumberUI,"Deal Number");
	        
	        SendKeyByXpath(SphereModules.Billing_DraftBilling_DealSearchBar_xp,sExpDealNumberDB,"Deal Number");

			fnLoadingPageWait();
			Thread.sleep(4000);
			if(ElementFound(SphereModules.Billing_DraftBilling_Deal_list_1))
				{
					ClickByXpath(SphereModules.Billing_DraftBilling_Deal_list_1, "Deal", true);
					fnLoadingPageWait();
					Thread.sleep(4000);
					
					if(ElementFound(SphereModules.Billing_DraftBilling_DraftBill_List_xp))
						
					{
						String sDraftBillNumber =driver.findElement(By.xpath(SphereModules.Billing_DraftBilling_DraftBill_Number_xp)).getText().trim();                  
						System.out.println(sDraftBillNumber);
						Thread.sleep(3000);
						String sExpTitle="Direct Charge Summary";
						RightClickByXpath(SphereModules.Billing_DraftBilling_DraftBill_List_xp, "Draft Bill");
						Thread.sleep(4000);
						ClickByXpath(SphereModules.Billing_DraftBilling_Intercept_View_Edit_DraftBill_xp, "View Edit", true);
						Thread.sleep(3000);
						waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Billing_DraftBilling_Edit_Title_xp)));
						//fnVerifyLabelMsgTextByXpath(sExpTitle, SphereModules.Billing_DraftBilling_Edit_Title_xp);
						WebElement DirectChargePageTitle=TestDriver.driver.findElement(By.xpath(SphereModules.Billing_DraftBilling_Edit_Title_xp));
						HighlightElement(DirectChargePageTitle);
						//SendKeyById(SphereModules.Billing_DraftBilling_percent_id, "" , "Search Box");
						//TestDriver.driver.findElement(By.id(SphereModules.Billing_DraftBilling_percent_id)).click();
						
						//TestDriver.driver.findElement(By.id(SphereModules.Billing_DraftBilling_percent_id)).sendKeys(Keys.HOME);
						//TestDriver.driver.findElement(By.id(SphereModules.Billing_DraftBilling_percent_id)).sendKeys("10");
		 				Thread.sleep(3000);
		 				
		 				ClickByXpath(SphereModules.Billing_DraftBilling_Edit_Create_xp, "immeadiate", true);
						Thread.sleep(3000);
						ClickByXpath(SphereModules.InvoiceStatementInquiry_Immediate, "immeadiate", true);
						//ClickByXpath(SphereModules.Billing_DCS_DraftBilling_immediate_xp, "immeadiate", true);
						Thread.sleep(3000);
						
						WebElement PopupTitle1 = TestDriver.driver.findElement(By.xpath(objSphereModules.Billing_DraftBilling_createImmediate_PopUp_Title_xp));
						HighlightElement(PopupTitle1);
						Thread.sleep(3000);
						
						ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
						Thread.sleep(3000);
						
						
						
						if(ElementFound(SphereModules.Billing_DraftBilling_DraftBill_List_xp)==false)
						{
							obj.repAddData( "Verify  Draft Bill disappeared after creating immediate: ",
									"Draft Bill list should not be dispalyed", "Draft Bill list is not displayed", "Pass");
						}
						else
						{
							obj.repAddData( "Verify  Draft Bill disappeared after creating immediate: ", "Draft Bill list should not be dispalyed", "Draft Bill list is still displayed", "Fail");
						}
	                      
						Thread.sleep(5000);
						
					}
				}
						objBusinessLib.fnClickMainMenuElement("Invoice/Statement");
						Thread.sleep(5000);
						/*ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "click", true);
						Thread.sleep(3000);*/
						
						ClickByXpath(SphereModules.InvoiceStatementInquiry_DealNumberFilter, "click", true);
						Thread.sleep(3000);

						SendKeyByXpath(SphereModules.InvoiceStatementInquiry_SearchDealNumberFilter,sExpDealNumberDB,"Deal Number");
						fnLoadingPageWait();
						Thread.sleep(6000);
						ClickByXpath(SphereModules.InvoiceStatementInquiry_ClickSearchDealNumberFilter2, "click", true);
						Thread.sleep(3000);
						
						
						if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
						{
							obj.repAddData( "Verify Status of the Transaction ",
									"Status of the Transaction should be dispalyed as Final Billed", "Status of the Transaction is dispalyed as Final Billed", "Pass");
						}
						else
						{
							obj.repAddData( "Verify Status of the Transaction ",
									"Status of the Transaction should be dispalyed as Final Billed", "Status of the Transaction is not dispalyed as Final Billed", "Fail");
						}
	                      
			
	}
	catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1041 Failed!", e );
	}			

	finally {
		/*ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);*/
	if(!testCaseStatus)
	{
		Reporter.iTotalFail++;	
	}
	else
	{
		Reporter.iTotalPass++;
	}
	log.info("Execution of Script TC1041 Completed");
	}
	return obj;
	}


public Reporter TC1045(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1045 Started..");
try {
	
	
	
	String sDealTitle ="";

    String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
    System.out.println(sDealTitleRandom);

    String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
	String sProjectName="SCRIPTED WORLD";
	String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	//sDealTitleUI = "AutoTestDeal_"+sRandom;
	String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
	
	
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(10000); 
	ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
	fnLoadingPageWait();
	fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
	objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
	ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
	fnLoadingPageWait();
	
	//String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 99999));

    String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
	System.out.println(sCustomerTitleRandom);
	

	String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	
	String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
	/*if(!sOperation.equalsIgnoreCase("Duplicate"))
	{
	
		sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	}
	*/
	String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
	String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
	
	//Date date = new Date();
	//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
	
	Date dTomorrow = DateUtils.addDays(new Date(), +1);
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	String sStartDateUI1 = sdf.format(dTomorrow);
	
	sdf.applyPattern("yyyy-MM-dd");
	String sStartDateUIDBpattern=sdf.format(dTomorrow);
/*	Date dYesterday = DateUtils.addDays(new Date(), -1);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String sStartDateUI2 = sdf.format(dYesterday);*/
	
	String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
	String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
	String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
	//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
	String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
	String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
	String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
	String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();

	/*objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
	objGenericFunctionLibrary.fnLoadingPageWait();
	//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
	objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
	Thread.sleep(4000);
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
	objGenericFunctionLibrary.fnLoadingPageWait();*/
	objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
	//objGenericFunctionLibrary.ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
	//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
	
	/////////////////Adding Customer Address Start//////////////////
	
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
    
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
	
	String sCreditLimitUI=sRandom+".00";
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
	
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
		objGenericFunctionLibrary.fnLoadingPageWait();
		
	
	/*SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);*/
	ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
	SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
	SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
	SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
	//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
	ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
	ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
	///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
	ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
	WebElement Customer_Number1 = driver.findElement(By.xpath(SphereModules.Deal_NewCustomer_Number));
	 String Customer_Number= Customer_Number1.getText();
	 System.out.println(Customer_Number);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
	
	ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
	SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
	ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
	fnLoadingPageWait();

	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	
	/*String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();*/
	 Thread.sleep(90000); 
	 Thread.sleep(40000); 
	 
	/* objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 */
	 
	 
	 
	 
	 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	/* if(Deal_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Fail");
	 }
	 else
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Pass");
	 }*/
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	 
	 
	
	 
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,Customer_Number,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Customer_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Customer_StatusUI= Customer_Status.getText();
	/* if(Customer_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Fail");
	 }
	 else
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Pass");
	 }
	*/
	 
	 List<WebElement> count1=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count1)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	 
	 
	 
	 
	 
	 
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1045 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1045 Completed");

}
return obj;
}


public Reporter TC1047(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1047 Started..");
try {
	
	
	//String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	/*sDealTitleUI = objBusinessLib.fnAddDealAccountWithCustomerCode(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);*/
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(3000); 
	
	ClickByXpath(SphereModules.Deals_Open_Deals, "Open Deals", true);
	Thread.sleep(5000); 
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter, "costcenterFilter", true);
	 ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_280, "costcenterFilter", true);
	 WebElement Deal_Number = driver.findElement(By.xpath(SphereModules.Deals_DealNumber));
	 String Deal_NumberUI= Deal_Number.getText();
	 WebElement Deal_Title = driver.findElement(By.xpath(SphereModules.Deals_DealTitle));
	 String sDealTitleUI= Deal_Title.getText();
	 WebElement Deal_CustomerTitle = driver.findElement(By.xpath(SphereModules.Deals_CustomerTitle));
	 String sCustomer= Deal_CustomerTitle.getText();
	// ClickByXpath(SphereModules.Common_View_Transactions_Table_First_Row_xp, "First Row", true);
	 String Productiontype = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
	 String Customer_Number = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Number").trim();
	 
	 ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Row", true);
	 WebElement Deal_CustomerNumber = driver.findElement(By.xpath(SphereModules.Deals_CustomerNumber));
	 String Deal_CustomerNumberUI= Deal_CustomerNumber.getText();
	 
	 
	 String sCustomerNumber= Deal_CustomerNumberUI;
	 String sExpDealNumberDB=Deal_NumberUI;
	 fnSelectFromComboBoxXpath(SphereModules.Deals_DealType,Productiontype);
	 String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	 SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id,sRandom, "PO Number");
	 Thread.sleep(3000);
	 if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
		{ClickByXpath(SphereModules.Deals_UpdateDeal_SaveButton, "Save", true);
			}
		else
		{
			ClickByXpath(SphereModules.Exception_DealSaveButton, "Save", true);
			}
	 Thread.sleep(90000);
	 Thread.sleep(40000);
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	/* if(Deal_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Fail");
	 }
	 else
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Pass");
	 }*/
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	 
	 
	
	 
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,Customer_Number,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Customer_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Customer_StatusUI= Customer_Status.getText();
	/* if(Customer_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Fail");
	 }
	 else
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Pass");
	 }
	*/
	 
	 List<WebElement> count1=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count1)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	 
	 objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
		
	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1047 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1047 Completed");

}
return obj;
}

public Reporter TC1048(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1048 Started..");
try {
	
	
	
	String sDealTitle ="";

    String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
    System.out.println(sDealTitleRandom);

    String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
	String sProjectName="SCRIPTED WORLD";
	String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	//sDealTitleUI = "AutoTestDeal_"+sRandom;
	String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
	
	
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(10000); 
	ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
	fnLoadingPageWait();
	fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
	objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
	ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
	fnLoadingPageWait();
	
	//String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 99999));

    String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
	System.out.println(sCustomerTitleRandom);
	

	String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	
	String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
	/*if(!sOperation.equalsIgnoreCase("Duplicate"))
	{
	
		sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	}
	*/
	String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
	String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
	
	//Date date = new Date();
	//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
	
	Date dTomorrow = DateUtils.addDays(new Date(), +1);
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	String sStartDateUI1 = sdf.format(dTomorrow);
	
	sdf.applyPattern("yyyy-MM-dd");
	String sStartDateUIDBpattern=sdf.format(dTomorrow);
/*	Date dYesterday = DateUtils.addDays(new Date(), -1);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String sStartDateUI2 = sdf.format(dYesterday);*/
	
	String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
	String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
	String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
	//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
	String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
	String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
	String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
	String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();

	/*objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
	objGenericFunctionLibrary.fnLoadingPageWait();
	//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
	objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
	Thread.sleep(4000);
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
	objGenericFunctionLibrary.fnLoadingPageWait();*/
	objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
	//objGenericFunctionLibrary.ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
	//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
	
	/////////////////Adding Customer Address Start//////////////////
	
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
    
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
	
	String sCreditLimitUI=sRandom+".00";
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
	
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
		objGenericFunctionLibrary.fnLoadingPageWait();
		
	
	/*SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);*/
	ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
	SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
	SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
	SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
	//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
	ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
	ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
	///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
	ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
	
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
	
	ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
	SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
	ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
	fnLoadingPageWait();

	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	
	/*String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();*/
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1048 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1048 Completed");

}
return obj;
}



public Reporter TC1050(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1050 Started..");
try {
	
	
	//String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	/*sDealTitleUI = objBusinessLib.fnAddDealAccountWithCustomerCode(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);*/
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(3000); 
	
	ClickByXpath(SphereModules.Deals_Open_Deals, "Open Deals", true);
	Thread.sleep(5000); 
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter, "costcenterFilter", true);
	 ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_434, "434 Costcenter", true);
	 WebElement Deal_Number = driver.findElement(By.xpath(SphereModules.Deals_DealNumber));
	 String Deal_NumberUI= Deal_Number.getText();
	 WebElement Deal_Title = driver.findElement(By.xpath(SphereModules.Deals_DealTitle));
	 String sDealTitleUI= Deal_Title.getText();
	 WebElement Deal_CustomerTitle = driver.findElement(By.xpath(SphereModules.Deals_CustomerTitle));
	 String sCustomer= Deal_CustomerTitle.getText();
	// ClickByXpath(SphereModules.Common_View_Transactions_Table_First_Row_xp, "First Row", true);
	 String Productiontype = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
		
	 ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Row", true);
	 WebElement Deal_CustomerNumber = driver.findElement(By.xpath(SphereModules.Deals_CustomerNumber));
	 String Deal_CustomerNumberUI= Deal_CustomerNumber.getText();
	 
	 
	 String sCustomerNumber= Deal_CustomerNumberUI;
	 String sExpDealNumberDB=Deal_NumberUI;
	 fnSelectFromComboBoxXpath(SphereModules.Deals_DealType,Productiontype);
	 String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	 SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id,sRandom, "PO Number");
	 
	 if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
		{ClickByXpath(SphereModules.Deals_UpdateDeal_SaveButton, "Save", true);
			}
		else
		{
			ClickByXpath(SphereModules.Exception_DealSaveButton, "Save", true);
			}
	 Thread.sleep(90000); 
	  objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	 
	 objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
		
	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1050 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1050 Completed");

}
return obj;
}


public Reporter TC1051(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1051 Started..");
try {
	
	
	
	String sDealTitle ="";

    String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
    System.out.println(sDealTitleRandom);

    String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
	String sProjectName="SCRIPTED WORLD";
	String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	//sDealTitleUI = "AutoTestDeal_"+sRandom;
	String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
	
	
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(10000); 
	ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
	fnLoadingPageWait();
	fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
	objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
	ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
	fnLoadingPageWait();
	
	//String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 99999));

    String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
	System.out.println(sCustomerTitleRandom);
	

	String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	
	String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
	/*if(!sOperation.equalsIgnoreCase("Duplicate"))
	{
	
		sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	}
	*/
	String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
	String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
	
	//Date date = new Date();
	//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
	
	Date dTomorrow = DateUtils.addDays(new Date(), +1);
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	String sStartDateUI1 = sdf.format(dTomorrow);
	
	sdf.applyPattern("yyyy-MM-dd");
	String sStartDateUIDBpattern=sdf.format(dTomorrow);
/*	Date dYesterday = DateUtils.addDays(new Date(), -1);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String sStartDateUI2 = sdf.format(dYesterday);*/
	
	String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
	String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
	String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
	//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
	String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
	String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
	String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
	String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();

	/*objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
	objGenericFunctionLibrary.fnLoadingPageWait();
	//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
	objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
	Thread.sleep(4000);
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
	objGenericFunctionLibrary.fnLoadingPageWait();*/
	objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
	//objGenericFunctionLibrary.ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
	//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
	
	/////////////////Adding Customer Address Start//////////////////
	
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
    
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
	
	String sCreditLimitUI=sRandom+".00";
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
	
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
		objGenericFunctionLibrary.fnLoadingPageWait();
		
	
	/*SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);*/
	ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
	SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
	SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
	SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
	//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
	ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
	ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
	///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
	ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
	
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
	
	ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
	SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
	ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
	fnLoadingPageWait();

	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	
	/*String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();*/
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1051 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1051 Completed");

}
return obj;
}


public Reporter TC1053(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1053 Started..");
try {
	
	
	//String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	/*sDealTitleUI = objBusinessLib.fnAddDealAccountWithCustomerCode(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);*/
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(3000); 
	
	ClickByXpath(SphereModules.Deals_Open_Deals, "Open Deals", true);
	Thread.sleep(5000); 
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter, "costcenterFilter", true);
	 ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_368, "368 Costcenter", true);
	 WebElement Deal_Number = driver.findElement(By.xpath(SphereModules.Deals_DealNumber));
	 String Deal_NumberUI= Deal_Number.getText();
	 WebElement Deal_Title = driver.findElement(By.xpath(SphereModules.Deals_DealTitle));
	 String sDealTitleUI= Deal_Title.getText();
	 WebElement Deal_CustomerTitle = driver.findElement(By.xpath(SphereModules.Deals_CustomerTitle));
	 String sCustomer= Deal_CustomerTitle.getText();
	// ClickByXpath(SphereModules.Common_View_Transactions_Table_First_Row_xp, "First Row", true);
	 String Productiontype = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
		
	 ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Row", true);
	 WebElement Deal_CustomerNumber = driver.findElement(By.xpath(SphereModules.Deals_CustomerNumber));
	 String Deal_CustomerNumberUI= Deal_CustomerNumber.getText();
	 
	 String sRandom = String.valueOf(fnRandomNum(10001, 14999));
		
	 String sCustomerNumber= Deal_CustomerNumberUI;
	 String sExpDealNumberDB=Deal_NumberUI;
	 fnSelectFromComboBoxXpath(SphereModules.Deals_DealType,Productiontype);
	 SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id,sRandom, "PO Number");
			
	 
	 if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
		{ClickByXpath(SphereModules.Deals_UpdateDeal_SaveButton, "Save", true);
			}
		else
		{
			ClickByXpath(SphereModules.Exception_DealSaveButton, "Save", true);
			}
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);

	 
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1053 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1053 Completed");

}
return obj;
}


public Reporter TC1056(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1056 Started..");
try {
	
	
	//String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	/*sDealTitleUI = objBusinessLib.fnAddDealAccountWithCustomerCode(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);*/
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(3000); 
	
	ClickByXpath(SphereModules.Deals_Open_Deals, "Open Deals", true);
	Thread.sleep(5000); 
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter, "costcenterFilter", true);
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_240, "240 Costcenter", true);
	 //ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_265, "265 Costcenter", true);
		
	 WebElement Deal_Number = driver.findElement(By.xpath(SphereModules.Deals_DealNumber));
	 String Deal_NumberUI= Deal_Number.getText();
	 WebElement Deal_Title = driver.findElement(By.xpath(SphereModules.Deals_DealTitle));
	 String sDealTitleUI= Deal_Title.getText();
	 WebElement Deal_CustomerTitle = driver.findElement(By.xpath(SphereModules.Deals_CustomerTitle));
	 String sCustomer= Deal_CustomerTitle.getText();
	// ClickByXpath(SphereModules.Common_View_Transactions_Table_First_Row_xp, "First Row", true);
	 String Productiontype = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
		
	 ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Row", true);
	 WebElement Deal_CustomerNumber = driver.findElement(By.xpath(SphereModules.Deals_CustomerNumber));
	 String Deal_CustomerNumberUI= Deal_CustomerNumber.getText();
	 
	 String sRandom = String.valueOf(fnRandomNum(10001, 14999));
		
	 String sCustomerNumber= Deal_CustomerNumberUI;
	 String sExpDealNumberDB=Deal_NumberUI;
	 fnSelectFromComboBoxXpath(SphereModules.Deals_DealType,Productiontype);
	 SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id,sRandom, "PO Number");
			
	 if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
		{ClickByXpath(SphereModules.Deals_UpdateDeal_SaveButton, "Save", true);
			}
		else
		{
			ClickByXpath(SphereModules.Exception_DealSaveButton, "Save", true);
			}
	 
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);

   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1056 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1056 Completed");

}
return obj;
}

public Reporter TC1054(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1054 Started..");
try {
	
	
	
	String sDealTitle ="";

    String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
    System.out.println(sDealTitleRandom);

    String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
	String sProjectName="SCRIPTED WORLD";
	String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	//sDealTitleUI = "AutoTestDeal_"+sRandom;
	String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
	
	
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(10000); 
	ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
	fnLoadingPageWait();
	fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
	objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
	ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
	fnLoadingPageWait();
	
	//String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 99999));

    String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
	System.out.println(sCustomerTitleRandom);
	

	String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	
	String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
	/*if(!sOperation.equalsIgnoreCase("Duplicate"))
	{
	
		sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	}
	*/
	String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
	String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
	
	//Date date = new Date();
	//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
	
	Date dTomorrow = DateUtils.addDays(new Date(), +1);
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	String sStartDateUI1 = sdf.format(dTomorrow);
	
	sdf.applyPattern("yyyy-MM-dd");
	String sStartDateUIDBpattern=sdf.format(dTomorrow);
/*	Date dYesterday = DateUtils.addDays(new Date(), -1);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String sStartDateUI2 = sdf.format(dYesterday);*/
	
	String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
	String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
	String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
	//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
	String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
	String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
	String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
	String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();

	/*objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
	objGenericFunctionLibrary.fnLoadingPageWait();
	//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
	objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
	Thread.sleep(4000);
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
	objGenericFunctionLibrary.fnLoadingPageWait();*/
	objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
	//objGenericFunctionLibrary.ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
	//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
	
	/////////////////Adding Customer Address Start//////////////////
	
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
    
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
	
	String sCreditLimitUI=sRandom+".00";
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
	
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
		objGenericFunctionLibrary.fnLoadingPageWait();
		
	
	/*SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);*/
	ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
	SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
	SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
	SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
	//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
	ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
	ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
	///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
	ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
	
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
	
	ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
	SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
	ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
	fnLoadingPageWait();

	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	
	/*String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();*/
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);

	 
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1054 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1054 Completed");

}
return obj;
}

public Reporter TC1055(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1055 Started..");
try {
	
	
	String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);
	
	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
    Thread.sleep(90000);
    objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);

		
	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1055 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1055 Completed");

}
return obj;
}


public Reporter TC1052(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1052 Started..");
try {
	
	
	String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);
	
	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
    Thread.sleep(90000);
    objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);

	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1052 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1052 Completed");

}
return obj;
}



public Reporter TC1049(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1049 Started..");
try {
	
	
	String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);
	
	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
    Thread.sleep(90000);
    objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
	
	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1049 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1049 Completed");

}
return obj;
}


public Reporter TC1042(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1042 Started..");
try {
	
	
	
	String sDealTitle ="";

    String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
    System.out.println(sDealTitleRandom);

    String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;	
	String sProjectName="SCRIPTED WORLD";
	String sRandom = String.valueOf(fnRandomNum(10001, 14999));
	//sDealTitleUI = "AutoTestDeal_"+sRandom;
	String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
    String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
    String sQuery2 = objSQLConfig.sDeal_Customer_Cannot_Deactivate_Query;
	
	
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(10000); 
	ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
	fnLoadingPageWait();
	fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
	objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
	ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
	fnLoadingPageWait();
	
	//String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 99999));

    String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
	System.out.println(sCustomerTitleRandom);
	

	String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	
	String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
	/*if(!sOperation.equalsIgnoreCase("Duplicate"))
	{
	
		sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
	}
	*/
	String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
	String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
	
	//Date date = new Date();
	//String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
	String sCustomer_CodeID="PAYTV";
	Date dTomorrow = DateUtils.addDays(new Date(), +1);
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	String sStartDateUI1 = sdf.format(dTomorrow);
	
	sdf.applyPattern("yyyy-MM-dd");
	String sStartDateUIDBpattern=sdf.format(dTomorrow);
/*	Date dYesterday = DateUtils.addDays(new Date(), -1);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	String sStartDateUI2 = sdf.format(dYesterday);*/
	
	String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
	String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
	String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
	//String sAddr3UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address3").trim();
	String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
	String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
	String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
	String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();

	/*objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
	objGenericFunctionLibrary.fnLoadingPageWait();
	//WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
	objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //pre-condition
	Thread.sleep(4000);
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
	objGenericFunctionLibrary.fnLoadingPageWait();*/
	objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputTaxId_id, sTaxIdUI, "Tax Id");
	objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.CustomersMaster_AddCustomer_ComboParentCompany_id,sParentCompanyUI);
	//objGenericFunctionLibrary.ClickById(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id, "Production Start Date", true);
	//TestDriver.driver.findElement(By.id(SphereModules.CustomersMaster_AddCustomer_InputStartDate_id)).sendKeys(sStartDateUI1);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
	
	/////////////////Adding Customer Address Start//////////////////
	
	objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
	//objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine3_id, sAddr3UI, "Address Line 3");
    
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
	objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
	
	String sCreditLimitUI=sRandom+".00";
	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
	objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
	
		objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
		objGenericFunctionLibrary.fnLoadingPageWait();
		
	
	/*SendKeyByXpath(SphereModules.Deals_AddDeal_SearchCustomers_xp,sCustomerUI, "Search customer");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);*/
	ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
	SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
	SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
	SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
	fnLoadingPageWait();
	ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
	//objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnInsuranceCertifiedYes_id, "Insurance Certified", true);
	//objGenericFunctionLibrary.SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
	ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
	ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
	///objGenericFunctionLibrary.ClickById(SphereModules.Deals_AddDealBtnRevenueShareYes_id, "Revenue Share", true);
    ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
	ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
	WebElement Customer_Number1 = driver.findElement(By.xpath(SphereModules.Deal_NewCustomer_Number));
	 String Customer_Number= Customer_Number1.getText();
	
	
	
	
	
	fnSelectFromComboBoxId(SphereModules.Deals_AddDeal_Customer_Code_id,sCustomer_CodeID);
	//objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Deals_AddDealComboInvoiceFormat_id,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
	fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
	
	ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
	SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
	ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
	fnLoadingPageWait();

	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
	
	/*String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
	String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();*/
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 if(Deal_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Pass");
	 }
	 else
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Fail");
	 }
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Pass");
		 }
		 
	 }
	 
	 
	
	 
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,Customer_Number,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Customer_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Customer_StatusUI= Customer_Status.getText();
	 if(Customer_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Pass");
	 }
	 else
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Fail");
	 }
	
	 
	 List<WebElement> count1=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count1)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Pass");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHub(sExpDealNumberDB);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1042 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1042 Completed");

}
return obj;
}

public Reporter TC1044(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1044 Started..");
try {
	
	
	//String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	/*sDealTitleUI = objBusinessLib.fnAddDealAccountWithCustomerCode(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);*/
	objBusinessLib.fnClickMainMenuElement("Deals");
	WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
	Thread.sleep(3000); 
	
	ClickByXpath(SphereModules.Deals_Open_Deals, "Open Deals", true);
	Thread.sleep(5000); 
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter, "costcenterFilter", true);
	 
	 ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_265, "265 Costcenter", true);
	 //ClickByXpath(SphereModules.Deals_CostCenterFilter_SelectCostCenter_265, "265 Costcenter", true);
	 String Customer_Number = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Number").trim();
	 WebElement Deal_Number = driver.findElement(By.xpath(SphereModules.Deals_DealNumber));
	 String Deal_NumberUI= Deal_Number.getText();
	 WebElement Deal_Title = driver.findElement(By.xpath(SphereModules.Deals_DealTitle));
	 String sDealTitleUI= Deal_Title.getText();
	 WebElement Deal_CustomerTitle = driver.findElement(By.xpath(SphereModules.Deals_CustomerTitle));
	 String sCustomer= Deal_CustomerTitle.getText();
	// ClickByXpath(SphereModules.Common_View_Transactions_Table_First_Row_xp, "First Row", true);
	 String Productiontype = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
		
	 ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Row", true);
	 WebElement Deal_CustomerNumber = driver.findElement(By.xpath(SphereModules.Deals_CustomerNumber));
	 String Deal_CustomerNumberUI= Deal_CustomerNumber.getText();
	 
	 String sRandom = String.valueOf(fnRandomNum(10001, 14999));
		
	 String sCustomerNumber= Deal_CustomerNumberUI;
	 String sExpDealNumberDB=Deal_NumberUI;
	 fnSelectFromComboBoxXpath(SphereModules.Deals_DealType,Productiontype);
	 SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id,sRandom, "PO Number");
			
	 if(ElementFound(SphereModules.InvoiceStatement_FinalBilled_Status)==true)
		{ClickByXpath(SphereModules.Deals_UpdateDeal_SaveButton, "Save", true);
			}
		else
		{
			ClickByXpath(SphereModules.Exception_DealSaveButton, "Save", true);
			}
	 
	 Thread.sleep(90000); 
	 objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 if(Deal_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Pass");
	 }
	 else
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Fail");
	 }
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Pass");
		 }
		 
	 }
	 
	 
	
	 
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,Customer_Number,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Customer_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Customer_StatusUI= Customer_Status.getText();
	 if(Customer_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Pass");
	 }
	 else
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Fail");
	 }
	
	 
	 List<WebElement> count1=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count1)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Pass");
		 }
		 
	 }
	 
	 objBusinessLib.fnVerifyNonStudioPostCostCenterHub(sExpDealNumberDB);
		
	 
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1044 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1044 Completed");

}
return obj;
}
public Reporter TC1043(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1043 Started..");
try {
	
	
	String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	sDealTitleUI = objBusinessLib.fnAddDealAccount265(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);
	String Customer_Number = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Number").trim();
	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
    Thread.sleep(90000);
    objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Order", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 if(Deal_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Pass");
	 }
	 else
	 {
		 obj.repAddData( "Verify Status",
				 "Status should be displayed as Complete",
				 "Customer Status is displayed as "+Deal_StatusUI+"", "Fail");
	 }
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Pass");
		 }
		 
	 }
	 
	 
	
	 
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,Customer_Number,"Deal Number");
	 Thread.sleep(3000); 
	 WebElement Customer_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Customer_StatusUI= Customer_Status.getText();
	 if(Customer_StatusUI.equalsIgnoreCase("COMPLETE"))
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Pass");
	 }
	 else
	 {
		 obj.repAddData( "Verify Customer Status",
				 "Customer Status should be displayed as Complete",
				 "Customer Status is displayed as "+Customer_StatusUI+"", "Fail");
	 }
	
	 
	 List<WebElement> count1=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count1)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Pass");
		 }
		 
	 }
	 
	 objBusinessLib.fnVerifyNonStudioPostCostCenterHub(sExpDealNumberDB);
		
	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1043 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1043 Completed");

}
return obj;
}



public Reporter TC1046(Reporter obj) throws Exception
{
	log.info("Execution of Script TC1046 Started..");
try {
	
	
	String sDealTitleUI ="";
	obj.repAddData( "Adding a new deal account ", "", "", "");
	sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
	System.out.println(sDealTitleUI);
	
	String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
	sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
	TestDriver.conn = objDBUtility.fnOpenDBConnection();
	TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
	HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
    Thread.sleep(90000);
    objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
	 ClickByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp, "Search Bar", true);
	 SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sExpDealNumberDB,"Deal Number");
	 Thread.sleep(3000); 
	 /*WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	 Thread.sleep(3000); 
	 if(Deal_StatusUI.contains("COMPLETE"))
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is Completed", "Pass");
	    		//return obj;
	    	}else
		
	    	
	    	{
	    		obj.repAddData( "Verify  Deal status", "Deal status should be Completed", "Deal status is not Completed", "Fail");
	    	
	    	}
	*/
	 
	 
	 WebElement Deal_Status = driver.findElement(By.xpath(SphereModules.QueueLogging_Deal_Status));
	 String Deal_StatusUI= Deal_Status.getText();
	
	
	 
	 List<WebElement> count=TestDriver.driver.findElements(By.xpath(SphereModules.QueueLogging_DealSystemName));
	 for(WebElement systemName:count)
	 {
		 String systmName=systemName.getText();
		 if(systmName.equalsIgnoreCase("ScheduallStudioPost"))
		 {
			 obj.repAddData( "Verify  queue logging",
					 "studio post system should not be present on queue logging page for the particular Deal "+sExpDealNumberDB+"",
					 "studio post system is present on queue logging page for the particular Deal "+sExpDealNumberDB+"", "Fail");
		 }
		 
	 }
	
	objBusinessLib.fnVerifyNonStudioPostCostCenterHubNewCustomer_280(sExpDealNumberDB);
	
	 //objBusinessLib.fnVerifyCostCenterHub(sDealTitleUI,sCustomer,sCustomerNumber);
	
	
   }

   
    

catch (Exception e) {
	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	Thread.sleep(6000);
	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	Thread.sleep(3000);
	e.printStackTrace();
	testCaseStatus = false;
	//bLoginFlag=false;
	obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
	log.error( "Script TC1046 Failed!", e );
}			

finally {

if(!testCaseStatus)
{
	Reporter.iTotalFail++;	
}
else
{
	Reporter.iTotalPass++;
}
log.info("Execution of Script TC1046 Completed");

}
return obj;
}

/*public Reporter TC11133(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1113 Started..");

	try {
		String sDealTitleUI ="";
		String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 14999));

		 String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sDealTitleRandom);
			
			sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;
			//sDealTitleUI = "AUTOTESTDEAL_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			
			String sProjectName= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Project").trim();
			//String sCustomerUI="AUTOTESTDEALCUSTOMER";
			String sFirstName="AutoTestFirstName"+sRandom;
			String sLastName="AutoTestLastName"+sRandom;
			String sContactTitleUI="AutoTitle"+sRandom;
			String sEmailAddressUI="AutoTestEmail"+"sRandom+@nbcuni.com";
			String sphoneRandom= String.valueOf(objGenericFunctionLibrary.fnRandomNum(2222222, 9999999));
			String sContactPhone ="248"+sphoneRandom;
			String sCustomerUI= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Customer").trim();
			String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
		    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
		    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
		    String sCostCenterUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			  
		    Date date = new Date();
		    String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);//not using SimpleDateFormat
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday);
			
			objBusinessLib.fnClickMainMenuElement("Deals");
			WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
			Thread.sleep(10000); 

			objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
			objGenericFunctionLibrary.fnLoadingPageWait();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
			
			objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
			fnLoadingPageWait();
			String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sCustomerTitleRandom);
			String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
			String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
			String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
			String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
			String sCustomer_CodeID="PAYTV";
			Date dTomorrow = DateUtils.addDays(new Date(), +1);
			sdf.applyPattern("yyyy-MM-dd");
			String sStartDateUIDBpattern=sdf.format(dTomorrow);
			String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
			String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
			String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
			String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
			String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
			String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
			String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
			String TaxID = "12-1234567";
			String VatID = "123456";
			if((ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true)&&(ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true))
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is displayed for a new customer when accessed via the Add Deal form", "Pass");
			
			}
			else
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is not displayed for a new customer when accessed via the Add Deal form", "fail");
			}
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_TaxID, TaxID, "Tax ID");
			Thread.sleep(3000);
			ClickByXpath(SphereModules.Deals_AddCustomer_VATID, "VAT Id", true);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_VATID, VatID, "VAT ID");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
			String sCreditLimitUI=sRandom+".00";
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
			
				objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
				objGenericFunctionLibrary.fnLoadingPageWait();
				ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
				SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
				SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
				SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
				fnLoadingPageWait();
				ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
				ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
				ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
				ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
				ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
				WebElement Customer_Number1 = driver.findElement(By.xpath(SphereModules.Deal_NewCustomer_Number));
				 String Customer_Number= Customer_Number1.getText();
				//fnSelectFromComboBoxId(SphereModules.Deals_AddDeal_Customer_Code_id,sCustomer_CodeID);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
				
				ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
				SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2016","Insurance Expiration");
				ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
				fnLoadingPageWait();

				String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
				sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
				TestDriver.conn = objDBUtility.fnOpenDBConnection();
				TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
				HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
			    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
			    objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp, Customer_Number, "Customer Search");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_Project_or_Production_firstrow, "searched Customer", true);
			    String actualTaxId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_TaxID)).getAttribute("value");
			    String actualVATId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_VATID)).getAttribute("value");
				if((actualTaxId.equals(TaxID))&&(actualVATId.equals(VatID)))
			    {
			    	obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Pass");
				}
				else
				{
					obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is not able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Fail");
			    }
				ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	 }
	
	catch (Exception e) {
		ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);
		ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
		Thread.sleep(3000);
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1113 Failed!", e );
	}			

	finally {

	if(!testCaseStatus)
	{
		Reporter.iTotalFail++;	
	}
	else
	{
		Reporter.iTotalPass++;
	}
	log.info("Execution of Script TC1113 Completed");

	}
	return obj;
	}*/

public Reporter TC1114(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1114 Started..");

	try {
		String sDealTitleUI ="";
		String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 14999));

		 String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sDealTitleRandom);
			
			sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;
			//sDealTitleUI = "AUTOTESTDEAL_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			
			String sProjectName= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Project").trim();
			//String sCustomerUI="AUTOTESTDEALCUSTOMER";
			String sFirstName="AutoTestFirstName"+sRandom;
			String sLastName="AutoTestLastName"+sRandom;
			String sContactTitleUI="AutoTitle"+sRandom;
			String sEmailAddressUI="AutoTestEmail"+"sRandom+@nbcuni.com";
			String sphoneRandom= String.valueOf(objGenericFunctionLibrary.fnRandomNum(2222222, 9999999));
			String sContactPhone ="248"+sphoneRandom;
			String sCustomerUI= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Customer").trim();
			String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
		    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
		    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
		    String sCostCenterUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			  
		    Date date = new Date();
		    String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);//not using SimpleDateFormat
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday);
			
			objBusinessLib.fnClickMainMenuElement("Deals");
			WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
			Thread.sleep(10000); 

			objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
			objGenericFunctionLibrary.fnLoadingPageWait();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
			
			objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
			fnLoadingPageWait();
			String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sCustomerTitleRandom);
			String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
			String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
			String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
			String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
			String sCustomer_CodeID="PAYTV";
			Date dTomorrow = DateUtils.addDays(new Date(), +1);
			sdf.applyPattern("yyyy-MM-dd");
			String sStartDateUIDBpattern=sdf.format(dTomorrow);
			String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
			String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
			String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
			String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
			String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
			String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
			String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
			String TaxID = "12-1234567";
			String VatID = "123456";
			if((ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true)&&(ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true))
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is displayed for a new customer when accessed via the Add Deal form", "Pass");
			
			}
			else
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is not displayed for a new customer when accessed via the Add Deal form", "fail");
			}
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_TaxID, TaxID, "Tax ID");
			Thread.sleep(3000);
			ClickByXpath(SphereModules.Deals_AddCustomer_VATID, "VAT Id", true);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_VATID, VatID, "VAT ID");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
			String sCreditLimitUI=sRandom+".00";
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
			
				objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
				objGenericFunctionLibrary.fnLoadingPageWait();
				ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
				SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
				SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
				SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
				fnLoadingPageWait();
				ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
				ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
				ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
				ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
				ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
				WebElement Customer_Number1 = driver.findElement(By.xpath(SphereModules.Deal_NewCustomer_Number));
				 String Customer_Number= Customer_Number1.getText();
				//fnSelectFromComboBoxId(SphereModules.Deals_AddDeal_Customer_Code_id,sCustomer_CodeID);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
				
				ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
				SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
				ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
				fnLoadingPageWait();

				String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
				sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
				TestDriver.conn = objDBUtility.fnOpenDBConnection();
				TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
				HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
			    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
			    objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp, Customer_Number, "Customer Search");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_Project_or_Production_firstrow, "searched Customer", true);
			    String actualTaxId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_TaxID)).getAttribute("value");
			    String actualVATId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_VATID)).getAttribute("value");
				if((actualTaxId.equals(TaxID))&&(actualVATId.equals(VatID)))
			    {
			    	obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Pass");
				}
				else
				{
					obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Fail");
			    }
				ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	 }
	
	catch (Exception e) {
		ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);
		ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
		Thread.sleep(3000);
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1114 Failed!", e );
	}			

	finally {

	if(!testCaseStatus)
	{
		Reporter.iTotalFail++;	
	}
	else
	{
		Reporter.iTotalPass++;
	}
	log.info("Execution of Script TC1114 Completed");

	}
	return obj;
	}

public Reporter TC1115(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1115 Started..");

	try {
		String sDealTitleUI ="";
		String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 14999));

		 String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sDealTitleRandom);
			
			sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;
			//sDealTitleUI = "AUTOTESTDEAL_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			
			String sProjectName= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Project").trim();
			//String sCustomerUI="AUTOTESTDEALCUSTOMER";
			String sFirstName="AutoTestFirstName"+sRandom;
			String sLastName="AutoTestLastName"+sRandom;
			String sContactTitleUI="AutoTitle"+sRandom;
			String sEmailAddressUI="AutoTestEmail"+"sRandom+@nbcuni.com";
			String sphoneRandom= String.valueOf(objGenericFunctionLibrary.fnRandomNum(2222222, 9999999));
			String sContactPhone ="248"+sphoneRandom;
			String sCustomerUI= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Customer").trim();
			String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
		    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
		    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
		    String sCostCenterUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			  
		    Date date = new Date();
		    String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);//not using SimpleDateFormat
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday);
			
			objBusinessLib.fnClickMainMenuElement("Deals");
			WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
			Thread.sleep(10000); 

			objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
			objGenericFunctionLibrary.fnLoadingPageWait();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
			
			objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
			fnLoadingPageWait();
			String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sCustomerTitleRandom);
			String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
			String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
			String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
			String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
			String sCustomer_CodeID="PAYTV";
			Date dTomorrow = DateUtils.addDays(new Date(), +1);
			sdf.applyPattern("yyyy-MM-dd");
			String sStartDateUIDBpattern=sdf.format(dTomorrow);
			String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
			String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
			String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
			String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
			String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
			String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
			String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
			String TaxID = "12-1234567";
			String VatID = "123456";
			if((ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true)&&(ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true))
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is displayed for a new customer when accessed via the Add Deal form", "Pass");
			
			}
			else
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is not displayed for a new customer when accessed via the Add Deal form", "fail");
			}
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_TaxID, TaxID, "Tax ID");
			Thread.sleep(3000);
			ClickByXpath(SphereModules.Deals_AddCustomer_VATID, "VAT Id", true);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_VATID, VatID, "VAT ID");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
			String sCreditLimitUI=sRandom+".00";
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
			
				objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
				objGenericFunctionLibrary.fnLoadingPageWait();
				ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
				SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
				SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
				SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
				fnLoadingPageWait();
				ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
				ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
				ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
				ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
				ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
				WebElement Customer_Number1 = driver.findElement(By.xpath(SphereModules.Deal_NewCustomer_Number));
				 String Customer_Number= Customer_Number1.getText();
				//fnSelectFromComboBoxId(SphereModules.Deals_AddDeal_Customer_Code_id,sCustomer_CodeID);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
				
				ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
				SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
				ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
				fnLoadingPageWait();

				String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
				sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
				TestDriver.conn = objDBUtility.fnOpenDBConnection();
				TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
				HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
			    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
			    objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp, Customer_Number, "Customer Search");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_Project_or_Production_firstrow, "searched Customer", true);
			    String actualTaxId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_TaxID)).getAttribute("value");
			    String actualVATId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_VATID)).getAttribute("value");
				if((actualTaxId.equals(TaxID))&&(actualVATId.equals(VatID)))
			    {
			    	obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Pass");
				}
				else
				{
					obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Fail");
			    }
				ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	 }
	
	catch (Exception e) {
		ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);
		ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
		Thread.sleep(3000);
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1115 Failed!", e );
	}			

	finally {

	if(!testCaseStatus)
	{
		Reporter.iTotalFail++;	
	}
	else
	{
		Reporter.iTotalPass++;
	}
	log.info("Execution of Script TC1115 Completed");

	}
	return obj;
	}

public Reporter TC1116(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC1116 Started..");

	try {
		String sDealTitleUI ="";
		String sRandom = String.valueOf(objGenericFunctionLibrary.fnRandomNum(10001, 14999));

		 String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
		 System.out.println(sDealTitleRandom);
			
			sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;
			//sDealTitleUI = "AUTOTESTDEAL_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			
			String sProjectName= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Project").trim();
			//String sCustomerUI="AUTOTESTDEALCUSTOMER";
			String sFirstName="AutoTestFirstName"+sRandom;
			String sLastName="AutoTestLastName"+sRandom;
			String sContactTitleUI="AutoTitle"+sRandom;
			String sEmailAddressUI="AutoTestEmail"+"sRandom+@nbcuni.com";
			String sphoneRandom= String.valueOf(objGenericFunctionLibrary.fnRandomNum(2222222, 9999999));
			String sContactPhone ="248"+sphoneRandom;
			String sCustomerUI= TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Customer").trim();
			String sDeal_TypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Deal_Type").trim();
		    String sInvoiceFormatUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Invoice_Format").trim();
		    String sBillingScheduleUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Billing_Schedule").trim();
		    String sCostCenterUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			  
		    Date date = new Date();
		    String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);//not using SimpleDateFormat
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday);
			
			objBusinessLib.fnClickMainMenuElement("Deals");
			WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
			Thread.sleep(10000); 

			objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_AddDeal_LinkAddPlusSign_xp, "Add Deal Link", true);
			objGenericFunctionLibrary.fnLoadingPageWait();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.Deals_AddDeal_LabelTitle_Msg, SphereModules.Deals_AddDeal_LabelAddDealTitle_xp);
			
			objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			ClickByXpath(SphereModules.DealPage_AddCustomerButton, "Add Customer plus button", true);
			fnLoadingPageWait();
			String sCustomerTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sCustomerTitleRandom);
			String sCustomerNameUI = "AUTOTESTCUSTOMER_"+sRandom;
			String sTaxIdUI = String.valueOf(objGenericFunctionLibrary.fnRandomNum(100000001, 999999999));
			String sCustomerTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Customer_Type").trim();
			String sProductionTypeUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Production_Type").trim();
			String sCustomer_CodeID="PAYTV";
			Date dTomorrow = DateUtils.addDays(new Date(), +1);
			sdf.applyPattern("yyyy-MM-dd");
			String sStartDateUIDBpattern=sdf.format(dTomorrow);
			String sParentCompanyUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
			String sAddr1UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address1").trim();
			String sAddr2UI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Address2").trim();
			String sCityUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("City").trim();
			String sZipUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Zip").trim();
			String sStateUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("State").trim();
			String sCountryUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Country").trim();
			objGenericFunctionLibrary.fnVerifyLabelMsgTextByXpath(AppMessages.CustomersMaster_AddCustomer_LabelTitle_msg, SphereModules.CustomersMaster_AddCustomer_LabelAddCustomerTitle_xp);
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputName_id, sCustomerNameUI, "Name");
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboCustomerType_id,sCustomerTypeUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxId(SphereModules.Customers_EditNationalAccount_ComboProductionType_id,sProductionTypeUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.CustomersMaster_AddCustomer_InputPhoneNumber_xp, "2487678989", "Phone Number");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputEmail_id, "AutoTestEmail"+sRandom+"@nbcuni.com", "Email");
			String TaxID = "12-1234567";
			String VatID = "123456";
			if((ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true)&&(ElementFound(SphereModules.Deals_AddCustomer_TaxID)==true))
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is displayed for a new customer when accessed via the Add Deal form", "Pass");
			
			}
			else
			{
				obj.repAddData( "Verify TaxId and Vat Id ",
						"TaxId and Vat Id should display for a new customer when accessed via the Add Deal form", "TaxId and Vat Id is not displayed for a new customer when accessed via the Add Deal form", "fail");
			}
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_TaxID, TaxID, "Tax ID");
			Thread.sleep(3000);
			ClickByXpath(SphereModules.Deals_AddCustomer_VATID, "VAT Id", true);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Deals_AddCustomer_VATID, VatID, "VAT ID");
			objGenericFunctionLibrary.SendKeyById(SphereModules.CustomersMaster_AddCustomer_InputAddressLine1_id, sAddr1UI, "Address Line 1");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_addressLine2, sAddr2UI, "Address Line 2");
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_Country,sCountryUI);
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.DealPage_AddCustomer_state,sStateUI);
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_City, sCityUI, "City");
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_zip, sZipUI, "Zip");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_CheckBoxSupportMultipleAddresses_xp, "Support Multiple Address Checkbox", true);
			String sCreditLimitUI=sRandom+".00";
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.DealPage_AddCustomer_creditLimit, sRandom, "Credit Limit");
			objGenericFunctionLibrary.ClickByXpath(SphereModules.DealPage_AddCustomer_alternateRadio, "Yes radio button", true);
			
				objGenericFunctionLibrary.ClickByXpath(SphereModules.CustomersMaster_AddCustomer_BtnAdd_xp, "Add Button", true);
				objGenericFunctionLibrary.fnLoadingPageWait();
				ClickById(SphereModules.Deals_AddDeal_RadioCustomerAddress_id, "Customer Address Radio Button", true);
				SendKeyById(SphereModules.Deals_AddDeal_InputDealTitle_id, sDealTitleUI, "Deal Title");
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDeal_InputDealType_id,sDeal_TypeUI);
				SendKeyById(SphereModules.Deals_AddDeal_InputPoNumber_id, "5466", "PO Number");
				SendKeyByXpath(SphereModules.Deals_AddDeal_SearchProjects_xp,sProjectName, "Search Project");
				fnLoadingPageWait();
				ClickByXpath(SphereModules.Deals_AddDeal_ProjectListSearch_xp, "First customer Row", true);
				ClickById(SphereModules.Deals_AddDealBtnOnLotYes_id, "On Lot", true);
				ClickById(SphereModules.Deals_AddDealBtnTaxYes_id, "Tax", true);
				ClickById(SphereModules.Deals_AddDealBtnRevenueShareNo_id, "Revenue Share", true);
				ClickById(SphereModules.Deals_AddDealBtnCostPlusYes_id, "Cost Plus", true);
				WebElement Customer_Number1 = driver.findElement(By.xpath(SphereModules.Deal_NewCustomer_Number));
				 String Customer_Number= Customer_Number1.getText();
				//fnSelectFromComboBoxId(SphereModules.Deals_AddDeal_Customer_Code_id,sCustomer_CodeID);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboInvoiceFormat_xp,sInvoiceFormatUI);
				fnSelectFromComboBoxXpath(SphereModules.Deals_AddDealComboBillingSchedule_xp,sBillingScheduleUI);
				
				ClickById(SphereModules.Deals_AddDealBtnInsuranceCertified_id, "Insurance Certified", true);
				SendKeyById(SphereModules.Deals_AddDeal_InsuranceExpiredDate_id,"09/10/2021","Insurance Expiration");
				ClickByXpath(SphereModules.Deals_AddDeal_BtnSave_xp,"Save Button", true);
				fnLoadingPageWait();

				String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
				sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
				TestDriver.conn = objDBUtility.fnOpenDBConnection();
				TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
				HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
			    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
			    objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.SendKeyByXpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp, Customer_Number, "Customer Search");
			    Thread.sleep(4000);
			    objGenericFunctionLibrary.ClickByXpath(SphereModules.Deals_Project_or_Production_firstrow, "searched Customer", true);
			    String actualTaxId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_TaxID)).getAttribute("value");
			    String actualVATId = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Deals_AddCustomer_VATID)).getAttribute("value");
				if((actualTaxId.equals(TaxID))&&(actualVATId.equals(VatID)))
			    {
			    	obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Pass");
				}
				else
				{
					obj.repAddData( "Verify user is able to enter TaxId and Vat Id ",
							"User should be able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "User is able to add the Vat ID and Tax ID fields for a new customer when accessed via the Add Deal form", "Fail");
			    }
				ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	 }
	
	catch (Exception e) {
		ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);
		ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
		Thread.sleep(3000);
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC1116 Failed!", e );
	}			

	finally {

	if(!testCaseStatus)
	{
		Reporter.iTotalFail++;	
	}
	else
	{
		Reporter.iTotalPass++;
	}
	log.info("Execution of Script TC1116 Completed");

	}
	return obj;
	}

//Sprint 2_TC029_ORB-280_Customer_NationalAccount_Cancel
public Reporter TC5759(Reporter obj) throws Exception
{
	//Boolean bLoginFlag = true;	
	log.info("Execution of Script TC5759 Started..");

	try {
				
		obj.repAddData( "Adding a national account with mandatory fields missing", "", "", "");
		
		objBusinessLib.fnClickSubMenuElement("Customers Master","Customers");
		WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewCustomersModule_Table_xp)));
		waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_xp)));
		ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); //post-condition
		Thread.sleep(4000);
		ClickByXpath(SphereModules.CustomersMaster_AddCustomer_LinkAddPlusSign_xp, "Add Customer Link", true);
		
			
		
		ArrayList<String> webElementList = new ArrayList<String>();
		ArrayList<String> webElementList1 = new ArrayList<String>();
		List<WebElement> parentCompanies = TestDriver.driver.findElements(By.xpath("//*[@id='parentCompany']/option"));
		for(int i=1;i<=parentCompanies.size()-1;i++)
		{
			WebElement txt = parentCompanies.get(i);
			String actualtxt = txt.getText();
			webElementList.add(actualtxt);
			webElementList1.add(actualtxt);
		}
		
		
		boolean test = objBusinessLib.isCollectionSorted(webElementList);
		obj.repAddData( "Verify whether the parent company filed is sorted",
				"Parent company field should be sorted", "Parent company field is sorted", "Pass");
		
		
		
		
		}
	catch (Exception e) {
		e.printStackTrace();
		testCaseStatus = false;
		//bLoginFlag=false;
		obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		log.error( "Script TC105 Failed!", e );
	}
	finally {
		fnCloseOpenedForm();
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC105 Completed");
	}
	return obj;
} //End of Script TC105	

}

		


