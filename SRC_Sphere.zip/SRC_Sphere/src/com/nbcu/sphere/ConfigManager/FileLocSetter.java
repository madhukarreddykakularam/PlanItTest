package com.nbcu.sphere.ConfigManager;

public class FileLocSetter {

	//public static final String sProjPath = "\\Automation_Workspace\\SphereAutomation\\";
	public static final String sProjPath = System.getProperty("user.dir")+"//";
	//	public static final String sProjPath = System.getProperty("user.dir")+"\\";
	public static final String sTestDataPath = sProjPath+"TestData//";
	public static final String sConfigPath = sProjPath+"config//";
	public static final String sFileName = "Sphere_Automation_Data.xls";
	public static final String sPropFile = sProjPath+"global.properties"; // properties file
	public static final String sReportsPath = sProjPath	;
	
	public static final String sSharedServerPath = "C://Users//sarshad//Dropbox (NBCUniversal)//Sphere Program//Sphere Development//QA//Automation//Results//";
	
	public static final String sDownloadPath = "C://Users//206500871//Downloads//";//"C://Users//Igundlur//Downloads//"	;
	public static final String sBillingSharedDrive = "\\\\tfayd.com\\Shared\\StudioOpsDeptsysBillingQA\\us-ush\\share";
	//public static final String sBillingSharedDrive = "\\\\tfayd.com\\Shared\\StudioOpsDeptsysBillingSTG\\us-ush\\share";
		
}
