/******************************************************************************
$Id : HtmlEventReporter.java 3/3/2016 7:07:27 PM
Copyright 2016-2017 IGATE GROUP OF COMPANIES. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF IGATE GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND IGATE GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
 ******************************************************************************/

package cbf.reporting;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import cbf.engine.TestResult;
import cbf.engine.TestResult.ResultType;
import cbf.harness.ResourcePaths;
import cbf.model.ResultReporter;
import cbf.model.TestCase;
import cbf.model.TestIteration;
import cbf.utils.FileUtils;
import cbf.utils.LogUtils;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbf.utils.StringUtils;

/**
 * 
 * Implements ResultReporter and generates HTML reports
 * 
 */
public class TestNgReporter implements ResultReporter {

	/**
	 * Constructor to initialize reporter related parameters
	 * 
	 * @param params
	 *            map containing parameters
	 */

	public TestNgReporter(Map params) {

		try {

			filePath = ResourcePaths.getInstance().getRunResource("testng-result.xml", "");

			writer = new PrintWriter(filePath);
		} catch (FileNotFoundException e) {
			logger.handleError("Error in creating testng reporter", e.getCause());
		}

	}

	/**
	 * Reporter open method
	 * 
	 * @param headers
	 *            contains header info, like run name, config details etc
	 */
	public void open(Map headers) {
		String tsName = (String) cbf.harness.Harness.GCONFIG.get("testSetSheet");
		writer.println("<?xml version='1.0' encoding='UTF-8'?>");
		writer.println("<testng-results>");
		writer.println("	<suite>");
		writer.println("		<test name='" + tsName + "' duration-ms='' started-at='' finished-at=''>");
		writer.println("			<class name='" + tsName + "'>");
	}

	/**
	 * Reporter close method
	 */
	public void close() {
		
		writer.println("			</class>");
		writer.println("		</test>");
		writer.println("	</suite>");
		writer.println("</testng-results>");
		writer.close();
	}

	/**
	 * Reports entity execution start details
	 * 
	 * @param result
	 *            entity object
	 */
	public void start(TestResult result) {
		report("START", result, result.entityDetails);
	}

	/**
	 * Logs execution details in report
	 * 
	 * @param result
	 *            entity details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void log(TestResult result, ResultType rsType, Map details) {
		report("DETAILS", result, details);
	}

	/**
	 * Reports execution details along with result counts
	 * 
	 * @param result
	 *            execution details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void finish(TestResult result, ResultType rsType, Object details) {
		report("FINISH", result, result.entityDetails);
	}

	private void report(String eventType, TestResult result, Object eventData) {
		try {
			switch (result.entityType) {
			
			/*case TESTSET:
				String inx = (String) ((Map) result.entityDetails).get("runIndex");
				rerun = (ArrayList) ((Map) result.entityDetails).get("reRunInstances");
				index = Integer.parseInt(inx);
				break;
				*/
			case ITERATION:

				break;
			case TESTCASE:
				if (eventType.equals("FINISH")) {
					String str;
					if (result.msRsType.isPassed()) {
						str = "PASSED";
					} else {
						str = "FAILED";
					}

					writer.println("				<test-method status='" + str + "' rerun='" + index + "' name='"
							+ result.entityName + "' duration-s='"
							+ calculateDuration(result.finishTime, result.startTime)
							+ "' started-at='' finished-at=''> </test-method>");

				}
				break;

			case TESTSTEP:
				if (eventType.equals("START")) {
					eventType.equalsIgnoreCase("");
				}
				break;
			case COMPONENT:
				if (eventType.equals("DETAILS")) {

				}
			}
		} catch (Exception e) {
			logger.handleError("Error in testNg reporting", e);
		}

	}
	private String calculateDuration(Date d2, Date d1) {
		if (d2 == null || d1 == null) {
			return null;
		} else {
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;

			try {
				String diffTime = cal(String.valueOf(diffSeconds));

				return diffTime;
			} catch (Exception e) {
				logger.handleError("Error in calculating duration in HTML report", e);
				return null;
			}
		}
	}

	private String cal(String time) {
		while (time.length() != 2)
			time = "0" + time;
		return time;
	}

	/**
	 * Returns HtmlEventReporter along with html report folder path format
	 * string
	 */
	public String toString() {
		return StringUtils.mapString(this, params);

	}

	private LogUtils logger = new LogUtils(this);

	private Map params;
	private PrintWriter writer;
	private String filePath;
	String tsName = null;
	private long totalduration=0;
	private int count=0,index=0;
	private ArrayList rerun = new ArrayList<>();
}
