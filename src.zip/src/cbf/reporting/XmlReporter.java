package cbf.reporting;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;

import cbf.engine.TestResult;
import cbf.engine.TestResult.ResultType;
import cbf.harness.ResourcePaths;
import cbf.model.ResultReporter;
import cbf.runner.TestSetRunner;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

public class XmlReporter  implements ResultReporter  {
	
	/**
	 * Constructor to initialize reporter related parameters
	 * 
	 * @param params
	 *            map containing parameters
	 */

	public XmlReporter(Map params) {

		try {

			filePath = ResourcePaths.getInstance().getRunResource("junit-result.xml", "");

			writer = new PrintWriter(filePath);
		} catch (FileNotFoundException e) {
			logger.handleError("Error in creating testng reporter", e.getCause());
		}

	}

	/**
	 * Reporter open method
	 * 
	 * @param headers
	 *            contains header info, like run name, config details etc
	 */
	public void open(Map headers) {
		
		writer.println("<?xml version='1.0' encoding='UTF-8'?>");
		//writer.println("<Junit-report>");
		
	}
	

	/**
	 * Reporter close methods
	 */
	public void close() {
		
		
	
		writer.println("<testsuite " + "tests=  "    +count+   " " +   "time= "+ calculateDuration(testFinish, testStart) +  "  " +  "failures="+failed+ "/>");
		//writer.println("</testsuite>");
		//writer.println("</Junit-report>");
		writer.close();
	}
	
	public String calculateDuration(Date d2, Date d1) {

		if (d2 == null || d1 == null) {
			return null;
		} else {
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			try {
				String diffTime = cal(String.valueOf(diffHours)) + ":"
						+ cal(String.valueOf(diffMinutes)) + ":"
						+ cal(String.valueOf(diffSeconds));
				return diffTime;
			} catch (Exception e) {
				logger.handleError(
						"Error in calculating duration in HTML report", e);
				return null;
			}
		}
	}
	/**
	 * Reports entity execution start details
	 * 
	 * @param result
	 *            entity object
	 */
	public void start(TestResult result) {
		report("START", result, result.entityDetails);
	}

	/**
	 * Logs execution details in report
	 * 
	 * @param result
	 *            entity details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void log(TestResult result, ResultType rsType, Map details) {
		report("DETAILS", result, details);
	}

	/**
	 * Reports execution details along with result counts
	 * 
	 * @param result
	 *            execution details
	 * @param rsType
	 *            result type of the current executed entity
	 * @param details
	 *            execution details of the current executed entity
	 */
	public void finish(TestResult result, ResultType rsType, Object details) {
		report("FINISH", result, result.entityDetails);
	}

	private void report(String eventType, TestResult result, Object eventData) {
		try {
			switch (result.entityType) {
			case ITERATION:
				if(eventType.equals("START")){
					testStart=result.startTime;
				
				}
				if(eventType.equals("FINISH")){
					testFinish=result.finishTime;
					str =  calculateDuration(testFinish, testStart);
					
				}
				if(eventType.equals("DETAILS")){
					
				}
				
				break;
			case TESTCASE:
				if (eventType.equals("START")) {
					count=TestSetRunner.tsCount;
				}
				if (eventType.equals("FINISH")) {
					String str;
					if (result.msRsType.isPassed()) {
						str = "PASS";
					} else {
						str = "FAIL";
					}
					if(count>0){
						
						writer.println("<testcase name =" +result.entityName +     "time="+calculateDuration(testFinish, testStart)+">");
						
					}
				}
				break;
			case COMPONENT:
				if (eventType.equals("DETAILS")) {
					stepNo++;
				}
					Map detailsMap = (Map) eventData;
					if(result.finalRsType.name.equals("FAILED")){
						failed++;
						
					writer.println("<failure message=" +detailsMap.get("actual")+ ">");
					writer.println("</failed>");
					writer.println("</testcase>");

	
					}
				
				//}
				
				break;
			
			
			}
		} catch (Exception e) {
			logger.handleError("Error in junit reporting", e);
		}
		

	}

	private String cal(String time) {
		while (time.length() != 2)
			time = "0" + time;
		return time;
	}

	
	public String toString() {
		return StringUtils.mapString(this, params);

	}
	
	
	private LogUtils logger = new LogUtils(this);

	private Map params;
	private PrintWriter writer;
	private String filePath;
	String tsName = null;
	private  int count=0,stepNo=0,totcount,failed=0;
	public int  testCaseNo=0;
	private Date testStart, testFinish, startTime = null;
	public String str;
	private String actualMsg;
}
