/******************************************************************************
$Id : JsonTestSetAccess.java 12/23/2016 4:08:36 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbf.testaccess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import cbf.harness.Harness;
import cbf.model.TestCase;
import cbf.model.TestInstance;
import cbf.model.TestIteration;
import cbf.model.TestSet;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;
import java.io.FileReader;
import java.io.FileWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import cbf.utils.FileUtils;

/**
 * 
 * Implements TestSet interface and makes TestInstance
 * 
 */
public class JsonTestSetAccess implements TestSet {

	private static Map<Integer, ArrayList<String>> testInstanceInfo = new HashMap<Integer, ArrayList<String>>();

	/**
	 * Constructor which reads the TestSet sheet and makes a list map for
	 * instances as per the user selection
	 * 
	 * @param params
	 */
	public JsonTestSetAccess(Map params) {
		JSONObject jsonObj = new JSONObject();
		String testCaseName = null;
		String folderPath = null;
		int index = 0;
		try {
			try {
				jsonObj = FileUtils.processJson(params);
			} catch (Exception e) {
				logger.handleError("Unable to parse sample json file",
						params.get("jsonInputFile"), e);
			}

			try {

				JSONArray testSetArray = (JSONArray) jsonObj.get("testSets");

				Iterator itr = testSetArray.iterator();
				while (itr.hasNext()) {
					Map<String, ArrayList<Map>> testSetMap = makeTestSets(
							jsonObj, itr);

					for (int ix = 0; ix < testcaseMap.size(); ix++) {
						for (String key : testSetMap.keySet()) {
							ArrayList<Map> testset = testSetMap.get(key);

							testCaseName = (String) testset.get(ix).get("name");
							folderPath = (String) testSetObj.get("path");
							ArrayList<String> instanceList = new ArrayList<String>();
							instanceList.add(testCaseName);
							instanceList.add(folderPath);
							testInstanceInfo.put(index, instanceList);
							index++;
						}

					}
				}
			}

			catch (Exception e) {
				logger.handleError("Failed to read testcases", e);
			}
		} catch (Exception e) {
			logger.handleError("Failed to read testsets", e);
		}
	}

	public Map<String, ArrayList<Map>> makeTestSets(JSONObject Obj, Iterator itr) {

		Map<String, ArrayList<Map>> instanceMap = new HashMap<String, ArrayList<Map>>();
		testSetObj = (JSONObject) itr.next();
		testcaseMap = (ArrayList<Map>) testSetObj.get("testCases");
		testsetname = (String) testSetObj.get("name");
		instanceMap.put(testsetname, testcaseMap);

		return instanceMap;
	}

	/**
	 * Returns ExcelTestSetAccess format string
	 */
	public String toString() {
		return StringUtils.mapString(this, params);
	}

	private LogUtils logger = new LogUtils(this);
	private Map params;

	@Override
	public int testInstanceCount() {
		return testInstanceInfo.size();
	}

	@Override
	public TestInstance testInstance(final int ix) {
		testInstanceInfo.get(ix);
		final ArrayList<String> params = testInstanceInfo.get(ix);
		return new TestInstance() {

			public TestCase testCase() {
				return null;
			}

			public String description() {
				return null;
			}

			public String instanceName() {
				return params.get(0);
			}

			public TestIteration[] iterations() {
				return null;
			}

			public String folderPath() {
				return params.get(1);
			}
		};
	}
	
	public static void updateSummary() throws Exception {
		String filePath = Harness.GCONFIG.get("RunHome") + "\\"+"Summary.json";
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader(filePath));
		JSONObject jsonObject = (JSONObject) obj;
		jsonObject.put("status", "completed");
		FileWriter FR = new FileWriter(filePath);
		FR.write(jsonObject.toJSONString());
		FR.close();
	}
	
	public ArrayList<Map> testcaseMap = new ArrayList<Map>();
	JSONObject testSetObj = new JSONObject();
	private String testsetname = "";
}
