/******************************************************************************
$Id : TestSetRunner.java 12/23/2016 4:08:21 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
 ******************************************************************************/

package cbf.runner;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import cbf.engine.TestCaseRunner.TCMaker;
import cbf.engine.TestResult;
import cbf.harness.Harness;
import cbf.harness.TestSetAccess;
import cbf.model.TestCase;
import cbf.model.TestCaseAccess;
import cbf.model.TestSet;
import cbf.plugin.PluginManager;
import cbf.utils.LogUtils;
import cbf.utils.StringUtils;
import cbf.utils.Utils;

public class TestSetRunner {

	/**
	 * Main method to start the execution
	 * 
	 * @param args
	 *            command line arguments
	 */
	public static void main(String args[]) {
		LinkedHashMap<String, String> runMap = new Utils()
				.parseCommandLineArgs(args);
		if (!runMap.containsKey("configFilePath")) {
			System.out
					.println("Error:Parameter 'configFilePath' must be defined");
			logger.handleError("Parameter 'configfilepath' must be defined");
		}
		logger.trace("Arguments", args, runMap);
		harness = new Harness(runMap, runMap.get("testSetSheet"));
		runner = new TestSetRunner();
		runner.runTestSet();
		harness.finalize();
	}

	/**
	 * Run the test set from parameters
	 * 
	 * @param runMap
	 *            command line arguments
	 * @param harness
	 * 
	 */

	private void runTestSet() {
		TestSet ts = TestSetAccess.instantiate();
		
		tsCount = ts.testInstanceCount();
		for (int ix = 0; ix < tsCount; ix++) {
			if (ix > 0) { // delay between 2 test cases
				delayTestCase();
			}

			Map<String, String> instanceMap = new HashMap<String, String>();

			instanceMap.put("folderPath", ts.testInstance(ix).folderPath());
			instanceMap.put("instanceName", ts.testInstance(ix).instanceName());

			try {
				TestResult result = runner.runTestInstance(instanceMap);
			} catch (Exception e) {
				logger.handleError(
						"Unknown error during testinstance execution ", e, " ",
						ix, " ", instanceMap);
			}
		}
	}

	private void delayTestCase() {
		int interTcDelay;
		interTcDelay = Integer.parseInt((String) Harness.GCONFIG
				.get("InterTestCaseDelay"));
		if (interTcDelay != 0) {
			try {
				Thread.sleep(interTcDelay * 1000);
				logger.trace("Test case delay:" + interTcDelay);
			} catch (InterruptedException e) {
				logger.handleError("Exception caught in delay test case : ", e,
						interTcDelay);
			}
		}
	}

	private TestResult runTestInstance(final Map<String, String> instanceMap) {
		final String instanceName = instanceMap.get("instanceName");

		TCMaker tcMaker = new TCMaker() {
			public TestCase make() throws Exception {
				return getTestCase(instanceMap);
			}

			public String toString() {
				return instanceName;
			}
		};
		return harness.runTest(tcMaker, instanceName);
	}

	private TestCase getTestCase(Map<String, String> instanceMap) {
		logger.trace("GetTestCase(), instanceMap");
		try {
			return getTestCaseAccess().getTestCase(instanceMap);
		} catch (ClassCastException e) {
			logger.handleError("Error in building test case from ",
					instanceMap, e);
		}
		return null;
	}

	private TestCaseAccess getTestCaseAccess() {
		if (testCaseAccess != null)
			return testCaseAccess;
		Map<String, Object> pluginParams = null;
		try {
			pluginParams = (Map<String, Object>) Harness.GCONFIG
					.get("TestCaseAccess");
			if (pluginParams == null) {
				logger.handleError("TestCaseAccess is not configured; cannot build test case");
			}
			testCaseAccess = (TestCaseAccess) PluginManager
					.getPlugin(pluginParams);
		} catch (ClassCastException e) {
			logger.handleError("'TestCaseAccess' is not configured correctly",
					pluginParams, e);
		}

		return testCaseAccess;
	}

	/**
	 * Returns TestSetRunner format string
	 */
	public String toString() {
		return StringUtils.mapString(this, harness);
	}

	/**
	 * @CHECKME: check if harness can be privatized
	 */
	public static Harness harness;
	private TestCaseAccess testCaseAccess = null;
	private boolean flag;
	private static LogUtils logger = new LogUtils("TestSetRunner");
	private static TestSetRunner runner;
	public LinkedHashMap<String, String> runMap;
	public static int tsCount=0;

}
