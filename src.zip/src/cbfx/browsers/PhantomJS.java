/******************************************************************************
$Id : PhantomJS.java 12/23/2016 4:08:50 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/
package cbfx.browsers;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import cbf.utils.LogUtils;
import cbf.utils.StringUtils;

public class PhantomJS implements Browser {

	/**
	 * Constructor to initialise browser related parameters
	 * 
	 * @param parameters
	 * 
	 */

	public PhantomJS(Map parameters) {

		this.params = parameters;
	}

	/**
	 * Loads Phantom js driver
	 * 
	 * @return Phantom js  driver instance
	 */

	public WebDriver openDriver() {
		System.setProperty("phantomjs.binary.path",
				(String) params.get("browserdriver") + "phantomjs.exe");
		ArrayList<String> cliArgsCap = new ArrayList<String>();
		DesiredCapabilities capabilities = DesiredCapabilities.phantomjs();
		capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS,
				cliArgsCap);
		capabilities.setJavascriptEnabled(true);

		try {
			PhantomJSDriver = new PhantomJSDriver(capabilities);
		} catch (Exception e) {
			logger.handleError("Failed to read browser details ", e);
		}
		return PhantomJSDriver;
	}

	/**
	 * Quits chrome driver
	 * 
	 */

	public void closeDriver() {
		PhantomJSDriver.quit();
	}

	/**
	 * Overriding toString() method to return Chrome format string
	 */
	public String toString() {
		return StringUtils.mapString(this);
	}

	private Map params;
	private PhantomJSDriver PhantomJSDriver;
	private static LogUtils logger = new LogUtils();
}
