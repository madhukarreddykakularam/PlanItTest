/******************************************************************************
$Id : BaseWebAppDriver.java 12/23/2016 4:08:49 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbfx.basedrivers;

import java.util.ArrayList;
import java.util.Map;

import cbf.engine.BaseAppDriver;

import cbfx.selenium.WebUIDriver;
import cbfx.selenium.WebUIDriver;


/**
 * Manages the loading of tool specificapplication drivers
 * 
 * 
 */
abstract public class BaseWebAppDriver extends BaseAppDriver {

	public static WebUIDriver uiDriver;
	

	/**
	 * initialize WebDriver
	 */
	public BaseWebAppDriver(Map params) {

		loadDrivers(params);
	}

	private void loadDrivers(Map params) {
		Object obj = params.get("UIDrivers");
		ArrayList<Map<String, Object>> list = (ArrayList<Map<String, Object>>) obj;
		for (Map<String, Object> map : list) {

			String plugin = (String) map.get("plugin");
			switch (plugin) {
			case "Selenium":
				Map browserparams = (Map) map.get("value");
				uiDriver = new WebUIDriver(browserparams);
				break;
		/*	case "Seetest":
				Map Clientparams = (Map) map.get("value");
				seetestuiDriver = new SeetestUIDriver(Clientparams);
				break;*/
			default:
				logger.handleError("Invalid UI Driver plugin :", plugin);
				break;
			}
		}

	}

	/**
	 * close browsers
	 */
	public void recover() {
		if (uiDriver != null)
			uiDriver.closeBrowsers();
	}
}
