/******************************************************************************
$Id : TableHandler.java 12/23/2016 4:09:01 PM
Copyright � 2016 Capgemini Group of companies. All rights reserved
(Subject to Limited Distribution and Restricted Disclosure Only.)
THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
INFORMATION OF CAPGEMINI GROUP OF COMPANIES AND IS INTENDED FOR USE
ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
DISCLOSURE UNDER APPLICABLE LAW.
YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
CONDITIONS OF AN AGREEMENT BETWEEN YOU AND CAPGEMINI GROUP OF COMPANIES.
The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
RESTRICTED AS SET FORTH THEREIN.
******************************************************************************/

package cbfx.selenium;

import static cbf.engine.TestResultLogger.*;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cbf.utils.LogUtils;
import cbf.utils.StringUtils;
import cbfx.objectmaps.ObjectMap;

/**
 * Selenium wrapper to handle table related functionalities
 * 
 *
 */
public class TableHandler {

	/**
	 * For assigning driver instance to the class
	 */

	public TableHandler(WebUIDriver driver) {
		this.driver = driver;
	}

	private WebElement getWebElement(String elementName) {
		WebElement tableElement = null;
		try {

			tableElement = driver.getControl(elementName);

		} catch (Exception e) {
			logger.handleError("Failed to get WebElement ", elementName);
		}
		return tableElement;
	}

	/**
	 * For getting total number of columns in table
	 * 
	 * @param elementName
	 *            Element name for table locator
	 * @return number of columns
	 */

	public int getColumnCount(String elementName) {
		int col_count = 0;

		try {
			col_count = getWebElement(elementName).findElements(
					By.tagName("td")).size();
		} catch (Exception e) {
			logger.handleError("Failed to get row count for ", elementName);
		}
		return col_count;
	}

	/**
	 * For getting total number of rows in table
	 * 
	 * @param elementName
	 *            Element name for table locator
	 * @return number of rows
	 */
	public int getRowCount(String elementName) {
		int row_count = 0;
		try {
			row_count = getWebElement(elementName).findElements(
					By.tagName("tr")).size();

		} catch (Exception e) {
			logger.handleError("Failed to get row count for ", elementName);
		}
		return row_count;
	}

	/**
	 * For getting total number of columns for particular row in table
	 * 
	 * @param elementName
	 *            table element name
	 * @return number of columns in a row
	 */

	public int getColumnCountOfRow(String elementName) {
		WebElement tableElement = getWebElement(elementName);

		List<WebElement> td_collection = tableElement.findElement(
				By.tagName("tr")).findElements(By.tagName("td"));
		try {
			if (td_collection.size() == 0) {
				td_collection = tableElement.findElement(By.tagName("tr"))
						.findElements(By.tagName("th"));
			}
		} catch (Exception e) {
			logger.handleError("Failed to get column count for ", tableElement);
		}
		return td_collection.size();
	}

	/**
	 * For getting an object of the table by matching the name with given text
	 * 
	 * @param textTosearch
	 *            Name of the table you want to search
	 * @return Object of table
	 */
	public WebElement getTableObjectByText(String textTosearch) {
		List<WebElement> tablecollection = webDr.findElements(By
				.tagName("table"));
		int FinalIndex = 0;
		try {
			for (int i = 0; i < tablecollection.size(); i++) {
				if (tablecollection.get(i).getText().contains(textTosearch)) {
					FinalIndex = i;
					break;
				}
				if (i == tablecollection.size() - 1) {
					failed("FAIL", "The table does not exist",
							"The table with the given text,'" + textTosearch
									+ "' is not present");
				}
			}
		} catch (Exception e) {
			logger.handleError("Failed to get text ", textTosearch, "for ",
					textTosearch, " ", e);
		}
		return tablecollection.get(FinalIndex);
	}

	/**
	 * For getting data of particular cell
	 * 
	 * @param elementName
	 *            Element of the table
	 * @param row
	 *            Row number
	 * @param col
	 *            Column number
	 * @return data of that particular cell
	 */

	public String getCellData(String elementName, int row, int col) {
		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By
				.tagName("tr"));
		int row_num = 0;
		String Data = null;
		try {
			for (WebElement trElement : tr_Collection) {

				if (row_num == row) {
					List<WebElement> td_collection = trElement.findElements(By
							.tagName("td"));

					if (td_collection.size() == 0) {
						td_collection = trElement
								.findElements(By.tagName("th"));
					}
					Data = td_collection.get(col).getText();

					break;
				}

				row_num++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to get cell data for ", tableElement,
					" ", e);
		}
		return Data;
	}

	/**
	 * For getting data of particular cell
	 * 
	 * @param elementName
	 *            Element of the table
	 * @param row
	 *            Row number
	 * @param colName
	 *            Column name
	 * @return data of that particular cell
	 */

	public String getCellData(String elementName, int row, String colName) {
		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By
				.tagName("tr"));
		int row_num = 0;
		int col_num = 0;
		String Data = null;
		try {
			for (WebElement trElement : tr_Collection) {
				if (row_num == 0) {
					List<WebElement> td_col = trElement.findElements(By
							.tagName("td"));
					if (td_col.size() == 0) {
						td_col = trElement.findElements(By.tagName("th"));
					}
					for (int i = 0; i < td_col.size(); i++) {
						if (td_col.get(i).getText().contains(colName)) {
							col_num = i;
							break;
						}
					}
				}

				if (row_num == row) {
					List<WebElement> td_collection = trElement.findElements(By
							.tagName("td"));
					Data = td_collection.get(col_num).getText();
					break;
				}

				row_num++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to get cell data for ", tableElement,
					" ", e);
		}
		return Data;

	}

	/**
	 * For getting data of particular cell
	 * 
	 * @param elementName
	 *            Element of the table
	 * @param rowName
	 *            Row name
	 * @param colName
	 *            Column name
	 * @return data of that particular cell
	 */
	public String getCellData(String elementName, String rowName, String colName) {

		WebElement tableElement = getWebElement(elementName);
		List<WebElement> tr_Collection = tableElement.findElements(By
				.tagName("tr"));
		int row_num = 0;
		int col_num = 0;

		String Data = null;
		try {
			for (WebElement trElement : tr_Collection) {
				if (row_num == 0) {
					List<WebElement> td_col = trElement.findElements(By
							.tagName("td"));

					for (int i = 0; i < td_col.size(); i++) {
						if (td_col.get(i).getText().contains(colName)) {
							col_num = i;
							break;
						}
					}
				}
				List<WebElement> td_col = trElement.findElements(By
						.tagName("td"));
				if (td_col.get(0).getText().contains(rowName)) {
					Data = td_col.get(col_num).getText();
					break;
				}
				row_num++;
			}
		} catch (Exception e) {
			logger.handleError("Failed to get cell data for ", tableElement,
					" ", e);
		}

		return Data;

	}

	/**
	 * To retrieve the data of a cell in dynamic table
	 * 
	 * @param elementName
	 *            table element
	 * @param searchName
	 *            unique text to identify the corresponding cell and the row
	 *            number
	 * @param columnNumber
	 *            column number
	 * @return cell data
	 */
	public String getRelativeCellData(String elementName, String searchName,
			int columnNumber) {
		int row_count = 0;
		String cellData = null;

		WebElement tableElement = getWebElement(elementName);
		List<WebElement> allRows = tableElement.findElements(By.tagName("tr"));
		try {
			for (WebElement row : allRows) {
				int col_count = 0;
				List<WebElement> cells = row.findElements(By.tagName("td"));
				for (WebElement cell : cells) {
					if (cell.getText().equals(searchName)) {
						cellData = getCellData(elementName, row_count,
								columnNumber);
						break;
					}

					col_count++;
				}
				row_count++;
			}

		} catch (Exception e) {
			logger.handleError("getRelativeCellData ", elementName);

		}
		return cellData;
	}

	/**
	 * To retrieve the data of a cell in dynamic table and click on it
	 * 
	 * @param elementName Element name for table locator 
	 * 
	 * @return Number of rows
	 */
	public String findRelativeCellAndClick(String elementName,
			String searchName, int columnNumber, String text) {
		int row_count = 0;
		String cellData = null;

		WebElement tableElement = getWebElement(elementName);
		List<WebElement> allRows = tableElement.findElements(By.tagName("tr"));
		try {
			for (WebElement row : allRows) {
				int col_count = 0;
				List<WebElement> cells = row.findElements(By.tagName("td"));
				for (WebElement cell : cells) {
					if (cell.getText().equals(searchName)) {
						cellData = getCellData(elementName, row_count,
								columnNumber);
						if (cellData.equals(text)) {
							clickCell(cell);
						}
						break;
					}

					col_count++;
				}

				row_count++;
				if (cellData != null) {
					break;
				}

			}

		} catch (Exception e) {
			logger.handleError("getRelativeCellData ", elementName);

		}
		return cellData;
	}

	private void clickCell(WebElement element) {

		element.click();

	}

	/**
	 * Overriding toString() method to return TableHandler format string
	 */
	public String toString() {
		return StringUtils.mapString(this);
	}

	private LogUtils logger = new LogUtils(this);
	private WebDriver webDr;
	private ObjectMap objMap;
	private WebUIDriver driver;
}
