package com.nbcu.sphere;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.util.logging.Level;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.nbcu.sphere.ConfigManager.FileLocSetter;
     
    public class Test1{
        public WebDriver driver;
         
      @Test
      public void openBrowser() throws Exception {
    	  //driver = new FirefoxDriver();
    	
    	
    	//  System.setProperty("webdriver.chrome.driver","C://Automation_Workspace_Profile//SphereAutomation1//chromedriver.exe");
    	  System.setProperty("webdriver.chrome.driver","C://Automation_Workspace//SphereAutomation1//chromedriver.exe");
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			options.addArguments("--disable-extensions"); 
			capabilities.setCapability("chrome.binary","C://Automation_Workspace//SphereAutomation1//chromedriver.exe");
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);  
			/////////////////////////////////Console Logs///////////////////////////////////////
			LoggingPreferences logPrefs = new LoggingPreferences();
	        logPrefs.enable(LogType.BROWSER, Level.ALL);
	        capabilities.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
			/////////////////////////////////////////////////////////////////////////
			driver = new ChromeDriver(capabilities);
    	  
    	  driver.manage().window().maximize();
    	  driver.get("http://www.google.com");
    	  try{
                //the below statement will throw an exception as the element is not found, Catch block will get executed and takes the screenshot.
    		  Thread.sleep(5000);
    		  driver.findElement(By.id("testing")).sendKeys("test");
                 
                   //if we remove the below comment, it will not return exception and screen shot method will not get executed.
    		  //driver.findElement(By.id("gbqfq")).sendKeys("test");
    	  }
    	  catch (Exception e){
    		  System.out.println("I'm in exception");
//calls the method to take the screenshot.
    		  getscreenshot();
     	  }
      }
      
      public void getscreenshot() throws Exception 
      {
              File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
           //The below method will save the screen shot in d drive with name "screenshot.png"
              FileUtils.copyFile(scrFile, new File("C:\\screenshot.png"));
      }
 }