package com.nbcu.sphere;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nbcu.sphere.Common.BusinessFunctionLibrary;
import com.nbcu.sphere.Common.GenericFunctionLibrary;
import com.nbcu.sphere.ObjectRepository.SphereCommon;
import com.nbcu.sphere.ObjectRepository.SphereModules;
import com.nbcu.sphere.ReportManager.Reporter;
import com.nbcu.sphere.UtilManager.AppMessages;

public class SAPValidation extends TestDriver {
	SphereModules objSphereModules = new SphereModules();
	SphereCommon objSphereCommon = new SphereCommon();
	AppMessages objAppMessages = new AppMessages();
	BusinessFunctionLibrary objBusinessLib = new BusinessFunctionLibrary();
	GenericFunctionLibrary objGenericFunctionLibrary = new GenericFunctionLibrary();
	
	
	@SuppressWarnings("static-access")
	public Reporter TC1420(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying headers list on View QueueLogging page", "", "", "");
			
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			
			fnVerifyHeaders(arrHeaderColumns,0,"Request Timestamp");
			fnVerifyHeaders(arrHeaderColumns,1,"Status");
			fnVerifyHeaders(arrHeaderColumns,2,"Customer Number");
			fnVerifyHeaders(arrHeaderColumns,3,"Deal Number");
			fnVerifyHeaders(arrHeaderColumns,4,"System");
			
			Thread.sleep(4000);			
			//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
			HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetQueueTableData(objSphereModules.Common_ViewQueueLogging_Table_xp);
			System.out.println("Hello");
			
			String sQuery = objSQLConfig.sQueuelogging_viewAllQueuelogging_Query;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
			
			
			
			System.out.println(mTableDataUI.size());
			Boolean bResultFlag = true;
			
			//mTableDataDB.equals(mTableDataDB);
			for(int i=1;i<=mTableDataUI.size(); i++)
			{
				//String sDealnumberDB = mTableDataDB.get(i).get(4).toString().trim();
				//System.out.println("DB Deal value\t:"+ sDealnumberDB);
                for(int j=1; j<=mTableDataDB.size();j++)
                {
				String sSystemnameDB = mTableDataDB.get(i).get(5).toString().trim();
				System.out.println("DB systemNamevalue\t:"+ sSystemnameDB);
				
				//String sSystemDealUI=mTableDataUI.get(i).get(3).toString();
				//System.out.println("UI Deal value\t:"+ sSystemDealUI);
				String sSystemnameUI=mTableDataUI.get(i).get(4).toString();
				System.out.println("UI Systemname value\t:"+ sSystemnameUI);
				
				//if((!sSystemDealUI.equals(sDealnumberDB))||(!sSystemnameUI.equals(sSystemnameDB)))
				if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
				{
					bResultFlag = false;
					obj.repAddData( "Compare record for Queue logging record : ", "Record on UI and DB should match for Queue logging : ", "Validation failed for deal Number : \t systemname: "+sSystemnameUI, "Fail");
				    break;
				}
				
                }
			}

			if(bResultFlag == true)
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" queuelogging records displayed on the screen", "All queuelogging records on UI should match with DB records", "UI and DB validation successful for all queuelogging records", "Pass");
			}
			else
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" queuelogging records displayed on the screen", "All queuelogging records on UI should match with DB records", "UI and DB validation failed for all queuelogging records", "Fail");
			}
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
		}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC1388 Failed!", e );
			}			
	
finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC1420 Completed");
		}
		return obj;
		} //End of Script TC1420		
	
	@SuppressWarnings("static-access")
	public Reporter TC171(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying headers list on View QueueLogging page", "", "", "");
			
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
			Thread.sleep(4000);
			
			//objBusinessLib.fnVerifyHubQueueViewRecordswithDB(objSphereModules.Common_ViewQueueLogging_Table_xp,objSQLConfig.sQueuelogging_CompleteView_Query,"Complete",objSphereModules.Common_ViewModules_LinkComplete_Xp);
			//objBusinessLib.fnVerifyHubQueueViewRecordswithDB(objSphereModules.Common_ViewQueueLogging_Table_xp,objSQLConfig.sQueuelogging_Failure_Query,"Failure",objSphereModules.Common_ViewModules_LinkFailure_Xp);
			//objBusinessLib.fnVerifyHubQueueViewRecordswithDB(objSphereModules.Common_ViewQueueLogging_Table_xp,objSQLConfig.sQueuelogging_Error_Query,"Failure",objSphereModules.Common_ViewModules_LinkError_Xp);
			
			
	}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC171 Failed!", e );
			}			
	
       finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC171 Completed");
		}
		return obj;
		} //End of Script TC171		
	
	@SuppressWarnings("static-access")
	public Reporter TC1440(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying headers list on View QueueLogging page", "", "", "");
			
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
			ClickByXpath(SphereModules.Common_ViewModules_LinkFailure_Xp, "failure", true);
									
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Request Timestamp");
			fnVerifyHeaders(arrHeaderColumns,1,"Status");
			fnVerifyHeaders(arrHeaderColumns,2,"Customer Number");
			fnVerifyHeaders(arrHeaderColumns,3,"Deal Number");
			fnVerifyHeaders(arrHeaderColumns,4,"System");
			
			obj.repAddData( "Verifying failure records  of QueueLogging", "", "", "");
			
			Thread.sleep(4000);			
			//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
			HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetQueueTableData(objSphereModules.Common_ViewQueueLogging_Table_xp);
			System.out.println("Hello");
			
			String sQuery = objSQLConfig.sQueuelogging_Failure_Query;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			System.out.println(mTableDataUI.size());
			Boolean bResultFlag = true;
			
			//mTableDataDB.equals(mTableDataDB);
			for(int i=1;i<=mTableDataUI.size(); i++)
			{
				String sSystemnameDB = mTableDataDB.get(i).get(5).toString().trim();
				System.out.println("DB systemNamevalue\t:"+ sSystemnameDB);
				String sSystemnameUI=mTableDataUI.get(i).get(5).toString();
				System.out.println("UI Systemname value\t:"+ sSystemnameUI);
				
				//String sDealNumber = mTableDataUI.get(i).get(1).toString();
				System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
				if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
				{
					bResultFlag = false;
					obj.repAddData( "Compare record for Queue logging record : ", "Record on UI and DB should match for Queue logging : ", "Validation failed for systemname : \t systemname: "+sSystemnameUI, "Fail");
				}
				
			
			}

			if(bResultFlag == true)
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" queuelogging records displayed on the screen", "All queuelogging records on UI should match with DB records", "UI and DB validation successful all queuelogging records", "Pass");
			}
			else
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" queuelogging records displayed on the screen", "All queuelogging records on UI should match with DB records", "UI and DB validation failed for all queuelogging records", "Fail");
			}
			
			
			
		}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC1388 Failed!", e );
			}			
	
finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC1440 Completed");
		}
		return obj;
		} //End of Script TC1440		
	
	@SuppressWarnings("static-access")
	public Reporter TC1450(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying headers list on View QueueLogging page", "", "", "");
			
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
			ClickByXpath(SphereModules.Common_ViewModules_LinkError_Xp, "Error", true);
									
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Request Timestamp");
			fnVerifyHeaders(arrHeaderColumns,1,"Status");
			fnVerifyHeaders(arrHeaderColumns,2,"Customer Number");
			fnVerifyHeaders(arrHeaderColumns,3,"Deal Number");
			fnVerifyHeaders(arrHeaderColumns,4,"System");
			
			obj.repAddData( "Verifying error records  of QueueLogging", "", "", "");
			
			Thread.sleep(4000);			
			//HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewNationalAccountModule_Table_xp+"/tbody");
			HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetQueueTableData(objSphereModules.Common_ViewQueueLogging_Table_xp);
			System.out.println("Hello");
			
			String sQuery = objSQLConfig.sQueuelogging_Error_Query;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			System.out.println(mTableDataUI.size());
			Boolean bResultFlag = true;
			
			//mTableDataDB.equals(mTableDataDB);
			for(int i=1;i<=mTableDataUI.size(); i++)
			{

				String sSystemnameDB = mTableDataDB.get(i).get(5).toString().trim();
				System.out.println("DB systemNamevalue\t:"+ sSystemnameDB);
				
				//String sSystemDealUI=mTableDataUI.get(i).get(3).toString();
				//System.out.println("UI Deal value\t:"+ sSystemDealUI);
				String sSystemnameUI=mTableDataUI.get(i).get(5).toString();
				System.out.println("UI Systemname value\t:"+ sSystemnameUI);
				System.out.println(mTableDataUI.get(i).equals(mTableDataDB.get(i)));
				if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
				{
					bResultFlag = false;
					obj.repAddData( "Compare record for Queue logging record : ", "Record on UI and DB should match for Queue logging : ", "Validation failed for systemname : \t systemname: "+sSystemnameUI, "Fail");
				}
				
			
			}

			if(bResultFlag == true)
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" queuelogging records displayed on the screen", "All queuelogging records on UI should match with DB records", "UI and DB validation successful for all queuelogging records", "Pass");
			}
			else
			{
				obj.repAddData( "Compare all "+mTableDataUI.size()+" queuelogging records displayed on the screen", "All queuelogging records on UI should match with DB records", "UI and DB validation failed for all queuelogging records", "Fail");
			}
			
			
			
		}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC1450 Failed!", e );
			}			
	
finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC1450Completed");
		}
		return obj;
		} //End of Script TC1450		
	
	
	/*@SuppressWarnings("static-access")
	public Reporter TC1460(Reporter obj) throws Exception
	{
		try {
			obj.repAddData( "Verifying pagination on  QueueLogging page", "", "", "");
					
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));		
			Thread.sleep(2000);
			fnCheckFieldDisplayByXpath(SphereModules.Common_View_pagination_groupText_xp, "Showing items" , true,true);
			Thread.sleep(2000);
			fnCheckFieldDisplayByXpath(SphereModules.Common_ViewQueueLogging_pagination_dropDown_xp,"20 per page",true,true);
			Thread.sleep(2000);
			fnCheckFieldDisplayByXpath(SphereModules.Common_ViewQueueLogging_pagination_numbersequence_xp,"page number sequence",true,true);
						
	
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC1460 Failed!", e );
		}			

finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

/*		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC1460Completed");
	}
	return obj;
	} //End of Script TC1460
	
	
	@SuppressWarnings("static-access")
	public Reporter TC1470(Reporter obj) throws Exception
	{
		try {
			obj.repAddData( "Verifying number per page on  QueueLogging page", "", "", "");
					
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));		
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Common_ViewQueueLogging_pagination_dropDown50_xp,"50",true);
			Thread.sleep(3000);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
			Thread.sleep(2000);
			HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewQueueLogging_Table_xp);
			System.out.println("Hello");
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp));
			List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tr"));  //Get the table data rows
			System.out.println("Data Rows Size>>>>"+arrTableRows.size());
			Boolean bResultFlag=false;
			int rowCount=50;
			if(arrTableRows.size()==rowCount)
				{
					bResultFlag=true;
					
					obj.repAddData( "Total "+arrTableRows.size()+" queuelogging records displayed on the screen", "All queuelogging records count should match with page option", "UI validation  for queuelogging records count successful   ", "pass");
				}
				/*if(!mTableDataUI.get(i).equals(mTableDataDB.get(i)))
				{
					bResultFlag = false;
			}		obj.repAddData( "Compare record for Queue logging record : ", "Record on UI and DB should match for Queue logging : ", "Validation failed for deal account number : " , "Fail");
				//}*/
			/*	else/
				{
					obj.repAddData( "Total "+arrTableRows.size()+" queuelogging records displayed on the screen", "All queuelogging records count should match with page option", "UI validation  for queuelogging records count not successful   ", "Fail");
			
				}
				
				
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC1470 Failed!", e );
		}			

finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

	/*	if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC1470Completed");
	}
	return obj;
	} //End of Script TC1470
	
	
	@SuppressWarnings("static-access")
	public Reporter TC1480(Reporter obj) throws Exception
	{
		try {
			obj.repAddData( "Verifying number per page on  QueueLogging page", "", "", "");
					
			//objBusinessLib.fnClickMainMenuElement("Administration");
			objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));		
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Common_ViewQueueLogging_pagination_dropDown100_xp,"100",true);
			Thread.sleep(3000);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
			Thread.sleep(2000);
			HashMap<Integer, HashMap<Integer, String>> mTableDataUI = fnGetTableData(objSphereModules.Common_ViewQueueLogging_Table_xp);
			System.out.println("Hello");
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp));
			List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tr"));  //Get the table data rows
			System.out.println("Data Rows Size>>>>"+arrTableRows.size());
			//Boolean bResultFlag=false;
			int rowCount=100;
			/*for(int i=1;i<=arrTableRows.size(); i++)
			{
				String record = arrTableRows.get(1).toString();
				//System.out.println(arrTableRows.get(i));
			}*/
			/*	if(arrTableRows.size()==rowCount)
				{
					//bResultFlag=true;
				obj.repAddData( "Total "+arrTableRows.size()+" queuelogging records displayed on the screen", "All queuelogging records count should match with page option", "UI validation  for queuelogging records count successful   ", "pass");
				    
				}
				else
				{
					obj.repAddData( "Total "+arrTableRows.size()+" queuelogging records displayed on the screen", "All queuelogging records count should match with page option", "UI validation  for queuelogging records count not successful   ", "Fail");

				}
				
			
	
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC1480 Failed!", e );
		}			

finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		/*if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC1480Completed");
	}
	return obj;
	} //End of Script TC1480
	public Reporter TC1490(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC1490 Started..");

		try {
								
				objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
				WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
				//String sTableXPath = SphereModules.Common_ViewQueueLogging_Table_xp;
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewQueueLogging_Table_xp)));
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_Xp)));
				Thread.sleep(6000);
				ClickByXpath(SphereModules.Common_ViewModules_LinkAll_Xp, "All Link", true);
				Thread.sleep(8000);
				objBusinessLib.fnVerifyCustSearchFilterData(SphereModules.Common_ViewQueueLogging_Table_xp,"complete","complete",1);
				objBusinessLib.fnVerifyCustSearchFilterData(SphereModules.Common_ViewQueueLogging_Table_xp,"failure","failure",1);						
				objBusinessLib.fnVerifyCustSearchFilterData(SphereModules.Common_ViewQueueLogging_Table_xp,"error","error",1);						
				
			}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC1490 Failed!", e );
		}
		finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

		/*	if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC1490 Completed");
		}
		return obj;
	} //End of Script TC136	
	
	public Reporter TC1500(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC1500 Started..");

		try {
								
				objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
				WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
				//String sTableXPath = SphereModules.Common_ViewQueueLogging_Table_xp;
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewQueueLogging_Table_xp)));
				//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_Xp)));
				ClickByXpath(SphereModules.Common_ViewModules_LinkAll_Xp, "All Link", true);
				Thread.sleep(6000);
				//ClickByXpath(SphereModules.Common_ViewModules_LinkAll_Xp, "All Link", true);
				Thread.sleep(8000);
				objBusinessLib.fnVerifyCustSearchFilterData(SphereModules.Common_ViewQueueLogging_Table_xp,"failure","failure",1);
										
										
				
			}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC1500 Failed!", e );
		}
		finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

	/*		if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC1500 Completed");
		}
		return obj;
	} //End of Script TC1500
	
	public Reporter TC1510(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC1510 Started..");

		try {
								
				objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
				WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
				//String sTableXPath = SphereModules.Common_ViewQueueLogging_Table_xp;
				waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewQueueLogging_Table_xp)));
				//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewModules_LinkAll_Xp)));
				Thread.sleep(6000);
				ClickByXpath(SphereModules.Common_ViewModules_LinkAll_Xp, "All Link", true);
				Thread.sleep(8000);
				objBusinessLib.fnVerifyCustSearchFilterData(SphereModules.Common_ViewQueueLogging_Table_xp,"error","error",1);
										
													
			}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC1510 Failed!", e );
		}
		finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			//if(!testCaseStatus)
		/*	{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC1510 Completed");
		}
		return obj;
	} //End of Script TC1510
	*/	
	@SuppressWarnings("static-access")
	public Reporter TC521(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Cost Objects on SAP Validation page", "", "", "");
			
			obj.repAddData( "Verifying all Cost Object Tables on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpChartOfAccountTitle="Chart Of Account";
			String ExpWbseTitle="WBSE";
			String ExpCostCenterTitle="Cost Center";
			String ExpProfitCenterTitle="Profit Center";
			String ExpInternalOrdersTitle="Internal Orders";
			String ExpManualFunds="Manual Funds Commitment";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			fnVerifyLabelMsgTextByXpath(AppMessages.Sap_Validation_Screen_Title_xp, SphereModules.Sap_Validation_Screen_Title_xp);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			SendKeyByXpath(SphereModules.SAP_Validation_Company,"FN09","Company"); 
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			
			obj.repAddData( "Verifying Chart Of Account Table", "", "", "");
			
			/*String ActChartOfAccountTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpChartOfAccountTitle,ActChartOfAccountTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp, "Chart Of Account", true);
		*/	WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_ChartOfAccount_Table_xp));
			List<WebElement> arrHeaderColumns1 = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns1.size());
			fnVerifyHeaders(arrHeaderColumns1,0,"Account Number");
			fnVerifyHeaders(arrHeaderColumns1,1,"Company");
			fnVerifyHeaders(arrHeaderColumns1,2,"Description");
			//objBusinessLib.fnVerifyRecordsWithDB(objSphereModules.Common_View_ChartOfAccount_Table_xp,objSQLConfig.sChartOfAccount_View_Query,"Chart Of Account");
			
		
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC521 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC521 Completed");
		}
		return obj;
		} //End of Script TC521
	
	@SuppressWarnings("static-access")
	public Reporter TC522(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying all Cost Object Tables on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpChartOfAccountTitle="Chart Of Account";
			String ExpWbseTitle="WBSE";
			String ExpCostCenterTitle="Cost Center";
			String ExpProfitCenterTitle="Profit Center";
			String ExpInternalOrdersTitle="Internal Orders";
			String ExpManualFunds="Manual Funds Commitment";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			fnVerifyLabelMsgTextByXpath(AppMessages.Sap_Validation_Screen_Title_xp, SphereModules.Sap_Validation_Screen_Title_xp);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			SendKeyByXpath(SphereModules.SAP_Validation_Company,"FN09","Company"); 
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			
			obj.repAddData( "Verifying Chart Of Account Table", "", "", "");
			
			/*String ActChartOfAccountTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpChartOfAccountTitle,ActChartOfAccountTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp, "Chart Of Account", true);
		*/	WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_ChartOfAccount_Table_xp));
			List<WebElement> arrHeaderColumns1 = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns1.size());
			fnVerifyHeaders(arrHeaderColumns1,0,"Account Number");
			fnVerifyHeaders(arrHeaderColumns1,1,"Company");
			fnVerifyHeaders(arrHeaderColumns1,2,"Description");
			//objBusinessLib.fnVerifyRecordsWithDB(objSphereModules.Common_View_ChartOfAccount_Table_xp,objSQLConfig.sChartOfAccount_View_Query,"Chart Of Account");
			
			obj.repAddData( "Verifying WBSE Table", "", "", "");
			SendKeyByXpath(SphereModules.SAP_Validation_Description,"zzz","Description"); 
			/*String ActWbseTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpWbseTitle,ActWbseTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Title_xp, "WBSE", true);
		*/	WebElement eleTable2 = driver.findElement(By.xpath(objSphereModules.Common_View_WBSE_Table_xp));
			List<WebElement> arrHeaderColumns2 = eleTable2.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns2.size());
			
			fnVerifyHeaders(arrHeaderColumns2,0,"WBS Element");
			fnVerifyHeaders(arrHeaderColumns2,1,"Company");
			fnVerifyHeaders(arrHeaderColumns2,2,"Description");
			fnVerifyHeaders(arrHeaderColumns2,3,"Project");
			//objBusinessLib.fnVerifyRecordsWithDB(objSphereModules.Common_View_WBSE_Table_xp,objSQLConfig.sWbse_View_Query,"WBSE");
			
			obj.repAddData( "Verifying Cost Center Table", "", "", "");
			
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC522 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC522 Completed");
		}
		return obj;
		} //End of Script TC521
	public Reporter TC523(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Cost Object indicator text on SAP Validation page", "", "", "");
		
obj.repAddData( "Verifying all Cost Object Tables on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpChartOfAccountTitle="Chart Of Account";
			String ExpWbseTitle="WBSE";
			String ExpCostCenterTitle="Cost Center";
			String ExpProfitCenterTitle="Profit Center";
			String ExpInternalOrdersTitle="Internal Orders";
			String ExpManualFunds="Manual Funds Commitment";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			fnVerifyLabelMsgTextByXpath(AppMessages.Sap_Validation_Screen_Title_xp, SphereModules.Sap_Validation_Screen_Title_xp);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			SendKeyByXpath(SphereModules.SAP_Validation_Company,"FN09","Company"); 
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			
			obj.repAddData( "Verifying Chart Of Account Table", "", "", "");
			
			/*String ActChartOfAccountTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpChartOfAccountTitle,ActChartOfAccountTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp, "Chart Of Account", true);
		*/	WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_ChartOfAccount_Table_xp));
			List<WebElement> arrHeaderColumns1 = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns1.size());
			fnVerifyHeaders(arrHeaderColumns1,0,"Account Number");
			fnVerifyHeaders(arrHeaderColumns1,1,"Company");
			fnVerifyHeaders(arrHeaderColumns1,2,"Description");
			//objBusinessLib.fnVerifyRecordsWithDB(objSphereModules.Common_View_ChartOfAccount_Table_xp,objSQLConfig.sChartOfAccount_View_Query,"Chart Of Account");
			
			obj.repAddData( "Verifying WBSE Table", "", "", "");
			SendKeyByXpath(SphereModules.SAP_Validation_Description,"zzz","Description"); 
			/*String ActWbseTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpWbseTitle,ActWbseTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Title_xp, "WBSE", true);
		*/	WebElement eleTable2 = driver.findElement(By.xpath(objSphereModules.Common_View_WBSE_Table_xp));
			List<WebElement> arrHeaderColumns2 = eleTable2.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns2.size());
			
			fnVerifyHeaders(arrHeaderColumns2,0,"WBS Element");
			fnVerifyHeaders(arrHeaderColumns2,1,"Company");
			fnVerifyHeaders(arrHeaderColumns2,2,"Description");
			fnVerifyHeaders(arrHeaderColumns2,3,"Project");
			//objBusinessLib.fnVerifyRecordsWithDB(objSphereModules.Common_View_WBSE_Table_xp,objSQLConfig.sWbse_View_Query,"WBSE");
			
			obj.repAddData( "Verifying Cost Center Table", "", "", "");
			
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC523 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC523 Completed");
		}
		return obj;
		} //End of Script TC523	
	public Reporter TC524(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Pagination for all tables on SAP Validation page", "", "", "");
	
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
			
			}
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Sap_Validation_ChartOfAccount_Pagination_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Text_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Next_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Previous_xp,"Chart Of Account");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Sap_Validation_Wbse_Pagination_xp,SphereModules.Sap_Validation_Wbse_Pagination_Text_xp,SphereModules.Sap_Validation_Wbse_Pagination_Next_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Previous_xp,"Wbse");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Sap_Validation_CostCenter_Pagination_xp,SphereModules.Sap_Validation_CostCenter_Pagination_Text_xp,SphereModules.Sap_Validation_CostCenter_Pagination_Next_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Previous_xp,"Cost Center");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Sap_Validation_ProfitCenter_Pagination_xp,SphereModules.Sap_Validation_ProfitCenter_Pagination_Text_xp,SphereModules.Sap_Validation_ProfitCenter_Pagination_Next_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Previous_xp,"Profit Center");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Sap_Validation_InternalOrders_Pagination_xp,SphereModules.Sap_Validation_InternalOrders_Pagination_Text_xp,SphereModules.Sap_Validation_InternalOrders_Pagination_Next_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Previous_xp,"Internal Orders");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Sap_Validation_ManualFunds_Pagination_xp,SphereModules.Sap_Validation_ManualFunds_Pagination_Text_xp,SphereModules.Sap_Validation_ManualFunds_Pagination_Next_xp,SphereModules.Sap_Validation_ChartOfAccount_Pagination_Previous_xp,"Manual Funds Commitment");
		  }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC524 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC524 Completed");
		}
		return obj;
		} //End of Script TC524	
	
	@SuppressWarnings("static-access")
	public Reporter TC525 (Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC525 Started..");

		try {
					
			obj.repAddData( "Verifying  Sorting Functionality of SAP Columns ", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewDealModule_Table_xp)));
			Thread.sleep(4000);
			obj.repAddData( "Verifying Sorting on Chart Of Account table columns  on SAP Validation page", "", "", "");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ChartOfAccount_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_ChartOfAccount_Column_1,"Desc",objSQLConfig.sChartOfAccount_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ChartOfAccount_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_ChartOfAccount_Column_1,"Asc",objSQLConfig.sChartOfAccount_Asc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ChartOfAccount_Table_xp,"Account Number",2,objSphereModules.Sap_Validation_Btn_Sorting_ChartOfAccount_Column_2,"Desc",objSQLConfig.sChartOfAccount_Desc_AcctNumber_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ChartOfAccount_Table_xp,"Account Number",2,objSphereModules.Sap_Validation_Btn_Sorting_ChartOfAccount_Column_2,"Asc",objSQLConfig.sChartOfAccount_Asc_AcctNumber_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ChartOfAccount_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_ChartOfAccount_Column_3,"Desc",objSQLConfig.sChartOfAccount_Desc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ChartOfAccount_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_ChartOfAccount_Column_3,"Asc",objSQLConfig.sChartOfAccount_Asc_Description_Query,"SAP Validation");	
			
			obj.repAddData( "Verifying Sorting on WBSE table columns  on SAP Validation page", "", "", "");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_1,"Desc", objSQLConfig.sWbse_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_1,"Asc",objSQLConfig.sWbse_Asc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"WBS Element",2,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_2,"Desc",objSQLConfig.sWbse_Desc_WBS_ELEMENT_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"WBS Element",2,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_2,"Asc",objSQLConfig.sWbse_Asc_WBS_ELEMENT_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_3,"Desc",objSQLConfig.sWbse_Desc_ShortDesciption_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_3,"Asc", objSQLConfig.sWbse_Asc_ShortDesciption_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"Project",4,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_4,"Desc",objSQLConfig.sWbse_Desc_PROJECT_DEFINITION_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_WBSE_Table_xp,"Project",4,objSphereModules.Sap_Validation_Btn_Sorting_Wbse_Column_4,"Asc",objSQLConfig.sWbse_Asc_PROJECT_DEFINITION_Query,"SAP Validation");
			

			obj.repAddData( "Verifying Sorting on Cost Center table columns  on SAP Validation page", "", "", "");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_CostCenter_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_CostCenter_Column_1,"Desc",objSQLConfig.sCostCenter_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_CostCenter_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_CostCenter_Column_1,"Asc",objSQLConfig.sCostCenter_Asc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_CostCenter_Table_xp,"Cost Center",2,objSphereModules.Sap_Validation_Btn_Sorting_CostCenter_Column_2,"Desc",objSQLConfig.sCostCenter_Desc_CostCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_CostCenter_Table_xp,"Cost Center",2,objSphereModules.Sap_Validation_Btn_Sorting_CostCenter_Column_2,"Asc",objSQLConfig.sCostCenter_Asc_CostCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_CostCenter_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_CostCenter_Column_3,"Desc",objSQLConfig.sCostCenter_Desc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_CostCenter_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_CostCenter_Column_3,"Asc",objSQLConfig.sCostCenter_Asc_Description_Query,"SAP Validation");	
		    

			obj.repAddData( "Verifying Sorting on Profit Center table columns  on SAP Validation page", "", "", "");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ProfitCenter_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_ProfitCenter_Column_1,"Desc",objSQLConfig.sProfitCenter_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ProfitCenter_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_ProfitCenter_Column_1,"Asc",objSQLConfig.sProfitCenter_Asc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ProfitCenter_Table_xp,"Profit Center",2,objSphereModules.Sap_Validation_Btn_Sorting_ProfitCenter_Column_2,"Desc",objSQLConfig.sProfitCenter_Desc_ProfitCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ProfitCenter_Table_xp,"Profit Center",2,objSphereModules.Sap_Validation_Btn_Sorting_ProfitCenter_Column_2,"Asc",objSQLConfig.sProfitCenter_Asc_ProfitCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ProfitCenter_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_ProfitCenter_Column_3,"Desc",objSQLConfig.sProfitCenter_Desc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_ProfitCenter_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_ProfitCenter_Column_3,"Asc",objSQLConfig.sProfitCenter_Asc_Description_Query,"SAP Validation");	
		  

			obj.repAddData( "Verifying Sorting on Internal Orders table columns  on SAP Validation page", "", "", "");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_InternalOrders_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_InternalOrder_Column_1,"Desc",objSQLConfig.sInternalOrders_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_InternalOrders_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_InternalOrder_Column_1,"Asc",objSQLConfig.sInternalOrders_Asc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_InternalOrders_Table_xp,"Internal Order",2,objSphereModules.Sap_Validation_Btn_Sorting_InternalOrder_Column_2,"Desc",objSQLConfig.sInternalOrders_Desc_IntOrder_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_InternalOrders_Table_xp,"Internal Order",2,objSphereModules.Sap_Validation_Btn_Sorting_InternalOrder_Column_2,"Asc",objSQLConfig.sInternalOrders_Asc_IntOrder_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_InternalOrders_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_InternalOrder_Column_3,"Desc",objSQLConfig.sInternalOrders_Desc_ShortText_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_InternalOrders_Table_xp,"Description",3,objSphereModules.Sap_Validation_Btn_Sorting_InternalOrder_Column_3,"Asc",objSQLConfig.sInternalOrders_Asc_ShortText_Query,"SAP Validation");	
		  
			obj.repAddData( "Verifying Sorting on Manual Funds Commitment table columns  on SAP Validation page", "", "", "");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_1,"Desc",objSQLConfig.sManualFundsCommitment_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Company",1,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_1,"Asc",objSQLConfig.sManualFundsCommitment_Asc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Document Number",2,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_2,"Desc",objSQLConfig.sManualFundsCommitment_Desc_DOC_Number_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Document Number",2,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_2,"Asc",objSQLConfig.sManualFundsCommitment_Asc_DOC_Number_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Item",3,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_3,"Desc",objSQLConfig.sManualFundsCommitment_Desc_DOC_Item_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Item",3,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_3,"Asc",objSQLConfig.sManualFundsCommitment_Asc_DOC_Item_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Description",4,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_4,"Desc",objSQLConfig.sManualFundsCommitment_Desc_DOC_Text_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"Description",4,objSphereModules.Sap_Validation_Btn_Sorting_ManualFunds_Column_4,"Asc",objSQLConfig.sManualFundsCommitment_Asc_DOC_Text_Query,"SAP Validation");	
		
		
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC525 Failed!", e );
		}
		finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC525 Completed");
		}
		return obj;
	} //End of Script TC525
	@SuppressWarnings("static-access")
	public Reporter TC777(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying all Cost Objects Records count on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			List<WebElement> arrCostObjects=driver.findElements(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_List_xp));
			String sCostObject = "";
            for(WebElement elesCostObject : arrCostObjects)
            {
            	sCostObject =sCostObject+elesCostObject.getText().trim().toUpperCase() + ",";
				
            }
            sCostObject = sCostObject.trim();	
            String sCostObjectlist =sCostObject.trim(); 
			String [] ActCostObjectlist = sCostObjectlist.split(",");
			String sWBSEValue = ActCostObjectlist[0].toString().trim();
			String sWBSECount = sWBSEValue.substring(sWBSEValue.indexOf("(")+1,sWBSEValue.indexOf(")"));
			String sCostCenterValue = ActCostObjectlist[1].toString().trim();
			String sCostCenterCount = sCostCenterValue.substring(sCostCenterValue.indexOf("(")+1,sCostCenterValue.indexOf(")"));
			String sInternalOrdersValue = ActCostObjectlist[2].toString().trim();
			String sInternalOrdersCount = sInternalOrdersValue.substring(sInternalOrdersValue.indexOf("(")+1,sInternalOrdersValue.indexOf(")"));
			String sChartOfAccountsValue = ActCostObjectlist[3].toString().trim();
			String sChartOfAccountsCount = sChartOfAccountsValue.substring(sChartOfAccountsValue.indexOf("(")+1,sChartOfAccountsValue.indexOf(")"));
			String sProfitCentersValue = ActCostObjectlist[4].toString().trim();
			String sProfitCentersCount = sProfitCentersValue.substring(sProfitCentersValue.indexOf("(")+1,sProfitCentersValue.indexOf(")"));
			String sManualFundsValue = ActCostObjectlist[5].toString().trim();
			String sManualFundsCount = sManualFundsValue.substring(sManualFundsValue.indexOf("(")+1,sManualFundsValue.indexOf(")"));
			
		
			objBusinessLib.fnVerifySAPRecordsCount(objSQLConfig.Wbse_Query,sWBSECount,"WBSE");
			objBusinessLib.fnVerifySAPRecordsCount(objSQLConfig.sInternalOrders_Query,sInternalOrdersCount,"Internal Orders");
			objBusinessLib.fnVerifySAPRecordsCount(objSQLConfig.sChartOfAccount_Query,sChartOfAccountsCount,"Chart Of Account");
			objBusinessLib.fnVerifySAPRecordsCount(objSQLConfig.sCostCenter_Query,sCostCenterCount,"Cost Center");
			objBusinessLib.fnVerifySAPRecordsCount(objSQLConfig.sProfitCenter_Query,sProfitCentersCount,"Profit Center");
			objBusinessLib.fnVerifySAPRecordsCount(objSQLConfig.Manualfunds_Query,sManualFundsCount,"Manual Funds Commitment");
			
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC777 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC777 Completed");
		}
		return obj;
		} //End of Script TC777

	@SuppressWarnings("static-access")
	public Reporter TC356(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Chart of Account Table on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpChartOfAccountTitle="Chart Of Account";
			String ExpText="Search ...";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_CheckBox_xp)).click();
			Thread.sleep(2000);
			obj.repAddData( "Verifying Chart Of Account Table", "", "", "");
			
			String ActChartOfAccountTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpChartOfAccountTitle,ActChartOfAccountTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp, "Chart Of Account", true);
			
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Search_bar_xp,"search bar",true,true);
			
			String ActSearchBarText=TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp)).getAttribute("placeholder");
			fnVerifyLabelMsgText(ExpText, ActSearchBarText.trim());
			
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkAll_xp,"All",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Green_xp,"Green Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkActive_xp,"Active",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Red_xp,"Red Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkInactive_xp,"Inactive",true,true);
			Thread.sleep(2000);
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sChartOfAccount_View_Query,"Chart Of Account");
			
			obj.repAddData( "Verifying Pagination fields", "", "", "");
			
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Common_View_pagination_numbersequence_xp,SphereModules.Common_View_pagination_groupText_xp,SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,"Chart Of Account");
			
			obj.repAddData( "Verifying Sorting on Chart Of Account table columns", "", "", "");
			Thread.sleep(2000);
			
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Account Number",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sChartOfAccount_Desc_AcctNumber_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Account Number",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc",objSQLConfig.sChartOfAccount_Asc_AcctNumber_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sChartOfAccount_Desc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sChartOfAccount_Asc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Desc",objSQLConfig.sChartOfAccount_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Asc",objSQLConfig.sChartOfAccount_Asc_Company_Query,"SAP Validation");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_CheckBox_xp)).click();// post condition
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC356 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC356 Completed");
		}
		return obj;
		} //End of Script TC356
	@SuppressWarnings("static-access")
	public Reporter TC357(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Cost Center Table on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpCostCenterTitle="Cost Center";
			String ExpText="Search ...";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_CostCenter_CheckBox_xp)).click();
			Thread.sleep(2000);
			obj.repAddData( "Verifying Cost Center Table", "", "", "");
			
			String ActCostCenterTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_CostCenter_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpCostCenterTitle,ActCostCenterTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_CostCenter_Title_xp, "Cost Center", true);
			fnCheckFieldDisplayByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_Cost_Center_Indicator_xp,"Indicator K",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Search_bar_xp,"search bar",true,true);
			
			String ActSearchBarText=TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp)).getAttribute("placeholder");
			fnVerifyLabelMsgText(ExpText, ActSearchBarText.trim());
			
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkAll_xp,"All",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Green_xp,"Green Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkActive_xp,"Active",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Red_xp,"Red Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkInactive_xp,"Inactive",true,true);
			Thread.sleep(2000);
			
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Cost Center");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sCostCenter_View_Query,"Cost Center");
			
			obj.repAddData( "Verifying Pagination fields", "", "", "");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Common_View_pagination_numbersequence_xp,SphereModules.Common_View_pagination_groupText_xp,SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,"Cost Center");
			Thread.sleep(2000);
			
			obj.repAddData( "Verifying Sorting on Cost Center table columns", "", "", "");
			
			
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Cost Center",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sCostCenter_Desc_CostCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Cost Center",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc",objSQLConfig.sCostCenter_Asc_CostCenter_Query,"SAP Validation");
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sCostCenter_Desc_Description_Query,"SAP Validation");	
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sCostCenter_Asc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Desc",objSQLConfig.sCostCenter_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Asc",objSQLConfig.sCostCenter_Asc_Company_Query,"SAP Validation");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_CostCenter_CheckBox_xp)).click();// post condition
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC357 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC357 Completed");
		}
		return obj;
		} //End of Script TC357
	@SuppressWarnings("static-access")
	public Reporter TC358(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Profit Center Table on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpProfitCenterTitle="Profit Center";
			String ExpText="Search ...";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ProfitCenter_CheckBox_xp)).click();
			Thread.sleep(2000);
            
			obj.repAddData( "Verifying Profit Center Table", "", "", "");
			
			String ActProfitCenterTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ProfitCenter_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpProfitCenterTitle,ActProfitCenterTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ProfitCenter_Title_xp, "Profit Center", true);
			fnCheckFieldDisplayByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_Profit_Center_Indicator_xp,"Indicator Z",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Search_bar_xp,"search bar",true,true);
			
			String ActSearchBarText=TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp)).getAttribute("placeholder");
			fnVerifyLabelMsgText(ExpText, ActSearchBarText.trim());
			
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkAll_xp,"All",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Green_xp,"Green Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkActive_xp,"Active",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Red_xp,"Red Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkInactive_xp,"Inactive",true,true);
			Thread.sleep(2000);
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Profit Center");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sProfitCenter_View_Query,"Profit Center");
			
			obj.repAddData( "Verifying Pagination fields", "", "", "");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Common_View_pagination_numbersequence_xp,SphereModules.Common_View_pagination_groupText_xp,SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,"Profit Center");
			
			obj.repAddData( "Verifying Sorting on Profit Center table columns", "", "", "");
			
			
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Profit Center",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sProfitCenter_Desc_ProfitCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Profit Center",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc",objSQLConfig.sProfitCenter_Asc_ProfitCenter_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sProfitCenter_Desc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sProfitCenter_Asc_Description_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Desc",objSQLConfig.sProfitCenter_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Asc",objSQLConfig.sProfitCenter_Asc_Company_Query,"SAP Validation");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ProfitCenter_CheckBox_xp)).click();// post condition
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC358 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC358 Completed");
		}
		return obj;
		} //End of Script TC358
	@SuppressWarnings("static-access")
	public Reporter TC359(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Internal Orders Table on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpInternalOrdersTitle="Internal Orders";
			String ExpText="Search ...";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_InternalOrders_CheckBox_xp)).click();
			Thread.sleep(2000);
            
			obj.repAddData( "Verifying Internal Orders Table", "", "", "");
			
            String ActInternalorderTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_InternalOrders_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpInternalOrdersTitle,ActInternalorderTitle);
			
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_InternalOrders_Title_xp, "Internal Orders", true);
			fnCheckFieldDisplayByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_Internal_Order_Indicator_xp,"Indicator W",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Search_bar_xp,"search bar",true,true);
			
			String ActSearchBarText=TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp)).getAttribute("placeholder");
			fnVerifyLabelMsgText(ExpText, ActSearchBarText.trim());
			
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkAll_xp,"All",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Green_xp,"Green Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkActive_xp,"Active",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Red_xp,"Red Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkInactive_xp,"Inactive",true,true);
			Thread.sleep(2000);
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Internal Order");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sInternalOrders_View_Query,"Internal Orders");
			
			obj.repAddData( "Verifying Pagination fields", "", "", "");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Common_View_pagination_numbersequence_xp,SphereModules.Common_View_pagination_groupText_xp,SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,"Internal Orders");
			
			obj.repAddData( "Verifying Sorting on Internal Orders table columns  on SAP Validation page", "", "", "");
			
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Internal Order",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sInternalOrders_Desc_IntOrder_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Internal Order",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc",objSQLConfig.sInternalOrders_Asc_IntOrder_Query,"SAP Validation");
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sInternalOrders_Desc_ShortText_Query,"SAP Validation");	
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sInternalOrders_Asc_ShortText_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Desc",objSQLConfig.sInternalOrders_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Asc",objSQLConfig.sInternalOrders_Asc_Company_Query,"SAP Validation");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_InternalOrders_CheckBox_xp)).click();// post condition
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC359 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC359 Completed");
		}
		return obj;
		} //End of Script TC359
	@SuppressWarnings("static-access")
	public Reporter TC360(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Manual Funds Table on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpManualFunds="Manual Funds Commitment";
			String ExpText="Search ...";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFundsCommitement_CheckBox_xp)).click();
			Thread.sleep(2000);
			
			String ActManualFunds =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpManualFunds,ActManualFunds);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp, "Manual Funds Commitment", true);
			fnCheckFieldDisplayByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Indicator_xp,"Indicator M",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Search_bar_xp,"search bar",true,true);
			
			String ActSearchBarText=TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp)).getAttribute("placeholder");
			fnVerifyLabelMsgText(ExpText, ActSearchBarText.trim());
			
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkAll_xp,"All",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Green_xp,"Green Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkActive_xp,"Active",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Red_xp,"Red Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkInactive_xp,"Inactive",true,true);
			Thread.sleep(2000);
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Document Number - Item");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sManualFundsCommitment_View_Query,"Manual Funds Commitment");
			
			obj.repAddData( "Verifying Pagination fields", "", "", "");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Common_View_pagination_numbersequence_xp,SphereModules.Common_View_pagination_groupText_xp,SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,"Manual Funds Commitment");
			
			obj.repAddData( "Verifying Sorting on Manual Funds Commitment table columns", "", "", "");
			
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Document Number - Item",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sManualFundsCommitment_Desc_DOC_Number_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Document Number - Item",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc",objSQLConfig.sManualFundsCommitment_Asc_DOC_Number_Query,"SAP Validation");
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Item",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sManualFundsCommitment_Desc_DOC_Item_Query,"SAP Validation");	
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Item",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc",objSQLConfig.sManualFundsCommitment_Asc_DOC_Item_Query,"SAP Validation");	
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",4,objSphereModules.Common_Btn_Sorting_Column_4,"Desc",objSQLConfig.sManualFundsCommitment_Desc_DOC_Text_Query,"SAP Validation");	
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",4,objSphereModules.Common_Btn_Sorting_Column_4,"Asc",objSQLConfig.sManualFundsCommitment_Asc_DOC_Text_Query,"SAP Validation");	
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Desc",objSQLConfig.sManualFundsCommitment_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Asc",objSQLConfig.sManualFundsCommitment_Asc_Company_Query,"SAP Validation");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFundsCommitement_CheckBox_xp)).click();// post condition
		}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC360 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC360 Completed");
		}
		return obj;
		} //End of Script TC360
	@SuppressWarnings("static-access")
	public Reporter TC361(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying WBSE Table on SAP Validation page", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String ExpWbseTitle="WBSE";
			String ExpText="Search ...";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_CheckBox_xp)).click();
			Thread.sleep(2000);
			
			String ActWbseTitle =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Title_xp)).getText().trim();
			fnVerifyLabelMsgText(ExpWbseTitle,ActWbseTitle);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Title_xp, "WBSE", true);
			fnCheckFieldDisplayByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_WBSE_Indicator_xp,"Indicator A",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Search_bar_xp,"search bar",true,true);
			
			String ActSearchBarText=TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Table_Search_bar_xp)).getAttribute("placeholder");
			fnVerifyLabelMsgText(ExpText, ActSearchBarText.trim());
			
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkAll_xp,"All",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Green_xp,"Green Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkActive_xp,"Active",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Sap_Validation_Screen_Table_Active_Red_xp,"Red Indicator",true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Common_ViewModules_LinkInactive_xp,"Inactive",true,true);
			Thread.sleep(2000);
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"WBS Element");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			fnVerifyHeaders(arrHeaderColumns,3,"Project");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sWbse_View_Query,"WBSE");
			
			obj.repAddData( "Verifying Pagination fields", "", "", "");
			objBusinessLib.fnVerifyPaginationgroup(SphereModules.Common_View_pagination_numbersequence_xp,SphereModules.Common_View_pagination_groupText_xp,SphereModules.Common_View_pagination_nextButton_xp,SphereModules.Common_View_pagination_previousButton_xp,"Wbse");
			
			obj.repAddData( "Verifying Sorting on WBSE table columns", "", "", "");
			
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"WBS Element",2,objSphereModules.Common_Btn_Sorting_Column_2,"Desc",objSQLConfig.sWbse_Desc_WBS_ELEMENT_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"WBS Element",2,objSphereModules.Common_Btn_Sorting_Column_2,"Asc",objSQLConfig.sWbse_Asc_WBS_ELEMENT_Query,"SAP Validation");
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Desc",objSQLConfig.sWbse_Desc_ShortDesciption_Query,"SAP Validation");
			//objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Description",3,objSphereModules.Common_Btn_Sorting_Column_3,"Asc", objSQLConfig.sWbse_Asc_ShortDesciption_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Project",4,objSphereModules.Common_Btn_Sorting_Column_4,"Desc",objSQLConfig.sWbse_Desc_PROJECT_DEFINITION_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Project",4,objSphereModules.Common_Btn_Sorting_Column_4,"Asc",objSQLConfig.sWbse_Asc_PROJECT_DEFINITION_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Desc", objSQLConfig.sWbse_Desc_Company_Query,"SAP Validation");
			objBusinessLib.fnCheckColumnSorting(objSphereModules.Common_View_Sap_Table_xp,"Company",1,objSphereModules.Common_Btn_Sorting_Column_1,"Asc",objSQLConfig.sWbse_Asc_Company_Query,"SAP Validation");
			
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_CheckBox_xp)).click();
			Thread.sleep(2000);
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC361 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC361 Completed");
		}
		return obj;
		} //End of Script TC361
	
	@SuppressWarnings("static-access")
	public Reporter TC362(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying chart of account filtered records and Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="BANK";
			String sCompanySearchValue="Z0CC";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
		
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_CheckBox_xp)).click();
			Thread.sleep(2000);			
			ClickByXpath(SphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_Title_xp, "Chart Of Account", true);
			
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Account Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			
			obj.repAddData( "Verifying chart of account filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			Thread.sleep(2000);
			
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Active");
			
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sChartOfAccount_Active_Query,"Chart Of Account");
			Thread.sleep(2000);
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
			Thread.sleep(2000);
			
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Inactive");
			
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sChartOfAccount_Inactive_Query,"Chart Of Account");
           
			ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
            Thread.sleep(3000);

			obj.repAddData( "Verifying chart of account filtered records", "", "", "");
			
			String sTableXPath=SphereModules.Common_View_Sap_Table_xp;
		
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDescSearchValue,sDescSearchValue,3,"ChartOfAccount");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sCompanySearchValue,sCompanySearchValue,1,"ChartOfAccount");
			
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ChartOfAccount_CheckBox_xp)).click();
			Thread.sleep(2000);
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC362 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC362 Completed");
		}
		return obj;
		} //End of Script TC362
	@SuppressWarnings("static-access")
	public Reporter TC363(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying cost center filtered records and Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="Trade Operations";
			String sCompanySearchValue="ZTH1";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
			
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_CostCenter_CheckBox_xp)).click();
			Thread.sleep(2000);
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Cost Center");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			Thread.sleep(3000);

			obj.repAddData( "Verifying cost center filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Active");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sCostCenter_Active_Query,"Cost Center");
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Inactive");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sCostCenter_Inactive_Query,"Cost Center");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
			Thread.sleep(3000);
			
			obj.repAddData( "Verifying cost center Search functionality", "", "", "");
			String sTableXPath=SphereModules.Common_View_Sap_Table_xp;
			
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDescSearchValue,sDescSearchValue,3,"CostCenter");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sCompanySearchValue,sCompanySearchValue,1,"CostCenter");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_CostCenter_CheckBox_xp)).click();
			Thread.sleep(2000);
		   
		}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC363 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC363 Completed");
		}
		return obj;
		} //End of Script TC363
	@SuppressWarnings("static-access")
	public Reporter TC364(Reporter obj) throws Exception
	{
		try {
			obj.repAddData( "Verifying Internal orders filtered records and Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="vista";
			String sIOrderSearchValue="000004800004";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_InternalOrders_CheckBox_xp)).click();
			Thread.sleep(2000);
			
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Internal Order");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			Thread.sleep(3000);

			obj.repAddData( "Verifying Internal orders filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Active");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sInternalOrders_Active_Query,"Internal Order");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Inactive");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sInternalOrders_Inactive_Query,"Internal Order");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
			Thread.sleep(3000);
			String sTableXPath=SphereModules.Common_View_Sap_Table_xp;
			
			obj.repAddData( "Verifying Internal orders search functionality", "", "", "");
			
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDescSearchValue,sDescSearchValue,3,"InternalOrder");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sIOrderSearchValue,sIOrderSearchValue,2,"InternalOrder");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_InternalOrders_CheckBox_xp)).click();
			Thread.sleep(2000);
		   
		}
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC364 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC364 Completed");
		}
		return obj;
		} //End of Script TC364
	@SuppressWarnings("static-access")
	public Reporter TC365(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Profit center filtered records and Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="BANK";
			String sCompanySearchValue="1001";
			String sProfitSearchValue="BUS20802";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ProfitCenter_CheckBox_xp)).click();
			Thread.sleep(2000);
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Profit Center");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			Thread.sleep(3000);
			
			obj.repAddData( "Verifying Profit center filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Active");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sInternalOrders_Active_Query,"Internal Order");
			
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
			Thread.sleep(2000);
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sProfitCenter_Inactive_Query,"Profit Center");
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Inactive");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
			Thread.sleep(3000);
			
			String sTableXPath=SphereModules.Common_View_Sap_Table_xp;

			obj.repAddData( "Verifying Profit center search functionality", "", "", "");
			
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDescSearchValue,sDescSearchValue,3,"ProfitCenter");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sCompanySearchValue,sCompanySearchValue,1,"ProfitCenter");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sProfitSearchValue,sProfitSearchValue,2,"ProfitCenter");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ProfitCenter_CheckBox_xp)).click();
			Thread.sleep(2000);
		   
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC365 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC365 Completed");
		}
		return obj;
		} //End of Script TC365
	@SuppressWarnings("static-access")
	public Reporter TC366(Reporter obj) throws Exception
	{
		try {
			

			obj.repAddData( "Verifying WBSE filtered records and Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="fear";
			String sCompanySearchValue="E0Q6";
			String sWbsEleSearchValue="DC-HW4.71";
			String sProjectSearchValue="DC-HW4.7";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_CheckBox_xp)).click();
			Thread.sleep(2000);
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"WBS Element");
			fnVerifyHeaders(arrHeaderColumns,2,"Description");
			fnVerifyHeaders(arrHeaderColumns,3,"Project");
			Thread.sleep(3000);

			obj.repAddData( "Verifying WBSE filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Active");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sWbse_Active_Query,"WBSE");
			//Thread.sleep(2000);
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Inactive");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sWbse_Inactive_Query,"WBSE");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
			Thread.sleep(3000);
			String sTableXPath=SphereModules.Common_View_Sap_Table_xp;

			obj.repAddData( "Verifying WBSE search functionality", "", "", "");
			
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDescSearchValue,sDescSearchValue,3,"WBSE");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sCompanySearchValue,sCompanySearchValue,1,"WBSE");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sWbsEleSearchValue,sWbsEleSearchValue,2,"WBSE");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sProjectSearchValue,sProjectSearchValue,4,"WBSE");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_WBSE_CheckBox_xp)).click();
			Thread.sleep(2000);
		   
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC366 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC366 Completed");
		}
		return obj;
		} //End of Script TC366
	@SuppressWarnings("static-access")
	public Reporter TC367(Reporter obj) throws Exception
	{
		try {

			obj.repAddData( "Verifying Manual Funds Commitment filtered records and Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="BANK";
			String sCompanySearchValue="9024";
			String sDocNumSearchValue="0500000557";
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFundsCommitement_CheckBox_xp)).click();
			Thread.sleep(2000);
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Sap_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,0,"Company");
			fnVerifyHeaders(arrHeaderColumns,1,"Document Number - Item");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			Thread.sleep(3000);

			obj.repAddData( "Verifying Manual Funds Commitment filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Common_ViewModules_LinkActive_xp, "Active Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Active");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sManualFunds_Inactive_Query,"WBSE");
			//Thread.sleep(2000);
			ClickByXpath(SphereModules.Common_ViewModules_LinkInactive_xp, "Inactive Link", true);
			Thread.sleep(2000);
			objBusinessLib.fnVerifyactiveinactivefilteredrecords("SAP Valiadtion",objSphereModules.Common_View_Sap_Table_xp,1,"Inactive");
			//objBusinessLib.fnVerifySAPRecordsWithDB(objSphereModules.Common_View_Sap_Table_xp,objSQLConfig.sManualFunds_Active_Query,"WBSE");
			ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true); 
			Thread.sleep(3000);
			String sTableXPath=SphereModules.Common_View_Sap_Table_xp;
			
			obj.repAddData( "Verifying Manual Funds Commitment search functionality", "", "", "");
			
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDescSearchValue,sDescSearchValue,4,"ManualFundsCommitment");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sCompanySearchValue,sCompanySearchValue,1,"ManualFundsCommitment");
			objBusinessLib.fnVerifySAPSearchFilterData(sTableXPath,"TableSearch",sDocNumSearchValue,sDocNumSearchValue,2,"ManualFundsCommitment");
			
			driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFundsCommitement_CheckBox_xp)).click();
			Thread.sleep(2000);
		   
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC367 Failed!", e );
			}			
	
          finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC367 Completed");
		}
		return obj;
		} //End of Script TC367
	@SuppressWarnings("static-access")
	public Reporter TC368(Reporter obj) throws Exception
	{
		try {
			
			obj.repAddData( "Verifying Global Search functionality", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			String sDescSearchValue="FEES";
			//String sCompanySearchValue="100";
			//String sDocNumSearchValue="0500000557";
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
			SendKeyByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp, sDescSearchValue, "Search");
			fnLoadingPageWait();
			Thread.sleep(15000);
			
			
			objBusinessLib.fnVerifySAPSearchFilterData(SphereModules.Common_View_ChartOfAccount_Table_xp,"GlobalSearch",sDescSearchValue,sDescSearchValue,3,"ChartOfAccount");
			objBusinessLib.fnVerifySAPSearchFilterData(SphereModules.Common_View_WBSE_Table_xp,"GlobalSearch",sDescSearchValue,sDescSearchValue,3,"WBSE");
			objBusinessLib.fnVerifySAPSearchFilterData(SphereModules.Common_View_CostCenter_Table_xp,"GlobalSearch",sDescSearchValue,sDescSearchValue,3,"CostCenter");
			objBusinessLib.fnVerifySAPSearchFilterData(SphereModules.Common_View_ProfitCenter_Table_xp,"GlobalSearch",sDescSearchValue,sDescSearchValue,3,"Profit Center");
			objBusinessLib.fnVerifySAPSearchFilterData(SphereModules.Common_View_InternalOrders_Table_xp,"GlobalSearch",sDescSearchValue,sDescSearchValue,3,"Internal Orders");
			objBusinessLib.fnVerifySAPSearchFilterData(SphereModules.Common_View_Manual_Funds_Commitment_Table_xp,"GlobalSearch",sDescSearchValue,sDescSearchValue,4,"ManualFundsCommitment");
			
			SendKeyByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp," ", "Search");
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC368 Failed!", e );
			}			
	
            finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC368 Completed");
		}
		return obj;
		} //End of Script TC368
	
	
	@SuppressWarnings("static-access")
	public Reporter TC527(Reporter obj) throws Exception
	{
		try {

			obj.repAddData( "Verifying presence of Document Number-Item header in the table", "", "", "");
			
			objBusinessLib.fnClickMainMenuElement("SAP Validation");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
			WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
			HighlightElement(ele);
			Thread.sleep(2000);
			String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
			if(CheckTextOnPage(sSapValidationTitleMessage))
			{
				obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
				
			}
			WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
			HighlightElement(Logoele);
			Thread.sleep(2000);
			ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
			Thread.sleep(2000);
		
			
			WebElement ManualFundsCommitment=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ManualFundsCommitment);
			WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th")); 
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
			fnVerifyHeaders(arrHeaderColumns,1,"Document Number - Item");
			Thread.sleep(3000);

			obj.repAddData( "Verifying Manual Funds Commitment filtered records", "", "", "");
			
			ClickByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp,"Search",true );
			
		   }
			catch (Exception e) {
				e.printStackTrace();
				testCaseStatus = false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC527 Failed!", e );
			}			
	
          finally {
		
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC527 Completed");
		}
		return obj;
		} //End of Script TC527



@SuppressWarnings("static-access")
public Reporter TC528(Reporter obj) throws Exception
{
	try {

		obj.repAddData( "Verifying presence of Document Number-Item header in the table", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		WebDriverWait wait = new WebDriverWait(driver, 60);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
		WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		HighlightElement(ele);
		Thread.sleep(2000);
		String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
		if(CheckTextOnPage(sSapValidationTitleMessage))
		{
			obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
			
		}
		WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
		HighlightElement(Logoele);
		Thread.sleep(2000);
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
		Thread.sleep(2000);
	
		
		WebElement ManualFundsCommitment=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ManualFundsCommitment);
		WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th")); 
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
		
		int headerSize = arrHeaderColumns.size();
		
		for(int i=1;i<headerSize;i++)
		{
		
		if(arrHeaderColumns.get(i).getText().equalsIgnoreCase("Document Number"))
		{
			obj.repAddData( "Verify '"+"Document Number"+"' in the Header", "'"+"Document Number"+"' should not be shown in the header",
					"'"+"Document Number"+"' shown in the header", "Fail");
		}
		else
		{
			obj.repAddData(  "Verify '"+"Document Number"+"' in the Header", "'"+"Document Number"+"' should not be shown in the header",
					"'"+"Document Number"+"' not shown in the header", "Pass");
		}
		if(arrHeaderColumns.get(i).getText().equalsIgnoreCase("Item"))
		{
			obj.repAddData( "Verify '"+"Item"+"' in the Header", "'"+"Item"+"' should not be shown in the header",
					"'"+"Item"+"' shown in the header", "Fail");
		}
		else
		{
			obj.repAddData(  "Verify '"+"Item"+"' in the Header", "'"+"Item"+"' should not be shown in the header",
					"'"+"Item"+"' not shown in the header", "Pass");
		}
		}
		Thread.sleep(3000);

		obj.repAddData( "Verifying Manual Funds Commitment filtered records", "", "", "");
		
		
	   
	   }
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC528 Failed!", e );
		}			

      finally {
	
		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC528 Completed");
	}
	return obj;
	} //End of Script TC31999


@SuppressWarnings("static-access")
public Reporter TC530(Reporter obj) throws Exception
{
	try {

		obj.repAddData( "Verifying presence of Document Number-Item header in the table", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
		WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		HighlightElement(ele);
		Thread.sleep(5000);
		String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
		if(CheckTextOnPage(sSapValidationTitleMessage))
		{
			obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
			
		}
		WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
		HighlightElement(Logoele);
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
		fnLoadingPageWait();
		WebElement ManualFundsCommitment=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ManualFundsCommitment);
		WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th")); 
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp,"Search", true);
		//String smutualfundscSearchValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
		String smutualfundscSearchValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("SAP_Indicator").trim();
		SendKeyByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp, smutualfundscSearchValue, "Search");
		fnLoadingPageWait();
		Thread.sleep(5000);
		objGenericFunctionLibrary.fnVerifySearchedFilterOnMutualFundDocumentItem(smutualfundscSearchValue);	
		String sapValidationValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("SAP_Indicator").trim();
		WebElement sapValidation=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sapValidation);
		
		
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp,"Search", true);
		SendKeyByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp, sapValidationValue, "Search");
		fnLoadingPageWait();
		Thread.sleep(3000);
		//objGenericFunctionLibrary.fnVerifySearchedDocumentItem(sapValidationValue);
		objGenericFunctionLibrary.fnVerifySearchedFilterOnMutualFundDocumentItem(sapValidationValue);	
		obj.repAddData( "Verifying Manual Funds Commitment filtered records", "", "", "");
		
	    	
		
	
		 
	  String sQuery = objSQLConfig.sSapValidationCountryAndDocumentItemNo_Query;  
		 int iRow = 1; 
			TestDriver.conn = objDBUtility.fnOpenDBConnectionsoap();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sCompanyDB = mTableDataDB.get(iRow).get(13).toString().trim();
			String sDocumentItemNoDB = mTableDataDB.get(iRow).get(2).toString().trim();
			//need to modify
			
				String documentItem[] =  sapValidationValue.split("-");	
				String DocValue = documentItem[0];
				if(sDocumentItemNoDB.equalsIgnoreCase(DocValue))
				{	
					obj.repAddData( "Compare Document Item record",
					"Document Item record on UI and DB should match",
					"Validation successful for Document Item record", "Pass");
				}
					else
				{
					obj.repAddData( "Compare Document Item record",
					"Document Item record on UI and DB should match",
					"Validation not successful for Document Item record", "Fail");
			}

	}
		
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC530 Failed!", e );
		}			

      finally {
	
		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC530 Completed");
	}
	return obj;
	} //End of Script TC61999

@SuppressWarnings("static-access")
public Reporter TC531(Reporter obj) throws Exception
{
	try {

		obj.repAddData( "Verifying presence of Document Number-Item header in the table", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
		WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		HighlightElement(ele);
		Thread.sleep(5000);
		String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
		if(CheckTextOnPage(sSapValidationTitleMessage))
		{
			obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
			
		}
		WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
		HighlightElement(Logoele);
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
		fnLoadingPageWait();
		WebElement ManualFundsCommitment=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ManualFundsCommitment);
		WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th")); 
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp,"Search", true);
		String smutualfundscSearchValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
		SendKeyByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp, smutualfundscSearchValue, "Search");
		fnLoadingPageWait();
		Thread.sleep(5000);
		objGenericFunctionLibrary.fnVerifySearchedFilterOnMutualFundCompany(smutualfundscSearchValue);	
		String sapValidationValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
		WebElement sapValidation=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sapValidation);
		
		
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp,"Search", true);
		SendKeyByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp, sapValidationValue, "Search");
		fnLoadingPageWait();
		objGenericFunctionLibrary.fnVerifySearchedFilterOnMutualFundCompany(sapValidationValue);
		obj.repAddData( "Verifying Manual Funds Commitment filtered records", "", "", "");
		
		
		
		  String sQuery = objSQLConfig.sSapValidationCountryAndDocumentItemNo_Query;  
	    	 int iRow = 1; 
		
			TestDriver.conn = objDBUtility.fnOpenDBConnectionsoap();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			String sCompanyDB = mTableDataDB.get(iRow).get(13).toString().trim();
			//String sDocumentItemNoDB = mTableDataDB.get(iRow).get(2).toString().trim();
			//String sItem = mTableDataDB.get(iRow).get(2).toString().trim();
			
			
			if(smutualfundscSearchValue.equalsIgnoreCase(sCompanyDB) )
				{	
					obj.repAddData( "Compare company record",
							"Invalid company record should not be present in the DB",
							"Invalid company record is present in the DB", "Fail");
					}
					else
					{
						obj.repAddData( "Compare company record",
								"Invalid company record should not be present in the DB",
								"Invalid company record is not present in the DB", "Pass");
				}
			
				
				/*if(sapValidationValue.equalsIgnoreCase(sDocumentItemNoDB))
				{	
					obj.repAddData( "Compare Document Item record",
					"Invalid Document Item record should not be present in the DB",
					"Invalid Document Item record is present in the DB", "Fail");
				}
					else
				{
					obj.repAddData( "Compare Document Item record",
					"Invalid Document Item record should not be present in the DB",
					"Invalid Document Item record is not be present in the DB", "Pass");
			}*/

	}
		
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC531 Failed!", e );
		}			

      finally {
	
		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC531 Completed");
	}
	return obj;
	} //End of Script TC531

@SuppressWarnings("static-access")
public Reporter TC529(Reporter obj) throws Exception
{
	try {

		obj.repAddData( "Verifying presence of Document Number-Item header in the table", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp)));
		WebElement ele =TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		HighlightElement(ele);
		Thread.sleep(5000);
		String sSapValidationTitleMessage = AppMessages.Sap_Validation_Screen_Title_xp.toString().trim();
		if(CheckTextOnPage(sSapValidationTitleMessage))
		{
			obj.repAddData( "Verify SAP Validation page", "SAP Validation page should be loaded", "SAP Validation page loaded successfully with Title : "+sSapValidationTitleMessage, "Pass");
			
		}
		WebElement Logoele =TestDriver.driver.findElement(By.xpath(SphereModules.Sap_Validation_Screen_Title_Logo_xp));
		HighlightElement(Logoele);
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_btn_xp, "Search", true);
		fnLoadingPageWait();
		WebElement ManualFundsCommitment=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Cost_Object_ManualFunds_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ManualFundsCommitment);
		WebElement eleTable1 = driver.findElement(By.xpath(objSphereModules.Common_View_Manual_Funds_Commitment_Table_xp));
		List<WebElement> arrHeaderColumns = eleTable1.findElements(By.xpath("../thead/tr/th")); 
		System.out.println("Rows Size>>>>"+arrHeaderColumns.size());
		fnLoadingPageWait();
		ClickByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp,"Search", true);
		String smutualfundscSearchValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
		SendKeyByXpath(SphereModules.Sap_Validation_Screen_Manual_Funds_Commitment_Search_xp, smutualfundscSearchValue, "Search");
		fnLoadingPageWait();
		Thread.sleep(5000);
		objGenericFunctionLibrary.fnVerifySearchedFilterOnMutualFundCompany(smutualfundscSearchValue);	
		String sapValidationValue = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Parent_Company").trim();
		WebElement sapValidation=TestDriver.driver.findElement(By.xpath(objSphereModules.Sap_Validation_Screen_Title_xp));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sapValidation);
		
		
		ClickByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp,"Search", true);
		SendKeyByXpath(SphereModules.Sap_Validation_Screen_Search_bar_xp, sapValidationValue, "Search");
		fnLoadingPageWait();
		objGenericFunctionLibrary.fnVerifySearchedFilterOnMutualFundCompany(sapValidationValue);	
		obj.repAddData( "Verifying Manual Funds Commitment filtered records", "", "", "");
		
		
		
		  String sQuery = objSQLConfig.sSapValidationCountryAndDocumentItemNo_Query;  
	    	 int iRow = 1; 
		
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			
			String sCompanyDB = mTableDataDB.get(iRow).get(13).toString().trim();
		
			
			
			if(smutualfundscSearchValue.equalsIgnoreCase(sCompanyDB) )
				{	
					obj.repAddData( "Compare company record",
							"company record on UI and DB should match",
							"Validation successful for company record", "Pass");
					}
					else
					{
						obj.repAddData( "Compare company record",
								"company record on UI and DB should match",
								"Validation not successful for company record", "Fail");
				}
	}
		
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC529 Failed!", e );
		}			

      finally {
	
		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC529 Completed");
	}
	return obj;
	} //End of Script TC529

@SuppressWarnings("static-access")
public Reporter TC5063(Reporter obj) throws Exception
{
	try {
		
		obj.repAddData( "Verifying Cost Objects on SAP Validation page", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		SendKeyByXpath(SphereModules.SAP_Validation_Description,"BANK BAL-USD-OPERATING #51","Description"); 
		SendKeyByXpath(SphereModules.SAP_Validation_AccCostObject,"0010001051","Acc or Cost Object"); 
		SendKeyByXpath(SphereModules.SAP_Validation_Company,"FN09","Company"); 
		Thread.sleep(500);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_Checkbox, "select", true);
		Thread.sleep(500);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_CostCenter_Checkbox, "select", true);
		Thread.sleep(500);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_GLAccount_Checkbox, "select", true);
		Thread.sleep(500);
		//	ClickByXpath(SphereModules.SAP_Validation_WBSElement_ProftCenters_Checkbox, "select", true);
		//ClickByXpath(SphereModules.SAP_Validation_WBSElement_ManualFundsCommitments_Checkbox, "select", true);
	  
		ClickByXpath(SphereModules.WipRecon_Summary_Search, "select", true);
		Thread.sleep(2000);
		WebElement AccNumber = driver.findElement(By.xpath(SphereModules.SAP_Validation_AccountNumber_firstRow));
		String AccNumber_UI = AccNumber.getText();
		if(AccNumber_UI.equalsIgnoreCase("0010001051"))
		{
				obj.repAddData( "Verify the filtered Account Number",
				"Account Number filtered data should be same",
				"Account Number is filtered according to the data", "Pass");
		}
		else
		{
				obj.repAddData( "Verify the filtered Account Number",
				"Account Number filtered data should be same",
				"Account Number is not filtered according to the data", "Fail");
		}
	
		WebElement Company = driver.findElement(By.xpath(SphereModules.SAP_Validation_Company_firstRow));
		String Company_UI = Company.getText();
		if(Company_UI.equalsIgnoreCase("FN09"))
		{
				obj.repAddData( "Verify the filtered Company",
				"Company field filtered data should be same",
				"Company field is filtered according to the data", "Pass");
		}
		else
		{
				obj.repAddData( "Verify the filtered Company field",
				"Company field filtered data should be same",
				"Company field is not filtered according to the data", "Fail");
		}
		
		
		WebElement Description = driver.findElement(By.xpath(SphereModules.SAP_Validation_Description_firstRow));
		String Description_UI = Description.getText();
		if(Description_UI.equalsIgnoreCase("BANK BAL-USD-OPERATING #51"))
		{
				obj.repAddData( "Verify the filtered Description",
				"Description field filtered data should be same",
				"Description field is filtered according to the data", "Pass");
		}
		else
		{
				obj.repAddData( "Verify the filtered Description field",
				"Description field filtered data should be same",
				"Description field is not filtered according to the data", "Fail");
		}
	
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC521 Failed!", e );
		}			

      finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC521 Completed");
	}
	return obj;
	} //End of Script TC521

@SuppressWarnings("static-access")
public Reporter TC022(Reporter obj) throws Exception
{
	try {
		
		obj.repAddData( "Verifying Cost Objects on SAP Validation page", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		SendKeyByXpath(SphereModules.SAP_Validation_Description,"zzz","Description"); 
		SendKeyByXpath(SphereModules.SAP_Validation_AccCostObject,"zzz","Acc or Cost Object"); 
		SendKeyByXpath(SphereModules.SAP_Validation_Company,"zzz","Company"); 
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_Checkbox, "select", true);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_CostCenter_Checkbox, "select", true);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_GLAccount_Checkbox, "select", true);
	
		ClickByXpath(SphereModules.WipRecon_Summary_Search, "select", true);
		Thread.sleep(2000);
		WebElement errormsg = driver.findElement(By.xpath(SphereModules.SAP_Validation_ErrorMsg));
		String errormsg_UI = errormsg.getText();
		if(errormsg_UI.equalsIgnoreCase("*** Search did not match any cost objects ***"))
		{
				obj.repAddData("Verify Error msg",
				"Error message should be displayed on searching invalid data",
				"Error message is displayed on searching invalid data", "Pass");
		}
		else
		{
				obj.repAddData( "Verify Error msg",
				"Error message should be displayed on searching invalid data",
				"Error message is not displayed on searching invalid data", "Fail");
		}
	
		
	
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC521 Failed!", e );
		}			

      finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC521 Completed");
	}
	return obj;
	} //End of Script TC521
				
@SuppressWarnings("static-access")
public Reporter TC020(Reporter obj) throws Exception
{
	try {
		
		obj.repAddData( "Verifying Cost Objects on SAP Validation page", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		SendKeyByXpath(SphereModules.SAP_Validation_Description,"MMM","Description"); 
		SendKeyByXpath(SphereModules.SAP_Validation_AccCostObject,"B-036127834","Acc or Cost Object"); 
		SendKeyByXpath(SphereModules.SAP_Validation_Company,"S001","Company"); 
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_Checkbox, "select", true);
		Thread.sleep(500);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_CostCenter_Checkbox, "select", true);
		Thread.sleep(500);
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_GLAccount_Checkbox, "select", true);
		Thread.sleep(500);
	
		ClickByXpath(SphereModules.WipRecon_Summary_Search, "select", true);
		Thread.sleep(2000);
		
		ClickByXpath(SphereModules.SAP_Validation_ClickFirstRow_xp, "First Account Row", true);
		fnLoadingPageWait();
		Thread.sleep(500);
		WebElement title = driver.findElement(By.xpath(SphereModules.SAP_Validation_ClickFirstRow_xp_SlideOutTitle));
		String Actual_Title = title.getText();
		if(Actual_Title.equalsIgnoreCase("WBS Element"))
		{
			obj.repAddData("Verify slide out page",
					"Slide out page should be displayed",
					"Slide out page is displayed", "Pass");
		}else
		{
			obj.repAddData("Verify slide out page",
					"Slide out page should be displayed",
					"Slide out page is not displayed", "Fail");}
		
		
		ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		Thread.sleep(6000);
		
		
		
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC521 Failed!", e );
		}			

      finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC521 Completed");
	}
	return obj;
	} //End of Script TC521
				
public Reporter TC5798(Reporter obj) throws Exception
{
	try {
		
		obj.repAddData( "Verifying Cost Objects on SAP Validation page", "", "", "");
		
		objBusinessLib.fnClickMainMenuElement("SAP Validation");
		SendKeyByXpath(SphereModules.SAP_Validation_Description,"12307 CHILDREN OF MEN","Description"); 
		ClickByXpath(SphereModules.SAP_Validation_WBSElement_Checkbox, "select", true);
		Thread.sleep(500);
	 
		ClickByXpath(SphereModules.WipRecon_Summary_validateButton, "select", true);
		Thread.sleep(2000);
	
		WebElement header = driver.findElement(By.xpath("//h2[contains(text(),'WBS Elements')]"));
		String header_UI = header.getText();
		if(header_UI.equalsIgnoreCase("WBS Elements'"))
		{
				obj.repAddData( "Verify the header",
				"header should be wbs element",
				"header is displayed as wbs element", "Pass");
		}
		else
		{
				obj.repAddData( "Verify the header",
				"header should be wbs element",
				"header is not displayed as wbs element", "Fail");
		}
		
		
		WebElement Description = driver.findElement(By.xpath(SphereModules.SAP_Validation_Description_firstRow));
		String Description_UI = Description.getText();
		if(Description_UI.equalsIgnoreCase("12307 CHILDREN OF MEN"))
		{
				obj.repAddData( "Verify the filtered Description",
				"Description field filtered data should be same",
				"Description field is filtered according to the data", "Pass");
		}
		else
		{
				obj.repAddData( "Verify the filtered Description field",
				"Description field filtered data should be same",
				"Description field is not filtered according to the data", "Fail");
		}
		
		//db validation should be done
	
	}
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC521 Failed!", e );
		}			

      finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/

		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC521 Completed");
	}
	return obj;
	} //End of Script TC521

}	

		


