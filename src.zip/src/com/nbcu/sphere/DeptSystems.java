package com.nbcu.sphere;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nbcu.sphere.ReportManager.Reporter;


import com.nbcu.sphere.Common.BusinessFunctionLibrary;
import com.nbcu.sphere.ConfigManager.FileLocSetter;
import com.nbcu.sphere.ObjectRepository.SphereCommon;
import com.nbcu.sphere.ObjectRepository.SphereModules;
import com.nbcu.sphere.UtilManager.AppMessages;

@SuppressWarnings("static-access")
public class DeptSystems extends TestDriver {
	SphereModules objSphereModules = new SphereModules();
	SphereCommon objSphereCommon = new SphereCommon();
	AppMessages objAppMessages = new AppMessages();
	BusinessFunctionLibrary objBusinessLib = new BusinessFunctionLibrary();
	
	@SuppressWarnings({ "unused", "deprecation" })
	public Reporter TC70002(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC70002 Started..");
	
		try {
			
			String sDealNumberUI ="";
			String sOrderUI ="";
			//String sErrorReason="";
			String sRecordStatus="";
			String sOrderStatus="";
			String sMultiDept="";
			String sDeptSystemNum="";
			String sCostCenterNum="";
			String sExceptionRecord="";
			String sTransactionRecord="";
			String sBillingRequestStatusDB="";
			String sTransactionStatusDB="";
            String sQuery="";
            String sQuery1="";
            String sTransactionDate="";
            String sTransactionDatenew="";
            String sInterfaceCode="";
            obj.repAddData( "Pre-Condition : Search for an existing deal", "", "", "");
						
			WebDriverWait waitForTableLoad;	
			waitForTableLoad = new WebDriverWait(driver, 60);
			mDeptSystemsData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"DeptSystemsData", "");
			
			for(int i=1;i<=mDeptSystemsData.size();i++)
			{
			   System.out.println("Deal depart system process is in progress : "+i);
			   sTransactionDate=TestDriver.mDeptSystemsData.get(i).get("Transaction Date").trim();
			   sDealNumberUI = TestDriver.mDeptSystemsData.get(i).get("Deal").trim();	
			   System.out.println(sDealNumberUI);
			   
			   sOrderUI = TestDriver.mDeptSystemsData.get(i).get("Set No").trim();
			   sDeptSystemNum=TestDriver.mDeptSystemsData.get(i).get("Dept Systems No").trim();
			   sCostCenterNum=TestDriver.mDeptSystemsData.get(i).get("Cost Center").trim();
			   //sMultiDept=TestDriver.mDeptSystemsData.get(i).get("Multi Dept?").trim();
			   sInterfaceCode=TestDriver.mDeptSystemsData.get(i).get("Interface Code").trim();
			   
			   String value = null;
			  if(sDealNumberUI.length()==5){
				   sDealNumberUI = "0"+String.valueOf(sDealNumberUI); 
			   }
			   System.out.println(sDealNumberUI);
			   
			   /*if(Integer.parseInt(sOrderUI)<10){
				   sOrderUI = "00"+String.valueOf(sOrderUI);
			   
			   }else if(Integer.parseInt(sOrderUI)>9 && Integer.parseInt(sOrderUI)<100){
				   sOrderUI = "0"+String.valueOf(sOrderUI);
			   }else{
				   sOrderUI = String.valueOf(sOrderUI);
			   }
			   System.out.println(sOrderUI);*/
			  
			   
			   
			   Date date1 = new SimpleDateFormat("yyyyMMdd").parse(sTransactionDate);
			   SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			   sdf.applyPattern("yyyy-MM-dd");
			   System.out.println(sdf.format(date1));
			   sTransactionDatenew=sdf.format(date1);
			   System.out.println(sTransactionDatenew);
			   //System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(new Date(sTransactionDate)));
			  // System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(sTransactionDate));
			   //System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(new Date(sTransactionDate)));
			   System.out.println("Deal number  : "+sDealNumberUI);
			   System.out.println("Order number  : "+sOrderUI);				
									
			   
			try {
				objBusinessLib.fnClickSubMenuElement("Administration","Queue Logging");
				   
				   waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
										
					WebElement eleTable = TestDriver.driver.findElement(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp));
					SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp,sDealNumberUI,"Search Box");
					Thread.sleep(4000);
					waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_ViewQueueLogging_Table_xp)));
					fnLoadingPageWait();
					
					List<WebElement> arrTableRows = eleTable.findElements(By.xpath("./tr"));  //Get the table data rows
					System.out.println("Data Rows Size>>>>"+arrTableRows.size());
					Thread.sleep(4000);
					
					if(arrTableRows.size()>0)
					{					
					    boolean isValuepresent=false;
						for(int iRow=0;iRow<arrTableRows.size();iRow++)  //Exclude first header row 
					{	
						List<WebElement> arrTableColumns = arrTableRows.get(iRow).findElements(By.xpath("./td"));  //Get the table data rows
						
						String sColValue = arrTableColumns.get(4).getText().toString().trim();//.toString();
						//String sStatus=arrTableColumns.get(1).findElement(By.xpath("./span")).getText().trim();
						if(sColValue.contains(sOrderUI) && sColValue.contains(sDealNumberUI))
						//if(sColValue.contains(sOrderUI)&&sDealNumberUI))
						{
							isValuepresent=true;
							 String sStatus=arrTableColumns.get(1).findElement(By.xpath("./span")).getText().trim(); //Select the checkbox
							
							 if(sStatus.equalsIgnoreCase("FAILURE"))
							
							 {
								arrTableColumns.get(1).findElement(By.xpath("./span")).click();
								fnLoadingPageWait();
								
								waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Queuelogging_Screen_Integration_Error_Title_xp)));
								String sError="Integration Error";
								fnVerifyLabelMsgTextByXpath(sError, SphereModules.Queuelogging_Screen_Integration_Error_Title_xp);
								String sErrortext=TestDriver.driver.findElement(By.xpath(objSphereModules.Queuelogging_Screen_Integration_Error_xp)).getText().toString().trim();//.split("[")[1]).split("]")[0];
								sRecordStatus= sErrortext;
								fnCloseOpenedForm();
								obj.repAddData( "Verify QueueLogging page Deal Order Status : ", "Status should be Complete : ", "Validation failed for  : \t Order Number: "+sOrderUI, "Fail");
								break;
							
							 
							 }
							 else
							 {
								 
								 sRecordStatus= sStatus;
								 //obj.repAddData( "Verify QueueLogging page Deal Order Status : ", "Status should be Complete : ", "Validation failed for  : \t Order Number: "+sOrderUI, "Fail");
								 break;
							 
							 }
						
							 						 
						}
						
					}
					if(isValuepresent==false){
						sRecordStatus="No deal-order number found in the table";
					}
					
					}
						else{
							sRecordStatus="No records found";
						}
					
				} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test. i.e. "+e.getMessage(), "Fail");
			}
				/////////////////////////////////////Verifying the orders status////////////////////// 
				try {
					/*objBusinessLib.fnClickMainMenuElement("Orders");
					waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
					WebElement Titleele = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
					HighlightElement(Titleele);
					
					//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
					SendKeyByXpath(SphereModules.Order_Screen_DealNumber_SearchBar_xp,sDealNumberUI,"Deal Number");
					ClickByXpath(SphereModules.Orders_DealNumber_SearchBtn_xp, "Search button", true);
					fnLoadingPageWait();*/
					objBusinessLib.fnClickMainMenuElement("Dashboard");
					waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
					WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
					HighlightElement(Titleele);
				    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
					
					//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
					SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sDealNumberUI,"Deal Number");
					fnLoadingPageWait();
					Thread.sleep(4000);
					ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
					fnLoadingPageWait();
					ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
					waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
					WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
					HighlightElement(Titleele1);					
					
					
					if(ElementFound(SphereModules.Order_Screen_OrderNumber_SearchBar_xp))
					{
						SendKeyByXpath(SphereModules.Order_Screen_OrderNumber_SearchBar_xp,sOrderUI,"Order Number");
						fnLoadingPageWait();
						String OrderTablexpath=SphereModules.Order_Screen_Table_xp;
						if(TestDriver.driver.findElements(By.xpath(SphereModules.Order_Table_Col4_xp)).size()>0==true)
						{
							String ActualColor=TestDriver.driver.findElement(By.xpath(OrderTablexpath+"/tr["+1+"]/td["+2+"]"+"/sp-status-color/i")).getAttribute("class");
							String [] arrClassName = ActualColor.split(" ");
						    String sStatus = arrClassName[arrClassName.length-1].toString().trim();					
						    System.out.println(sStatus);
						   
						    if(sStatus.equalsIgnoreCase("inactiveRecord")){
						    	sOrderStatus="Closed Order";
						    
						    }
						    else if(sStatus.equalsIgnoreCase("activeRecord")){
						    	sOrderStatus="Open Order";
						    
						    }
	
						 }
						else{
							sOrderStatus="Order not exist";
							obj.repAddData( "Verify Order record on orders screen : ", "Order records should be displayed: ", "Validation failed for  : \t Order Number: "+sOrderUI, "Fail");
						}
					}
					else
					{
						sOrderStatus="Please enter a valid deal number. No Order search bar exists";
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test. i.e " +e.getMessage(), "Fail");
				
				}
				
				//////////////////////Verifying in Arc Screen///////////////////////////
				
				try {
					objBusinessLib.fnClickSubMenuElement("Billing","ARC");
					waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.ARC_Title_xp)));
					WebElement Title = driver.findElement(By.xpath(objSphereModules.ARC_Title_xp));
					HighlightElement(Title);
					ClickByXpath(SphereModules.ARC_Screen_Clear_Btn_xp, "Clear button", true);
					fnLoadingPageWait();
					SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,sDealNumberUI,"Deal Number");
					fnLoadingPageWait();
					Thread.sleep(4000);
					if(ElementFound(SphereModules.ARC_Screen_Deal_list_1))
					{
					ClickByXpath(SphereModules.ARC_Screen_Deal_list_1, "Deal", true);
					fnLoadingPageWait();
					if(ElementFound(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp))
					{
					SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,sOrderUI,"Order Number");
					fnLoadingPageWait();
					if(ElementFound(SphereModules.ARC_Screen_Order_list_1)){

						ClickByXpath(SphereModules.ARC_Screen_Order_list_1, "Order", true);
						ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						Thread.sleep(4000);
						WebElement ArcTable = driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));
						if(TestDriver.driver.findElements(By.xpath(SphereModules.Order_Table_Col4_xp)).size()>0==true)
						{
							obj.repAddData( "Verify  transactions on ARC Screen for: " +sDealNumberUI+ "-" +sOrderUI, "Transactions for Order "+sOrderUI+ "Should be dispalyed", "Validation successful for  : \t Order Number: "+sOrderUI, "Pass");  
							System.out.println("Transactions exist");	
							sTransactionRecord="Transaction Records found";
						
						}
						else{
							obj.repAddData( "Verify  transactions on ARC Screen for: " +sDealNumberUI+ "-" +sOrderUI, "Transactions for Order "+sOrderUI+ "Should be dispalyed", "Validation failed for  : \t Order Number: "+sOrderUI, "Fail");
							sTransactionRecord="Transaction Records not found";
						
						}
					}
					else{
						sTransactionRecord="Deal found but order not found on ARC Screen";
					}
					
					}
					else{
						sTransactionRecord="Deal found but order search bar not found on ARC Screen";
					}
				
					}else{
						sTransactionRecord="Deal not found on ARC Screen";
						
					}
				
				
				} 
										
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.i.e " +e.getMessage(), "Fail");
				
				}
				
                  /////////////////////////////////////Verifying the records on Exceptions page////////////////////// 
				try {
					objBusinessLib.fnClickSubMenuElement("Billing","Exceptions");
									
					waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Transaction_Accordian_Table_xp)));
					SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp,sDeptSystemNum,"Dept System Number");		
					fnLoadingPageWait();
					
					Thread.sleep(5000);
					//if(sMultiDept.equalsIgnoreCase("No"))
					//{
								
					if(TestDriver.driver.findElements(By.xpath(SphereModules.Transaction_Accordian_Table_Rows_xp)).size()>0==true)
					{
						//obj.repAddData( "Verify  exceptions on Exceptions Screen for: " +sDealNumberUI+ "-" +sOrderUI, "Exceptions for Order "+sOrderUI+ "Should not be dispalyed", "Validation failed for  : \t Order Number: "+sOrderUI, "Fail");  
						System.out.println("Exceptions exist");	
						sExceptionRecord="Exception records found";
					
					}
					else{
						//obj.repAddData( "Verify  exceptions on Exceptions Screen for: " +sDealNumberUI+ "-" +sOrderUI, "Exceptions for Order "+sOrderUI+ " not dispalyed", "Validation successful for  : \t Order Number: "+sOrderUI, "Pass");
						sExceptionRecord="No Exception records";
					
					}
                  // }else
					// if(sMultiDept.equalsIgnoreCase("Yes"))
					// {
							
						/*(TestDriver.driver.findElements(By.xpath(SphereModules.Transaction_Accordian_Table_Rows_xp)).size()>0==true)
							{
								obj.repAddData( "Verify  exceptions on Exceptions Screen for: " +sDealNumberUI+ "-" +sOrderUI, "Exceptions for Order "+sOrderUI+ "Should be dispalyed", "Validation successful for  : \t Order Number: "+sOrderUI, "Pass");  
								System.out.println("Exceptions exist");	
								sExceptionRecord="Exception records found";
							}
							else{
								obj.repAddData( "Verify  exceptions on Exceptions Screen for: " +sDealNumberUI+ "-" +sOrderUI, "Exceptions for Order "+sOrderUI+ " not dispalyed", "Validation failed for  : \t Order Number: "+sOrderUI, "Fail");
								sExceptionRecord="Exception records not found";
							}*/
						// }
				} catch (Exception e) {
					// TODO Auto-generated catch block
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.i.e"+e.getMessage(), "Fail");
					e.printStackTrace();
				}
				
				try {
					
				    sQuery = objSQLConfig.sTransaction_Status_Query;
				    sQuery = sQuery.replaceAll("deal_number_param",sDealNumberUI);//use Deal Number here instead of DealTitle;
				    sQuery = sQuery.replaceAll("set_number_param",sOrderUI);
				    sQuery = sQuery.replaceAll("department_system_number_param",sDeptSystemNum);
				    //sQuery = sQuery.replaceAll("performing_cost_center_param",sCostCenterNum.replaceAll("00",""));
				    sQuery = sQuery.replaceAll("interface_code_param",sInterfaceCode);
				    sQuery = sQuery.replaceAll("transaction_date_param",sTransactionDatenew);
				    sQuery = sQuery.replaceAll("performing_cost_center_param",sCostCenterNum);
				    
				    TestDriver.conn = objDBUtility.fnOpenDBConnection();
					TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
					HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
					
					objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
					if(!mTableDataDB.isEmpty())
					{
						sTransactionStatusDB = mTableDataDB.get(1).get(1).toString().trim();
					}
					else
					{
						//sTransactionStatusDB = "No record for Transaction Status found";
						sTransactionStatusDB ="No record found";
					
					}
					
						 
				} catch (Exception e) {
					// TODO Auto-generated catch block
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test "+sDealNumberUI+ " Transaction query", "Exception found in current test.i.e" +e.getMessage(), "Fail");
					e.printStackTrace();
				}
				try {
				    sQuery1 = objSQLConfig.sBillingRequest_Status_Query;
				    sQuery1 = sQuery1.replaceAll("deal_number_param",sDealNumberUI);//use Deal Number here instead of DealTitle;
				    sQuery1 = sQuery1.replaceAll("set_number_param",sOrderUI);
				    sQuery1 = sQuery1.replaceAll("department_system_number_param",sDeptSystemNum);
				    //sQuery1 = sQuery1.replaceAll("performing_cost_center_param",sCostCenterNum.replaceAll("00",""));
				    sQuery1 = sQuery1.replaceAll("performing_cost_center_param",sCostCenterNum);
				    sQuery1 = sQuery1.replaceAll("interface_code_param",sInterfaceCode);
					sQuery1 = sQuery1.replaceAll("transaction_date_param",sTransactionDatenew);
				    //use Deal Number here instead of DealTitle;
		
				    TestDriver.conn = objDBUtility.fnOpenDBConnection();
					TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
					HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
					
					objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);

					if(!mTableDataDB1.isEmpty())
					{
						sBillingRequestStatusDB = mTableDataDB1.get(1).get(1).toString().trim();
					}
					else
					{
						//sBillingRequestStatusDB = "No record for Billing Request Status found";
						sBillingRequestStatusDB = "No record found";
					}
						 					 
				} catch (Exception e) {
					// TODO Auto-generated catch block
					obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.i.e " +e.getMessage(), "Fail");
					e.printStackTrace();
				}
				/////
				//Put DB things here
				  System.out.println(i+"th record complete");
				/////
				//TestDriver.bw1.append("\n"+sDealNumberUI+","+sOrderUI+",\'"+sDeptSystemNum+",\'"+sCostCenterNum+","+sMultiDept+","+sTransactionStatusDB+","+sBillingRequestStatusDB+","+sOrderStatus+","+sTransactionRecord+","+sExceptionRecord+","+sRecordStatus);
				TestDriver.bw1.append("\n"+sDealNumberUI+","+sOrderUI+",\'"+sDeptSystemNum+",\'"+sCostCenterNum+","+sInterfaceCode+","+sTransactionDate+","+sTransactionStatusDB+","+sBillingRequestStatusDB+","+sOrderStatus+","+sTransactionRecord+","+sExceptionRecord+","+sRecordStatus);
			
			}
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC70002 Failed!", e );
		}
		finally {
			fnCloseOpenedForm();
	
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC70002 Completed");
		}
		return obj;
		}
	}
		
	





