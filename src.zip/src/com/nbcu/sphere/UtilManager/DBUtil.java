package com.nbcu.sphere.UtilManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Properties;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.seleniumhq.jetty7.util.log.Log;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.PreparedStatement;
import com.nbcu.sphere.TestDriver;
import com.nbcu.sphere.ConfigManager.FileLocSetter;
import com.nbcu.sphere.ConfigManager.SQLConfig;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.pool.OracleDataSource;

public class DBUtil {

	public static ResultSet rsetlocal = null;
	public static Statement stmtlocal = null;
	public static Connection connlocal = null;
	SQLConfig objSQLConfig = new SQLConfig();
	// GenericFunctionLibrary objGenericFunctionLibrary = new
	// GenericFunctionLibrary();
	PropUtil objPropertiesUtility = new PropUtil();
	Properties prop = objPropertiesUtility.fnLoadObjects(FileLocSetter.sConfigPath, "global.properties");
	// String sConnString =
	// "jdbc:oracle:thin:"+prop.getProperty("atmUser")+"/"+prop.getProperty("atmPass")+"@"+prop.getProperty("atmHostName")+":"+prop.getProperty("atmPort")+"/"+prop.getProperty("atmSid");
	// String sConnString =
	// "jdbc:oracle:thin:"+prop.getProperty("atmUser")+"/"+prop.getProperty("atmPass")+"@"+prop.getProperty("atmHostName")+":"+prop.getProperty("atmPort")+"/"+prop.getProperty("atmSid");
	/*String sDBUrl = "jdbc:mysql://" + prop.getProperty("dbHostName") + ":" + prop.getProperty("dbPort") + "/"
			+ prop.getProperty("dbSchema") + "?autoReconnect=true&useSSL=false";
	String sDriverClass = "com.mysql.jdbc.Driver";*/

	String sDBUrl = "jdbc:mysql://dbHostNameParam:" + prop.getProperty("dbPort") + "/" + prop.getProperty("dbSchema") + "?autoReconnect=true&useSSL=false";
	//String sDBUrl = "jdbc:mysql://dbHostNameParam:" + prop.getProperty("dbPort");
    
	String sDriverClass = "com.mysql.jdbc.Driver";
    
    String sDBUrSosap = "jdbc:mysql://dbHostNameParam:" + prop.getProperty("dbPortSosap") + "/" + prop.getProperty("dbSchemaSosap") + "?autoReconnect=true&useSSL=false";
 

    public Connection fnOpenDBConnectionTest1() throws Exception {
        Connection mySQLConn = null;
        // TestDriver.rset = null;
        try {

            Class.forName(sDriverClass).newInstance();
            // Get connection to DB
            
            ///////To run smoke tests in dev environment from jenkins, change to dev dbhostname details in properties file// 
           
           /* sDBUrl = sDBUrl.replaceAll("dbHostNameParam", prop.getProperty("dbHostName"));
			
            sDBUrl = sDBUrl.replaceAll("dbHostNameParam", System.getenv("dbHostName"));   
			System.out.println("In Jenkins phase1 >>>>>>"+System.getenv("sDBUrl"));
			
			if(sDBUrl==null)
			{
				sDBUrl = sDBUrl.replaceAll("dbHostNameParam", prop.getProperty("dbHostName"));
                mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("dbUser"), prop.getProperty("dbPass"));
			}
			else{
				 sDBUrl = sDBUrl.replaceAll("dbHostNameParam", System.getenv("dbHostName"));    
	             mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("devdbUser"), prop.getProperty("devdbPass"));
			}*/
			
			if(TestDriver.sPhase.equalsIgnoreCase("Smoke"))
            {
                sDBUrl = sDBUrl.replaceAll("dbHostNameParam", System.getenv("dbHostName"));    
                mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("devdbUser"), prop.getProperty("devdbPass"));
            }
            else
            {
                sDBUrl = sDBUrl.replaceAll("dbHostNameParam", prop.getProperty("dbHostName"));
                mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("dbUser"), prop.getProperty("dbPass"));
            }
            
           // sDBUrl = sDBUrl.replaceAll("dbHostNameParam", prop.getProperty("dbHostName"));
           // mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("dbUser"), prop.getProperty("dbPass"));
           
            
            /*
             * OracleDataSource ods = new OracleDataSource();
             * System.out.println(sConnString); ods.setURL(sConnString);
             * 
             * // connect to the database and turn off auto commit ocon =
             * (OracleConnection)ods.getConnection(); ocon.setAutoCommit(true);
             */
        } catch (Exception e) {
            System.out.println("Function fnOpenDBConnection Failed");
            TestDriver.log.error("Function fnOpenDBConnection Failed ", e);
            throw (e);
        }

        return mySQLConn;
    }
    
    
    
    
    
    public Connection fnOpenDBConnection() throws Exception {
    	Connection mySQLConn = null;
        try {
        	
            String strSshUser = "ec2-user"; // SSH loging username
            String strSshPassword = ""; // SSH login password
            String strSshHost = "ec2-54-202-25-120.us-west-2.compute.amazonaws.com"; // hostname or ip or
                                                            // SSH server
            //int nSshPort = 22; // remote SSH host port number
            String strRemoteHost = "rds-mysql-sphere-qa.cottheu5yzrk.us-west-2.rds.amazonaws.com"; // hostname or
                                                                    // ip of
                                                                    // your
                                                                    // database
                                                             // server
            int nLocalPort = 3306; // local port number use to bind SSH tunnel
            int nRemotePort = 3306; // remote port number of your database
            //String strDbUser = "readwrite"; // database loging username
            //String strDbPassword = "Iforg3tWhatItW4$"; // database login password

            String strDbUser = "readonly"; // database loging username
            String strDbPassword = "dn520u7r20v2ll14"; // database login password
            /*doSshTunnel(strSshUser, strSshPassword, strSshHost, nSshPort, strRemoteHost, nLocalPort,
                    nRemotePort);*/

            final JSch jsch = new JSch();
            Session session = jsch.getSession(strSshUser, strSshHost, 3306);
            session.setPassword(strSshPassword);

            final Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);

            session.connect();
            session.setPortForwardingL(nLocalPort, strRemoteHost, nRemotePort);
            
            
            Class.forName("com.mysql.jdbc.Driver");
            mySQLConn = DriverManager.getConnection("jdbc:mysql://localhost:" + nLocalPort, strDbUser,
                    strDbPassword);
            //con.close();
        } catch (Exception e) {
        	System.out.println("Function fnOpenDBConnection Failed");
            e.printStackTrace();
        } 
        return mySQLConn;
    }
  
   
    public Connection fnOpenDBConnectionsoap() throws Exception {
        Connection mySQLConn = null;
        // TestDriver.rset = null;
        try {
        	String sDBUrl = "jdbc:mysql://dbHostNameParam:" + prop.getProperty("dbPort") + "/" + prop.getProperty("dbSchemaSOAP") + "?autoReconnect=true&useSSL=false";
       	 
        	 String sDriverClass = "com.mysql.jdbc.Driver";
    		
    	          Class.forName(sDriverClass).newInstance();
    	          sDBUrl = sDBUrl.replaceAll("dbHostNameParam", prop.getProperty("dbSchemaSOAPhhostname"));
                  mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("dbsoapusername"), prop.getProperty("dbsoappassword"));
                    
    	      
          
        } catch (Exception e) {
            System.out.println("Function fnOpenDBConnection Failed");
            TestDriver.log.error("Function fnOpenDBConnection Failed ", e);
            throw (e);
        }

        return mySQLConn;
    }
    
    
    
    public Connection fnOpenDBConnection1() throws Exception {
        Connection mySQLConn = null;
        // TestDriver.rset = null;
        try {

            Class.forName(sDriverClass).newInstance();
           
			
                sDBUrl = sDBUrl.replaceAll("dbHostNameParam", prop.getProperty("dbHostNameSosap"));
                mySQLConn = DriverManager.getConnection(sDBUrl, prop.getProperty("devdbUserSosap"), prop.getProperty("devdbPassSosap"));
           
          
        } catch (Exception e) {
            System.out.println("Function fnOpenDBConnection Failed");
            TestDriver.log.error("Function fnOpenDBConnection Failed ", e);
            throw (e);
        }

        return mySQLConn;
    }

	public void fnCloseDBConnection(Statement stmt, ResultSet rset, Connection conn) throws Exception {

		try {
			// stmt.close();
			if (rset != null) {
				rset.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			System.out.println("Function fnCloseDBConnection Failed");
			TestDriver.log.error("Function fnCloseDBConnection Failed ", e);
			throw (e);
		}

	}


	public HashMap<Integer, HashMap<Integer, String>> fnWriteResultSet1(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection();
	//	String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		
					
		
		return mTableData;

	}
	
	
	public HashMap<Integer, HashMap<Integer, String>> fnWriteResultSet3(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection1();
	//	String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		
					
		
		return mTableData;

	}
	
	
	
	public ResultSet fnGetDBData(Connection conn, String sQuery) throws Exception {

		// ResultSet rset = null;
		try {
			// create the statement and execute the query
			TestDriver.stmt = (Statement) conn.createStatement();
			// Statement stmt = (Statement) conn.createStatement();
			// method which returns the requested information as rows of data
			TestDriver.rset = (ResultSet) TestDriver.stmt.executeQuery(sQuery);
			// rset = (ResultSet) stmt.executeQuery(sQuery);

			// OracleStatement stmt = (OracleStatement)ocon.createStatement();
			// rset = (OracleResultSet)stmt.executeQuery(sQuery);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			TestDriver.log.error("Function fnGetDBData Failed ", e);
		}
		return TestDriver.rset;
	}
	
	public ResultSet fnGetDBDataUpdate(Connection conn, String sQuery) throws Exception {

		// ResultSet rset = null;
		try {
			// create the statement and execute the query
			TestDriver.stmt = (Statement) conn.createStatement();
			Statement stmt = null;
			// Statement stmt = (Statement) conn.createStatement();
			// method which returns the requested information as rows of data
			//TestDriver.rset = (ResultSet) TestDriver.stmt.executeQuery(sQuery);
			int rset = (int) TestDriver.stmt.executeUpdate(sQuery);
			TestDriver.rset = (ResultSet)((ResultSet) TestDriver.stmt.executeQuery(sQuery));
			// OracleStatement stmt = (OracleStatement)ocon.createStatement();
			// rset = (OracleResultSet)stmt.executeQuery(sQuery);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			TestDriver.log.error("Function fnGetDBData Failed ", e);
		}
		return TestDriver.rset;
	}
	
	
	@SuppressWarnings("unused")
	public HashMap<Integer, HashMap<Integer, String>> fnWriteResultSet(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection();
		String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		try {
			if (resultSet != null)
			{
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				Integer iColCount = rsMetaData.getColumnCount();
				// System.out.println(rsMetaData.getColumnName(2));
				Integer iRow = 0;
				while (resultSet.next())
				{
					iRow = iRow + 1;
					mTableData.put(iRow, new HashMap<Integer, String>()); // Map row starts with 1
					for (int iCol = 1; iCol <= iColCount; iCol++)
					{
						String sColValue = "";
                        System.out.println(rsMetaData.getColumnName(iCol).toString());
						if (resultSet.getString(iCol) == null)
						{
							sColValue = "";
						} 
						else {
							if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("last_login_timestamp")&&
									resultSet.getTimestamp(iCol) != null){//try with string and convert it to date for sorting
								Timestamp sDateValue = resultSet.getTimestamp(iCol);

								//SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy hh:mm a"); //old
								SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");  //new

								if(!TestDriver.zoneIdDefault.toString().equalsIgnoreCase("America/Los_Angeles"))
								{

									String sUpdatedDate = sDateValue.toLocalDateTime().plusHours(3).toString();
									System.out.println(sUpdatedDate);

									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
									Date d = sdf.parse(sUpdatedDate);
									sColValue = format.format(d);

								}
								else
								{
									sColValue = format.format(sDateValue);
								}
								
								System.out.println("New Date--->" + sColValue); 

							}
							else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("updated_timestamp")

									&& resultSet.getTimestamp(iCol) != null)

							{
								Timestamp sDateValue = resultSet.getTimestamp(iCol);
								System.out.println("DB data value :" + sDateValue);
								// SimpleDateFormat format = new
								// SimpleDateFormat("MM/dd/yy hh:mm a"); //old
								// SimpleDateFormat format = new  SimpleDateFormat("MM/dd/yyyy hh:mm a"); //new
								SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");// very
								// new
								if (!TestDriver.zoneIdDefault.toString().equalsIgnoreCase("America/Los_Angeles"))
								{
									System.out.println("Before to String " + sDateValue.toLocalDateTime().plusHours(3));
									String sUpdatedDate = sDateValue.toLocalDateTime().plusHours(3).toString();
									if (sUpdatedDate.length() == 16)
									{
										sUpdatedDate = sUpdatedDate + ":00";
									}
									System.out.println(sUpdatedDate);
									//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd'T'HH:mm:ss");
									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
									//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm a");
									Date d = sdf.parse(sUpdatedDate);
									sColValue = format.format(d);
								}
								else
								{
									sColValue = format.format(sDateValue);
								}

								System.out.println("New Date--->" + sColValue);
							}
							else if((rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("COST_CENTER_DESCRIPT")))
							{
								sColValue = resultSet.getString(iCol);
								sColValue= sColValue.replace("  ", " ");
							}
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("SHORT_TEXT"))
							{
								sColValue = resultSet.getString(iCol);
								if (sColValue.contains("GEAR� (9/2007 -� Pre"))
								{
									sColValue.replace("  "," ").trim();

								}
							}
							else  if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone_number"))
							{
								sColValue = resultSet.getString(iCol);
                                System.out.println(sColValue);
								if (sColValue.contains("+"))
								{
									sColValue = sColValue.replace("+", "").trim();
								}

							}                                                          ///alias name of is_credit_permanent column on customers table
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_permanent")) ///alias name of is_credit_permanent column on customers table
							{
								sColValue = resultSet.getString(iCol);
								// System.out.println("DB data value :" + resultSet.getDate(new SimpleDateFormat("MM/dd/yyyy").format(iCol)));
								
								if(!sColValue.equalsIgnoreCase("permanent"))
								{
									DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
									//String sUpdatedDate = sDateValue.toString();
									//System.out.println(sUpdatedDate);
									DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
									Date d = sdf.parse(sColValue);
									sColValue= formatter.format(d);	
								}
								/*else
								{
									sColValue =sColValue;
								}*/
								//sColValue= formatter.format(sDateValue);
								//System.out.println("DB data value :" + sColValue);	
								//mTableData.get(iRow).put(iCol, sColValue.trim());	
							}

							/*else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_limit")) 
							{
								sColValue = resultSet.getString(iCol);
								if (sColValue.contains(".00")){
									//sColValue = "$"+sColValue.replace(".00","").trim();
									sColValue = sColValue.replace(".00","").trim();
								}
								if (sColValue.length()==1){
									sColValue ="$"+sColValue;
								}else
									if (sColValue.length()==4){
										sColValue ="$"+sColValue.substring(0,1).concat(",")+sColValue.substring(1,4).trim();
									}else
										if (sColValue.length()==5){
											sColValue ="$"+sColValue.substring(0,2).concat(",")+sColValue.substring(2,5).trim();	
										}else
											if (sColValue.length()==6){
												sColValue ="$"+sColValue.substring(0,3).concat(",")+sColValue.substring(3,6).trim();
											}else
												if (sColValue.length()==7){
													sColValue ="$"+sColValue.substring(0,1).concat(",")+sColValue.substring(1,4).concat(",")+sColValue.substring(4,7).trim();
												}
							}*/

							else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("customer_type_code_id")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("production_type_code_id")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("national_account_id")||
									rsMetaData.getColumnName(iCol).toString().contains("code_id"))
							{

								String sColValueID = resultSet.getString(iCol);
								String sColValue1 = "";
								if (sColValueID.contains(","))
								{
									String[] arrNum = sColValueID.split(",");
									sColValue1 = arrNum[0].toString().trim();
									sColValueID = arrNum[1].toString().trim();
								}
								sLookupQuery = sLookupQuery.replaceAll("lookup_code_param", sColValueID);
								stmtlocal = (Statement) connlocal.createStatement();
								rsetlocal = (ResultSet) stmtlocal.executeQuery(sLookupQuery);

								while (rsetlocal.next()) {
									sColValue = rsetlocal.getString(1);
								}
								if (!sColValue1.equalsIgnoreCase(""))
								{
									sColValue = sColValue1 + ", " + sColValue.trim();
								}

								sLookupQuery = sLookupQuery.replaceAll(sColValueID, "lookup_code_param"); // reset
								// query
							} 
							else
							{
								sColValue = resultSet.getString(iCol);
							}
						}
						System.out.println(sColValue);
						mTableData.get(iRow).put(iCol, sColValue.trim());
					}
				}

			} else {
				System.out.println("No Data found in the result set");
			}
			fnCloseDBConnection(stmtlocal, rsetlocal, connlocal);
		} catch (Exception e) {
			System.out.println("Function fnWriteResultSet Failed");
			TestDriver.log.error("Function fnWriteResultSet Failed ", e);
			throw (e);
		}
		return mTableData;

		/*
		 * while (resultSet.next()) {
		 * 
		 * String sso_id = resultSet.getString("sso_id"); String first_name =
		 * resultSet.getString("first_name"); String last_name =
		 * resultSet.getString("last_name"); String email_address =
		 * resultSet.getString("email_address"); Timestamp last_login_timestamp
		 * = resultSet.getTimestamp("last_login_timestamp"); SimpleDateFormat
		 * format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		 * System.out.println("New Date--->" +
		 * format.format(last_login_timestamp));
		 * 
		 * System.out.println("sso_id: " + sso_id); System.out.println(
		 * "first_name: " + first_name); System.out.println("last_name: " +
		 * last_name); System.out.println("email_address: " + email_address);
		 * System.out.println("last_login_timestamp: " + last_login_timestamp);
		 * }
		 */
	}
	public HashMap<Integer, HashMap<Integer, String>> fnWriteResultSetTest(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection();
		String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		try {
			if (resultSet != null)
			{
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				Integer iColCount = rsMetaData.getColumnCount();
				// System.out.println(rsMetaData.getColumnName(2));
				Integer iRow = 0;
				while (resultSet.next())
				{
					iRow = iRow + 1;
					mTableData.put(iRow, new HashMap<Integer, String>()); // Map row starts with 1
					for (int iCol = 1; iCol <= iColCount; iCol++)
					{
						String sColValue = "";
                        System.out.println(rsMetaData.getColumnName(iCol).toString());
						if (resultSet.getString(iCol) == null)
						{
							sColValue = "";
						} 
						else {
							if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("last_login_timestamp")&&
									resultSet.getTimestamp(iCol) != null){//try with string and convert it to date for sorting
								Timestamp sDateValue = resultSet.getTimestamp(iCol);

								//SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy hh:mm a"); //old
								SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");  //new

								if(!TestDriver.zoneIdDefault.toString().equalsIgnoreCase("America/Los_Angeles"))
								{

									String sUpdatedDate = sDateValue.toLocalDateTime().plusHours(3).toString();
									System.out.println(sUpdatedDate);

									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
									Date d = sdf.parse(sUpdatedDate);
									sColValue = format.format(d);

								}
								else
								{
									sColValue = format.format(sDateValue);
								}
								
								System.out.println("New Date--->" + sColValue); 

							}
							else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("updated_timestamp")

									&& resultSet.getTimestamp(iCol) != null)

							{
								Timestamp sDateValue = resultSet.getTimestamp(iCol);
								System.out.println("DB data value :" + sDateValue);
								// SimpleDateFormat format = new
								// SimpleDateFormat("MM/dd/yy hh:mm a"); //old
								// SimpleDateFormat format = new  SimpleDateFormat("MM/dd/yyyy hh:mm a"); //new
								SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");// very
								// new
								if (!TestDriver.zoneIdDefault.toString().equalsIgnoreCase("America/Los_Angeles"))
								{
									System.out.println("Before to String " + sDateValue.toLocalDateTime().plusHours(3));
									String sUpdatedDate = sDateValue.toLocalDateTime().plusHours(3).toString();
									if (sUpdatedDate.length() == 16)
									{
										sUpdatedDate = sUpdatedDate + ":00";
									}
									System.out.println(sUpdatedDate);
									//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd'T'HH:mm:ss");
									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
									//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm a");
									Date d = sdf.parse(sUpdatedDate);
									sColValue = format.format(d);
								}
								else
								{
									sColValue = format.format(sDateValue);
								}

								System.out.println("New Date--->" + sColValue);
							}
							else if((rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("COST_CENTER_DESCRIPT")))
							{
								sColValue = resultSet.getString(iCol);
								sColValue= sColValue.replace("  ", " ");
							}
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("SHORT_TEXT"))
							{
								sColValue = resultSet.getString(iCol);
								if (sColValue.contains("GEAR� (9/2007 -� Pre"))
								{
									sColValue.replace("  "," ").trim();

								}
							}
							else  if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone_number"))
							{
								sColValue = resultSet.getString(iCol);
                                System.out.println(sColValue);
								if (sColValue.contains("+"))
								{
									sColValue = sColValue.replace("+", "").trim();
								}

							}                                                          ///alias name of is_credit_permanent column on customers table
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_permanent")) ///alias name of is_credit_permanent column on customers table
							{
								sColValue = resultSet.getString(iCol);
								// System.out.println("DB data value :" + resultSet.getDate(new SimpleDateFormat("MM/dd/yyyy").format(iCol)));
								
								if(!sColValue.equalsIgnoreCase("permanent"))
								{
									DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
									//String sUpdatedDate = sDateValue.toString();
									//System.out.println(sUpdatedDate);
									DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
									Date d = sdf.parse(sColValue);
									sColValue= formatter.format(d);	
								}
									}

							

							else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("customer_type_code_id")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("production_type_code_id")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("national_account_id")||
									rsMetaData.getColumnName(iCol).toString().contains("code_id"))
							{

								String sColValueID = resultSet.getString(iCol);
								String sColValue1 = "";
								if (sColValueID.contains(","))
								{
									String[] arrNum = sColValueID.split(",");
									sColValue1 = arrNum[0].toString().trim();
									sColValueID = arrNum[1].toString().trim();
								}
							//	sLookupQuery = sLookupQuery.replaceAll("lookup_code_param", sColValueID);
								stmtlocal = (Statement) connlocal.createStatement();
								rsetlocal = (ResultSet) stmtlocal.executeQuery(sLookupQuery);

								while (rsetlocal.next()) {
									sColValue = rsetlocal.getString(1);
								}
								if (!sColValue1.equalsIgnoreCase(""))
								{
									sColValue = sColValue1 + ", " + sColValue.trim();
								}

								sLookupQuery = sLookupQuery.replaceAll(sColValueID, "lookup_code_param"); // reset
								// query
							} 
							else
							{
								sColValue = resultSet.getString(iCol);
							}
						}
						System.out.println(sColValue);
						mTableData.get(iRow).put(iCol, sColValue.trim());
					}
				}

			} else {
				System.out.println("No Data found in the result set");
			}
			fnCloseDBConnection(stmtlocal, rsetlocal, connlocal);
		} catch (Exception e) {
			System.out.println("Function fnWriteResultSet Failed");
			TestDriver.log.error("Function fnWriteResultSet Failed ", e);
			throw (e);
		}
		return mTableData;
	}
	
	public HashMap<Integer, HashMap<Integer, String>> fnWriteResultSet2(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection1();
		String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		try {
			if (resultSet != null)
			{
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				Integer iColCount = rsMetaData.getColumnCount();
				// System.out.println(rsMetaData.getColumnName(2));
				Integer iRow = 0;
				while (resultSet.next())
				{
					iRow = iRow + 1;
					mTableData.put(iRow, new HashMap<Integer, String>()); // Map row starts with 1
					for (int iCol = 1; iCol <= iColCount; iCol++)
					{
						String sColValue = "";
                        System.out.println(rsMetaData.getColumnName(iCol).toString());
						if (resultSet.getString(iCol) == null)
						{
							sColValue = "";
						} 
						else {
							if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("last_login_timestamp")&&
									resultSet.getTimestamp(iCol) != null){//try with string and convert it to date for sorting
								Timestamp sDateValue = resultSet.getTimestamp(iCol);

								//SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy hh:mm a"); //old
								SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");  //new

								if(!TestDriver.zoneIdDefault.toString().equalsIgnoreCase("America/Los_Angeles"))
								{

									String sUpdatedDate = sDateValue.toLocalDateTime().plusHours(3).toString();
									System.out.println(sUpdatedDate);

									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
									Date d = sdf.parse(sUpdatedDate);
									sColValue = format.format(d);

								}
								else
								{
									sColValue = format.format(sDateValue);
								}
								
								System.out.println("New Date--->" + sColValue); 

							}
							else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("updated_timestamp")

									&& resultSet.getTimestamp(iCol) != null)

							{
								Timestamp sDateValue = resultSet.getTimestamp(iCol);
								System.out.println("DB data value :" + sDateValue);
								// SimpleDateFormat format = new
								// SimpleDateFormat("MM/dd/yy hh:mm a"); //old
								// SimpleDateFormat format = new  SimpleDateFormat("MM/dd/yyyy hh:mm a"); //new
								SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");// very
								// new
								if (!TestDriver.zoneIdDefault.toString().equalsIgnoreCase("America/Los_Angeles"))
								{
									System.out.println("Before to String " + sDateValue.toLocalDateTime().plusHours(3));
									String sUpdatedDate = sDateValue.toLocalDateTime().plusHours(3).toString();
									if (sUpdatedDate.length() == 16)
									{
										sUpdatedDate = sUpdatedDate + ":00";
									}
									System.out.println(sUpdatedDate);
									//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd'T'HH:mm:ss");
									SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
									//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm a");
									Date d = sdf.parse(sUpdatedDate);
									sColValue = format.format(d);
								}
								else
								{
									sColValue = format.format(sDateValue);
								}

								System.out.println("New Date--->" + sColValue);
							}
							else if((rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("COST_CENTER_DESCRIPT")))
							{
								sColValue = resultSet.getString(iCol);
								sColValue= sColValue.replace("  ", " ");
							}
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("SHORT_TEXT"))
							{
								sColValue = resultSet.getString(iCol);
								if (sColValue.contains("GEAR� (9/2007 -� Pre"))
								{
									sColValue.replace("  "," ").trim();

								}
							}
							else  if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone_number"))
							{
								sColValue = resultSet.getString(iCol);
                                System.out.println(sColValue);
								if (sColValue.contains("+"))
								{
									sColValue = sColValue.replace("+", "").trim();
								}

							}                                                          ///alias name of is_credit_permanent column on customers table
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_permanent")) ///alias name of is_credit_permanent column on customers table
							{
								sColValue = resultSet.getString(iCol);
								// System.out.println("DB data value :" + resultSet.getDate(new SimpleDateFormat("MM/dd/yyyy").format(iCol)));
								
								if(!sColValue.equalsIgnoreCase("permanent"))
								{
									DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
									//String sUpdatedDate = sDateValue.toString();
									//System.out.println(sUpdatedDate);
									DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
									Date d = sdf.parse(sColValue);
									sColValue= formatter.format(d);	
								}
								/*else
								{
									sColValue =sColValue;
								}*/
								//sColValue= formatter.format(sDateValue);
								//System.out.println("DB data value :" + sColValue);	
								//mTableData.get(iRow).put(iCol, sColValue.trim());	
							}

							/*else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_limit")) 
							{
								sColValue = resultSet.getString(iCol);
								if (sColValue.contains(".00")){
									//sColValue = "$"+sColValue.replace(".00","").trim();
									sColValue = sColValue.replace(".00","").trim();
								}
								if (sColValue.length()==1){
									sColValue ="$"+sColValue;
								}else
									if (sColValue.length()==4){
										sColValue ="$"+sColValue.substring(0,1).concat(",")+sColValue.substring(1,4).trim();
									}else
										if (sColValue.length()==5){
											sColValue ="$"+sColValue.substring(0,2).concat(",")+sColValue.substring(2,5).trim();	
										}else
											if (sColValue.length()==6){
												sColValue ="$"+sColValue.substring(0,3).concat(",")+sColValue.substring(3,6).trim();
											}else
												if (sColValue.length()==7){
													sColValue ="$"+sColValue.substring(0,1).concat(",")+sColValue.substring(1,4).concat(",")+sColValue.substring(4,7).trim();
												}
							}*/

							else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("customer_type_code_id")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("production_type_code_id")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("national_account_id")||
									rsMetaData.getColumnName(iCol).toString().contains("code_id"))
							{

								String sColValueID = resultSet.getString(iCol);
								String sColValue1 = "";
								if (sColValueID.contains(","))
								{
									String[] arrNum = sColValueID.split(",");
									sColValue1 = arrNum[0].toString().trim();
									sColValueID = arrNum[1].toString().trim();
								}
								sLookupQuery = sLookupQuery.replaceAll("lookup_code_param", sColValueID);
								stmtlocal = (Statement) connlocal.createStatement();
								rsetlocal = (ResultSet) stmtlocal.executeQuery(sLookupQuery);

								while (rsetlocal.next()) {
									sColValue = rsetlocal.getString(1);
								}
								if (!sColValue1.equalsIgnoreCase(""))
								{
									sColValue = sColValue1 + ", " + sColValue.trim();
								}

								sLookupQuery = sLookupQuery.replaceAll(sColValueID, "lookup_code_param"); // reset
								// query
							} 
							else
							{
								sColValue = resultSet.getString(iCol);
							}
						}
						System.out.println(sColValue);
						mTableData.get(iRow).put(iCol, sColValue.trim());
					}
				}

			} else {
				System.out.println("No Data found in the result set");
			}
			fnCloseDBConnection(stmtlocal, rsetlocal, connlocal);
		} catch (Exception e) {
			System.out.println("Function fnWriteResultSet Failed");
			TestDriver.log.error("Function fnWriteResultSet Failed ", e);
			throw (e);
		}
		return mTableData;

		/*
		 * while (resultSet.next()) {
		 * 
		 * String sso_id = resultSet.getString("sso_id"); String first_name =
		 * resultSet.getString("first_name"); String last_name =
		 * resultSet.getString("last_name"); String email_address =
		 * resultSet.getString("email_address"); Timestamp last_login_timestamp
		 * = resultSet.getTimestamp("last_login_timestamp"); SimpleDateFormat
		 * format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		 * System.out.println("New Date--->" +
		 * format.format(last_login_timestamp));
		 * 
		 * System.out.println("sso_id: " + sso_id); System.out.println(
		 * "first_name: " + first_name); System.out.println("last_name: " +
		 * last_name); System.out.println("email_address: " + email_address);
		 * System.out.println("last_login_timestamp: " + last_login_timestamp);
		 * }
		 */
	}
	@SuppressWarnings("unused")
	public HashMap<Integer, HashMap<Integer, String>> fnWriteSortResultSet(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection();
		String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		try {
			if (resultSet != null) {
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				Integer iColCount = rsMetaData.getColumnCount();
				// System.out.println(rsMetaData.getColumnName(2));
				Integer iRow = 0;
				while (resultSet.next()) {
					iRow = iRow + 1;
					mTableData.put(iRow, new HashMap<Integer, String>()); // Map row starts with 1
					for (int iCol = 1; iCol <= iColCount; iCol++) {
						String sColValue = "";

						if (resultSet.getString(iCol) == null)
						{
							sColValue = "";
						} else {
							
							if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("last_login_timestamp")&&
									 resultSet.getString(iCol) != null){//try with string and convert it to date for sorting
								     String sDateValue = resultSet.getString(iCol);
								     String sformat="MM/dd/yyyy hh:mm a";
										SimpleDateFormat format = new SimpleDateFormat(sformat);
										sDateValue = sDateValue.replace("@ ", "");
										sDateValue = sDateValue.replace("PM", " PM");
										sDateValue = sDateValue.replace("AM", " AM");
										Date dtDesExpLastActivity = format.parse(sDateValue);
										System.out.println(dtDesExpLastActivity);								
										sColValue=format.format(dtDesExpLastActivity);
								
								//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
								//Date d = sdf.parse(sUpdatedDate);
								//sColValue = format.format(d);
								
								}
								else
								{
									//sColValue = format.format(sDateValue);
								}
								
							    System.out.println("New Date--->" + sColValue); 
							
							}
							 {
								sColValue = resultSet.getString(iCol);
							 }
						
						System.out.println(sColValue);
						mTableData.get(iRow).put(iCol, sColValue.trim());
					}
				}

			} else {
				System.out.println("No Data found in the result set");
			}
			fnCloseDBConnection(stmtlocal, rsetlocal, connlocal);
		} catch (Exception e) {
			System.out.println("Function fnWriteResultSet Failed");
			TestDriver.log.error("Function fnWriteResultSet Failed ", e);
			throw (e);
		}
		return mTableData;
}
		

	 public Boolean fnUpdateDBData(String sQuery) throws Exception {

		boolean bUpdateResult = false;
		try {

			PreparedStatement updateEXP = (PreparedStatement) TestDriver.conn.prepareStatement(sQuery);
			int updateEXP_done = updateEXP.executeUpdate();
			System.out.println(updateEXP_done);
			if (updateEXP_done == 1) {
				bUpdateResult = true;
			}

		} catch (Exception e) {
			bUpdateResult = false;
			System.out.println("Function fnUpdateDBData Failed");
			TestDriver.log.error("Function fnUpdateDBData Failed ", e);
			throw (e);
		}
		return bUpdateResult;

	}

	public Boolean fnPrePostUpdateConditionForRoles(String sRoleName) throws Exception {

		boolean bUpdateResult = false;
		try {
			String sQuery = "";
			if (sRoleName.equalsIgnoreCase("Sphere Admin")) {
				sQuery = objSQLConfig.sAdministration_UpdateRoleSphereAdmin_Query;
				TestDriver.log.info("Updating DB role as " + sRoleName);
			} else if (sRoleName.equalsIgnoreCase("Unnamed Role")) {
				sQuery = objSQLConfig.sAdministration_UpdateRoleAutomation_Query;
				TestDriver.log.info("Updating DB role as " + sRoleName);
			} else if (sRoleName.equalsIgnoreCase("Finance Admin")) {
				sQuery = objSQLConfig.sAdministration_UpdateRoleFinanceAdmin_Query;
				TestDriver.log.info("Updating DB role as " + sRoleName);
			}
			TestDriver.conn = fnOpenDBConnection();
			boolean bUpdateFlag = fnUpdateDBData(sQuery);
			fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			TestDriver.log.info("Updated DB role as " + sRoleName);
			System.out.println("Updated DB role as " + sRoleName);

		} catch (Exception e) {
			bUpdateResult = false;
			System.out.println("Function fnPrePostUpdateConditionForRoles Failed");
			TestDriver.log.error("Function fnPrePostUpdateConditionForRoles Failed ", e);
			throw (e);
		}
		return bUpdateResult;

	}

	@SuppressWarnings("unused")
	public HashMap<Integer, HashMap<Integer, String>> fnWriteCreditpageResultSet(ResultSet resultSet) throws Exception {
		// ResultSet is initially before the first data set
		HashMap<Integer, HashMap<Integer, String>> mTableData = new HashMap<Integer, HashMap<Integer, String>>();

		connlocal = fnOpenDBConnection();
		String sLookupQuery = objSQLConfig.sCommon_LookupCode_Query;
		String sLookupQuery2 = objSQLConfig.sCommon_LookupCode_Query2;
		try {
			if (resultSet != null)
			{
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				Integer iColCount = rsMetaData.getColumnCount();
				// System.out.println(rsMetaData.getColumnName(2));
				Integer iRow = 0;
				while (resultSet.next())
				{
					iRow = iRow + 1;
					mTableData.put(iRow, new HashMap<Integer, String>()); // Map row starts with 1
					for (int iCol = 1; iCol <= iColCount; iCol++)
					{
						String sColValue = "";

						if (resultSet.getString(iCol) == null)
						{
							sColValue = "";
						}else 
						{
							if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("inactivation_date")||
									rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_expiration")|| 
								rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_permanent"))
							{
								
                                String sDateValue = resultSet.getString(iCol);
                                if(!sDateValue.equalsIgnoreCase("permanent"))
                            {
                                
                                // System.out.println("DB data value :" + resultSet.getDate(new SimpleDateFormat("MM/dd/yyyy").format(iCol)));
								DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
								DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
								Date d = sdf.parse(sDateValue);
								
								sColValue= formatter.format(d);
								//sColValue= formatter.format(sDateValue);
								System.out.println("DB data value :" + sColValue);	
								} 
                                else
								{
									sColValue =sDateValue;
								}
								
							}
						
							else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_limit"))
							 {
								sColValue = resultSet.getString(iCol);
								
								if (sColValue.contains(".00"))
								{
									//sColValue = "$"+sColValue.replace(".00","").trim();
									sColValue = sColValue.replace(".00","").trim();
								}if (sColValue.length()==1){
									sColValue ="$"+sColValue;
								}else
								    if (sColValue.length()==4)
								{
									sColValue ="$"+sColValue.substring(0,1).concat(",")+sColValue.substring(1,4);
								}else
									if (sColValue.length()==5)
									{
										sColValue ="$"+sColValue.substring(0,2).concat(",")+sColValue.substring(2,5);	
							     }else
								    if (sColValue.length()==6)
								{
									sColValue ="$"+sColValue.substring(0,3).concat(",")+sColValue.substring(3,6);
								}else
									if (sColValue.length()==7){
										sColValue ="$"+sColValue.substring(0,1).concat(",")+sColValue.substring(1,4).concat(",")+sColValue.substring(4,7).trim();
									}
							
							 }
							 
							 else if (rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone_number")||
										rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone"))
								{
								sColValue = resultSet.getString(iCol);
								if (sColValue.length()==10)
								{
									
									 sColValue = "("+sColValue.substring(0,3).concat(")")+" "+sColValue.substring(3, 6)+"-"+sColValue.substring(6, 10);
									//telephoneNumber = "("+telephoneNumber.substring(0, 3)+")-"+telephoneNumber.substring(3, 6)+"-"+telephoneNumber.substring(6, 10);
								}
							
													
							}
							
							 else if(rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("customer_type_code_id")
									//|| rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("production_type_code_id")
									|| rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("national_account_id")
									|| rsMetaData.getColumnName(iCol).toString().contains("code_id"))
							  {
								String sColValueID = resultSet.getString(iCol);
								String sColValue1 = "";
								
								if (sColValueID.contains(","))
								{
									String[] arrNum = sColValueID.split(",");
									sColValue1 = arrNum[0].toString().trim();
									sColValueID = arrNum[1].toString().trim();
								}
								sLookupQuery = sLookupQuery.replaceAll("lookup_code_param", sColValueID);
								stmtlocal = (Statement) connlocal.createStatement();
								rsetlocal = (ResultSet) stmtlocal.executeQuery(sLookupQuery);

								while (rsetlocal.next())
								{
									sColValue = rsetlocal.getString(1);
								}
								if (!sColValue1.equalsIgnoreCase(""))
								{
									sColValue = sColValue1 + ", " + sColValue.trim();
								}

								sLookupQuery = sLookupQuery.replaceAll(sColValueID, "lookup_code_param"); // reset
																											// original
							  }
							 // query
							/* if (!rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("inactivation_date")&&
								(!rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_expiration")&&
								(!rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("credit_limit")&&
								(!rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone_number")&&
								(!rsMetaData.getColumnName(iCol).toString().equalsIgnoreCase("phone"))))))*/
						else 
							{
								 //else {
								//sColValue = resultSet.getString(iCol).toUpperCase();
								sColValue = resultSet.getString(iCol);
							}
						//}
						System.out.println(sColValue);
						
						mTableData.get(iRow).put(iCol, sColValue.trim());
						//}
						}
				    }

				}
			
			}
		          else {
				System.out.println("No Data found in the result set");
			}
			fnCloseDBConnection(stmtlocal, rsetlocal, connlocal);
		} catch (Exception e) {
			System.out.println("Function fnWriteResultSet Failed");
			TestDriver.log.error("Function fnWriteResultSet Failed ", e);
			throw (e);
		}
		return mTableData;

		/*
		 * while (resultSet.next()) {
		 * 
		 * String sso_id = resultSet.getString("sso_id"); String first_name =
		 * resultSet.getString("first_name"); String last_name =
		 * resultSet.getString("last_name"); String email_address =
		 * resultSet.getString("email_address"); Timestamp last_login_timestamp
		 * = resultSet.getTimestamp("last_login_timestamp"); SimpleDateFormat
		 * format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		 * System.out.println("New Date--->" +
		 * format.format(last_login_timestamp));
		 * 
		 * System.out.println("sso_id: " + sso_id); System.out.println(
		 * "first_name: " + first_name); System.out.println("last_name: " +
		 * last_name); System.out.println("email_address: " + email_address);
		 * System.out.println("last_login_timestamp: " + last_login_timestamp);
		 * }
		 */
	}
	
}
