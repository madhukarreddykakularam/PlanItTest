package com.nbcu.sphere;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.poi.ss.util.NumberToTextConverter;

import com.nbcu.sphere.ObjectRepository.SphereModules;

public class TestApplication {

	public static WebDriver driver;

	// To Generate Random Number
	public static int fnRandomNum(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}

	// To select a value from dropdown
	public static void SelectFromComboBox(String SelectValue, String TextValue) {
		WebElement select = driver.findElement(By.xpath(SelectValue));
		// ((JavascriptExecutor)
		// driver).executeScript("arguments[0].scrollIntoView(true);", select);
		if (select.isDisplayed())// ||select.isEnabled())
		{
			List<WebElement> options = select
					.findElements(By.tagName("option"));
			for (WebElement option : options) {
				if (TextValue.equalsIgnoreCase(option.getText().trim())) {

					option.click();
					System.out.println("Value " + TextValue + "is Selected");
					break;
				}
			}
		}
	}

	// To set text in a field
	public static void SendKeyByXpath(String Xpath, String key,
			String sFieldName) throws Exception {
		try {

			WebElement ele = driver.findElement(By.xpath(Xpath));
			// ((JavascriptExecutor)
			// driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			ele.clear();
			ele.sendKeys(key);

			System.out.println("Entered " + key + " data to " + sFieldName
					+ " field");
		} catch (Exception e) {
			System.out.println("--No Such Element Found--");

		}
	}

	// To Click
	public static void ClickByXpath(String value, String faceValue)
			throws Exception {
		try {
			WebElement ele;
			ele = driver.findElement(By.xpath(value));
			ele.click();
			System.out.println("Clicked on '" + faceValue + "'");

		} catch (Exception e) {
			System.out.println(faceValue + "Element is not displayed");

		}
	}

	// Extracting data from an Excel and storing it in ArrayList.
	// Fetches data from the said row(which is test case name which we mention
	// in the parameters
	public static ArrayList<String> getData(String testcaseName)
			throws IOException {

		ArrayList<String> a = new ArrayList<String>();

		FileInputStream fis = new FileInputStream(
				"C:\\Users\\206670561\\Desktop\\Data\\TestData.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		int sheets = workbook.getNumberOfSheets();
		for (int i = 0; i < sheets; i++)

		{
			if (workbook.getSheetName(i).equalsIgnoreCase("testdata")) {
				XSSFSheet sheet = workbook.getSheetAt(i);
				Iterator<Row> rows = sheet.iterator();
				Row firstrow = rows.next();
				Iterator<Cell> ce = firstrow.cellIterator();
				int k = 0;
				int coloumn = 0;
				while (ce.hasNext()) {
					Cell value = ce.next();

					if (value.getStringCellValue()
							.equalsIgnoreCase("TestCases")) {
						coloumn = k;

					}

					k++;
				}
				System.out.println(coloumn);

				while (rows.hasNext()) {

					Row r = rows.next();

					if (r.getCell(coloumn).getStringCellValue()
							.equalsIgnoreCase(testcaseName)) {
						Iterator<Cell> cv = r.cellIterator();
						while (cv.hasNext()) {
							Cell c = cv.next();

							a.add(c.getStringCellValue());

						}
					}
				}
			}
		}
		return a;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Automation_Workspace\\Sphere_Automation1\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();

			ArrayList<String> Data = getData("Scenario1");

			String url = Data.get(1);
			String userName = Data.get(2);
			String Password = Data.get(3);
			String ZeroQuantity = Data.get(4);
			String TotalQuantity = Data.get(5);

			driver.get(url);
			WebDriverWait w = new WebDriverWait(driver, 20);
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.HomePageLogin)));
			ClickByXpath(ObjRepository.HomePageLogin, "Log in");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.LoginPage_WelcomeMessage)));
			String actWelcomeMessage = driver.findElement(
					By.xpath(ObjRepository.LoginPage_WelcomeMessage)).getText();
			if (actWelcomeMessage.equalsIgnoreCase("Welcome, Please Sign In!")) {
				System.out.println("Message is displayed as "
						+ actWelcomeMessage);
			} else {
				System.out.println("Message is not displayed as "
						+ actWelcomeMessage);
			}

			SendKeyByXpath(ObjRepository.LoginPage_MailId, userName, "Mail ID");
			SendKeyByXpath(ObjRepository.LoginPage_Password, Password,
					"Password");
			ClickByXpath(ObjRepository.LoginPage_LoginButton, "Submit Button");

			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.LogOut_Button)));
			String LogInUsername = driver.findElement(
					By.xpath(ObjRepository.HomePage_LoggedInUserName))
					.getText();
			if (LogInUsername.equalsIgnoreCase("testdemowebshop@gmail.com")) {
				System.out.println("UserAccountID is displayed as "
						+ LogInUsername);
			} else {
				System.out.println("UserAccountID is not displayed as "
						+ LogInUsername);
			}

			driver.findElement(
					By.xpath(ObjRepository.HomePage_ShoppingCart_Button))
					.click();
			try {
				Boolean Display = driver
						.findElement(
								By.xpath("//div[contains(text(),'Your Shopping Cart is empty!')]"))
						.isDisplayed();
			} catch (Exception e) {
				driver.findElement(By.xpath(ObjRepository.ShoppingCart_Qty))
						.clear();
				SendKeyByXpath(ObjRepository.ShoppingCart_Qty, ZeroQuantity,
						"Quantity");
				ClickByXpath(ObjRepository.ShoppingCart_UpdtaeShoppingCart,
						"Update SHopping Cart");
			}

			ClickByXpath(ObjRepository.DemoWorkShop, "Demo Work Shop");
			ClickByXpath(ObjRepository.HomePage_Categories_Books, "Books");
			ClickByXpath(ObjRepository.HomePage_Categories_Books, "Books");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.Books_HealthBook)));
			ClickByXpath(ObjRepository.Books_HealthBook, "Health Book");
			String Price = driver.findElement(
					By.xpath(ObjRepository.Books_HealthBook_Price)).getText().trim();
			
			Float prc = Float.parseFloat(Price);
			Float qnty = Float.parseFloat(TotalQuantity);
			Float subTotal = prc * qnty;
			String Subtotl = String.valueOf(subTotal);
			driver.findElement(
					By.xpath(ObjRepository.Books_HealthBook_Quantity)).clear();
			SendKeyByXpath(ObjRepository.Books_HealthBook_Quantity,
					TotalQuantity, "Quantity");
			ClickByXpath(ObjRepository.AddToCart, "Add To Cart");
			Subtotl=Subtotl+"0";
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.AddToCart_SuccessfullyAdded)));
			String AddToCartMessage = driver.findElement(
					By.xpath(ObjRepository.AddToCart_SuccessfullyAdded))
					.getText();
			if (AddToCartMessage
					.equalsIgnoreCase("The product has been added to your shopping cart")) {
				System.out.println("Add to Cart message is displayed as "
						+ AddToCartMessage);
			} else {
				System.out.println("Add to Cart message is not displayed as "
						+ AddToCartMessage);
			}
			ClickByXpath(ObjRepository.HomePage_ShoppingCart_Button,
					"Shopping Cart");
			String SubTotal = driver.findElement(
					By.xpath(ObjRepository.HomePage_ShoppingCart_SubTotal))
					.getText();
			if (SubTotal.equalsIgnoreCase(Subtotl)) {
				System.out.println("SubTotal is displayed as " + SubTotal);
			} else {
				System.out.println("SubTotal is not displayed as " + SubTotal);
			}
			ClickByXpath(ObjRepository.TermsofService, "TermsofService");
			ClickByXpath(ObjRepository.ShoppingCart_Checkout, "CheckOut");

			String Numb = String.valueOf(fnRandomNum(101, 999));
			System.out.println(Numb);
			String TestValue = "Test" + Numb;
			String PhoneNum = String.valueOf(fnRandomNum(100000001, 999999999));
			SelectFromComboBox(ObjRepository.BillingAddress, "New Address");
			SendKeyByXpath(ObjRepository.BillingAddress_FirstName, TestValue,
					"FirstName");
			SendKeyByXpath(ObjRepository.BillingAddress_LastName, TestValue,
					"LastName");
			SelectFromComboBox(ObjRepository.BillingAddress_Country, "India");
			SendKeyByXpath(ObjRepository.BillingAddress_City, TestValue, "City");
			SendKeyByXpath(ObjRepository.BillingAddress_Address, TestValue,
					"Address");
			SendKeyByXpath(ObjRepository.BillingAddress_PostalCode, "123123",
					"Postal Code");
			SendKeyByXpath(ObjRepository.BillingAddress_PhoneNumber, PhoneNum,
					"Phone Number");
			ClickByXpath(ObjRepository.BillingAddress_Continue, "Continue");
			// ClickByXpath(ObjRepository.ShippingAddress, "ShippingAddress");
			String Value = TestValue + " " + TestValue + ", " + TestValue
					+ ", " + TestValue + " 123123, India";
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.ShippingAddress)));
			SelectFromComboBox(ObjRepository.ShippingAddress, Value);
			// SendKeyByXpath(ObjRepository.ShippingAddress,TestValue,"Shipping Address");
			ClickByXpath(ObjRepository.ShippingAddress_Continue, "Continue");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.NextDayAir)));
			ClickByXpath(ObjRepository.NextDayAir, "NextDayAir");
			ClickByXpath(ObjRepository.ShippingMethod_Continue, "Continue");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.CashOnDelivery)));
			ClickByXpath(ObjRepository.CashOnDelivery, "CashOnDelivery");
			ClickByXpath(ObjRepository.PaymentMethod_Continue,
					"Payment Method Continue");

			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.PaymentMethod_COD_Method)));

			String CODPaymentMessage = driver.findElement(
					By.xpath(ObjRepository.PaymentMethod_COD_Method)).getText();
			if (CODPaymentMessage.equalsIgnoreCase("You will pay by COD")) {
				System.out.println("Payment type Message is displayed as "
						+ CODPaymentMessage);
			} else {
				System.out.println("Payment type Message is not displayed as "
						+ CODPaymentMessage);
			}
			ClickByXpath(ObjRepository.PaymentInfo_Continue, "Continue");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.ConfirmOrder)));
			ClickByXpath(ObjRepository.ConfirmOrder, "ConfirmOrder");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.OrderPlaces_SuccessMessage)));
			String SuccessMessage = driver.findElement(
					By.xpath(ObjRepository.OrderPlaces_SuccessMessage))
					.getText();
			if (SuccessMessage
					.equalsIgnoreCase("Your order has been successfully processed!")) {
				System.out.println("Success Message is displayed as "
						+ SuccessMessage);
			} else {
				System.out.println("Success Message is not displayed as "
						+ SuccessMessage);
			}

			String OrderNumber = driver.findElement(
					By.xpath(ObjRepository.OrderNumber)).getText();
			String[] arrSplit = OrderNumber.split(": ");
			String OrderNo = arrSplit[1];

			System.out.println("Order Number is" + OrderNo);

			ClickByXpath(ObjRepository.Continue_Button, "Continue Button");
			w.until(ExpectedConditions.visibilityOfElementLocated(By
					.xpath(ObjRepository.LogOut_Button)));

			ClickByXpath(ObjRepository.LogOut_Button, "LogOut Button");
			driver.quit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
