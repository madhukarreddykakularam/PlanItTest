package com.nbcu.sphere;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nbcu.sphere.Common.BusinessFunctionLibrary;
import com.nbcu.sphere.Common.GenericFunctionLibrary;
import com.nbcu.sphere.ConfigManager.FileLocSetter;
import com.nbcu.sphere.ObjectRepository.SphereCommon;
import com.nbcu.sphere.ObjectRepository.SphereModules;
import com.nbcu.sphere.ReportManager.Reporter;
import com.nbcu.sphere.UtilManager.AppMessages;

public class Orders extends TestDriver {

	SphereModules objSphereModules = new SphereModules();
	SphereCommon objSphereCommon = new SphereCommon();
	AppMessages objAppMessages = new AppMessages();
	BusinessFunctionLibrary objBusinessLib = new BusinessFunctionLibrary();
	GenericFunctionLibrary  objGenericFunctionLibrary = new GenericFunctionLibrary();


	@SuppressWarnings("static-access")
	public Reporter TC399(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC399 Started..");

		try {
			
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		   
			String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
			
			String UIorderNumber="001";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Validate that user is able to create order for the deal", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			/*objBusinessLib.fnClickMainMenuElement("Orders");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele);
			
			SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,"671673","Deal Number");
			ClickByXpath(SphereModules.Orders_DealNumber_SearchBtn_xp, "Search button", true);
			fnLoadingPageWait();*/
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);					
			
			
			//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_Orders_Table_xp)));
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			fnVerifyHeaders(arrHeaderColumns,1,"Order Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Order Mng CC");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			fnVerifyHeaders(arrHeaderColumns,4,"PO Number");
			fnVerifyHeaders(arrHeaderColumns,5,"Revenue");
			fnVerifyHeaders(arrHeaderColumns,6,"Cost");
			fnVerifyHeaders(arrHeaderColumns,7,"Margin");
			//fnVerifyHeaders(arrHeaderColumns,8,"Charge Method");
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			
			fnCheckFieldDisplayByXpath(objSphereModules.Orders_Add_Form_Customer_Field_xp, "Customer Field", true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Orders_Add_Form_Deal_Field_xp, "Deal Field", true,true);
			fnCheckFieldDisplayByXpath(objSphereModules.Orders_Add_Form_Order_Managing_CostCenter_xp, "Managing Cost Cener",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_Order_Description_id, "Order Description",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_Order_Number_id, "Order Number",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_TotalEstimateAmount_id, "Total Estimate Amount",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_POnumber_id, "PO Number",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_WIP_Charge_Method_id, "WIP Charge Method",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_Location_id, "Location",true,true);
			fnCheckFieldDisplayById(objSphereModules.Orders_Add_Form_EpisodeNumber_id, "Episode Number",true,true);
		
			//////////////verifying the default values of deal number and WIP charge method and cost center/////////////////////
			
			obj.repAddData( "Verifying the default values of WIP_Charge_Method field, deal number field and cost center field", "", "", "");
			
			String sDefaultChargeMethodValue=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Default_WIP_Charge_Method_Value_xp)).getText().trim();
			HighlightElementByXpath(SphereModules.Orders_Add_Form_Default_WIP_Charge_Method_Value_xp);
			System.out.println(sDefaultChargeMethodValue);
			String sExpStatusField ="Fixed Rate";
			fnVerifyLabelMsgText(sExpStatusField, sDefaultChargeMethodValue.trim());
			
			String sDefaultDealNumberValue=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Default_DealNumber_Value_xp)).getText().trim();
			HighlightElementByXpath(SphereModules.Orders_Add_Form_Default_DealNumber_Value_xp);
			System.out.println(sDefaultDealNumberValue);
			String[] sDefaultDealNumberValueArray=sDefaultDealNumberValue.split("-");
			String ActDealNumberDB=sDefaultDealNumberValueArray[0].toString().trim();
			//String sExpDealNumberDB="671673";
			fnVerifyLabelMsgText(sExpDealNumberDB, ActDealNumberDB.trim());
			
			String sDefaultCostCenterValue=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Default_CostCenter_Value_xp)).getText().trim();
			HighlightElementByXpath(SphereModules.Orders_Add_Form_Default_CostCenter_Value_xp);
			System.out.println(sDefaultCostCenterValue);
			String sExpcostCenter ="338 SET LIGHTING - IL";
			fnVerifyLabelMsgText(sExpcostCenter, sDefaultCostCenterValue.trim());
			fnCheckfieldDisbleByXPath(SphereModules.Orders_Add_Form_Disabled_Order_Managing_CostCenter_xp,"Order Managing Cost Center");
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			
			
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, sRequestorName, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, sApproverName, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			
			//////////////////DBb Validation for order//////////////////
			String sQuery = objSQLConfig.sAdd_Orders_Query;
		    sQuery = sQuery.replaceAll("deal_title_param",sDealTitleUI);
		    sQuery = sQuery.replaceAll("order_number_param",UIorderNumber);
		    //use Deal Number here instead of DealTitle;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sDealTitleDB = mTableDataDB.get(1).get(1).toString().trim();
			String sOrderNumberDB=mTableDataDB.get(1).get(2).toString().trim();
			String sOrderDescriptionDB=mTableDataDB.get(1).get(3).toString().trim();
			String iSbillableDB=mTableDataDB.get(1).get(4).toString().trim();
			String orderStatusDB=mTableDataDB.get(1).get(5).toString().trim();
			
			//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
			if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && 
					UIorderNumber.equalsIgnoreCase(sOrderNumberDB)&&
					sOrderDescUI.equalsIgnoreCase(sOrderDescriptionDB)&&
					iSbillableDB.equalsIgnoreCase("1")&&
					orderStatusDB.equalsIgnoreCase("Open"))
			{	
				
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation successful for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Pass");
			}
			else
			{
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI+" Order Number : "+sOrderNumberDB, "Fail");
			}
			
		
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC399 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC399 Completed");
		}
		return obj;
	} //End of Script TC399		
	@SuppressWarnings("static-access")
	public Reporter TC395(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC395 Started..");

		try {
			
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			/*objBusinessLib.fnClickMainMenuElement("Orders");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele);
			
			SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,"671674","Deal Number");
			ClickByXpath(SphereModules.Orders_DealNumber_SearchBtn_xp, "Search button", true);
			fnLoadingPageWait();*/
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);
			
		//	waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_Orders_Table_xp)));
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			fnVerifyHeaders(arrHeaderColumns,1,"Order Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Order Mng CC");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			fnVerifyHeaders(arrHeaderColumns,4,"PO Number");
			fnVerifyHeaders(arrHeaderColumns,5,"Revenue");
			fnVerifyHeaders(arrHeaderColumns,6,"Cost");
			fnVerifyHeaders(arrHeaderColumns,7,"Margin");
			//fnVerifyHeaders(arrHeaderColumns,8,"Charge Method");
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, sRequestorName, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, sApproverName, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			String sQuery = objSQLConfig.sAdd_Orders_Query;
		    sQuery = sQuery.replaceAll("deal_title_param",sDealTitleUI);
		    sQuery = sQuery.replaceAll("order_number_param",UIorderNumber);
		    //use Deal Number here instead of DealTitle;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sDealTitleDB = mTableDataDB.get(1).get(1).toString().trim();
			String sOrderNumberDB=mTableDataDB.get(1).get(2).toString().trim();
			String sOrderDescriptionDB=mTableDataDB.get(1).get(3).toString().trim();
			String iSbillableDB=mTableDataDB.get(1).get(4).toString().trim();
			String orderStatusDB=mTableDataDB.get(1).get(5).toString().trim();
			
			//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
			if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && 
					UIorderNumber.equalsIgnoreCase(sOrderNumberDB)&&
					sOrderDescUI.equalsIgnoreCase(sOrderDescriptionDB)&&
					iSbillableDB.equalsIgnoreCase("1")&&
					orderStatusDB.equalsIgnoreCase("Open"))
			{	
				
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation successful for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Pass");
			}
			else
			{
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI+" Order Number : "+sOrderNumberDB, "Fail");
			}
			
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, sRequestorName, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, sApproverName, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Orders_Add_Form_AlertMessage_Text_xp)));
			String sErrorMsg = driver.findElement(By.xpath(SphereModules.Orders_Add_Form_AlertMessage_Text_xp)).getText();
			HighlightElementByXpath(SphereModules.Orders_Add_Form_AlertMessage_Text_xp);
			System.out.println(sErrorMsg);
			fnVerifyLabelMsgText(AppMessages.Order_AddOrder_DuplicateOrderNumberError_msg, sErrorMsg.trim());
		   
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC395 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC395 Completed");
		}
		return obj;
	} //End of Script TC395	
	@SuppressWarnings("static-access")
	public Reporter TC396(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC396 Started..");

		try {
			
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
			
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sSecondRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sSecondOrderDescUI = "AUTOTESTORDER_"+sSecondRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sSecondPoNumberUI = "AutoPONumber_"+sSecondRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sSecondTotalEstimateAmountUI=sSecondRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sSecondEpisodeNumber="AutoEpNumber_"+sSecondRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sSecondRequestorName="AutoRequestorName_"+sSecondRandom;
			String sApproverName="AutoApproverName_"+sRandom;
			String sSecondApproverName="AutoApproverName_"+sSecondRandom;
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verify that the next available order number is displayed by default on the screen", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			/*objBusinessLib.fnClickMainMenuElement("Orders");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele);
			
			SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,"671675","Deal Number");
			ClickByXpath(SphereModules.Orders_DealNumber_SearchBtn_xp, "Search button", true);
			fnLoadingPageWait();*/
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);
			
			//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_Orders_Table_xp)));
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			fnVerifyHeaders(arrHeaderColumns,1,"Order Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Order Mng CC");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			fnVerifyHeaders(arrHeaderColumns,4,"PO Number");
			fnVerifyHeaders(arrHeaderColumns,5,"Revenue");
			fnVerifyHeaders(arrHeaderColumns,6,"Cost");
			fnVerifyHeaders(arrHeaderColumns,7,"Margin");
			//fnVerifyHeaders(arrHeaderColumns,8,"Charge Method");
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			
			String sExpOrder="001";
			String sActOrder=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).getAttribute("value");
			HighlightElementByXpath(SphereModules.Orders_Add_Form_Order_Number_xp);
			System.out.println(sActOrder);
			fnVerifyLabelMsgText(sExpOrder, sActOrder.trim());
			
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, sRequestorName, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, sApproverName, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			String sQuery = objSQLConfig.sAdd_Orders_Query;
		    sQuery = sQuery.replaceAll("deal_title_param",sDealTitleUI);
		    sQuery = sQuery.replaceAll("order_number_param",sExpOrder);
		    //use Deal Number here instead of DealTitle;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sDealTitleDB = mTableDataDB.get(1).get(1).toString().trim();
			String sOrderNumberDB=mTableDataDB.get(1).get(2).toString().trim();
			String sOrderDescriptionDB=mTableDataDB.get(1).get(3).toString().trim();
			String iSbillableDB=mTableDataDB.get(1).get(4).toString().trim();
			String orderStatusDB=mTableDataDB.get(1).get(5).toString().trim();
			
			//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
			if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && 
					sExpOrder.equalsIgnoreCase(sOrderNumberDB)&&
					sOrderDescUI.equalsIgnoreCase(sOrderDescriptionDB)&&
					iSbillableDB.equalsIgnoreCase("1")&&
					orderStatusDB.equalsIgnoreCase("Open"))
			{	
				
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation successful for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Pass");
			}
			else
			{
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI+" Order Number : "+sOrderNumberDB, "Fail");
			}
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sSecondOrderDescUI, "Order Description");
			
			obj.repAddData( "Validating the next available number on the Add order screen ", "", "", "");
			
			String sSecondExpOrder="002";
			String sSecondActOrder=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).getAttribute("value");
			HighlightElementByXpath(SphereModules.Orders_Add_Form_Order_Number_xp);
			System.out.println(sSecondActOrder);
			fnVerifyLabelMsgText(sSecondExpOrder, sSecondActOrder.trim());
			
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sSecondTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sSecondPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sSecondEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, sSecondRequestorName, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, sSecondApproverName, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			String sQuery2 = objSQLConfig.sAdd_Orders_Query;
		    sQuery2 = sQuery2.replaceAll("deal_title_param",sDealTitleUI);
		    sQuery2 = sQuery2.replaceAll("order_number_param",sSecondExpOrder);
		    //use Deal Number here instead of DealTitle;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery2);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB2 = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String DealTitleDB = mTableDataDB2.get(1).get(1).toString().trim();
			String OrderNumberDB=mTableDataDB2.get(1).get(2).toString().trim();
			String OrderDescriptionDB=mTableDataDB2.get(1).get(3).toString().trim();
			String siSbillableDB=mTableDataDB2.get(1).get(4).toString().trim();
			String sorderStatusDB=mTableDataDB2.get(1).get(5).toString().trim();
			
			//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
			if(sDealTitleUI.equalsIgnoreCase(DealTitleDB) && 
					sSecondExpOrder.equalsIgnoreCase(OrderNumberDB)&&
					sSecondOrderDescUI.equalsIgnoreCase(OrderDescriptionDB)&&
					siSbillableDB.equalsIgnoreCase("1")&&
					sorderStatusDB.equalsIgnoreCase("Open"))
			{	
				
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation successful for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Pass");
			}
			else
			{
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI+" Order Number : "+sOrderNumberDB, "Fail");
			}
			
		
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC396 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC396 Completed");
		}
		return obj;
	} //End of Script TC396	

	@SuppressWarnings("static-access")
	public Reporter TC397(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC397 Started..");
		
		try {
			
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    String sOrderDescUI = "AUTOTESTORDER_1";
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verify that the next available greater order number is displayed from the number that user entered", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
		/*	objBusinessLib.fnClickMainMenuElement("Orders");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele);
			
			SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,"671664","Deal Number");
			ClickByXpath(SphereModules.Orders_DealNumber_SearchBtn_xp, "Search button", true);
			fnLoadingPageWait();*/
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);
			
			
			
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_Orders_Table_xp)));
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			fnVerifyHeaders(arrHeaderColumns,1,"Order Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Order Mng CC");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			fnVerifyHeaders(arrHeaderColumns,4,"PO Number");
			fnVerifyHeaders(arrHeaderColumns,5,"Revenue");
			fnVerifyHeaders(arrHeaderColumns,6,"Cost");
			fnVerifyHeaders(arrHeaderColumns,7,"Margin");
			//fnVerifyHeaders(arrHeaderColumns,8,"Charge Method");
			
			for(int i=0;i<=9;i++)
			{
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String UIorderNumber="99"+i;
			String sOrderDesc="AUTOTESTORDER_"+sRandom;
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, "AUTOTESTORDER_"+sRandom, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,UIorderNumber, "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sRandom+".00", "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, "AutoPONumber_"+sRandom, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, "AutoEpNumber_"+sRandom, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, "AutoRequestorName_"+sRandom, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, "AutoApproverName_"+sRandom, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			//////////////DB Validation////////////////////
			String sQuery = objSQLConfig.sAdd_Orders_Query;
		    sQuery = sQuery.replaceAll("deal_title_param",sDealTitleUI);
		    sQuery = sQuery.replaceAll("order_number_param",UIorderNumber);
		    //use Deal Number here instead of DealTitle;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sDealTitleDB = mTableDataDB.get(1).get(1).toString().trim();
			String sOrderNumberDB=mTableDataDB.get(1).get(2).toString().trim();
			String sOrderDescriptionDB=mTableDataDB.get(1).get(3).toString().trim();
			String iSbillableDB=mTableDataDB.get(1).get(4).toString().trim();
			String orderStatusDB=mTableDataDB.get(1).get(5).toString().trim();
			
			//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
			if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && 
					UIorderNumber.equalsIgnoreCase(sOrderNumberDB)&&
					sOrderDesc.equalsIgnoreCase(sOrderDescriptionDB)&&
					iSbillableDB.equalsIgnoreCase("1")&&
					orderStatusDB.equalsIgnoreCase("Open"))
			{	
				
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation successful for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Pass");
			}
			else
			{
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Fail");
			}
			
			}
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			
			//objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			
			int iOrderNumberCount=9;
			for(int i=1;i<=iOrderNumberCount;i++)
			{
				SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp, String.valueOf(i), "Order Number");
				TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).sendKeys(Keys.TAB);
				Thread.sleep(3000);
				String visibleOrderNumberText=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).getAttribute("value");
				System.out.println(visibleOrderNumberText);
				
				if(i==1)
				{
				if(Integer.parseInt(visibleOrderNumberText)==100)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.parseInt(visibleOrderNumberText)>100)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==2)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==200)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>200)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==3)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==300)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>300)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==4)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==400)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>400)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==5)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==500)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>500)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==6)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==600)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>600)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==7)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==700)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>700)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==8)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==800)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>800)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				if(i==9)
				{
				
				if(Integer.valueOf(visibleOrderNumberText)==900)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
				}
				else if(Integer.valueOf(visibleOrderNumberText)>900)
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
				}
				else
				{
					obj.repAddData( "Verify the Order Numer", "Order number should be greater number than " +i, "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
				}
				
				}
				
			}
			
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp, "12", "Order Number");
			TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).sendKeys(Keys.TAB);
			Thread.sleep(3000);
			String visibleOrderNumberText=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).getAttribute("value");
			
			if(Integer.valueOf(visibleOrderNumberText)==120)
			{
				obj.repAddData( "Verify the Order Numer", "Order number should be greater number than 12", "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");	
			}
			else if(Integer.valueOf(visibleOrderNumberText)>120)
			{
				obj.repAddData( "Verify the Order Numer", "Order number should be greater number than 12", "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Pass");
			}
			else
			{
				obj.repAddData( "Verify the Order Numer", "Order number should be greater number than 12", "Validation successful for Order Number field with value displayed "+Integer.valueOf(visibleOrderNumberText), "Fail");
			}
			////////////include error message steps//////////////////
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp, "99", "Order Number");
			TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_Order_Number_xp)).sendKeys(Keys.TAB);
			Thread.sleep(3000);
			String existOrderNumberTextUI=TestDriver.driver.findElement(By.xpath(SphereModules.Orders_Add_Form_ExistOrderMessage_xp)).getText().trim();
			
			String sExpexistOrderNumberMsg ="Order Already Exists";
			fnVerifyLabelMsgText(sExpexistOrderNumberMsg, existOrderNumberTextUI.trim());
			WebElement Messageele = driver.findElement(By.xpath(objSphereModules.Orders_Add_Form_ExistOrderMessage_xp));
			Thread.sleep(3000);
			HighlightElement(Messageele);
		  }
		    catch (Exception e) 
		 {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC397 Failed!", e );
		 }
		   finally {
			   fnCloseOpenedForm();
			   /*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC397 Completed");
		}
		return obj;
	} //End of Script TC397	
	@SuppressWarnings("static-access")
	public Reporter TC398(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC398 Started..");

		try {
			
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="001";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verify that the user is not able to edit or change the Order number", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			/*objBusinessLib.fnClickMainMenuElement("Orders");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele);
			
			SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,"673160","Deal Number");
			ClickByXpath(SphereModules.Orders_DealNumber_SearchBtn_xp, "Search button", true);
			fnLoadingPageWait();*/
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			//SendKeyByXpath(SphereModules.Orders_DealNumber_SearchBox_xp,sExpDealNumberDB,"Deal Number");
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);
			
			//waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objSphereModules.Common_Orders_Table_xp)));
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			fnVerifyHeaders(arrHeaderColumns,1,"Order Number");
			fnVerifyHeaders(arrHeaderColumns,2,"Order Mng CC");
			fnVerifyHeaders(arrHeaderColumns,3,"Description");
			fnVerifyHeaders(arrHeaderColumns,4,"PO Number");
			fnVerifyHeaders(arrHeaderColumns,5,"Revenue");
			fnVerifyHeaders(arrHeaderColumns,6,"Cost");
			fnVerifyHeaders(arrHeaderColumns,7,"Margin");
			fnVerifyHeaders(arrHeaderColumns,9,"Charge Method");
			
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			
			obj.repAddData( "Verifying the mandatory fields", "", "", "");
	         ////////////////Verifying the required fields/////////////////////////////
	         String Redcolor="rgb(202, 2, 74)";

	        // String BeforeSaveMngCostCenterVisibleColor=driver.findElement(By.xpath(objSphereModules.Orders_Add_Form_Order_Managing_CostCenter_xp)).getCssValue("border-bottom-color");
	        // System.out.println("color>>>>"+BeforeSaveMngCostCenterVisibleColor);

	        // String BeforeSaveVisibleColor=driver.findElement(By.id(objSphereModules.Orders_Add_Form_Order_Description_id)).getCssValue("border-bottom-color");
	        // System.out.println("color>>>>"+BeforeSaveVisibleColor);

	         /*ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);

	        String AfterSaveMngCostCenterVisibleColor=driver.findElement(By.xpath(objSphereModules.Orders_Add_Form_Border_Color_Managing_CostCenter_xp)).getCssValue("border-color");
	         System.out.println("color>>>>"+AfterSaveMngCostCenterVisibleColor);

	        // String AfterSaveOrderDescVisibleColor=driver.findElement(By.id(objSphereModules.Orders_Add_Form_Order_Description_id)).getCssValue("border-bottom-color").trim();
	        // System.out.println("color>>>>"+AfterSaveOrderDescVisibleColor);

	         String AfterSaveOrderDescVisibleColor=driver.findElement(By.id(objSphereModules.Orders_Add_Form_Order_Description_id)).getCssValue("border-color").trim();
	         System.out.println("color>>>>"+AfterSaveOrderDescVisibleColor);
	         
	         if(AfterSaveOrderDescVisibleColor.equals(Redcolor)&& AfterSaveMngCostCenterVisibleColor.equals(Redcolor))
	         {	
		      obj.repAddData( "Verifying required field color", "Field border color should be displayed in red color", "Field border color  displayed in red color", "Pass");
	         }
	         else
	         {
		     obj.repAddData( "Verifying required field color", "Field border color should be displayed in red color", "Field border color not displayed in red color", "Fail");
	         }

	         waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Orders_Add_Form_AlertMessage_Text_xp)));
	         String sErrorMsg = driver.findElement(By.xpath(SphereModules.Orders_Add_Form_AlertMessage_Text_xp)).getText();
	         HighlightElementByXpath(SphereModules.Orders_Add_Form_AlertMessage_Text_xp);
	         System.out.println(sErrorMsg);
	         fnVerifyLabelMsgText(AppMessages.Order_AddOrder_DuplicateOrderNumberError_msg, sErrorMsg.trim());*/
			
	        objBusinessLib.fnSelectCostCenter(1,sCostCenterUI);
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_Add_Form_RequestorName_id, sRequestorName, "Requestor Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_RequestorPhone_xp, "248656"+sRandom, "Phone Number");
			//SendKeyById(SphereModules.Orders_Add_Form_Approver_Name_id, sApproverName, "Approver Name");
			//SendKeyByXpath(SphereModules.Orders_Add_Form_Approver_Phone_xp, "734256"+sRandom, "Phone Number");
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			String sQuery = objSQLConfig.sAdd_Orders_Query;
		    sQuery = sQuery.replaceAll("deal_title_param",sDealTitleUI);
		    sQuery = sQuery.replaceAll("order_number_param",UIorderNumber);
		    //use Deal Number here instead of DealTitle;
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			
			objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			String sDealTitleDB = mTableDataDB.get(1).get(1).toString().trim();
			String sOrderNumberDB=mTableDataDB.get(1).get(2).toString().trim();
			String sOrderDescriptionDB=mTableDataDB.get(1).get(3).toString().trim();
			String iSbillableDB=mTableDataDB.get(1).get(4).toString().trim();
			String orderStatusDB=mTableDataDB.get(1).get(5).toString().trim();
			
			//if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) &&sDeal_TypeUI.equalsIgnoreCase(sDealTypeDB)&& sCostCenterUI.equalsIgnoreCase(sCostCenterDB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB) && sEmailAddressUI.equalsIgnoreCase(sEmailAddressDB) && sAddr1UI.equalsIgnoreCase(sMainAddressLine3DB)&&sAddr2UI.equalsIgnoreCase(sMainAddressLine4DB) && sProjectNameUI.equalsIgnoreCase(sProjectNameDB)&& sProjectType.equalsIgnoreCase(sProjectTypeDB)&& sProjectClusterUI.equalsIgnoreCase(sProjectClusterDB))
			if(sDealTitleUI.equalsIgnoreCase(sDealTitleDB) && 
					UIorderNumber.equalsIgnoreCase(sOrderNumberDB)&&
					sOrderDescUI.equalsIgnoreCase(sOrderDescriptionDB)&&
					iSbillableDB.equalsIgnoreCase("1")&&
					orderStatusDB.equalsIgnoreCase("Open"))
			{	
				
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation successful for deal title : "+ sDealTitleUI+" and Order Number : "+sOrderNumberDB, "Pass");
			}
			else
			{
				obj.repAddData( "Compare order  record for Deal Title : "+ sDealTitleUI, "Order account record on UI and DB should match for Deal Title : "+ sDealTitleUI, "Validation failed for deal title : "+ sDealTitleUI+" Order Number : "+sOrderNumberDB, "Fail");
			}
			SendKeyByXpath(SphereModules.Common_ViewModules_InputSearchBox_xp,UIorderNumber, "Search Box");
			fnLoadingPageWait();
			Thread.sleep(3000);
			
			ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
			Thread.sleep(3000);
			
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Orders_Edit_Form_Title_xp)));
			HighlightElementByXpath(SphereModules.Orders_Edit_Form_Title_xp);
			String sEditTitleXPath = driver.findElement(By.xpath(SphereModules.Orders_Edit_Form_Title_xp)).getText().trim();
		
			String ActualTitle="";
			String[] arrOrder;
			arrOrder = sEditTitleXPath.split("#");
	        ActualTitle = arrOrder[1].toString().trim();
	        System.out.println(ActualTitle);
	        fnVerifyLabelMsgText(UIorderNumber, ActualTitle.trim());
			fnLoadingPageWait();
			
			fnCheckFieldDoesNotExistByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"Order Number",true);
			
		   
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC398 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC398 Completed");
		}
		return obj;
	} //End of Script TC398	
	
	
	@SuppressWarnings("static-access")
	public Reporter TC700(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC700 Started..");

		try {
			

			String sNewValue=objBusinessLib.fnCreateDCSDealOrder("Open Order","Open Deal");
			System.out.println(sNewValue);
		   
		}
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC700 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC700 Completed");
		}
		return obj;
	} //End of Script TC700	
	
	@SuppressWarnings("static-access")
	public Reporter TC701(Reporter obj) throws Exception
	{
		//Boolean bLoginFlag = true;	
		log.info("Execution of Script TC701 Started..");

		try {

			
			String sNewValue=objBusinessLib.fnCreateDealOrderforexception("CloseOpenOrder","Open Deal");
			System.out.println(sNewValue);
			
		   
		   }
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC701 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC701 Completed");
		}
		return obj;
	} //End of Script TC701	
	
	
	@SuppressWarnings("static-access")
	public Reporter TC535(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC535 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);*/
			
		
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			
		
			
			WebElement  disabledValue = driver.findElement(By.xpath(objSphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_Disabled));
			String Disabledattribute = disabledValue.getText();
			if(Disabledattribute.contains("Fixed Rate"))
			{	
				
				obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be disabled and should be displayed as 'FixedCharge' ", 
						"WIP Charge Method is disabled and is  displayed as 'FixedCharge' ",  "Pass");
			}
			else
			{
				obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be disabled and should be displayed as 'FixedCharge' ", 
						"WIP Charge Method is not disabled and is not displayed as 'FixedCharge' ",  "Fail");
			}
			
			ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	/*ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); */
		   
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 

			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC535 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC535 Completed");
		}
		return obj;
	} //End of Script TC535	
	
	
	public Reporter TC536(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC536 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);*/
			
		
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			WebElement EnabledValue1 = driver.findElement(By.xpath(objSphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_Enabled));
			if(EnabledValue1.isEnabled())
			{
				    	obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be enabled", 
						"WIP Charge Method is enabled",  "Pass");
			}
			else
			{
				obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be  enabled", 
						"WIP Charge Method is not enabled",  "Fail");
			}
			ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	/*ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); */
			
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC536 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC536 Completed");
		}
		return obj;
	} //End of Script TC536
	
	public Reporter TC537(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC537 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);*/
			
		
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod, sEpisodeNumber, "Episode Number");
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
			Thread.sleep(6000);
			
			String wipChargeMethod = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("WipChargeMethod").trim();
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_WIP_ChargeMethod,wipChargeMethod);
			obj.repAddData( "Update the Wip Charge Method", "Wip Charge Method should be updated to '"+wipChargeMethod+"' ", 
					"Wip Charge Method is updated to '"+wipChargeMethod+"'", "Pass");
		 	
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC537 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC537 Completed");
		}
		return obj;
	} //End of Script TC537
	
	
	public Reporter TC565(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC565 Started..");

		
		try {		
			/*String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);*/
			
			
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
		    
		    String sDescriptionUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Description").trim();
		    String sUM=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UM").trim();
		    String sRateUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Rate").trim();
		    String sTranType=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("TranType").trim();
		    String sQty=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Qty").trim();
		   
		    Date date = new Date();
			String sTransactionDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
			String sCurrentDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
			
			String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
			
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday); 
		    
		    
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;

			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
		
			
			
			String wipChargeMethod = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("WipChargeMethod").trim();
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_WIP_ChargeMethod,wipChargeMethod);
			obj.repAddData( "Update the Wip Charge Method", "Wip Charge Method should be updated to '"+wipChargeMethod+"' ", 
					"Wip Charge Method is updated to '"+wipChargeMethod+"'", "Pass");
			
			ClickByXpath(SphereModules.Orders_ViewCostPlusPercentage_WIP_ChargeMethod, "Click On View Cost plus", true);
			
			WebElement CostPlusOnUi = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_Screen));
			String costPlus = CostPlusOnUi.getText();
			if(costPlus.equals("Cost Plus %"))
			{
				obj.repAddData( "Verify Cost Plus % Page", "Cost Plus % page should be displayed ", 
						"Cost plus page is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify Cost Plus % Page", "Cost Plus % page should be displayed ", 
						"Cost plus page is not displayed", "Fail");
			}
			
			List<WebElement>  eleTable = driver.findElements(By.xpath(objSphereModules.Orders_CostPlusPercentage_ScreenHeader));
			fnVerifyHeaders(eleTable,0,"Source Code Group");
			fnVerifyHeaders(eleTable,1,"Default %");
			fnVerifyHeaders(eleTable,2,"Order %");
			
			
			WebElement onexxLaborui = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_onexxlabor));
			String onexxLabor = onexxLaborui.getText();
			if(onexxLabor.equals("1XX - Labor"))
			{
				obj.repAddData( "Verify 1XX - Labor field is displayed", "1XX - Labor field should be displayed ", 
						"1XX - Labor field is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify 1XX - Labor field is displayed", "1XX - Labor field should be displayed ", 
						"1XX - Labor field is not displayed", "Fail");
			}
			
			WebElement apui = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_AP));
			String ap = apui.getText();
			if(ap.equals("51X - AP"))
			{
				obj.repAddData( "Verify 51X - AP field is displayed", "51X - AP field should be displayed ", 
						"51X - AP field is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify 51X - AP field is displayed", "51X - AP field should be displayed ", 
						"51X - AP field is not displayed", "Fail");
			}
			WebElement JournalEntriesui = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_JournalEntries));
			String JournalEntries = JournalEntriesui.getText();
			if(JournalEntries.equals("81X - Journal Entries"))
			{
				obj.repAddData( "Verify 81X - Journal Entries field is displayed", "81X - Journal Entries field should be displayed ", 
						"81X - Journal Entries field is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify 81X - Journal Entries field is displayed", "81X - Journal Entries field should be displayed ", 
						"81X - Journal Entries field is not displayed", "Fail");
			}
			
			
			
			ClickByXpath(SphereModules.Orders_Costplus_CancelButton, "OK Button", true);
			fnLoadingPageWait();
			
			
			String wipChargeMethod1 = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("WipChargeMethod1").trim();
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_WIP_ChargeMethod,wipChargeMethod1);
			obj.repAddData( "Update the Wip Charge Method", "Wip Charge Method should be updated to '"+wipChargeMethod1+"' ", 
					"Wip Charge Method is updated to '"+wipChargeMethod1+"'", "Pass");
			
			WebElement viewcostpercentage1 = driver.findElement(By.xpath(SphereModules.Orders_ViewCostPlusPercentage_WIP_ChargeMethod));
			if(viewcostpercentage1.isDisplayed())
			{
				
				obj.repAddData( "Verify view cost plus percentage link is displayed", "view cost plus percentage link should not be displayed ", 
						"view cost plus percentage link is displayed ", "Fail");
			}
			else
			{
				obj.repAddData( "Verify view cost plus percentage link is displayed", "view cost plus percentage link should not be displayed ", 
						"view cost plus percentage link is not displayed ", "Pass");
			}
			
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 

	    	e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC565 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC565 Completed");
		}
		return obj;
	} //End of Script TC565
	

	
	
	public Reporter TC566(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC566 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
		    for(int i=0;i<=options.size();i++){
		    String optionName = options.get(i).getText();
		    System.out.println(optionName);
		    String DealNumUI = optionName.substring(0, 6);
		    System.out.println(DealNumUI);
		    if(DealNumUI.equals(sExpDealNumberDB))
		    {

		   options.get(i).click();
		    break;
		    }
		    }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
		
			
			
			String wipChargeMethod = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("WipChargeMethod").trim();
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_WIP_ChargeMethod,wipChargeMethod);
			obj.repAddData( "Update the Wip Charge Method", "Wip Charge Method should be updated to '"+wipChargeMethod+"' ", 
					"Wip Charge Method is updated to '"+wipChargeMethod+"'", "Pass");
			
			ClickByXpath(SphereModules.Orders_ViewCostPlusPercentage_WIP_ChargeMethod, "Click On View Cost plus", true);
			
			WebElement CostPlusOnUi = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_Screen));
			String costPlus = CostPlusOnUi.getText();
			if(costPlus.equals("Cost Plus %"))
			{
				obj.repAddData( "Verify Cost Plus % Page", "Cost Plus % page should be displayed ", 
						"Cost plus page is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify Cost Plus % Page", "Cost Plus % page should be displayed ", 
						"Cost plus page is not displayed", "Fail");
			}
			
			List<WebElement>  eleTable = driver.findElements(By.xpath(objSphereModules.Orders_CostPlusPercentage_ScreenHeader));
			fnVerifyHeaders(eleTable,0,"Source Code Group");
			fnVerifyHeaders(eleTable,1,"Default %");
			fnVerifyHeaders(eleTable,2,"Order %");
			
			
			WebElement onexxLaborui = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_onexxlabor));
			String onexxLabor = onexxLaborui.getText();
			if(onexxLabor.equals("1XX - Labor"))
			{
				obj.repAddData( "Verify 1XX - Labor field is displayed", "1XX - Labor field should be displayed ", 
						"1XX - Labor field is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify 1XX - Labor field is displayed", "1XX - Labor field should be displayed ", 
						"1XX - Labor field is not displayed", "Fail");
			}
			
			WebElement apui = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_AP));
			String ap = apui.getText();
			if(ap.equals("51X - AP"))
			{
				obj.repAddData( "Verify 51X - AP field is displayed", "51X - AP field should be displayed ", 
						"51X - AP field is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify 51X - AP field is displayed", "51X - AP field should be displayed ", 
						"51X - AP field is not displayed", "Fail");
			}
			WebElement JournalEntriesui = driver.findElement(By.xpath(objSphereModules.Orders_CostPlusPercentage_JournalEntries));
			String JournalEntries = JournalEntriesui.getText();
			if(JournalEntries.equals("81X - Journal Entries"))
			{
				obj.repAddData( "Verify 81X - Journal Entries field is displayed", "81X - Journal Entries field should be displayed ", 
						"81X - Journal Entries field is displayed", "Pass");
			}
			else
			{
				obj.repAddData( "Verify 81X - Journal Entries field is displayed", "81X - Journal Entries field should be displayed ", 
						"81X - Journal Entries field is not displayed", "Fail");
			}
			
			
			
			ClickByXpath(SphereModules.Orders_Costplus_Close, "click", true);
	    	Thread.sleep(4000);
			
			
			String wipChargeMethod1 = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("WipChargeMethod1").trim();
			objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_WIP_ChargeMethod,wipChargeMethod1);
			obj.repAddData( "Update the Wip Charge Method", "Wip Charge Method should be updated to '"+wipChargeMethod1+"' ", 
					"Wip Charge Method is updated to '"+wipChargeMethod1+"'", "Pass");
			
			WebElement viewcostpercentage1 = driver.findElement(By.xpath(SphereModules.Orders_ViewCostPlusPercentage_WIP_ChargeMethod));
			if(viewcostpercentage1.isDisplayed())
			{
				
				obj.repAddData( "Verify view cost plus percentage link is displayed", "view cost plus percentage link should not be displayed ", 
						"view cost plus percentage link is displayed ", "Fail");
			}
			else
			{
				obj.repAddData( "Verify view cost plus percentage link is displayed", "view cost plus percentage link should not be displayed ", 
						"view cost plus percentage link is not displayed ", "Pass");
			}
			
			
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
		   }
		    catch (Exception e) {
		    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
		    	Thread.sleep(6000);
		    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
		    	Thread.sleep(3000);
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC566 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC566 Completed");
		}
		return obj;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public Reporter TC578(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC578 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
		    
		    String sDescriptionUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Description").trim();
		    String sUM=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UM").trim();
		    String sRateUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Rate").trim();
		    String sTranType=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("TranType").trim();
		    String sQty=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Qty").trim();
		   
		    Date date = new Date();
			String sTransactionDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
			String sCurrentDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
			
			String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
			
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday); 
		    
		    
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;

			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod, sEpisodeNumber, "Episode Number");
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			RightClickByXpath(objSphereModules.Common_ViewModules_ClickFirstRow_xp,"First Row");
			
			Thread.sleep(3000);
			ClickByXpath(SphereModules.Customer_InterceptMenu_ViewEdit_Link_xp, "View/ Edit", true);
			Thread.sleep(3000);
			
			WebElement EnabledValue1 = driver.findElement(By.xpath(objSphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_Enabled));
			if(EnabledValue1.isEnabled())
			{
				    	obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be enabled", 
						"WIP Charge Method is enabled",  "Pass");
			}
			else
			{
				obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be  enabled", 
						"WIP Charge Method is not enabled",  "Fail");
			}
			
			ClickByXpath(SphereModules.Orders_ViewEditOrder_CancelButton, "Cancel Button", true);
			Thread.sleep(3000);
			
			
			
			
			RightClickByXpath(objSphereModules.Common_ViewModules_ClickFirstRow_xp,"First Row");
			ClickByXpath(SphereModules.Common_InterceptMenu_ViewTransactions_Link_xp, "View Transactions", true);
			Thread.sleep(3000);
			
			  ClickByXpath(SphereModules.Transactions_AddTransaction_LinkAddTransaction_Sign_xp, "Add Transaction Link", true);
				fnLoadingPageWait();
				
				fnVerifyLabelMsgTextByXpath(AppMessages.AddTransaction_LabelTitle_Msg, SphereModules.Transactions_AddTransaction_LabelAddTransaction_Title_xp);
			    			
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_SearchOrder_xp, "999", "Search order");
				Thread.sleep(2000);
				fnLoadingPageWait();
				ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
				//ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
				SendKeyById(SphereModules.Transaction_AddTransaction_PoNumber_id, ponumberDB, "PO Number");
				
				SendKeyById(SphereModules.Transaction_AddTransaction_TransactionDate_id, sTransactionDateUI, "Transaction Date");
				SendKeyById(SphereModules.Transaction_AddTransaction_RentalStartDate_id, sStartDateUI1, "Rental Start Date");
				SendKeyById(SphereModules.Transaction_AddTransaction_RentalEndDate_id, sEndDateUI2, "Rental End Date");
				
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_Description_xp, sDescriptionUI, "Description");
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_Qty_xp, sQty, "Quantity");
				fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_UnitofMeasure_id,sUM);
				fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_TransactionType_id,sTranType);
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_Rate_xp, sRateUI, "Rate");
				
				
				ClickByXpath(SphereModules.Transaction_AddTransaction_Save_Btn_xp, "Save", true);
				Thread.sleep(3000);
				
				waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
				
				/*objBusinessLib.fnClickSubMenuElement("Billing","Approvals");
				waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Billing_Approvals_Title_xp)));
				WebElement Title = TestDriver.driver.findElement(By.xpath(objSphereModules.Billing_Approvals_Title_xp));
			    HighlightElement(Title);
			    Thread.sleep(3000);
			    
			    String sQuery = objSQLConfig.sBillingApprovals_DeptSystem_Query;
			    sQuery = sQuery.replaceAll("deal_number_param",sExpDealNumberDB);
			    TestDriver.conn = objDBUtility.fnOpenDBConnection();
			    TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery);
			    HashMap<Integer, HashMap<Integer, String>> mTableDataDB = objDBUtility.fnWriteResultSet(TestDriver.rset);
			    System.out.println("Hello");
			    objDBUtility.fnCloseDBConnection(TestDriver.stmt, TestDriver.rset, TestDriver.conn);
			    
			    String sDeptSystemNumberDB = mTableDataDB.get(1).get(1).toString();
			    Thread.sleep(3000);
			    
			  //  SendKeyByXpath(SphereModules.Billing_Approvals_SearchBox_xp,sDeptSystemNumberDB,"Deal Number");
			    Thread.sleep(4000);
			    ClickByXpath(SphereModules.BillingApproval_TransactionDate,"Click",true);
			   
			    objBusinessLib.fnSelectandapprove(objSphereModules.Common_View_Billing_Approvals_Table_xp,2,sExpDealNumberDB);
			    
			   // ClickByXpath(SphereModules.Billing_Approvals_Approve_Btn_xp,"Approve",true);
				//Thread.sleep(3000);
				
				waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Billing_Approvals_PopUp_Title_xp)));
				WebElement PopupTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.Billing_Approvals_PopUp_Title_xp));
			    HighlightElement(PopupTitle);
				
				ClickByXpath(SphereModules.Billing_Approvals_Approve_Yes_Btn_xp,"Yes Btn",true);
				Thread.sleep(4000);*/
				
				
				
				objBusinessLib.fnClickSubMenuElement("Billing","ARC");
				waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.ARC_Title_xp)));
				WebElement ArcTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Title_xp));
			    HighlightElement(ArcTitle);
			    
			    ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "Clear All Button", true);
				Thread.sleep(4000);
				
				SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,"","Deal Number");
				SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,sExpDealNumberDB,"Deal Number");
				fnLoadingPageWait();
				Thread.sleep(4000);
				if(ElementFound(SphereModules.ARC_Screen_Deal_list_1))
				{
					ClickByXpath(SphereModules.ARC_Screen_Deal_list_1, "Deal", true);
					fnLoadingPageWait();
					Thread.sleep(4000);
					if(ElementFound(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp))
					{

						SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,UIorderNumber,"Order Number");
						fnLoadingPageWait();
						Thread.sleep(6000);
						if(ElementFound(SphereModules.ARC_Screen_Order_list_1))
						{

							ClickByXpath(SphereModules.ARC_Screen_Order_list_1, "Order", true);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
							//ClickByXpath(sFilterBtn, "Filter btn", true);
							Thread.sleep(4000);
							WebElement ArcTable = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));

							if(TestDriver.driver.findElements(By.xpath(SphereModules.Order_Table_Col4_xp)).size()>0==true)
							{
								obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
										"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation successful for  : \t Order Number: "+UIorderNumber, "Pass");  
								System.out.println("Transactions exist");	

							}
							else
							{
								obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
										"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation failed for  : \t Order Number: "+UIorderNumber, "Fail");

							}

						}

					}

				}
				
				ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "Click", true);
			    fnLoadingPageWait();
			    Thread.sleep(4000); 
			    
			    WebElement InterfaceCode = driver.findElement(By.xpath(SphereModules.Transaction_InterfaceCode_Disabled));
				HighlightElement(InterfaceCode);
				
				if(ElementFound(SphereModules.Transaction_InterfaceCode_Disabled)==true)
				{
					obj.repAddData( "Verify  InterfaceCode field ",
							"InterfaceCode field should  be disabled", "InterfaceCode field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  InterfaceCode field ",
							"InterfaceCode field should  be disabled", "InterfaceCode field is not disabled", "Fail");
				}
			    
				
				
				WebElement CashFlag = driver.findElement(By.xpath(SphereModules.Transaction_CashFlag_Disabled));
				HighlightElement(CashFlag);
				
				if(ElementFound(SphereModules.Transaction_CashFlag_Disabled)==true)
				{
					obj.repAddData( "Verify  CashFlag field ",
							"CashFlag field should  be disabled", "CashFlag field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  CashFlag field ",
							"CashFlag field should  be disabled", "CashFlag field is not disabled", "Fail");
				}
				
				WebElement RentalStartDate = driver.findElement(By.xpath(SphereModules.Transaction_rentalStartDate_Disabled));
				HighlightElement(RentalStartDate);
				
				if(ElementFound(SphereModules.Transaction_rentalStartDate_Disabled)==true)
				{
					obj.repAddData( "Verify  RentalStartDate field ",
							"RentalStartDate field should  be disabled", "RentalStartDate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  RentalStartDate field ",
							"RentalStartDate field should  be disabled", "RentalStartDate field is not disabled", "Fail");
				}
				
				WebElement RentalEndDate = driver.findElement(By.xpath(SphereModules.Transaction_rentalEndDate_Disabled));
				HighlightElement(RentalEndDate);
				
				if(ElementFound(SphereModules.Transaction_rentalEndDate_Disabled)==true)
				{
					obj.repAddData( "Verify  RentalEndDate field ",
							"RentalEndDate field should  be disabled", "RentalEndDate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  RentalEndDate field ",
							"RentalEndDate field should  be disabled", "RentalEndDate field is not disabled", "Fail");
				}
				
				
				WebElement Pricelist = driver.findElement(By.xpath(SphereModules.Transaction_Pricelist_Disabled));
				HighlightElement(Pricelist);
				
				if(ElementFound(SphereModules.Transaction_Pricelist_Disabled)==true)
				{
					obj.repAddData( "Verify  Pricelist field ",
							"Pricelist field should  be disabled", "Pricelist field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Pricelist field ",
							"Pricelist field should  be disabled", "Pricelist field is not disabled", "Fail");
				}
				
				
				WebElement ItemCode = driver.findElement(By.xpath(SphereModules.Transaction_ItemCode_Disabled));
				HighlightElement(ItemCode);
				
				if(ElementFound(SphereModules.Transaction_ItemCode_Disabled)==true)
				{
					obj.repAddData( "Verify  ItemCode field ",
							"ItemCode field should  be disabled", "ItemCode field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  ItemCode field ",
							"ItemCode field should  be disabled", "ItemCode field is not disabled", "Fail");
				}
			    
				WebElement RequestDate = driver.findElement(By.xpath(SphereModules.Transaction_RequestDate_Disabled));
				HighlightElement(RequestDate);
				
				if(ElementFound(SphereModules.Transaction_RequestDate_Disabled)==true)
				{
					obj.repAddData( "Verify  RequestDate field ",
							"RequestDate field should  be disabled", "RequestDate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  RequestDate field ",
							"RequestDate field should  be disabled", "RequestDate field is not disabled", "Fail");
				}
			    
				WebElement BillableYes = driver.findElement(By.xpath(SphereModules.Transaction_BillableYes_Disabled));
				HighlightElement(BillableYes);
				
				if(ElementFound(SphereModules.Transaction_BillableYes_Disabled)==true)
				{
					obj.repAddData( "Verify  Billable field ",
							"Billable field should  be disabled", "Billable field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Billable field ",
							"Billable field should  be disabled", "Billable field is not disabled", "Fail");
				}
			    
				WebElement LineDescription = driver.findElement(By.xpath(SphereModules.Transaction_LineDescription_Disabled));
				HighlightElement(LineDescription);
				
				if(ElementFound(SphereModules.Transaction_LineDescription_Disabled)==true)
				{
					obj.repAddData( "Verify  LineDescription field ",
							"LineDescription field should  be disabled", "LineDescription field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  LineDescription field ",
							"LineDescription field should  be disabled", "LineDescription field is not disabled", "Fail");
				}
				
				WebElement quantity = driver.findElement(By.xpath(SphereModules.Transaction_quantity_Disabled));
				HighlightElement(quantity);
				
				if(ElementFound(SphereModules.Transaction_quantity_Disabled)==true)
				{
					obj.repAddData( "Verify  quantity field ",
							"quantity field should  be disabled", "quantity field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  quantity field ",
							"quantity field should  be disabled", "quantity field is not disabled", "Fail");
				}
				
				WebElement unitOfMeasure = driver.findElement(By.xpath(SphereModules.Transaction_unitOfMeasure_Disabled));
				HighlightElement(unitOfMeasure);
				
				if(ElementFound(SphereModules.Transaction_unitOfMeasure_Disabled)==true)
				{
					obj.repAddData( "Verify  unitOfMeasure field ",
							"unitOfMeasure field should  be disabled", "unitOfMeasure field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  unitOfMeasure field ",
							"unitOfMeasure field should  be disabled", "unitOfMeasure field is not disabled", "Fail");
				}
			    
				WebElement Rate = driver.findElement(By.xpath(SphereModules.Transaction_Rate_Disabled));
				HighlightElement(Rate);
				
				if(ElementFound(SphereModules.Transaction_Rate_Disabled)==true)
				{
					obj.repAddData( "Verify  Rate field ",
							"Rate field should  be disabled", "Rate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Rate field ",
							"Rate field should  be disabled", "Rate field is not disabled", "Fail");
				}
			    
				WebElement transactionType = driver.findElement(By.xpath(SphereModules.Transaction_transactionType_Disabled));
				HighlightElement(transactionType);
				
				if(ElementFound(SphereModules.Transaction_transactionType_Disabled)==true)
				{
					obj.repAddData( "Verify  transactionType field ",
							"transactionType field should  be disabled", "transactionType field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  transactionType field ",
							"transactionType field should  be disabled", "transactionType field is not disabled", "Fail");
				}
				
				WebElement tax = driver.findElement(By.xpath(SphereModules.Transaction_taxYes_Disabled));
				HighlightElement(tax);
				
				if(ElementFound(SphereModules.Transaction_taxYes_Disabled)==true)
				{
					obj.repAddData( "Verify  tax field ",
							"tax field should  be disabled", "tax field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  tax field ",
							"tax field should  be disabled", "tax field is not disabled", "Fail");
				}
				
				ClickByXpath(SphereModules.Transaction_Cancelbutton, "Cancel Button", true);
				
				ClickByXpath(SphereModules.ARC_Select_FirstRowCheckBox, "CheckBox", true);
				//String bulkActionType1 = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("BulkActionType").trim();
				ClickByXpath(SphereModules.ARC_BulkActionsDropDown, "click", true);
				ClickByXpath(SphereModules.ARC_BulkActionsDropDown_Options_MakeNonBillable, "click", true);

				//objGenericFunctionLibrary.fnSelectFromComboBoxXpath(SphereModules.ARC_BulkActionsDropDown,bulkActionType1);

				SendKeyById(SphereModules.ARC_Screen_notes_id,"Testing","Notes text box");
				ClickByXpath(SphereModules.ARC_BulkActionsPopUp_Continue, "Button", true);
				Thread.sleep(3000);
				obj.repAddData( "Verify ", "", "", "Pass");
				
		
		///	
				RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
			    Thread.sleep(3000);
			    ClickByXpath(SphereModules.ARC_BulkActionsDropDown_Options_Unapprove, "UnApprove", true);
			    fnLoadingPageWait();
			    Thread.sleep(4000); 
			    ClickByXpath(SphereModules.ARC_YesButton_UnApprove, "Yes Button", true);
			    fnLoadingPageWait();
			    Thread.sleep(4000);
			    ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "Click", true);
			    fnLoadingPageWait();
			    Thread.sleep(4000); 
			    
			    WebElement InterfaceCode1 = driver.findElement(By.xpath(SphereModules.Transaction_InterfaceCode_Disabled));
				HighlightElement(InterfaceCode1);
				
				if(ElementFound(SphereModules.Transaction_InterfaceCode_Disabled)==true)
				{
					obj.repAddData( "Verify  InterfaceCode field ",
							"InterfaceCode field should  be disabled", "InterfaceCode field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  InterfaceCode field ",
							"InterfaceCode field should  be disabled", "InterfaceCode field is not disabled", "Fail");
				}
			    
				
				
				WebElement CashFlag1 = driver.findElement(By.xpath(SphereModules.Transaction_CashFlag_Disabled));
				HighlightElement(CashFlag1);
				
				if(ElementFound(SphereModules.Transaction_CashFlag_Disabled)==true)
				{
					obj.repAddData( "Verify  CashFlag field ",
							"CashFlag field should  be disabled", "CashFlag field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  CashFlag field ",
							"CashFlag field should  be disabled", "CashFlag field is not disabled", "Fail");
				}
				
				WebElement RentalStartDate1 = driver.findElement(By.xpath(SphereModules.Transaction_rentalStartDate_Disabled));
				HighlightElement(RentalStartDate1);
				
				if(ElementFound(SphereModules.Transaction_rentalStartDate_Disabled)==true)
				{
					obj.repAddData( "Verify  RentalStartDate field ",
							"RentalStartDate field should  be disabled", "RentalStartDate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  RentalStartDate field ",
							"RentalStartDate field should  be disabled", "RentalStartDate field is not disabled", "Fail");
				}
				
				WebElement RentalEndDate1 = driver.findElement(By.xpath(SphereModules.Transaction_rentalEndDate_Disabled));
				HighlightElement(RentalEndDate1);
				
				if(ElementFound(SphereModules.Transaction_rentalEndDate_Disabled)==true)
				{
					obj.repAddData( "Verify  RentalEndDate field ",
							"RentalEndDate field should  be disabled", "RentalEndDate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  RentalEndDate field ",
							"RentalEndDate field should  be disabled", "RentalEndDate field is not disabled", "Fail");
				}
				
				
				WebElement Pricelist1 = driver.findElement(By.xpath(SphereModules.Transaction_Pricelist_Disabled));
				HighlightElement(Pricelist1);
				
				if(ElementFound(SphereModules.Transaction_Pricelist_Disabled)==true)
				{
					obj.repAddData( "Verify  Pricelist field ",
							"Pricelist field should  be disabled", "Pricelist field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Pricelist field ",
							"Pricelist field should  be disabled", "Pricelist field is not disabled", "Fail");
				}
				
				
				WebElement ItemCode1 = driver.findElement(By.xpath(SphereModules.Transaction_ItemCode_Disabled));
				HighlightElement(ItemCode1);
				
				if(ElementFound(SphereModules.Transaction_ItemCode_Disabled)==true)
				{
					obj.repAddData( "Verify  ItemCode field ",
							"ItemCode field should  be disabled", "ItemCode field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  ItemCode field ",
							"ItemCode field should  be disabled", "ItemCode field is not disabled", "Fail");
				}
			    
				WebElement RequestDate1 = driver.findElement(By.xpath(SphereModules.Transaction_RequestDate_Disabled));
				HighlightElement(RequestDate1);
				
				if(ElementFound(SphereModules.Transaction_RequestDate_Disabled)==true)
				{
					obj.repAddData( "Verify  RequestDate field ",
							"RequestDate field should  be disabled", "RequestDate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  RequestDate field ",
							"RequestDate field should  be disabled", "RequestDate field is not disabled", "Fail");
				}
			    
				WebElement BillableYes1 = driver.findElement(By.xpath(SphereModules.Transaction_BillableYes_Disabled));
				HighlightElement(BillableYes1);
				
				if(ElementFound(SphereModules.Transaction_BillableYes_Disabled)==true)
				{
					obj.repAddData( "Verify  Billable field ",
							"Billable field should  be disabled", "Billable field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Billable field ",
							"Billable field should  be disabled", "Billable field is not disabled", "Fail");
				}
			    
				WebElement LineDescription1 = driver.findElement(By.xpath(SphereModules.Transaction_LineDescription_Disabled));
				HighlightElement(LineDescription1);
				
				if(ElementFound(SphereModules.Transaction_LineDescription_Disabled)==true)
				{
					obj.repAddData( "Verify  LineDescription field ",
							"LineDescription field should  be disabled", "LineDescription field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  LineDescription field ",
							"LineDescription field should  be disabled", "LineDescription field is not disabled", "Fail");
				}
				
				WebElement quantity1 = driver.findElement(By.xpath(SphereModules.Transaction_quantity_Disabled));
				HighlightElement(quantity1);
				
				if(ElementFound(SphereModules.Transaction_quantity_Disabled)==true)
				{
					obj.repAddData( "Verify  quantity field ",
							"quantity field should  be disabled", "quantity field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  quantity field ",
							"quantity field should  be disabled", "quantity field is not disabled", "Fail");
				}
				
				WebElement unitOfMeasure1 = driver.findElement(By.xpath(SphereModules.Transaction_unitOfMeasure_Disabled));
				HighlightElement(unitOfMeasure1);
				
				if(ElementFound(SphereModules.Transaction_unitOfMeasure_Disabled)==true)
				{
					obj.repAddData( "Verify  unitOfMeasure field ",
							"unitOfMeasure field should  be disabled", "unitOfMeasure field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  unitOfMeasure field ",
							"unitOfMeasure field should  be disabled", "unitOfMeasure field is not disabled", "Fail");
				}
			    
				WebElement Rate1 = driver.findElement(By.xpath(SphereModules.Transaction_Rate_Disabled));
				HighlightElement(Rate1);
				
				if(ElementFound(SphereModules.Transaction_Rate_Disabled)==true)
				{
					obj.repAddData( "Verify  Rate field ",
							"Rate field should  be disabled", "Rate field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Rate field ",
							"Rate field should  be disabled", "Rate field is not disabled", "Fail");
				}
			    
				WebElement transactionType1 = driver.findElement(By.xpath(SphereModules.Transaction_transactionType_Disabled));
				HighlightElement(transactionType1);
				
				if(ElementFound(SphereModules.Transaction_transactionType_Disabled)==true)
				{
					obj.repAddData( "Verify  transactionType field ",
							"transactionType field should  be disabled", "transactionType field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  transactionType field ",
							"transactionType field should  be disabled", "transactionType field is not disabled", "Fail");
				}
				
				WebElement tax1 = driver.findElement(By.xpath(SphereModules.Transaction_taxYes_Disabled));
				HighlightElement(tax1);
				
				if(ElementFound(SphereModules.Transaction_taxYes_Disabled)==true)
				{
					obj.repAddData( "Verify  tax field ",
							"tax field should  be disabled", "tax field is disabled", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  tax field ",
							"tax field should  be disabled", "tax field is not disabled", "Fail");
				}
				
				ClickByXpath(SphereModules.Transaction_Cancelbutton, "Cancel Button", true);
				
				
				}
				
		
			
		
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC578 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC578 Completed");
		}
		return obj;
	} 
	
	
	public Reporter TC735(Reporter obj) throws Exception
	{
	  try {
			
			
		  objBusinessLib.fnClickMainMenuElement("Deals");
			WebDriverWait waitForTableLoad = new WebDriverWait(TestDriver.driver, 80);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Common_ViewDealModule_Table_xp)));
			RightClickByXpath(objSphereModules.Deals_FirstDeal,"First Row");
			ClickByXpath(SphereModules.Deals_ViewOrder, "View Orders button",true);
			Thread.sleep(4000);
			
			if(ElementFound(SphereModules.Orders_Tablelist_Taxnotfound)==false)
			{
				obj.repAddData( "Verify  Tax Amount ",
						"Tax Amount should  be excluded", "Tax Amount is excluded", "Pass");
			}
			else
			{
				obj.repAddData( "Verify  Tax Amount ",
						"Tax Amount should  be excluded", "Tax Amount is not excluded", "Fail");
			}
			
			if(ElementFound(SphereModules.Orders_Tablelist_Taxnotfound_Righttable)==false)
			{
				obj.repAddData( "Verify  tax field ",
						"tax field should  be disabled", "tax field is disabled", "Pass");
			}
			else
			{
				obj.repAddData( "Verify  tax field ",
						"tax field should  be disabled", "tax field is not disabled", "Fail");
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			//bLoginFlag=false;  
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
			log.error( "Script TC638 Failed!", e );
		}			
		
		finally {
		
		/*if((bLoginFlag==true && driver!=null) )
		{
			fnSignOut();
		}*/
		
		if(!testCaseStatus)
		{
			Reporter.iTotalFail++;	
		}
		else
		{
			Reporter.iTotalPass++;
		}
		log.info("Execution of Script TC638 Completed");
		}
		return obj;
		}
	
	
	public Reporter TC579(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC579 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    String ponumberDB=mTableDataDB1.get(1).get(5).toString().trim();
		    
		    String sDescriptionUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Description").trim();
		    String sUM=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("UM").trim();
		    String sRateUI=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Rate").trim();
		    String sTranType=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("TranType").trim();
		    String sQty=TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Qty").trim();
		   
		    Date date = new Date();
			String sTransactionDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
			String sCurrentDateUI= new SimpleDateFormat("MM/dd/yyyy").format(date);
			
			String sStartDateUI1= new SimpleDateFormat("MM/dd/yyyy").format(date);
			
			Date dexpiredday = DateUtils.addDays(new Date(), +5);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");//changed format due to error
			String sEndDateUI2 = sdf.format(dexpiredday); 
		    
		    
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;

			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			
			ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
		
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			RightClickByXpath(objSphereModules.Common_ViewModules_ClickFirstRow_xp,"First Row");
			
			Thread.sleep(3000);
			ClickByXpath(SphereModules.Customer_InterceptMenu_ViewEdit_Link_xp, "View/ Edit", true);
			Thread.sleep(3000);
			
			WebElement EnabledValue1 = driver.findElement(By.xpath(objSphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod_Enabled));
			if(EnabledValue1.isEnabled())
			{
				    	obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be enabled", 
						"WIP Charge Method is enabled",  "Pass");
			}
			else
			{
				obj.repAddData( "Verify WIP Charge Method", 
						"WIP Charge Method should be  enabled", 
						"WIP Charge Method is not enabled",  "Fail");
			}
			
			ClickByXpath(SphereModules.Orders_ViewEditOrder_CancelButton, "Cancel Button", true);
			Thread.sleep(3000);
			
			
			
			
			RightClickByXpath(objSphereModules.Common_ViewModules_ClickFirstRow_xp,"First Row");
			ClickByXpath(SphereModules.Common_InterceptMenu_ViewTransactions_Link_xp, "View Transactions", true);
			Thread.sleep(3000);
			
			  ClickByXpath(SphereModules.Transactions_AddTransaction_LinkAddTransaction_Sign_xp, "Add Transaction Link", true);
				fnLoadingPageWait();
				
				fnVerifyLabelMsgTextByXpath(AppMessages.AddTransaction_LabelTitle_Msg, SphereModules.Transactions_AddTransaction_LabelAddTransaction_Title_xp);
			    			
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_SearchOrder_xp, "999", "Search order");
				Thread.sleep(2000);
				fnLoadingPageWait();
				ClickByXpath(SphereModules.Deals_AddDeal_CustomerListSearch_xp, "First customer Row", true);
			
				SendKeyById(SphereModules.Transaction_AddTransaction_PoNumber_id, ponumberDB, "PO Number");
				
				SendKeyById(SphereModules.Transaction_AddTransaction_TransactionDate_id, sTransactionDateUI, "Transaction Date");
				SendKeyById(SphereModules.Transaction_AddTransaction_RentalStartDate_id, sStartDateUI1, "Rental Start Date");
				SendKeyById(SphereModules.Transaction_AddTransaction_RentalEndDate_id, sEndDateUI2, "Rental End Date");
				
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_Description_xp, sDescriptionUI, "Description");
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_Qty_xp, sQty, "Quantity");
				fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_UnitofMeasure_id,sUM);
				fnSelectFromComboBoxId(SphereModules.Transaction_AddTransaction_TransactionType_id,sTranType);
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_Rate_xp, sRateUI, "Rate");
				
				
				ClickByXpath(SphereModules.Transaction_AddTransaction_Save_Btn_xp, "Save", true);
				Thread.sleep(30000);
				
				waitForTableLoad = new WebDriverWait(TestDriver.driver, 60);
				 
				objBusinessLib.fnClickSubMenuElement("Billing","ARC");
		//		waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.ARC_Title_xp)));
				WebElement ArcTitle = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Title_xp));
			    HighlightElement(ArcTitle);
			    
			    ClickByXpath(SphereModules.Billings_Suspense_ClearAll_Btn_xp, "Clear All Button", true);
				Thread.sleep(4000);
				
				SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,"","Deal Number");
				SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,sExpDealNumberDB,"Deal Number");
			//	SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,"655217","Deal Number");
				fnLoadingPageWait();
				Thread.sleep(4000);
				if(ElementFound(SphereModules.ARC_Screen_Deal_list_1))
				{
					ClickByXpath(SphereModules.ARC_Screen_Deal_list_1, "Deal", true);
					fnLoadingPageWait();
					Thread.sleep(4000);
					if(ElementFound(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp))
					{

						SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,UIorderNumber,"Order Number");
					//	SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,"999","Order Number");
						fnLoadingPageWait();
						Thread.sleep(6000);
						if(ElementFound(SphereModules.ARC_Screen_Order_list_1))
						{

							ClickByXpath(SphereModules.ARC_Screen_Order_list_1, "Order", true);
							ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp, "All Link", true);
						
							Thread.sleep(4000);
							WebElement ArcTable = TestDriver.driver.findElement(By.xpath(objSphereModules.ARC_Screen_transaction_table_xp));

							if(TestDriver.driver.findElements(By.xpath(SphereModules.Order_Table_Col4_xp)).size()>0==true)
							{
				//				obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
				//						"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation successful for  : \t Order Number: "+UIorderNumber, "Pass");  
								System.out.println("Transactions exist");	

							}
							else
							{
				//				obj.repAddData( "Verify  transactions on ARC Screen for: " +sExpDealNumberDB+ "-" +UIorderNumber,
				//						"Transactions for Order "+UIorderNumber+ "Should be dispalyed", "Validation failed for  : \t Order Number: "+UIorderNumber, "Fail");

							}

						}

					}

				}
				
		/*		 Thread.sleep(3000);
			    RightClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row");
			    Thread.sleep(3000);
			    ClickByXpath(SphereModules.ARC_BulkActionsDropDown_Options_NonBillable, "NonBillable", true);
			    fnLoadingPageWait();
			    Thread.sleep(4000); 
			    SendKeyByXpath(SphereModules.ARC_NonBillable_Notes,"Test","Deal Number");
				fnLoadingPageWait();
				WebElement ele = driver.findElement(By.xpath(SphereModules.ARC_NonBillable_Continue));
				ele.click();
				Thread.sleep(4000); 
				
					obj.repAddData( "Verify  Success Message ",
							"Success Message should  be displayed", "Success Message is displayed", "Pass");
				
	*/		   
	/*			ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Row", true);
				Thread.sleep(3000);
				WebElement ele = driver.findElement(By.xpath(SphereModules.Transaction_AddTransaction_PoNumber_id1));
			
				GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Transaction_AddTransaction_PoNumber_id1)).clear();
				SendKeyByXpath(SphereModules.Transaction_AddTransaction_PoNumber_id1, "501128", "PO Number");
				
				WebElement save = driver.findElement(By.xpath(SphereModules.Arc_Transaction_Save));
				save.click();
				Thread.sleep(3000);
			if(ElementFound(SphereModules.Transaction_SuspendTransaction_SuccessMessage)==true)
				{
					obj.repAddData( "Verify  Success Message ",
							"Success Message should  be displayed", "Success Message is displayed", "Pass");
				}
				else
				{
					obj.repAddData( "Verify  Success Message ",
							"Success Message should  be displayed", "Success Message is not displayed", "Fail");
				}
		*/	}
				
		    catch (Exception e) {
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC578 Failed!", e );
		   }
		   finally {
			 //  fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC578 Completed");
		}
		return obj;
	} 
	
	
	
	public Reporter TC452(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC452 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);*/
			
		
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			
			if(ElementFound(SphereModules.Orders_WipChargeMethod_Options)==true)
			{
				obj.repAddData( "Verify Wip Charge method options",
						"charge method 'FR' (Fixed Rate) and CP (Cost Plus) should be available in the Wip Charge Method", "charge method 'FR' (Fixed Rate) and CP (Cost Plus) is available in the Wip Charge Method", "Pass");
			}
			else
			{
				obj.repAddData( "Verify Wip Charge method options",
						"charge method 'FR' (Fixed Rate) and CP (Cost Plus) should be available in the Wip Charge Method", "charge method 'FR' (Fixed Rate) and CP (Cost Plus) is not available in the Wip Charge Method", "Fail");
			}
		    
			ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	
			
			
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC452 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC452 Completed");
		}
		return obj;
	} 
	
	public Reporter TC451(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC451 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);*/
			
		
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			
			if(ElementFound(SphereModules.Orders_WipChargeMethod_Disabled_FixedRate)==true)
			{
				obj.repAddData( "Verify Wip Charge method options",
						"Verify charge method 'FR' (Fixed Rate) is the only charge method available", "charge method 'FR' (Fixed Rate) is the only charge method available", "Pass");
			}
			else
			{
				obj.repAddData( "Verify Wip Charge method options",
						"Verify charge method 'FR' (Fixed Rate) is the only charge method available", "charge method 'FR' (Fixed Rate) is not the only charge method available", "Fail");
			}
		    
			ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	
			
			
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC451 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC451 Completed");
		}
		return obj;
	} 
	public Reporter TC450(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC450 Started..");

		
		try {		
			String sDealTitleUI ="";
			obj.repAddData( "Adding a new deal account ", "", "", "");
			sDealTitleUI = objBusinessLib.fnAddDealAccount(18, mTestPhaseData.get(iTC_ID).get("Cost_Center"));
			System.out.println(sDealTitleUI);
			
			String sQuery1 = objSQLConfig.sDeals_AddDeal_Query;
			sQuery1 = sQuery1.replaceAll("deal_title_param",sDealTitleUI);
			TestDriver.conn = objDBUtility.fnOpenDBConnection();
			TestDriver.rset = objDBUtility.fnGetDBData(TestDriver.conn,sQuery1);
			HashMap<Integer, HashMap<Integer, String>> mTableDataDB1 = objDBUtility.fnWriteResultSet(TestDriver.rset);
		    String sExpDealNumberDB=mTableDataDB1.get(1).get(1).toString().trim();
		    
		    String UIorderNumber="999";
			String sRandom = String.valueOf(fnRandomNum(1001, 9999));
			String sOrderDescUI = "AUTOTESTORDER_"+sRandom;
			String sPoNumberUI = "AutoPONumber_"+sRandom;
			String sTotalEstimateAmountUI=sRandom+".00";
			String sEpisodeNumber="AutoEpNumber_"+sRandom;
			String sRequestorName="AutoRequestorName_"+sRandom;
			String sApproverName="AutoApproverName_"+sRandom;
		
			String sCostCenterUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Cost_Center").trim();
			String sLocationUI = TestDriver.mTestPhaseData.get(TestDriver.iTC_ID).get("Location").trim();
		   
			obj.repAddData( "Verifying unique order number creation", "", "", "");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			
			objBusinessLib.fnClickMainMenuElement("Dashboard");
			waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereCommon.Main_HomeDashBoard_xp)));
			WebElement Titleele = driver.findElement(By.xpath(SphereCommon.Main_HomeDashBoard_xp));
			HighlightElement(Titleele);
		    fnSelectFromComboBoxXpath(SphereModules.Dashboard_SearchBy_Deal_xp,"Deal");
			
			
			SendKeyByXpath(SphereModules.Dashboard_Deal_SearchBar_xp,sExpDealNumberDB,"Deal Number");
			fnLoadingPageWait();
			Thread.sleep(4000);
			List<WebElement> options = TestDriver.driver.findElements(By.xpath("//ul[@class='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope'and @position='down']//div[starts-with(@id,'ui-select-choices-')]"));
			System.out.println(options.size());
	        for(int i=0;i<=options.size();i++){
	        String optionName = options.get(i).getText();
	        System.out.println(optionName);
	        String DealNumUI = optionName.substring(0, 6);
	        System.out.println(DealNumUI);
	        if(DealNumUI.equals(sExpDealNumberDB))
	        {

	       options.get(i).click();
	        break;
	        }
	        }
			
			//ClickByXpath(SphereModules.Dashboard_Deal_SearchBar_FirstRow_xp, "FirstRow", true);
			fnLoadingPageWait();
			Thread.sleep(4000);
			ClickByXpath(SphereModules.Dashboard_Deal_Search_Go_Btn_xp, "Go btn", true);
			fnLoadingPageWait();
			fnLoadingPageWait();
			fnLoadingPageWait();
			Thread.sleep(9000);
			/*waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(objSphereModules.Orders_Title_xp)));
			WebElement Titleele1 = driver.findElement(By.xpath(objSphereModules.Orders_Title_xp));
			HighlightElement(Titleele1);*/
			
		
		    
			WebElement eleTable = driver.findElement(By.xpath(objSphereModules.Common_Orders_Table_xp));
			List<WebElement> arrHeaderColumns = eleTable.findElements(By.xpath("../thead/tr/th"));  //Get the header
			System.out.println("Rows Size>>>>"+arrHeaderColumns.size());

			ClickByXpath(SphereModules.Orders_Plus_Add_Sign_xp, "Add Order Link", true);
			fnLoadingPageWait();
			fnVerifyLabelMsgTextByXpath(AppMessages.Order_AddOrder_LabelTitle_msg, SphereModules.Orders_Add_Form_Title_xp);
			 
			SendKeyById(SphereModules.Orders_Add_Form_Order_Description_id, sOrderDescUI, "Order Description");
			SendKeyByXpath(SphereModules.Orders_Add_Form_Order_Number_xp,"999", "Order Number");
			SendKeyById(SphereModules.Orders_Add_Form_TotalEstimateAmount_id, sTotalEstimateAmountUI, "Total Estimate Amount");
			SendKeyById(SphereModules.Orders_Add_Form_POnumber_id, sPoNumberUI, "PO Number");
			SendKeyById(SphereModules.Orders_Add_Form_Location_id, sLocationUI, "Location");
			SendKeyById(SphereModules.Orders_Add_Form_EpisodeNumber_id, sEpisodeNumber, "Episode Number");
			//SendKeyById(SphereModules.Orders_AddOrderComboInvoiceFormat_xp_Verify_WIP_ChargeMethod, sEpisodeNumber, "Episode Number");
			ClickByXpath(SphereModules.Orders_Add_Form_Save_Btn_xp, "Save Button", true);
			fnLoadingPageWait();
			
			ClickByXpath(SphereModules.Common_ViewModules_ClickFirstRow_xp, "First Account Row",true);
			Thread.sleep(6000);
			fnCheckDisbleByXPath(SphereModules.Orders_WipChargeMethod,"Wip Charge Method");
			
			if(ElementFound(SphereModules.Orders_WipChargeMethod_Disabled_FixedRate)==true)
			{
				obj.repAddData( "Verify Wip Charge method",
						"Verify Wip charge method is disabled and 'FR' (Fixed Rate) is the only option available", "Wip charge method is disabled and 'FR' (Fixed Rate) is the only option available", "Pass");
			}
			else
			{
				obj.repAddData( "Verify Wip Charge method",
						"Verify Wip charge method is disabled and 'FR' (Fixed Rate) is the only option available", "Wip charge method is not disabled", "Fail");
			}
		    
			ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
			fnLoadingPageWait();
			
		   }
		    catch (Exception e) {
	    	ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	    	Thread.sleep(6000);
	    	ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	    	Thread.sleep(3000); 
			e.printStackTrace();
			testCaseStatus = false;
			obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
		 	log.error( "Script TC450 Failed!", e );
		   }
		   finally {
			   fnCloseOpenedForm();
			
			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC450 Completed");
		}
		return obj;
	}
	public Reporter TC649(Reporter obj) throws Exception
	{
		log.info("Execution of Script TC649 Started..");
	try {
			
			obj.repAddData( "Verifying duplicate DSN is rejected", "", "", "");
			obj.repAddData( "File upload to shared drive is a prerequisite", "", "", "");
			
			String sNewValue=objBusinessLib.fnCreateDealOrderforexception4("Open Order","Open Deal");
			//String sNewValue = "679825001";
			System.out.println(sNewValue);
			String DealNum = sNewValue.substring(0,6);
			System.out.println(DealNum);
			Thread.sleep(4000);
			obj.repAddData( "Navigate to exceptions link in billing", "", "", "");
			objBusinessLib.fnClickSubMenuElement("Billing","Exceptions");
			WebDriverWait waitForTableLoad = new WebDriverWait(driver, 60);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.BillingRequest_Table_xp)));
			Thread.sleep(4000);
			
			//ClickByXpath(SphereModules.Billings_Rejection_Btn_xp, "Rejection", true);

		    String sDeptSyssNumberRandom = String.valueOf(fnRandomNum(100000001, 999999999));
		    System.out.println(sDeptSyssNumberRandom);
		   	

		    //String targetFileName=objBusinessLib.fnnewArchiveFile("C:\\Automation_Workspace\\Sphere_Automation\\TestData\\","CHSLGRIP_4162_158_DC - ARC_N_3.TXT");
		    String targetFileName=BusinessFunctionLibrary.fnnewArchiveFile("C:\\Automation_Workspace\\Sphere_Automation1\\TestData\\","SLGRIPN__4162_111_DC - ARC_N_3.TXT");
		    System.out.println(targetFileName);
		    
		    BusinessFunctionLibrary.fnReadReplaceTextFile(targetFileName,"DeptSysNum",sDeptSyssNumberRandom);
		    BusinessFunctionLibrary.fnReadReplaceTextFile(targetFileName,"DealOrder",sNewValue);
		    
		    

		    //no need to replace any value 
		  	    	   		
		    BusinessFunctionLibrary.fnCopyFileToSharedDrive(targetFileName,FileLocSetter.sBillingSharedDrive);
		    Thread.sleep(7000);
		     Thread.sleep(90000);
		      Thread.sleep(90000);
			//WebDriverWait waitForTableLoad;	
				waitForTableLoad = new WebDriverWait(GenericFunctionLibrary.driver, 60);
				obj.repAddData( "Navigate to ARC link in billing", "", "", "");
				Thread.sleep(4000);
				objBusinessLib.fnClickSubMenuElement("Billing","ARC");
				waitForTableLoad.until(ExpectedConditions.elementToBeClickable(By.xpath(SphereModules.ARC_Title_xp)));
				WebElement Title = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.ARC_Title_xp));
				Thread.sleep(4000);
				HighlightElement(Title);
				Thread.sleep(25000);
				
		    
		    
			Thread.sleep(4000);
			GenericFunctionLibrary objGenericFunctionLibrary = new GenericFunctionLibrary();
			objGenericFunctionLibrary.SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,DealNum,"Deal Number");
		//	objGenericFunctionLibrary.SendKeyByXpath(SphereModules.ARC_Screen_Deal_Search_Bar_xp,"704688","Deal Number");
			objGenericFunctionLibrary.fnLoadingPageWait();
			objGenericFunctionLibrary.ClickByXpath(SphereModules.ARC_Screen_Clear_Btn_xp, "Clear button", true);
			//objGenericFunctionLibrary.ClickByXpath(SphereModules.ARC_screen_reset_default_button_xp, "Reset button", true);
			waitForTableLoad.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SphereModules.Billing_ARC_Deal_Visibility_xp)));
		
				if(objGenericFunctionLibrary.ElementFound(SphereModules.ARC_Screen_Deal_list_1))
				{
					objGenericFunctionLibrary.ClickByXpath(SphereModules.ARC_Screen_Deal_list_1, "Deal", true);
					objGenericFunctionLibrary.fnLoadingPageWait();
					Thread.sleep(4000);
					if(objGenericFunctionLibrary.ElementFound(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp))
				{
				objGenericFunctionLibrary.SendKeyByXpath(SphereModules.ARC_Screen_OrderNumber_SearchBar_xp,"001","Order Number");
				objGenericFunctionLibrary.fnLoadingPageWait();
				Thread.sleep(4000);
				if(objGenericFunctionLibrary.ElementFound(SphereModules.ARC_Screen_Order_list_1)){

					objGenericFunctionLibrary.ClickByXpath(SphereModules.ARC_Screen_Order_list_1, "Order", true);
					Thread.sleep(4000);
					if(objGenericFunctionLibrary.ElementFound(SphereModules.Common_ViewModules_LinkAll_xp1))
					System.out.println("Link visible");
					objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ViewModules_LinkAll_xp1, "All Link", true);
					Thread.sleep(4000);
					
					if(objGenericFunctionLibrary.ElementFound(SphereModules.Common_ARC_ViewTransaction_xp));
					{
						WebElement ViewTran = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Common_ARC_ViewTransaction_xp));
						HighlightElement(ViewTran);
		 				objGenericFunctionLibrary.ClickByXpath(SphereModules.Common_ARC_ViewTransaction_xp, "View Transaction", true);
		 				Thread.sleep(4000);
		 				objGenericFunctionLibrary.ClickByXpath(SphereModules.Billing_ARC_View_Transaction_Notes_tab_xp,"Notes",true);
		 				WebElement notes = GenericFunctionLibrary.driver.findElement(By.xpath(SphereModules.Billing_ARC_View_transaction_Note_Content_xp));
		 				String noteContent=notes.getText().toString();
		 				System.out.println("Printing note content: "+noteContent);
		 				
		 				if(noteContent.isEmpty())
		 				{
		 					obj.repAddData( "Verify data present in Notes" ,"Data is not present", "Validation unsuccessful for: \t Order Number:"+"001", "Fail");
		 					
		 		 		}
		 				else
		 				{
		 					obj.repAddData( "Verify data present in Notes" ,"Data is present", "Validation successful for: \t Order Number:"+"001", "Pass");
		 					
		 				}
					}
				}
					
					
				
				
				else{
						obj.repAddData( "Verify order# is present for the deal : " , "Order# should be present", "Validation unsuccessful "+"001", "Fail");
										
					}
				
				}
				
				}
				
				objGenericFunctionLibrary.ClickByXpath(SphereModules.Exceptions_accordian_table_transaction_view_close_xp, "Close", true);
				/*if((SphereModules.Exceptions_accordian_table_billing_request_popup_close_xp1).exists())
				{
				objGenericFunctionLibrary.ClickByXpath(SphereModules.Exceptions_accordian_table_billing_request_popup_close_xp1, "Sure", true);

				}*/
			//objBusinessLib.fnVerifydataForRecordType();
			
			
	     }
	          catch (Exception e) {
	        	  ClickByXpath(SphereModules.InvoiceStatementInquiry_Exit, "click", true);
	        		Thread.sleep(6000);
	        		ClickByXpath(SphereModules.Billing_DraftBilling_createImmediate_PopUp_YesBtn_xp, "Yes", true);
	        		Thread.sleep(3000);
				e.printStackTrace();
				testCaseStatus = false;
				//bLoginFlag=false;
				obj.repAddData( "Error Handler ", "There should not be any error/exception in the test", "Exception found in current test.", "Fail");
				log.error( "Script TC649 Failed!", e );
			}			

	 finally {
			
			/*if((bLoginFlag==true && driver!=null) )
			{
				fnSignOut();
			}*/

			if(!testCaseStatus)
			{
				Reporter.iTotalFail++;	
			}
			else
			{
				Reporter.iTotalPass++;
			}
			log.info("Execution of Script TC649 Completed");
			
		}
		return obj;
		}

	}
