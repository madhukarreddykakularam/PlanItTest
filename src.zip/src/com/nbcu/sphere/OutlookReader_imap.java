package com.nbcu.sphere;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.mail.search.FlagTerm;

//need to import below jars


import org.apache.poi.util.IOUtils;

import com.adobe.acrobat.PDFDocument;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.nbcu.sphere.ConfigManager.FileLocSetter;
import com.nbcu.sphere.ObjectRepository.SphereModules;
import com.sun.mail.util.MailSSLSocketFactory;
import com.sun.net.httpserver.Authenticator;
import com.sun.net.httpserver.HttpExchange;

//import org.jboss.util.Base64;



import sun.net.www.protocol.http.HttpURLConnection;

public class OutlookReader_imap  {

	Folder inbox;
	javax.mail.Message[] msg;

	public void printAllMessages(javax.mail.Message[] messages) throws Exception {
		for (int i = 0; i < messages.length; i++) {
			System.out.println("MESSAGE #" + (i + 1) + ":");
			printEnvelope(messages[i]);
		}
	}

	public List<String> saveAttachments() throws Exception 
	{	List<String> fileSaveLocation = new ArrayList<String>();
	final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

	Properties props = System.getProperties();
	// Set manual Properties
	props.setProperty("mail.imaps.socketFactory.class", SSL_FACTORY);
	props.setProperty("mail.imaps.socketFactory.fallback", "false");
	props.setProperty("mail.imaps.port", "993");
	props.setProperty("mail.imaps.socketFactory.port", "993");
	//props.put("mail.imaps.host", "nbcumail.inbcu.com");
	props.put("mail.imaps.host", "https://login.microsoftonline.com");
	MailSSLSocketFactory sf=new MailSSLSocketFactory();
	sf.setTrustAllHosts(true);

	props.put("mail.smtp.ssl.socketFactory", sf);
	props.put("mail.smtp.starttls.enable", true);
	props.put("mail.smtp.EnableSSL.enable", true);

	/* Create the session and get the store for read the mail. */
	try{
		Session session = Session.getInstance(props, new javax.mail.Authenticator() 
		{
			protected PasswordAuthentication getPasswordAuthentication()
			{
				return new PasswordAuthentication("206500871", "Varshu#55");
			}
		});
		javax.mail.Store store = session.getStore("imaps");
		
		store.connect("https://outlook.office365.com/owa/TFAYD.com/", "206500871@tfayd.com");
		//store.connect("nbcumail.inbcu.com", "206500871", "Varshu#11");
		System.out.println("Connection has been established...");
		

		/* Mention the folder name which you want to read. */
		inbox = store.getFolder("INBOX");
		inbox.open(Folder.READ_ONLY);

		javax.mail.Message[] messages = inbox.search(new FlagTerm(new Flags(
				Flags.Flag.SEEN), false));
		System.out.println("No. of Unread Messages : " + inbox.getUnreadMessageCount());
		
		/* Use a suitable FetchProfile */
		FetchProfile fp = new FetchProfile();
		fp.add(FetchProfile.Item.ENVELOPE);
		inbox.fetch(messages, fp);
		
		for (Message msg : messages) {

			if (msg.getContent() instanceof Multipart) {
				Multipart multipart = (Multipart) msg.getContent();

				for (int i = 0; i < multipart.getCount(); i++) {
					Part part = multipart.getBodyPart(i);
					String disposition = part.getDisposition();

					if ((disposition != null) && 
							((disposition.equalsIgnoreCase(Part.ATTACHMENT) || 
									(disposition.equalsIgnoreCase(Part.INLINE))))) {
						MimeBodyPart mimeBodyPart = (MimeBodyPart) part;
						String fileName = mimeBodyPart.getFileName();
						System.out.println(fileName.split("\\.")[0]);
						
						fileName=fileName.split("\\.")[0]+"_"+new SimpleDateFormat("MMddyyyhhmmss").format(new Date())+".pdf";
						System.out.println(fileName);
						File fileToSave = new File(System.getProperty("user.dir")+"//TestData//InvoiceArch//" +fileName);

						mimeBodyPart.saveFile(fileToSave);
						fileSaveLocation.add(fileToSave.getPath().toString().trim());
						
					}
				}
			}
		}

	/*	List<String> fileSaveLocation = new ArrayList<String>();
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		Properties props = System.getProperties();
		// Set manual Properties
		props.setProperty("mail.imaps.socketFactory.class", SSL_FACTORY);
		props.setProperty("mail.imaps.socketFactory.fallback", "false");
		props.setProperty("mail.imaps.port", "993");
		props.setProperty("mail.imaps.socketFactory.port", "993");
		//props.put("mail.imaps.host", "nbcumail.inbcu.com");
		props.put("mail.imaps.host", "https://login.microsoftonline.com");
		MailSSLSocketFactory sf=new MailSSLSocketFactory();
		sf.setTrustAllHosts(true);

		props.put("mail.smtp.ssl.socketFactory", sf);
		props.put("mail.smtp.starttls.enable", true);
		props.put("mail.smtp.EnableSSL.enable", true);
*/
		/* Create the session and get the store for read the mail. */
		
		 /* Properties props = System.getProperties();               
		    props.put("mail.imaps.auth.plain.disable","true"); 
		    props.setProperty("mail.imaps.timeout", "100000");
		    props.setProperty("mail.imaps.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		    props.setProperty("mail.imaps.socketFactory.fallback", "false");
		    props.setProperty("mail.imaps.ssl.enable", "true");*/
		//try{
			
			
		/*	Properties props = System.getProperties();
			props.setProperty("mail.store.protocol", "imaps");

			Session session = Session.getDefaultInstance(props, null);
			Store store = session.getStore("imaps");
			store.connect("XXXX","username", "password");

			Folder inbox = store.getFolder("Inbox");
			System.out.println("No of Unread Messages : " + inbox.getUnreadMessageCount());
			inbox.open(Folder.READ_ONLY);*/
			
			
			/* Properties props = new Properties();        
			  props.setProperty("mail.imap.ssl.enable", "true");     
			  Session mailSession = Session.getInstance(props); 
			  mailSession.setDebug(true);
			  Store mailStore = mailSession.getStore("imap");
			  mailStore.connect("outlook.office365.com", "MadhukarReddy.Kakularam@capgemini.com", "Varshu#44");
			  System.out.println("CONNECTED");
			  
			  
			  */
			  
			  
			  
			  
			  
			  /*	String protocol="imaps";
			Properties props1 = new Properties();
			props1.setProperty("mail.store.protocol", protocol);
			                 
			//extra codes required for reading OUTLOOK mails during IMAP-start
			    props1.setProperty("mail.imaps.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			    props1.setProperty("mail.imaps.socketFactory.fallback", "false");
			    props1.setProperty("mail.imaps.port", "993");
			    props1.setProperty("mail.imaps.socketFactory.port", "993");
			//extra codes required for reading OUTLOOK mails during IMAP-end
			                 
			Session session = Session.getDefaultInstance(props1, null);
			Store store = session.getStore(protocol);
			store.connect("imap-mail.outlook.com", "MadhukarReddy.Kakularam@nbcuni.com", "Varshu#44");
			Folder inbox = store.getFolder("INBOX");
			inbox.open(Folder.READ_WRITE);
			
			
		*/	
			
			
			
			
			
			
			
			
			
			
		/*	
			
			
			Session session = Session.getInstance(props, new javax.mail.Authenticator() 
			{
				protected PasswordAuthentication getPasswordAuthentication()
				{
					return new PasswordAuthentication("206500871", "Varshu#22");
				}
			});
			javax.mail.Store store = session.getStore("imaps");
			
			store.connect("outlook.office365.com", "MadhukarReddy.Kakularam@nbcuni.com");
			
			System.out.println("Connection has been established...");
			

			 Mention the folder name which you want to read. 
			inbox = store.getFolder("INBOX");
			inbox.open(Folder.READ_ONLY);

			javax.mail.Message[] messages = inbox.search(new FlagTerm(new Flags(
					Flags.Flag.SEEN), false));
			System.out.println("No. of Unread Messages : " + inbox.getUnreadMessageCount());
			
			 Use a suitable FetchProfile 
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			inbox.fetch(messages, fp);
			
			for (Message msg : messages) {

				if (msg.getContent() instanceof Multipart) {
					Multipart multipart = (Multipart) msg.getContent();

					for (int i = 0; i < multipart.getCount(); i++) {
						Part part = multipart.getBodyPart(i);
						String disposition = part.getDisposition();

						if ((disposition != null) && 
								((disposition.equalsIgnoreCase(Part.ATTACHMENT) || 
										(disposition.equalsIgnoreCase(Part.INLINE))))) {
							MimeBodyPart mimeBodyPart = (MimeBodyPart) part;
							String fileName = mimeBodyPart.getFileName();
							System.out.println(fileName.split("\\.")[0]);
							
							fileName=fileName.split("\\.")[0]+"_"+new SimpleDateFormat("MMddyyyhhmmss").format(new Date())+".pdf";
							System.out.println(fileName);
							File fileToSave = new File(System.getProperty("user.dir")+"//TestData//InvoiceArch//" +fileName);

							mimeBodyPart.saveFile(fileToSave);
							fileSaveLocation.add(fileToSave.getPath().toString().trim());
							
						}
					}
				}
			}*/
		}
		    catch (Exception e) {
			System.out.println("Failed");    
			TestDriver.log.error("Save Attatchments failed",e);
			throw new AssertionError(e.getMessage());
		}
	//	return null;

		return fileSaveLocation;
	}
/*	public List<String> saveAttachments1() throws Exception 
	{	
		try{
			
			Properties props = new Properties();        
		      props.setProperty("mail.store.protocol", "imap");
		      props.setProperty("mail.imaps.starttls.enable", "true");    
		      props.setProperty("mail.imaps.host", "outlook.office365.com");
		      props.setProperty("mail.imaps.port", "143");    
		      Session session = Session.getInstance(props, new javax.mail.Authenticator() 
		     {
		    	  
		      };
		      Session mailSession = Session.getInstance(props); 
		      mailSession.setDebug(true);
		      javax.mail.Store Store = session.getStore("imaps");
		      Store mailStore = mailSession.getStore("imaps");
		      mailStore.connect("outlook.office365.com", "206500871@tfayd.com");
		}
		
		
		    catch (Exception e) {
			System.out.println("Failed");    
			TestDriver.log.error("Save Attatchments failed",e);
			throw new AssertionError(e.getMessage());
		}
		return null;

		
	}
*/
	public  List<String> convertPDFToTxt(String fileSaveLocation) throws Exception {
		List<String> dataList = new ArrayList<String>();
		FileInputStream file=new FileInputStream(fileSaveLocation);  
		PdfReader reader=new PdfReader(file);
		int pageNum=reader.getNumberOfPages();
		for(int i=1;i<=pageNum;i++){

			String text=PdfTextExtractor.getTextFromPage(reader, i);
			dataList.add(text);
			System.out.println("Text:"+text); 
		}
		return dataList;
	}       

	public void printEnvelope(javax.mail.Message messages) throws Exception {

		javax.mail.Address[] a;
		
		if ((a = ((javax.mail.Message) messages).getFrom()) != null) {
			for (int j = 0; j < a.length; j++) {
				System.out.println("De : " + a[j].toString());
			}
		}

		String subject = ((javax.mail.Message) messages).getSubject();
		String description = ((javax.mail.Message) messages).getContent().toString();
		Date receivedDate = ((javax.mail.Message) messages).getReceivedDate();
		Date sentDate = ((javax.mail.Message) messages).getSentDate(); // receivedDate is returning

		String message= ((javax.mail.Message) messages).getContent().toString();;
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		System.out.println("Asunto : " + subject);
		System.out.println("MailContent : " + org.jsoup.Jsoup.parse(description).text());
		if (receivedDate != null) {
			System.out.println("Recibido: " + df.format(receivedDate));
		}

		System.out.println("Enviado : " + df.format(sentDate));
	}
	
	
	public static String download (String link, String fName) {
        String save = null;
        URLConnection urlConn = null;
        HttpURLConnection htcon = null;
        InputStream is = null;
        StringBuffer sb = new StringBuffer();
        String authStr = "206499290:Marina1234";

       // String authStringEnc = Base64.encodeBytes(authStr.getBytes());
        String authStringEnc = new String(org.apache.commons.codec.binary.Base64.encodeBase64(org.apache.commons.codec.binary.StringUtils.getBytesUtf8(authStr)));

        try{
        	String fileName=fName+"_"+new SimpleDateFormat("MMddyyyyhhmmss").format(new Date())+".pdf";
            String file = link;
            
            
            URL url = new URL(link);
            urlConn=url.openConnection();
            urlConn.setRequestProperty("Authorization", "Basic " +  authStringEnc);
            ((HttpURLConnection) urlConn).setRequestMethod("GET");
                    urlConn.setRequestProperty("user-agent","Chrome/4.0");
                    urlConn.setRequestProperty("Content-Type","application/json");

            htcon = (HttpURLConnection) urlConn;
          is=htcon.getInputStream();
          InputStreamReader isr = new InputStreamReader(is);

          int numCharsRead;
          char[] charArray = new char[1024];

          while ((numCharsRead = isr.read(charArray)) > 0) {
              sb.append(charArray, 0, numCharsRead);
          }   

          System.out.println("sb: "+sb);
           
         /*   BufferedInputStream in = new BufferedInputStream(url.openStream());
            save = System.getProperty("user.dir")+"//TestData//Draft//" +fileName;   
           
            FileOutputStream fos = new FileOutputStream(new File(save));

            int length = -1;
            byte[] buffer = new byte[1024];

           while ((length = in.read(buffer)) > -1) {
                fos.write(buffer, 0, length);
           }
           fos.close();
           in.close();
           System.out.println("file is downloaded");*/

      } catch (IOException e) {
           e.printStackTrace();
      }
      return save;
   }
	/*ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
    driver.switchTo().window(tabs2.get(1));
    
    driver.close();
    driver.switchTo().window(tabs2.get(0));
	*/

	public static void main(String args[]) throws Throwable {
		new OutlookReader_imap();
	}
	
	public  List<String> convertPDFToTxtfile(URL url) throws Exception {
		List<String> dataList = new ArrayList<String>();
		// URL url = new URL(driver.getCurrentUrl());
	 //   BufferedInputStream fileToParse=new BufferedInputStream(url.openStream());  
		 BufferedInputStream file=new BufferedInputStream(url.openStream());  
		PdfReader reader=new PdfReader(file);
		int pageNum=reader.getNumberOfPages();
		for(int i=1;i<=pageNum;i++){

			String text=PdfTextExtractor.getTextFromPage(reader, i);
			dataList.add(text);
			System.out.println("Text:"+text); 
		}
		return dataList;
	}       
	
	
	public String saveAttachmentsNonNbcuEmail() throws Exception 
	{	String count = null;
		List<String> fileSaveLocation = new ArrayList<String>();
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		Properties props = System.getProperties();
		// Set manual Properties
		props.setProperty("mail.imaps.socketFactory.class", SSL_FACTORY);
		props.setProperty("mail.imaps.socketFactory.fallback", "false");
		props.setProperty("mail.imaps.port", "993");
		props.setProperty("mail.imaps.socketFactory.port", "993");
		props.put("mail.imaps.host", "nbcumail.inbcu.com");

		MailSSLSocketFactory sf=new MailSSLSocketFactory();
		sf.setTrustAllHosts(true);

		props.put("mail.smtp.ssl.socketFactory", sf);
		props.put("mail.smtp.starttls.enable", true);
		props.put("mail.smtp.EnableSSL.enable", true);

		/* Create the session and get the store for read the mail. */
		try{
			Session session = Session.getInstance(props, new javax.mail.Authenticator() 
			{
				protected PasswordAuthentication getPasswordAuthentication()
				{
					return new PasswordAuthentication("206536272", "Varshu@77");
				}
			});
			javax.mail.Store store = session.getStore("imaps");

			//store.connect("nbcumail.inbcu.com", "206558522", "Varshu@77");
			store.connect("nbcumail.inbcu.com", "206536272", "Varshu@77");
			System.out.println("Connection has been established...");
			

			/* Mention the folder name which you want to read. */
			inbox = store.getFolder("INBOX");
			inbox.open(Folder.READ_ONLY);

			javax.mail.Message[] messages = inbox.search(new FlagTerm(new Flags(
					Flags.Flag.SEEN), false));
			System.out.println("No. of Unread Messages : " + inbox.getUnreadMessageCount());
		    count = Integer.toString(inbox.getUnreadMessageCount());
		    
		    for (Message msg : messages) {
		    	
				if (msg.getContent() instanceof Multipart) {
					Multipart multipart = (Multipart) msg.getContent();

					for (int i = 0; i < multipart.getCount(); i++) {
						Part part = multipart.getBodyPart(i);
						String disposition = part.getDisposition();

						if ((disposition != null) && 
								((disposition.equalsIgnoreCase(Part.ATTACHMENT) || 
										(disposition.equalsIgnoreCase(Part.INLINE))))) {
							
							System.out.println("Mail is Recieved:Fail");
						}else
						{
							System.out.println("Mail is not Recieved:Pass");
						}
					}
				}
			}
		    
		}
		    catch (Exception e) {
			System.out.println("Failed");    
			TestDriver.log.error("Save Attatchments failed",e);
			throw new AssertionError(e.getMessage());
		}

		return count;
	}

	public List<String> saveFileFailedStatusAttachments() throws Exception 
	{	
		List<String> fileSaveLocation = new ArrayList<String>();
		final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

		Properties props = System.getProperties();
		// Set manual Properties
		props.setProperty("mail.imaps.socketFactory.class", SSL_FACTORY);
		props.setProperty("mail.imaps.socketFactory.fallback", "false");
		props.setProperty("mail.imaps.port", "993");
		props.setProperty("mail.imaps.socketFactory.port", "993");
		props.put("mail.imaps.host", "nbcumail.inbcu.com");

		MailSSLSocketFactory sf=new MailSSLSocketFactory();
		sf.setTrustAllHosts(true);

		props.put("mail.smtp.ssl.socketFactory", sf);
		props.put("mail.smtp.starttls.enable", true);
		props.put("mail.smtp.EnableSSL.enable", true);

		/* Create the session and get the store for read the mail. */
		try{
			Session session = Session.getInstance(props, new javax.mail.Authenticator() 
			{
				protected PasswordAuthentication getPasswordAuthentication()
				{
					//return new PasswordAuthentication("206538886", "July@2018");
					return new PasswordAuthentication("206536272", "Varshu@77");
				}
			});
			javax.mail.Store store = session.getStore("imaps");
			store.connect("nbcumail.inbcu.com", "206536272", "Varshu@77");
			//store.connect("nbcumail.inbcu.com", "206538886", "July@2018");
			System.out.println("Connection has been established...");
			

			/* Mention the folder name which you want to read. */
			inbox = store.getFolder("INBOX");
			inbox.open(Folder.READ_ONLY);

			javax.mail.Message[] messages = inbox.search(new FlagTerm(new Flags(
					Flags.Flag.SEEN), false));
			System.out.println("No. of Unread Messages : " + inbox.getUnreadMessageCount());
			
			/* Use a suitable FetchProfile */
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			inbox.fetch(messages, fp);
			
			for (Message msg : messages) {

				if (msg.getContent() instanceof Multipart) {
					Multipart multipart = (Multipart) msg.getContent();

					for (int i = 0; i < multipart.getCount(); i++) {
						Part part = multipart.getBodyPart(i);
						String disposition = part.getDisposition();

						if ((disposition != null) && 
								((disposition.equalsIgnoreCase(Part.ATTACHMENT) || 
										(disposition.equalsIgnoreCase(Part.INLINE))))) {
							MimeBodyPart mimeBodyPart = (MimeBodyPart) part;
							String fileName = mimeBodyPart.getFileName();
							System.out.println(fileName.split("\\.")[0]);
							
							fileName=fileName.split("\\.")[0]+"_"+new SimpleDateFormat("MMddyyyhhmmss").format(new Date())+".txt";
							System.out.println(fileName);
							File fileToSave = new File(System.getProperty("user.dir")+"//TestData//InvoiceArch//" +fileName);

							mimeBodyPart.saveFile(fileToSave);
							fileSaveLocation.add(fileToSave.getPath().toString().trim());
							
						}
					
					}
				}
			}
		}
		    catch (Exception e) {
			System.out.println("Failed");    
			TestDriver.log.error("Save Attatchments failed",e);
			throw new AssertionError(e.getMessage());
		}

		return fileSaveLocation;
	}

	public  List<String> ReadTxtFile(String fileSaveLocation,String sNewValue) throws Exception {
		
		List<String> dataList = new ArrayList<String>();
		FileReader fr=new FileReader(fileSaveLocation);
		BufferedReader br= new BufferedReader(fr);
		String text="";
		while ((text=br.readLine()) != null)
		{
			if(text.contains(sNewValue))
			{
		System.out.println(text +"\n");
		dataList.add(text);
			/*}else
			{
				//do nothing
			}*/
		}
		br.close();

			
		}
		return dataList;
		}   
	
	
	
}