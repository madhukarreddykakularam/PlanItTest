package com.nbcu.sphere;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.nbcu.sphere.Common.GenericFunctionLibrary;
import com.nbcu.sphere.ConfigManager.FileLocSetter;
import com.nbcu.sphere.ConfigManager.SQLConfig;
import com.nbcu.sphere.ReportManager.Reporter;
import com.nbcu.sphere.UtilManager.DBUtil;
import com.nbcu.sphere.UtilManager.ExcelUtil;
import com.nbcu.sphere.UtilManager.PropUtil;

//public class DriverScript extends TestCaseSpecificClass {
public class TestDriver extends GenericFunctionLibrary{

	String header = null;
	static String sIndexHeader = null;
	public static boolean bLoginFlag = false;
	public static boolean bIpadLoginFlag = false;
	
	public static int iRowId;
	public static int iTotalTestSetRows;
	public static int iMasterRowId;
	public static String sMachine = null;
	public static String sSkillSet = null;
	public static String sAppLink = null; 
	public static String sIpadLink = null; 
	public static String sCorporation = null;
	public static String sOffice = null;
	public static String sUsername = null;
	public static String sPassword = null;
	
	public static String sWorkingDirPath;

	public static String sHtmlLink = null; // sHtmlLink to index file
	public static String sFolderPath = null; // local report folder

	public static String sEnvironment; // IDT5, etc
	public static String sPhase; // Smoke, Regression, SIT
	public static String sModule; // Groups, Items, Flows, Property <-- to be implemented later
	public static String sRelease; // sRelease build: 5.2, 5.3, etc.s
	public static String sApplication; // GPS Europe
	public static String sReportName; //Test Suite Name

	public static int iTC_ID; // keep track of the testID
	public static String sTest_Case_ID; // keep track of the testID
	public static String sTest_Case_Name; // keep track of the tcName
	public static String sTest_Case_Description; // keep track of the test desc
	public static String sIpad_Test;
	public static String sShareResultsFlag;
	
	public static String Production; // Pre_Production or Production
	
	public static ResultSet rset=null;
	public static Statement stmt=null;
	public static Connection conn=null;
	
	public static  HashMap<Integer, HashMap<String, String>> mEnvSheetData=null;
	public static  HashMap<Integer, HashMap<String, String>> mTestSetSheetData=null;
	public static  HashMap<Integer, HashMap<String, String>> mTestPhaseData=null;
	public static  HashMap<Integer, HashMap<String, String>> mStagingCustomerData=null;
	public static  HashMap<Integer, HashMap<String, String>> mStagingDealData=null;
	public static  HashMap<Integer, HashMap<String, String>> mDeptSystemsData=null;
	public static  HashMap<Integer, HashMap<String, String>> mFleetMasterData=null;
	public static  HashMap<Integer, HashMap<String, String>> mCustomerSAPData=null;
	
	public static String sSoapActionUrl;
	public static String sIndexHTMLFileName="";
	
	public static Logger log = Logger.getLogger(TestDriver.class.getName());//
	
	public int tCounter = 0;
	public int tCount = 0;
	
	public String currentTC = null;
	public String stCounter = null;
	public String stCount = null;
	
	
	
	//public JFrame testUI = new JFrame("TestUI");
	public JFrame testUI;
	public JLabel tcIDindicator;
	public JLabel tcCountCurrent;
	public JLabel tcIDProfile;
	public JLabel tcNameProfile;
	JPanel leftP = new JPanel();
	JPanel middleP = new JPanel();
	JPanel rightP = new JPanel();

	public static String sProfileTesting;
	public static String sProfileName;
	public static String sProfileUserName;
	public static String sProfilePassword;
	
	public static ZoneId zoneIdDefault;
	public static FileWriter pw;
	public static BufferedWriter bw;
	public static FileWriter pw1;
	public static BufferedWriter bw1;
	public static FileWriter pw2;
	public static BufferedWriter bw2;
	public static FileWriter pw3;
	public static BufferedWriter bw3;
	public static FileWriter pw4;
	public static BufferedWriter bw4;
	public static String sDeptSystem;
	
	ExcelUtil objExcelUtility = new ExcelUtil();
	public static PropUtil objPropertiesUtility = new PropUtil();
	DBUtil objDBUtility = new DBUtil();
	SQLConfig objSQLConfig = new SQLConfig();
	
	@BeforeMethod
	public void beforeMethod() {
		System.out.println("@BeforeMethod");
		}
		
	@AfterMethod
	public void afterMethod() {
		System.out.println("@AfterMethod");
	}
	
	@BeforeTest
	public void beforeTest() {

		
				///////////////////////////////////////////////////////////////////////////////////
		
		try {			   
			try {
			
				
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddyyyyhhmmss"); 
				String date = simpleDateFormat.format(new Date());
				pw = new FileWriter(System.getProperty("user.dir")+"\\logs\\SphereAutomation_Traceability_Sheet_"+date+".csv", true);
				bw = new BufferedWriter(pw);
				//bw.write("Test Case Id,Test Case Name,Customer Name/Deal Title,Orbit Customer/Deal Number,Operation,Module,Customer Type,Production Type,Customer Address,Customer Tax Id");
				bw.write("Test Case Id,Test Case Name,Customer Name/Deal Title,Orbit Customer/Deal Number,Operation,Module,Customer Type,Address Line 1,Address Line 2,City,State,Country,ZipCode,Credit Status,Credit Expiration,Credit Amount,PO Number,Insurance Status,Insurance Validation,Tax Status,Customer Tax Id,RentalWorks,RTPro,TransWorks,ScheduALL,Cost Center,Deal Type,Deal Credit");
				
				
				pw1 = new FileWriter(System.getProperty("user.dir")+"\\logs\\SphereAutomation_BillingRequestTraceability_Sheet_"+date+".csv", true);
				bw1 = new BufferedWriter(pw1);
				//bw.write("Test Case Id,Test Case Name,Customer Name/Deal Title,Orbit Customer/Deal Number,Operation,Module,Customer Type,Production Type,Customer Address,Customer Tax Id,RentalWorks,RTPro,TransWorks,ScheduALL");
				
				bw1.write("Deal Number,Order Number,Dept Systems Number,Cost Center,sInterfaceCode,sTransactionDate,Transaction Status (From DB),Billing Request Status (From DB),Order Created?,In ARC (Front End)?,In Exception Queue (Front End)?,In Queue Logging (Front End)?");
				
				pw2 = new FileWriter(System.getProperty("user.dir")+"\\logs\\DeptSystem_SphereAutomation_Traceability_Sheet_"+date+".csv", true);
				bw2 = new BufferedWriter(pw2);
				//bw.write("Test Case Id,Test Case Name,Customer Name/Deal Title,Orbit Customer/Deal Number,Operation,Module,Customer Type,Production Type,Customer Address,Customer Tax Id,RentalWorks,RTPro,TransWorks,ScheduALL");
				
				//bw2.write("Test Case Id,Test Case Name,CustomerNumber,Name,CustomerStatus,Type,CustomerAddress1,CustomerAddress2,CustomerCity,CustomerState,CustomerZip,CustomerCountry,CustomerPhoneNo,CreditStatus,Through,Amount,DealNumber,Dealname,Dealtype,Address1,Address2,Status,City,State,Zip,Country,MainPhone,Status,CreditThrough,Certification,ValidThrough,TaxStatus,Department,PoNumber");		
				//bw2.write("Test Case Id,Test Case Name,CustomerNumber,Name,ManagingDept,Code,CustomerStatus,Type,CustomerAddress1,CustomerAddress2,CustomerCity,CustomerState,CustomerZip,CustomerCountry,CustomerPhoneNo,CreditStatus,Through,Amount,Certification,ValidThrough,TaxStatus,DealNumber,Dealname,Dealtype,Address1,Address2,Status,City,State,Zip,Country,MainPhone,Status,CreditThrough,Deal Credit Limit,Certification,ValidThrough,TaxStatus,Department,Code,PoNumber");
				bw2.write("CustomerNumber,Name,ManagingDept,Code,Office Location,CustomerStatus,Type,CustomerAddress1,CustomerAddress2,CustomerCity,CustomerState,CustomerZip,CustomerCountry,CustomerPhoneNo,Use Customer,CustomerAddress1,CustomerAddress2,CustomerCity,CustomerState,CustomerZip,CustomerCountry,CreditStatus,Through,Amount,Certification,ValidThrough,TaxStatus,DealNumber,Dealname,ParentNumber,Office Location,Dealtype,Address1,Address2,Status,City,State,Zip,Country,MainPhone,Billing Cycle,Pay Type,Status,CreditThrough,Deal Credit Limit,Certification,ValidThrough,TaxStatus,Tax Type,Department,Code,PoNumber,Type,Account,Cost Object,UPayType,PaymentType,Contact");
				pw3 = new FileWriter(System.getProperty("user.dir")+"\\logs\\SphereAutomation_FleetMasterTraceability_Sheet_"+date+".csv", true);
				bw3 = new BufferedWriter(pw3);
				//bw.write("Test Case Id,Test Case Name,Customer Name/Deal Title,Orbit Customer/Deal Number,Operation,Module,Customer Type,Production Type,Customer Address,Customer Tax Id,RentalWorks,RTPro,TransWorks,ScheduALL");
				
				bw3.write("Test Case Id,Test Case Name,Deal Number,Status,Result");
				
				pw4 = new FileWriter(System.getProperty("user.dir")+"\\logs\\SphereAutomation_CustomerMasterTraceability_Sheet_"+date+".csv", true);
				bw4 = new BufferedWriter(pw4);
				//bw.write("Test Case Id,Test Case Name,Customer Name/Deal Title,Orbit Customer/Deal Number,Operation,Module,Customer Type,Production Type,Customer Address,Customer Tax Id,RentalWorks,RTPro,TransWorks,ScheduALL");
				bw4.write("Test Case Id,Test Case Name,Customer Number,Status,Result");
				
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			zoneIdDefault = ZoneId.systemDefault();
			String sFormattedDate = fnDateFormatter("4/7/16 1:24 PM","MM/dd/yy hh:mm a");
			System.out.println("Date Formatter Check>>>"+sFormattedDate);
					
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		System.out.println("@BeforeTest");
		
		try {
	//		ExecuteCommand("C:\\Automation\\killprocess.bat");
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		prop = objPropertiesUtility.fnLoadObjects(FileLocSetter.sConfigPath, "global.properties");
	    		
	}

	@AfterTest
	public void afterTest() {
		System.out.println("@AfterTest");
		if (driver != null)
			driver.quit();		
		try {
			if(bw != null)
			bw.close();
			
			if(bw1 != null)
				bw1.close();
			if(bw2 != null)
				bw2.close();
			if(bw3 != null)
				bw3.close();
			if(bw4 != null)
				bw4.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void createTestUI() {
		/*JPanel leftP = new JPanel();
		JPanel rightP = new JPanel();*/
		testUI = new JFrame("TestUI");
		stCounter = "Completed " + String.valueOf(tCounter) + "out of ";
		stCount = String.valueOf(tCount) + " tests.";
		if(currentTC == null)
		{
			currentTC = "Login";
		}
	/*	tcIDindicator = new JLabel("Current Test Case: " + currentTC);
		tcCountCurrent = new JLabel("Working..." + "        Located " + stCount);
		
		leftP.add(tcIDindicator);
		rightP.add(tcCountCurrent);
		
		GridLayout tuLayout = new GridLayout(3,1);
		testUI.setLayout(tuLayout);
		testUI.add(leftP);
		testUI.add(rightP);
		testUI.setSize(350, 350);
		testUI.pack();
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	    GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
	    Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
	    int x = (int) rect.getMaxX() - testUI.getWidth();
	    int y = 0;
	    testUI.setLocation(x, y);
		testUI.setVisible(true);
		testUI.setAlwaysOnTop(true);*/
		
		tcIDindicator = new JLabel("Current Test Case: " + currentTC);
		//sProfileName
		tcIDProfile = new JLabel("Current Profile: " + sProfileName.replace("_", " "));
		tcCountCurrent = new JLabel("Working..." + "        Located " + stCount);
		
		leftP.add(tcIDindicator);
		middleP.add(tcIDProfile);
		rightP.add(tcCountCurrent);
		
		GridLayout tuLayout = new GridLayout(3,1);
		testUI.setLayout(tuLayout);
		testUI.add(leftP);
		testUI.add(middleP);
		testUI.add(rightP);
		testUI.setSize(350, 350);
		testUI.pack();
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	    GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
	    Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
	    int x = (int) rect.getMaxX() - testUI.getWidth();
	    int y = 0;
	    testUI.setLocation(x, y);
		testUI.setVisible(true);
		testUI.setAlwaysOnTop(true);
		
	}
	
	private void updateTestUICount() {
		tCounter++;
		stCounter = "Completed " + String.valueOf(tCounter) + " out of ";
		stCount = String.valueOf(tCount) + " tests.";
		tcCountCurrent.setText(stCounter + stCount);
	}
	
	public void updateTestUICurrent() {
		tcIDindicator.setText("Current Test Case: " + currentTC);
		testUI.repaint();
	}
	
	public void testUIcontrol(){
		updateTestUICount();
		testUI.repaint();
	}

// ============================================================ DRIVER SCRIPT ============================================================

	@Test
	public void run() throws Exception {

		try {
			//String sWorkingDir = System.getProperty("user.dir");	
			//sWorkingDirPath=sWorkingDir;
			String sPackageClass = "";
			sPackageClass = this.getClass().getPackage().getName();
			System.out.println(sPackageClass);
			DOMConfigurator.configure(FileLocSetter.sConfigPath+"log4j.xml");
				
			//SimpleDateFormat logFileDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			//System.setProperty("current.date", logFileDateFormat.format(new Date()));
			log.info("------------------Test Execution Started--------------------\n\n");
			
			//mEnvSheetData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"Environment", "");
			////////////////////////////
				
			
			sPhase = prop.getProperty("phase").toString().trim();  
			
			System.out.println("In Jenkins phase1 >>>>>>"+System.getenv("phase"));
			sPhase = System.getenv("phase");
			if(sPhase==null)
			{
				sPhase = prop.getProperty("phase").toString().trim();  //(Smoke/MiniRegression/Regression/Role)
			}
			
			
			//sPhase = prop.getProperty("testSuite").toString().trim();
			if(sPhase.equalsIgnoreCase("Role"))
			{
				mEnvSheetData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"Environment_"+sPhase, "");
			}
			else
			{
				mEnvSheetData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"Environment", "");
			}
			///////////////////////////	
				
			
			
			Integer iLoginAttempt = Integer.valueOf(prop.getProperty("loginAttempt").toString().trim());
			
			
			for (int masterRow = 1; masterRow <= mEnvSheetData.size(); masterRow++) 
			{	
				//iMasterRowId = Integer.toString(masterRow);
				iMasterRowId = masterRow;
				sShareResultsFlag = mEnvSheetData.get(masterRow).get("ShareResults").toString();  //Share results on shared server/drop box
						
				if(mEnvSheetData.get(masterRow).get("Execution_Flag").equalsIgnoreCase("Y")) 
				{
					sIpad_Test = "N";
					//fnSetBrowserCapabilities();
					sEnvironment = mEnvSheetData.get(masterRow).get("Environment");
					sApplication = mEnvSheetData.get(masterRow).get("Application");
					//sPhase = mEnvSheetData.get(masterRow).get("Phase");
					
					sRelease = mEnvSheetData.get(masterRow).get("Release");
					sReportName = mEnvSheetData.get(masterRow).get("ReportName");
					
					if(System.getenv("phase")!=null && sPhase.equalsIgnoreCase("Smoke") && System.getenv("appLink")!=null)
					{
						sAppLink = System.getenv("appLink").toString().trim();
					}
					else
					{
						sAppLink=mEnvSheetData.get(masterRow).get("AppLink").toString().trim();
					}
					
					sProfileTesting=mEnvSheetData.get(masterRow).get("Profile_Testing").toString().trim();
					sProfileName=mEnvSheetData.get(masterRow).get("Profile_Name").toString().trim();
					sProfileUserName=mEnvSheetData.get(masterRow).get("Username").toString().trim();
					sProfilePassword=mEnvSheetData.get(masterRow).get("Password").toString().trim();
					
				
					sIndexHeader = Reporter.repGenerateIndexHeader(sEnvironment, sApplication, sPhase);
					//mTestSetSheetData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"TestSet",""); //Get TestSet hash map
					mTestSetSheetData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"TestSet_"+sProfileName,""); //Get TestSet hash map
					//mTestPhaseData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,sPhase, "Test_Case_ID");    //Get Smoke/SIT/Regression hash map
					
					if(sPhase.equalsIgnoreCase("Role"))
					{
						mTestPhaseData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"TestData_"+sPhase, "Test_Case_ID");    //Test Data same for all, Get Smoke/SIT/Regression hash map
					}
					else if(sPhase.equalsIgnoreCase("MiniRegression"))
						//else if(sPhase.equalsIgnoreCase("Internal"))
					{
						mTestPhaseData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"TestData_Mini", "Test_Case_ID");    //Test Data same for all, Get Smoke/SIT/Regression hash map
					}
					else
					{
						mTestPhaseData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"TestData", "Test_Case_ID");    //Test Data same for all, Get Smoke/SIT/Regression hash map
					}
				
					//System.out.println("Test data size : "+mTestPhaseData.size());
					//System.out.println(mTestPhaseData.get(157).get("Country").toString());
					//System.out.println(mTestPhaseData.get(157).toString());
					//System.out.println(mTestPhaseData.get(1508).get("Cost_Center").toString());
					//System.out.println(mTestPhaseData.get(1508).toString());
					mStagingCustomerData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"Stage_Customers", "ROWID");    
					mStagingDealData = objExcelUtility.fnGetExcelData(FileLocSetter.sTestDataPath+ FileLocSetter.sFileName,"Stage_Deals", "ROWID");    
					    
					
								
					/*sUsername = prop.getProperty("sso").toString().trim();
					sPassword = prop.getProperty("password").toString().trim();*/
					
					if(!sProfileTesting.equalsIgnoreCase("Y"))
					{
						sUsername = prop.getProperty("sso").toString().trim();
						sPassword = prop.getProperty("password").toString().trim();
					}
					else
					{
						System.out.println("In profile test loop");
						sUsername = sProfileUserName;
						sPassword = sProfilePassword;
					}

					/////////////////////////////////////////////
					//for (int iTCRow = 1; iTCRow <=mTestSetSheetData.size(); iTCRow++)
					for (int iTCRow = 1; iTCRow <=iTotalTestSetRows; iTCRow++)
					{
						if(mTestSetSheetData.containsKey(iTCRow))
						{
							if( mTestSetSheetData.get(iTCRow).get(sPhase).equalsIgnoreCase("Y"))  //Test case check
							{
								tCount++;
							}
						}
					}
					
					
					createTestUI();
					Boolean bLoginAttempt = false;
					//Iterates through hashes and runs all flagged tests
					for (int iTCRow = 1; iTCRow <=iTotalTestSetRows; iTCRow++)
					{
						//RowId = Integer.toString(iTCRow);
						iRowId=iTCRow;
						
						//sUsername= mEnvSheetData.get(masterRow).get("Username").toString().trim();
						//sPassword= mEnvSheetData.get(masterRow).get("Password").toString().trim();
						
						if(mTestSetSheetData.containsKey(iTCRow))
						{
						
							sTest_Case_ID = mTestSetSheetData.get(iTCRow).get("Test_Case_ID");
							iTC_ID = Integer.parseInt(sTest_Case_ID);
							sModule = mTestSetSheetData.get(iTCRow).get("Module");
							
							
							if( mTestSetSheetData.get(iTCRow).get(sPhase).equalsIgnoreCase("Y"))  //Test case check
							{	
							   sIndexHTMLFileName="index.html";   //in case data is missing for a test case, index.html would be default index file, else will be overridden as below 
							   try {
										if(mTestPhaseData.get(iTC_ID)!=null)
										{
											sIndexHTMLFileName = "index_"+InetAddress.getLocalHost().getHostName()+".html";
											//Overriding with specific user id/password if any, else use credential from master sheet
											if(!mTestPhaseData.get(iTC_ID).get("Username").equalsIgnoreCase("") && !mTestPhaseData.get(iTC_ID).get("Password").equalsIgnoreCase(""))
											{
												 sUsername= mTestPhaseData.get(iTC_ID).get("Username").toString().trim();
												 sPassword= mTestPhaseData.get(iTC_ID).get("Password").toString().trim();
											}
										 }
										 else
										 {
											log.info("Test case warning for Test Case ID"+sTest_Case_ID+". Function or Data missing...");
										 }
									} catch (Exception e) {
										
										//log.error("Test case failed for Test Case ID"+sTest_Case_ID+". Data missing or Web service failure ",e);
									}	
						
									try 
									{
										sTest_Case_Name = mTestSetSheetData.get(iTCRow).get("Test_Case_Name");
										sTest_Case_Description = mTestSetSheetData.get(iTCRow).get("Test_Case_Description");
																				
										currentTC = mTestSetSheetData.get(iTCRow).get("FunctionName");
										
										header = Reporter.repGenerateHeader(sReportName, sTest_Case_Name, sApplication, sTest_Case_Description);
										fnInitializeGlobalVariables();
										
										if (bLoginFlag==false && bLoginAttempt == false)
										{
											//bLoginFlag = fnSphereLogIn(sAppLink,sUsername, sPassword);
											for(int i=0; i<iLoginAttempt;i++)
											{
												if(bLoginFlag==false)
												{   
													log.info("Login Attempt : "+ (i+1));
													bLoginAttempt = true;// Just to avoid login foe every test case
													fnSetBrowserCapabilities();
											    	updateTestUICurrent();
											    	//fnExecuteFunction(sPackageClass+ "."+sModule, "TC1"); //Remove after test
													
											    	fnExecuteFunction(sPackageClass+ "."+sModule, "TC18"); //Login function for Sphere program
											    	
													testUIcontrol();
													if(bLoginFlag==false && driver !=null)
													{
														driver.quit();
													}
												}
											}
										}
										else if(bLoginFlag==true  || bLoginAttempt == true)
										{
											//currentTC = mTestSetSheetData.get(iTCRow).get("FunctionName");
											updateTestUICurrent();
											fnExecuteFunction(sPackageClass+ "."+sModule, currentTC);
											testUIcontrol();
										}
																					
										obj.repGenerateResult(sTest_Case_Name, header);
										obj.repGenerateIndexReport(sIndexHeader);
										header = null;   
										
										
									} catch (Exception e) 
									{
										System.out.println("@@@ Exception in executeTest @@@");
										System.out.println(e);
										
									}
								
							}
						}
						else
						{
							//System.out.println("No Test Case present at row : " + iTCRow);
							//log.info("No Test Case present at row : " + iTCRow);
						}
						
					} //End Test case loop
					
						try {
							if (driver!=null)
							{
								bLoginFlag=false; //Added to handle profile testing
								fnSignOut();
								//driver.quit();
								//driver=null;
							}	
							fnResetJFrame();
							tCount = 0;
							tCounter = 0;
							currentTC = null;
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						finally
						{
							log.info("------------------Test Execution Completed------------------\n\n");
							System.out.println("Local HTML report folder: " + sFolderPath);
							System.out.println("Local HTML report index: " + sFolderPath + "\\" + sIndexHTMLFileName);
							if(sShareResultsFlag.equalsIgnoreCase("Y"))
							{
								obj.createTestResultsWithTimestamp(sFolderPath);
							}
							//obj.fnWriteResultsToATMDB(sHtmlLink);
							
							///////Changes made to make a build UNSTABLE////////
							//SoftAssert softAssertion= new SoftAssert();
							if(Reporter.iTotalFail>0)
							{
								System.out.println("Test Suite Failed");
								//softAssertion.assertEquals(Reporter.iTotalFail, 0, "Total : "+Reporter.iTotalFail+ " Failed");
							}
							//softAssertion.assertAll();
							System.out.println("Total Test Cases Executed : "+Reporter.iTotalExecuted);
							System.out.println("Total Test Cases Passed : "+Reporter.iTotalPass);
							System.out.println("Total Test Cases Failed : "+Reporter.iTotalFail);
							////////////////////////////////////////////////
							Reporter.openHTMLreport();
							Reporter.iSlNo = 0;
							Reporter.iTotalExecuted = 0;
							Reporter.iTotalPass = 0;
							Reporter.iTotalFail = 0;
							
						}
				}
			} // End of Suite/Master sheet loop

			
		} catch (Exception e) {
			if (driver!=null)
			{
				fnSignOut();
			}
			System.out.println(e);
		}

		finally {
			obj = null;
		}

	}


// ============================================================ DRIVER SCRIPT ============================================================
	
	//Reset JFrame
			public void fnResetJFrame() throws Exception
			 {
				try {

						leftP.removeAll();
						leftP.revalidate();
						leftP.repaint();
						
						middleP.removeAll();
						middleP.revalidate();
						middleP.repaint();
						
						rightP.removeAll();
						rightP.revalidate();
						rightP.repaint();						
						
						testUI.getContentPane().removeAll();
						testUI.revalidate();
						testUI.repaint();
						
						testUI.dispatchEvent(new WindowEvent(testUI, WindowEvent.WINDOW_CLOSING));
						testUI.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
						testUI.dispose();
						
						testUI = null;

				} catch (Exception e) 
				{
					System.out.println("fnResetJFrame-----failed");
					throw(e);
				}	
			}


} // end of Test
