package com.nbcu.sphere;

public class ObjRepository {
	public static final String HomePageLogin="//a[contains(text(),'Log in')]";
	public static final String LoginPage_WelcomeMessage="//h1[contains(text(),'Welcome, Please Sign In!')]";
	public static final String LoginPage_MailId="//input[@id='Email']";
	public static final String LoginPage_Password="//input[@id='Password']";
	public static final String LoginPage_LoginButton="//input[@value='Log in']";
	public static final String HomePage_LoggedInUserName="//a[contains(text(),'testdemowebshop@gmail.com')]";
	public static final String HomePage_Categories_Books="(//a[contains(text(),'Books')])[3]";
	public static final String Books_HealthBook="//a[contains(text(),'Health Book')]";
	public static final String Books_HealthBook_Price="//span[@itemprop='price']";
	public static final String Books_HealthBook_Quantity="//input[@id='addtocart_22_EnteredQuantity']";
	public static final String AddToCart="(//input[@value='Add to cart'])[1]";
	public static final String AddToCart_SuccessfullyAdded="//p[contains(text(),'The product has been added to your ')]";
	public static final String HomePage_ShoppingCart_Button="//span[contains(text(),'Shopping cart')]";
	public static final String HomePage_ShoppingCart_SubTotal="(//span[@class='product-price'])[1]";
	public static final String ShoppingCart_Checkout="//button[@id='checkout']";
	public static final String ShoppingCart_RemoveFromCart="//input[@name='removefromcart']";
	public static final String ShoppingCart_Qty="//span[contains(text(),'Qty.:')]/../input";
	public static final String ShoppingCart_UpdtaeShoppingCart="//input[@value='Update shopping cart']";
	public static final String DemoWorkShop="//img[@alt='Tricentis Demo Web Shop']";
	public static final String TermsofService="//input[@id='termsofservice']";
	public static final String BillingAddress="//select[@id='billing-address-select']";
	public static final String BillingAddress_Continue="(//input[@title='Continue'])[1]";
	public static final String ShippingAddress_Continue="(//input[@title='Continue'])[2]";
	public static final String ShippingAddress="//select[@id='shipping-address-select']";
	public static final String NextDayAir="//label[contains(text(),'Next Day Air')]";
	public static final String ShippingMethod_Continue="(//input[@value='Continue'])[3]";
	public static final String CashOnDelivery="//label[contains(text(),'Cash On Delivery (COD) (7.00)')]";
	public static final String PaymentMethod_Continue="(//input[@value='Continue'])[4]";
	public static final String PaymentMethod_COD_Method="//p[contains(text(),'You will pay by COD')]";
	public static final String PaymentInfo_Continue="(//input[@value='Continue'])[5]";
	public static final String ConfirmOrder="//input[@value='Confirm']";
	public static final String OrderPlaces_SuccessMessage="//strong[contains(text(),'Your order has been successfully processed!')]";
	public static final String OrderNumber="(//strong[contains(text(),'Your order has been successfully processed!')]/../../ul/li)[1]";
	public static final String Continue_Button="//input[@value='Continue']";
	public static final String LogOut_Button="//a[contains(text(),'Log out')]";
	public static final String ShoppingCartEmptyMessage="//div[contains(text(),'Your Shopping Cart is empty!')]";
	public static final String BillingAddress_FirstName="//input[@id='BillingNewAddress_FirstName']";
	public static final String BillingAddress_LastName="//input[@id='BillingNewAddress_LastName']";
	public static final String BillingAddress_Email="//input[@id='BillingNewAddress_Email']";
	public static final String BillingAddress_Country="//select[@id='BillingNewAddress_CountryId']";
	public static final String BillingAddress_City="//input[@id='BillingNewAddress_City']";
	public static final String BillingAddress_Address="//input[@id='BillingNewAddress_Address1']";
	public static final String BillingAddress_PostalCode="//input[@id='BillingNewAddress_ZipPostalCode']";
	public static final String BillingAddress_PhoneNumber="//input[@id='BillingNewAddress_PhoneNumber']";
	
	
	
	
}
