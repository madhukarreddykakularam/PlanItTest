package moduleDrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.log;
import static cbf.engine.TestResultLogger.passed;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import cbf.engine.TestResult.ResultType;
import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

public class GeneralDriver extends BaseWebModuleDriver {

	
	/****************************************
	 * Name: launchApp
	 * Description: launch application
	 * Date: 18-Oct-2017
	 * @throws IOException 
	 ****************************************/
	
	public void launchApp(DataRow input, DataRow output) throws IOException {
		
		
		uiDriver.launchApplication(input.get("url"));
		SleepUtils.sleep(TimeSlab.HIGH);
		
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Launching the Application", "Should Launch the Application", "Application Launched sucessfully!");
		} else {
			failed("Launching the Application", "Should Launch the Application", "Error in Launching the Application");
		}

	}

	/****************************************
	 * Name: login
	 * Description: login into the application
	 * Date: 18-Oct-2017
	 ****************************************/
	
	public void login(DataRow input, DataRow output)
	{
		/*String FN = input.get("Firstname");
		String LN = input.get("Lastname");
		uiDriver.click("WBtn_SubmitBtn");
		SleepUtils.sleep(TimeSlab.MEDIUM);*/
		uiDriver.setValue("WElement_UserName", input.get("username"));
		//SleepUtils.sleep(TimeSlab.LOW);
		SleepUtils.sleep(6);
		uiDriver.click("WElement_Password");
		SleepUtils.sleep(3);
		uiDriver.setValue("WElement_Password", input.get("password"));
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(3);
		uiDriver.click("WElement_SignInButton");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(12);
//		if (uiDriver.checkElementPresent("WElement_WelcomeMessage"))
//		{
//			passed("Login to Application", "Should loginto the Application", "Successfully logged into the application");
//		} 
//		else
//		{
//			log("Login to the Application", ResultType.FAILED, "Should loginto the Application",
//					"Error in logging into the Application", true);
//		}
		/*output.put("FirstName", FN);
		output.put("LastName", LN);*/
		
	}

	/****************************************
	 * Name: logout
	 * Description: logout of the application
	 * Date: 18-Oct-2017
	 ****************************************/
	
	public void logout(DataRow input, DataRow output)
	{
	
		uiDriver.click("WElement_SignOut");
		if(uiDriver.checkElementPresent("WElement_SignInButton")){
			
			passed("Logout of the Application", "Should logout of the Application", "Successfully logged out from the application");
		} 
		else
		{
			log("Logout to the Application", ResultType.FAILED, "Should log out from the Application",
					"Error in logging out of the Application", true);
		}
	}	
	
	
	
	
	/****************************************
	 * Name: CloseBrowser
	 * Description: Closing the Browser
	 * Date: 18-Oct-2017
	 ****************************************/
	
	public void CloseBrowser(DataRow input, DataRow output){
		uiDriver.closeBrowsers();
		
	}	
	
	
	/**
	 * Overriding toString() method of object class to print FlightBookingDriver
	 * format string
	 */
	public String toString() {
		return "GeneralDriver()";
	}

	

	/****************************************
	 * Name: login
	 * Description: login into the application
	 * Date: 18-Oct-2017
	 ****************************************/
	
	public void loginTelemundo(DataRow input, DataRow output)
	{
		
		uiDriver.setValue("Telemundo_LoginUsername", input.get("username"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("Telemundo_LoginPassword", input.get("password"));
		SleepUtils.sleep(2);
		uiDriver.click("Telemundo_LoginButton");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(12);

	}
	public void loginTelemundo1111(DataRow input, DataRow output)
	{
		
		uiDriver.setValue("Telemundo_Username", input.get("username"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("Telemundo_Password", input.get("password"));
		SleepUtils.sleep(2);
		uiDriver.click("Telemundo_Login");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(12);

	}
	/****************************************
	 * Name: login
	 * Description: login into the application
	 * Date: 18-Oct-2017
	 ****************************************/
	
	public void LoginStorm(DataRow input, DataRow output)
	{
		/*String FN = input.get("Firstname");
		String LN = input.get("Lastname");
		uiDriver.click("WBtn_SubmitBtn");
		SleepUtils.sleep(TimeSlab.MEDIUM);*/
		uiDriver.setValue("WElement_Storm_UserName", input.get("username"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("WElement_Storm_Password", input.get("password"));
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(12);
		uiDriver.click("WElement_Storm_SignIn");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		
//		if (uiDriver.checkElementPresent("WElement_WelcomeMessage"))
//		{
//			passed("Login to Application", "Should loginto the Application", "Successfully logged into the application");
//		} 
//		else
//		{
//			log("Login to the Application", ResultType.FAILED, "Should loginto the Application",
//					"Error in logging into the Application", true);
//		}
		/*output.put("FirstName", FN);
		output.put("LastName", LN);*/
	}
	public void Spherelogin(DataRow input, DataRow output)
	{
		/*String FN = input.get("Firstname");
		String LN = input.get("Lastname");
		uiDriver.click("WBtn_SubmitBtn");
		SleepUtils.sleep(TimeSlab.MEDIUM);*/
		uiDriver.setValue("Sphere_LogIn_Username", input.get("username"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("Sphere_LogIn_Password", input.get("password"));
		//SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(2);
		uiDriver.click("Sphere_LogIn_SignInButton");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(5);
		if (uiDriver.checkElementPresent("Sphere_DashBoardHeading"))
		{
			passed("Login to Application", "Should loginto the Application", "Successfully logged into the application");
		} 
		else
		{
			log("Login to the Application", ResultType.FAILED, "Should loginto the Application",
					"Error in logging into the Application", true);
		}
		/*output.put("FirstName", FN);
		output.put("LastName", LN);*/
	}
}
