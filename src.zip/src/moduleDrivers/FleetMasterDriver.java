package moduleDrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.passed;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbfx.basedrivers.BaseWebModuleDriver;
//import com.sun.java.swing.plaf.windows.TMSchema.Part;
//need 
//import org.jboss.util.Base64;


public class FleetMasterDriver extends BaseWebModuleDriver {
	
	//private static final String DateUtils = null;
	OutlookReader_imap obje = new OutlookReader_imap();
	
	/****************************************
	 * Name: NavigateToCustomer
	 * Description: NavigateToCustomer
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToCustomer(DataRow input, DataRow output) throws InterruptedException {
		
		uiDriver.click("WSubMenu_Customers");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_CustomersPage"))
		{
			passed("Customers page", "Should display Customers Page", "Customers Page displayed successfully");
		} 
		else
		{
			failed("Customers page", "Should display Customers Page", "Customers Page is not displayed");
		}
	}
	
	/****************************************
	 * Name: NavigateToInvoicing
	 * Description: NavigateToInvoicing
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToInvoicing(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(8);
		uiDriver.click("WSubMenu_Invoicing");
		SleepUtils.sleep(8);
		uiDriver.click("WSubMenu_Deals");
		SleepUtils.sleep(8);
		uiDriver.click("WSubMenu_Invoicing");
		SleepUtils.sleep(25);
			passed("Invoices page", "Should display Invoices Page", "Invoices Page displayed successfully");
			
			String InvoiceNumber = uiDriver.getValue("WSubMenu_Invoices_FirstTransaction");
			output.put("InvoiceNumber", InvoiceNumber);
			{
				passed("Invoice Number", "Invoice Number should be displayed", "Invoice Number is displayed as "+InvoiceNumber+" ");
			} 
			
	}
	
	/****************************************
	 * Name: NavigateToDeal
	 * Description: NavigateToDeal
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToDeal(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(15);	
		uiDriver.click("WSubMenu_Deals");
		SleepUtils.sleep(15);
		uiDriver.click("WSubMenu_Deals");
		SleepUtils.sleep(15);
		/*if(uiDriver.checkElementPresent("WElement_DealPage"))
		{
			passed("Deal page", "Should display Deal Page", "Deal Page displayed successfully");
		} 
		else
		{
			failed("Deal page", "Should displaye Deal Page", "Deal Page is not displayed");
		}*/
	}
	
	/****************************************
	 * Name: NavigateToPlanningDailyPlanningTab
	 * Description: NavigateToPlanningDailyPlanningTab
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToPlanningDailyPlanningTab(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(4);
		uiDriver.click("WElement_PlanningPage_DailyPlanningSubTab");
		SleepUtils.sleep(4);
			passed("Daily Planning page", "Should displaye Daily Planning Page", "Daily Planning Page is not displayed");
	}
	
	/****************************************
	 * Name: NavigateToPlanningScheduleBillingTab
	 * Description: NavigateToPlanningScheduleBillingTab
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToPlanningScheduleBillingTab(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WElement_PlanningPage_ScheduleBillingSubTab");
		SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("WElement_Planning_ScheduledBilling_Add"))
		{
			passed("Set up scheduled billing and Add Button", "Set up scheduled billing and Add Button should be displayed", "Set up scheduled billing and Add Button is displayed");
		} 
		else
		{
			failed("Set up scheduled billing and Add Button", "Set up scheduled billing and Add Button should be displayed", "Set up scheduled billing and Add Button is not displayed");
		}
		
	}
	
	/****************************************
	 * Name: NavigateToPlanning
	 * Description: NavigateToPlanning
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToPlanning(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WSubMenu_Planning");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_PlanningPage"))
		{
			passed("Planning page", "Should display Planning Page", "Planning Page displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye Planning Page", "Planning Page is not displayed");
		}
			
		if(uiDriver.checkElementPresent("WElement_PlanningPage_PlanningTab"))
		{
			passed("Planning page", "Should display Planning Tab", "Planning Tab displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye Planning Tab", "Planning Tab is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningPage_ListTab"))
		{
			passed("Planning page", "Should display List Tab", "List Tab displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye List Tab", "List Tab is not displayed");
		}
	}
	
	/****************************************
	 * Name: ClickOnFuelCards
	 * Description: ClickOnFuelCards
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnFuelCards(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(2);
		uiDriver.click("WSubMenu_EditDeals_FuelCards");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_EditDeal_FuelCardPage"))
		{
			passed("Fuel Card page", "Fuel Card page should be displayed", "Fuel Card page is displayed successfully");
		} 
		else
		{
			failed("Fuel Card page", "Fuel Card page should be displayed", "Fuel Card page is not displayed successfully");
		}
	}
	
	/****************************************
	 * Name: ClickOnDocuments
	 * Description: ClickOnDocuments
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnDocuments(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WSubMenu_EditDeals_Documents");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_EditDeal_DocumentsPage"))
		{
			passed("Documents page", "Documents page should be displayed", "Documents page is displayed successfully");
		} 
		else
		{
			failed("Documents page", "Documents page should be displayed", "Documents page is not displayed successfully");
		}
	}
	
	/****************************************
	 * Name: ClickOnPlanningHistory
	 * Description: ClickOnPlanningHistory
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnPlanningHistory(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WSubMenu_EditDeals_PlanningHistory");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_EditDeal_PlanningHistoryPage"))
		{
			passed("Planning History page", "Planning History page should be displayed", "Planning History page is displayed successfully");
		} 
		else
		{
			failed("Planning History page", "Planning History page should be displayed", "Planning History page is not displayed successfully");
		}
	}
	
	/****************************************
	 * Name: ClickOnListSubTab
	 * Description: ClickOnListSubTab
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnListSubTab(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WElement_PlanningPage_ListTab");
		SleepUtils.sleep(5);
		/*	if(uiDriver.checkElementPresent("WElement_EditDeal_PlanningHistoryPage"))
		{
			passed("Planning History page", "Planning History page should be displayed", "Planning History page is displayed successfully");
		} 
		else
		{
			failed("Planning History page", "Planning History page should be displayed", "Planning History page is not displayed successfully");
		}*/
	}
	
	
	/****************************************
	 * Name: ClickOnAddPlanningList
	 * Description: ClickOnAddPlanningList
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnAddPlanningList(DataRow input, DataRow output) throws InterruptedException {
		Thread.sleep(4000);
		uiDriver.click("WElement_AddPlanningList");
		SleepUtils.sleep(10);
		if(uiDriver.checkElementPresent("WElement_EditPlanning_PlanningLisAddPage"))
		{
			passed("Planning List page", "Planning List page should be displayed", "Planning List page is displayed successfully");
		} 
		else
		{
			failed("Planning List page", "Planning List page should be displayed", "Planning List page is not displayed successfully");
		}
	}
	
	/****************************************
	 * Name: ClickOnPlanningCalender
	 * Description: ClickOnPlanningCalender
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnPlanningCalender(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WSubMenu_EditDeals_PlanningCalender");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_EditDeal_PlanningCalenderPage"))
		{
			passed("Planning Calender page", "Planning Calender page should be displayed", "Planning Calender page is displayed successfully");
		} 
		else
		{
			failed("Planning Calender page", "Planning Calender page should be displayed", "Planning Calender page is not displayed successfully");
		}
	}
	
	/****************************************
	 * Name: ClickOnPlanningPage_OK_Btn
	 * Description: ClickOnPlanningPage_OK_Btn
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnPlanningPage_OK_Btn(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(4);
		uiDriver.click("WBtn_Planning_OK_Btn");
			passed("Ok Button", "Ok Button should be Clicked", "Ok Button is Clicked");
			SleepUtils.sleep(10);
		 uiDriver.click("WElement_createdPlanning");
		 	passed("planning", "Newly Created planning should be opened", "Newly Created planning is opened");
		 	SleepUtils.sleep(6);
		 String planningNumber = uiDriver.getValue("WElement_EditRentalPage_VehicleDriverHistoryNumber");
			output.put("planningNumber", planningNumber);
		 uiDriver.click("WElement_PushEntireContractToInvoiceProposal");
		 	Alert alert = uiDriver.webDr.switchTo().alert();
			alert.accept();
		 passed("Ok Button", "Ok Button should be Clicked", "Ok Button is Clicked");
	}
	/****************************************
	 * Name: ClickOnAdditionalSphereInformation
	 * Description: ClickOnAdditionalSphereInformation
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnAdditionalSphereInformation(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(2);
		uiDriver.click("WSubMenu_EditDeals_AdditionalSphereInformation");
		SleepUtils.sleep(4);
			passed("Additional Sphere Information page", "Additional Sphere Information page should be displayed", "Additional Sphere Information page is displayed successfully");
	}
	
	/****************************************
	 * Name: SearchCustomer
	 * Description: SearchCustomer
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void SearchCustomer(DataRow input, DataRow output) throws InterruptedException {
		
		
		uiDriver.setValue("WElement_CustomersSearchBox", input.get("CustomerNumber"));
		SleepUtils.sleep(4);
			passed("Customer Number", "Customer Number should be entered in Search Box", "Customer Number is entered in Search Box");
		
	}
	
	/****************************************
	 * Name: VerifyCustomerGridHeaders
	 * Description: VerifyCustomerGridHeaders
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyCustomerGridHeaders(DataRow input, DataRow output) throws InterruptedException {
		
	
		List<WebElement> CustomerList = uiDriver.webDr.findElements(By.xpath("//thead[@class='k-grid-header']/tr/th"));
		String actualheader = input.get("GridHeaders");
		String header[] = actualheader.split(",");
		//for(WebElement cuslist :CustomerList)
		for(int i=0;i<5;i++)
		{
			WebElement actualCustomer = CustomerList.get(i+1);
		    String actcus = actualCustomer.getText();
		    if(actcus.equalsIgnoreCase(header[i]))
		    {
		    	
					passed("Customers page grid headers", ""+header[i]+" should be displayed", ""+actcus+" is displayed");
		    }
			else
			{
				failed("Customers page grid headers", ""+header[i]+" should be displayed", ""+actcus+" is not displayed");
			}
		  }
		
		if(uiDriver.checkElementPresent("WElement_CustomersPage_MailIcon"))
		{
			passed("Customers page", "Mail icon should be displayed on Customers Page", "Mail icon is displayed on Customers Page");
		} 
		else
		{
			failed("Customers page", "Mail icon should be displayed on Customers Page", "Mail icon is displayed on Customers Page");
		}
		
		if(uiDriver.checkElementPresent("WElement_CustomersPage_GraphIcon"))
		{
			passed("Customers page", "Graph icon should be displayed on Customers Page", "Graph icon is displayed on Customers Page");
		} 
		else
		{
			failed("Customers page", "Graph icon should be displayed on Customers Page", "Graph icon is displayed on Customers Page");
		}	
			
		
		
		if(uiDriver.checkElementPresent("WElement_CustomersPage_PencilIcon"))
		{
			passed("Customers page", "Pencil icon should be displayed on Customers Page", "Pencil icon is displayed on Customers Page");
		} 
		else
		{
			failed("Customers page", "Pencil icon should be displayed on Customers Page", "Pencil icon is displayed on Customers Page");
		}
		
	//	mail should be configured
	//	uiDriver.click("WElement_CustomersPage_MailIcon");
		
		uiDriver.click("WElement_CustomersPage_GraphIcon");
		if(uiDriver.checkElementPresent("WElement_TCO_ROI_Page"))
		{
			passed("Customers page", "TCO/ROI page should be displayed ", "TCO/ROI page is displayed ");
		} 
		else
		{
			failed("Customers page", "TCO/ROI page should be displayed ", "TCO/ROI page is displayed ");
		}	
		
		uiDriver.click("WSubMenu_Customers");
		SleepUtils.sleep(4);
		
		
		SearchCustomer(input,output);
		
		uiDriver.click("WElement_CustomersPage_PencilIcon");
		SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("WElement_EditCustomer_Page"))
		{
			passed("Customers page", "Customer page should be displayed ", "Customer page is displayed ");
		} 
		else
		{
			failed("Customers page", "Customer page should be displayed ", "Customer page is displayed ");
		}
		SleepUtils.sleep(5);
		String expCustomerNumber = input.get("CustomerNumber");
		String actCustomerNumber = uiDriver.getValue("WElement_EditCustomersPage_Address_CustomerNumber");
		if(expCustomerNumber.equalsIgnoreCase(actCustomerNumber))
		{
			passed("Verify Customer Number","Customer Number should be '"+expCustomerNumber+"'","Customer Number is displayed as '"+actCustomerNumber+"'");
		}
		else
		{
			failed("Verify Customer Number","Customer Number should be '"+expCustomerNumber+"'","Customer Number is displayed as '"+actCustomerNumber+"'");
		}
		
		String expCustomerName = input.get("CustomerName");
		String actCustomerName = uiDriver.getValue("WElement_CustomersPage_CustomerName");
		if(expCustomerName.equalsIgnoreCase(actCustomerName))
		{
			passed("Verify Customer Name","Customer Name should be '"+expCustomerName+"'","Customer Name is displayed as '"+actCustomerName+"'");
		}
		else
		{
			failed("Verify Customer Name","Customer Name should be '"+expCustomerName+"'","Customer Name is displayed as '"+actCustomerName+"'");
		}
	
		String expCustomerType = input.get("Customertype");
		String actCustomerType = uiDriver.getValue("WElement_EditCustomersPage_CustomerType");
		if(expCustomerType.equalsIgnoreCase(actCustomerType))
		{
			passed("Verify Customer Type","Customer Type should be '"+expCustomerType+"'","Customer Type is displayed as '"+actCustomerType+"'");
		}
		else
		{
			failed("Verify Customer Type","Customer Type should be '"+expCustomerType+"'","Customer Type is displayed as '"+actCustomerType+"'");
		}
		
		String expTelephoneNumber = input.get("TelephoneNumber");
		String actTelephoneNumber = uiDriver.getValue("WElement_EditCustomersPage_TelephoneNumber");
		if(expTelephoneNumber.equalsIgnoreCase(actTelephoneNumber))
		{
			passed("Verify Telephone Number","Telephone Number should be '"+expTelephoneNumber+"'","Telephone Number is displayed as '"+actTelephoneNumber+"'");
		}
		else
		{
			failed("Verify Telephone Number","Telephone Number should be '"+expTelephoneNumber+"'","Telephone Number is displayed as '"+actTelephoneNumber+"'");
		}
		
		/*uiDriver.click("WElement_EditCustomersPage_TotalAddressField");
		Thread.sleep(4000);
		
		String expStreet = input.get("StreetAddress");
		String actStreet = uiDriver.getValue("WElement_EditCustomersPage_Address_Street");
		if(expStreet.equalsIgnoreCase(actStreet))
		{
			passed("Verify Street Address","Street Address should be '"+expStreet+"'","Street Address is displayed as '"+actStreet+"'");
		}
		else
		{
			failed("Verify Street Address","Street Address should be '"+expStreet+"'","Street Address is displayed as '"+actStreet+"'");
		}
		
		String expZip = input.get("ZipAddress");
		String actZip = uiDriver.getValue("WElement_EditCustomersPage_Address_Zip");
		if(expZip.equalsIgnoreCase(actZip))
		{
			passed("Verify Zip Address","Zip Address should be '"+expZip+"'","Zip Address is displayed as '"+actZip+"'");
		}
		else
		{
			failed("Verify Zip Address","Zip Address should be '"+expZip+"'","Zip Address is displayed as '"+actZip+"'");
		}
		
		String expCity = input.get("CityAddress");
		String actCity = uiDriver.getValue("WElement_EditCustomersPage_Address_City");
		if(expCity.equalsIgnoreCase(actCity))
		{
			passed("Verify City Address","City Address should be '"+expCity+"'","City Address is displayed as '"+actCity+"'");
		}
		else
		{
			failed("Verify City Address","City Address should be '"+expCity+"'","City Address is displayed as '"+actCity+"'");
		}
		
		String expStateAddress = input.get("StateAddress");
		String actStateAddress = uiDriver.getValue("WElement_EditCustomersPage_Address_State");
		if(expStateAddress.equalsIgnoreCase(actStateAddress))
		{
			passed("Verify State Address","State Address should be '"+expStateAddress+"'","State Address is displayed as '"+actStateAddress+"'");
		}
		else
		{
			failed("Verify State Address","State Address should be '"+expStateAddress+"'","State Address is displayed as '"+actStateAddress+"'");
		}
		
		String expCountryAddress = input.get("CountryAddress");
		String actCountryAddress = uiDriver.getValue("WElement_EditCustomersPage_Address_Country");
		if(expCountryAddress.equalsIgnoreCase(actCountryAddress))
		{
			passed("Verify Country Address","Country should be '"+expCountryAddress+"'","Country is displayed as '"+actCountryAddress+"'");
		}
		else
		{
			failed("Verify Country Address","Country should be '"+expCountryAddress+"'","Country is displayed as '"+actCountryAddress+"'");
		}
		
		uiDriver.click("WElement_EditCustomersPage_Address_CancelButton");
		Thread.sleep(2000);*/
		uiDriver.click("WElement_EditCustomersPage_Additonal_Sphere_information");
		SleepUtils.sleep(2);
		
		String expCreditlimit = input.get("Creditlimit");
		String actCreditlimit = uiDriver.getValue("WElement_EditCustomersPage_CreditLimit");
		if(expCreditlimit.equalsIgnoreCase(actCreditlimit))
		{
			passed("Verify Credit limit","Credit limit should be '"+expCreditlimit+"'","Credit limit is displayed as '"+actCreditlimit+"'");
		}
		else
		{
			failed("Verify Credit limit","Credit limit should be '"+expCreditlimit+"'","Credit limit is displayed as '"+actCreditlimit+"'");
		}
		
		String expCreditExpiration = input.get("Creditexpiration");
		String actCreditExpiration = uiDriver.getValue("WElement_EditCustomersPage_CreditExpiration");
		if(expCreditExpiration.equalsIgnoreCase(actCreditExpiration))
		{
			passed("Verify Credit expiration","Credit expiration should be '"+expCreditExpiration+"'","Credit expiration is displayed as '"+actCreditExpiration+"'");
		}
		else
		{
			failed("Verify Credit expiration","Credit expiration should be '"+expCreditExpiration+"'","Credit expiration is displayed as '"+actCreditExpiration+"'");
		}
		
		
		

		//dont delete
		/*uiDriver.click("WSubMenu_Customers");
		Thread.sleep(4000);
		
		
		SearchCustomer(input,output);
		
		uiDriver.click("WElement_Customer_Page_ExpandIcon");
		Thread.sleep(4000);
		
		List<WebElement> deallist = uiDriver.webDr.findElements(By.xpath("//td[@class='k-detail-cell']//td[1]/span"));
		for(WebElement deal:deallist)	
		{
			String dealNum = deal.getText();
			if(input.get("DealAssociated").equalsIgnoreCase(dealNum))
			{
				passed("Verify Associated deal", ""+dealNum+" should be associated to the customer", ""+dealNum+" is associated to the customer");
				return;
			}	
		}
		
		failed("Verify Associated deal", " "+input.get("DealAssociated")+" should be associated to the customer", ""+input.get("DealAssociated")+" is not associated to the customer");
		
		*/
		//dont delete
	}
	
	/****************************************
	 * Name: VerifyDealGridHeaders
	 * Description: VerifyDealGridHeaders
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyDealGridHeaders(DataRow input, DataRow output) throws InterruptedException {
		
	
		/*List<WebElement> DealList = uiDriver.webDr.findElements(By.xpath("//thead[@class='k-grid-header']/tr/th"));
		String actualheader = input.get("GridHeaders");
		String header[] = actualheader.split(",");
		//for(WebElement cuslist :CustomerList)
		for(int i=0;i<5;i++)
		{
			WebElement actualdeal = DealList.get(i+1);
		    String actcus = actualdeal.getText();
		    if(actcus.equalsIgnoreCase(header[i]))
		    {
		    	
					passed("Deal page grid headers", ""+header[i]+" should be displayed", ""+actcus+" is displayed");
		    }
			else
				{
					failed("Deal page grid headers", ""+header[i]+" should be displayed", ""+actcus+" is not displayed");
				}
		    }
		
		if(uiDriver.checkElementPresent("WElement_DealsPage_PencilIcon"))
		{
			passed("Deals page", "Pencil icon should be displayed on Deals Page", "Pencil icon is displayed on Deals Page");
		} 
		else
		{
			failed("Deals page", "Pencil icon should be displayed on Deals Page", "Pencil icon is displayed on Deals Page");
		}
		*/
	
	}
	/****************************************
	 * Name: SearchDeal
	 * Description: SearchDeal
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void SearchDeal(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_DealSearchBox", input.get("DealNumber"));
		String DealNumber=input.get("DealNumber");
		SleepUtils.sleep(8);
			passed("Deal Number", "Deal Number should be entered in Search Box", "Deal Number is entered in Search Box");
			String type = uiDriver.getDyanmicData("WElement_firstRowDeal");
			
			String type1 = type.replace("#",DealNumber);
		    SleepUtils.sleep(2);
	 	    uiDriver.click_dynamic(type1);
			SleepUtils.sleep(13);
	}
	
	/****************************************
	 * Name: SearchDeal
	 * Description: SearchDeal
	 * Date: 18-Oct-2017
	 * @throws InterruptedException 
	 ****************************************/
	
	public void EditSearchDeal(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(10);
		//uiDriver.click("WElement_firstRowDeal");
		
		
		/*if(uiDriver.checkElementPresent("WElement_Deal_Page"))
		{
			passed("Deal page", "Edit deal page should be displayed ", "Edit deal page is displayed ");
		} 
		else
		{
			failed("Deal page", "Edit deal page should be displayed ", "Edit deal page is displayed ");
		}*/	
		
		
	
	}
	
	/****************************************
	 * Name: VerifyDealGeneralTab
	 * Description: VerifyDealGeneralTab
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyDealGeneralTab(DataRow input, DataRow output) throws InterruptedException {
		
	
		String expDealNumber = input.get("DealNumber");
		String actDealNumber = uiDriver.getValue("WElement_EditDealPage_DealNumber");
		if(expDealNumber.equalsIgnoreCase(actDealNumber))
		{
			passed("Verify Deal Number","Deal Number should be '"+expDealNumber+"'","Deal Number is displayed as '"+actDealNumber+"'");
		}
		else
		{
			failed("Verify Deal Number","Deal Number should be '"+expDealNumber+"'","Deal Number is displayed as '"+actDealNumber+"'");
		}
		
		String expDealName = input.get("DealName");
		String actDealName = uiDriver.getValue("WElement_EditDealPage_DealName");
		if(expDealName.equalsIgnoreCase(actDealName))
		{
			passed("Verify Deal Name","Deal Name should be '"+expDealName+"'","Deal Name is displayed as '"+actDealName+"'");
		}
		else
		{
			failed("Verify Deal Name","Deal Name should be '"+expDealName+"'","Deal Name is displayed as '"+actDealName+"'");
		}
	
		String expDealtype = input.get("Dealtype");
		String actDealtype = uiDriver.getValue("WElement_EditDealPage_DealType");
		if(expDealtype.equalsIgnoreCase(actDealtype))
		{
			passed("Verify Deal Type","Deal Type should be '"+expDealtype+"'","Deal Type is displayed as '"+actDealtype+"'");
		}
		else
		{
			failed("Verify Deal Type","Deal Type should be '"+expDealtype+"'","Deal Type is displayed as '"+actDealtype+"'");
		}
		
		
		
		
		
		
		/*if(uiDriver.checkElementPresent("WElement_DealPage_Name"))
		{
			passed("Name field in General Tab of Edit Deal Page", "Name field in General Tab of Edit Deal Page should be displayed", "Name field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Name field in General Tab of Edit Deal Page", "Name field in  General Tab of Edit Deal Page should be displayed", "Name field in General Tab of Edit Deal Page is not displayed");
		}	
		
		
		if(uiDriver.checkElementPresent("WElement_DealPage_DealType"))
		{
			passed("Deal Type field in General Tab of Edit Deal Page", "Deal Type field in Edit Deal Page should be displayed", "Deal Type field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Type field in General Tab of Edit Deal Page", "Deal Type field in Edit Deal Page should be displayed", "Deal Type field in General Tab of Edit Deal Page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_BillingFrequency"))
		{
			passed("Billing Frequency field in General Tab of Edit Deal Page", "Billing Frequency field in General Tab of Edit Deal Page should be displayed", "Billing Frequency field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Billing Frequency field in General Tab of Edit Deal Page", "Billing Frequency field in General Tab of Edit Deal Page should be displayed", "Billing Frequency field in General Tab of Edit Deal Page is not displayed");
		}	
		
		
		if(uiDriver.checkElementPresent("WElement_DealPage_AutoApproveInvoiceProposals"))
		{
			passed("Auto Approve Invoice Proposals field in General Tab of Edit Deal Page", "Auto Approve Invoice Proposals field in General Tab of Edit Deal Page should be displayed", "Auto Approve Invoice Proposals field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Auto Approve Invoice Proposals field in General Tab of Edit Deal Page", "Auto Approve Invoice Proposals field in General Tab of Edit Deal Page should be displayed", "Auto Approve Invoice Proposals field in General Tab of Edit Deal Page is not displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_DealPage_ChargeNumberRequired"))
		{
			passed("Charge Number Required field in General Tab of Edit Deal Page", "Charge Number Required field in General Tab of Edit Deal Page should be displayed", "Charge Number Required field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Charge Number Required field in General Tab of Edit Deal Page", "Charge Number Required field in General Tab of Edit Deal Page should be displayed", "Charge Number Required field in General Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_DealPage_DefaultChargeNumber"))
		{
			passed("Default Charge Number field in General Tab of Edit Deal Page", "Default Charge Number field in General Tab of Edit Deal Page should be displayed", "Default Charge Number field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Charge Number Required field in General Tab of Edit Deal Page", "Default Charge Number field in General Tab of Edit Deal Page should be displayed", "Default Charge Number field in General Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_DealPage_DealNumber"))
		{
			passed("Deal Number field in General Tab of Edit Deal Page", "Deal Number field in General Tab of Edit Deal Page should be displayed", "Deal Number field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Number field in General Tab of Edit Deal Page", "Deal Number field in General Tab of Edit Deal Page should be displayed", "Deal Number field in General Tab of Edit Deal Page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_Customer"))
		{
			passed("Customer field in General Tab of Edit Deal Page", "Customer field in General Tab of Edit Deal Page should be displayed", "Customer field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Customer field in General Tab of Edit Deal Page", "Customer field in General Tab of Edit Deal Page should be displayed", "Customer field in General Tab of Edit Deal Page is not displayed");
		}
		if(uiDriver.checkElementPresent("WElement_DealPage_ActiveProduction"))
		{
			passed("Active Production field in General Tab of Edit Deal Page", "Active Production field in General Tab of Edit Deal Page should be displayed", "Active Production field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Active Production field in General Tab of Edit Deal Page", "Active Production field in General Tab of Edit Deal Page should be displayed", "Active Production field in General Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_DealPage_Memo"))
		{
			passed("Memo field in General Tab of Edit Deal Page", "Memo field in General Tab of Edit Deal Page should be displayed", "Memo field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Memo field in General Tab of Edit Deal Page", "Memo field in General Tab of Edit Deal Page should be displayed", "Memo field in General Tab of Edit Deal Page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_Memo"))
		{
			passed("Deal page DealType Element", "deal page DealType Element should be displayed", "Edit deal DealType Element page is displayed");
		} 
		else
		{
			failed("Deal page DealType Element", "deal page DealType Element should be displayed", "Edit deal DealType Element page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_OrderNumber"))
		{
			passed("Order Number field in General Tab of Edit Deal Page", "Order Number field in General Tab of Edit Deal Page should be displayed", "Order Number field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Order Number field in General Tab of Edit Deal Page", "Order Number field in General Tab of Edit Deal Page should be displayed", "Order Number field in General Tab of Edit Deal Page is not displayed");
		}	
		if(uiDriver.checkElementPresent("WElement_DealPage_PONumber"))
		{
			passed("PO Number field in General Tab of Edit Deal Page", "PO Number field in General Tab of Edit Deal Page should be displayed", "PO Number field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("PO Number field in General Tab of Edit Deal Page", "PO Number field in General Tab of Edit Deal Page should be displayed", "PO Number field in General Tab of Edit Deal Page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_Description"))
		{
			passed("Description field in General Tab of Edit Deal Page", "Description field in General Tab of Edit Deal Page should be displayed", "Description field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Description field in General Tab of Edit Deal Page", "Description field in General Tab of Edit Deal Page should be displayed", "Description field in General Tab of Edit Deal Page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_ActiveUntil"))
		{
			passed("Active Until field in General Tab of Edit Deal Page", "Active Until field in General Tab of Edit Deal Page should be displayed", "Active Until field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Active Until field in General Tab of Edit Deal Page", "Active Until field in General Tab of Edit Deal Page should be displayed", "Active Until field in General Tab of Edit Deal Page is not displayed");
		}	
		
		if(uiDriver.checkElementPresent("WElement_DealPage_Status"))
		{
			passed("Status field in General Tab of Edit Deal Page", "Status field in General Tab of Edit Deal Page should be displayed", "Status field in General Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Status field in General Tab of Edit Deal Page", "Status field in General Tab of Edit Deal Page should be displayed", "Status field in General Tab of Edit Deal Page is not displayed");
		}*/	

	}
	
	
	/****************************************
	 * Name: AddOrderDetails
	 * Description: AddOrderDetails
	 
	 * @throws InterruptedException 
	 ****************************************//*
	
	public void AddOrderDetails(DataRow input, DataRow output) throws InterruptedException {
		
	
	//	uiDriver.setValue("WElement_DealPage_Status", "001");
		uiDriver.click("WSubMenu_EditDeals_GeneralTab");
		SleepUtils.sleep(2);
		
		String mandateStatus = uiDriver.getAttribute("WElement_DealPage_MandateStatus", "disabled");
		if(mandateStatus.equalsIgnoreCase("true"))
		{
			passed("Verify Mandate status","Mandate status should be disabled","Mandate status is disabled");
			
		}else
		{
			failed("Verify Mandate status","Mandate status should be disabled","Mandate status is not disabled");
		}
		Random rand = new Random();
		   // nextInt is normally exclusive of the top value,
		   // so add 1 to make it inclusive
		
		   int OrderNumber1 = rand.nextInt((1000-1)+1000)+1;
		   String OrderNumber = Integer.toString(OrderNumber1);
		   
		   int PONumber1 = rand.nextInt((1000000-1)+1000000)+1;
		   String PONumber = Integer.toString(PONumber1);
		   
		   String Description = "ORDER"+OrderNumber;
		   Date date = new Date();
			String startDate1= new SimpleDateFormat("MM/dd/yyyy").format(date);
			Date endDate1 = DateUtils.addDays(new Date(), +4);
			//Date endDate1 = DateUtils.
			String startDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
		//String OrderNumber = input.get("OrderNumber");
		uiDriver.setValue("WElement_DealPage_OrderNumberfield", OrderNumber);
			passed("Order Number","Order Number should entered","Order Number is entered");
		uiDriver.setValue("WElement_DealPage_PONumberfield", PONumber);
			passed("PO Number","PO Number should entered","PO Number is entered");
		uiDriver.setValue("WElement_DealPage_Descriptionfield", Description);
			passed("Description","Description should entered","Description is entered");
		//uiDriver.setValue("WElement_DealPage_Descriptionfield", "Test");
		uiDriver.click("WElement_DealPage_Calender");
		uiDriver.setValue("WElement_DealPage_CalenderDate", startDate);
		//WebElement date = uiDriver.webDr.findElement(By.xpath("//*[@id='8eff997d-e6ae-448c-901d-feae5b36eede']/table/tbody/tr[4]/td[3]/a"));
		//date.click();
		Thread.sleep(5000);
		uiDriver.click("WBtn_DealPage_AddOrder");
		Thread.sleep(3000);
			passed("Add Order","Add Order should be clicked","Add Order is clicked");
		//String OrderNumber= "999";
		output.put("OrderNumber", OrderNumber);
	//	output.put(OrderNumber, "OrderNumber");
		}*/
	
	/****************************************
	 * Name: VerifyTabsOnDealPage
	 * Description: VerifyTabsOnDealPage
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyTabsOnDealPage(DataRow input, DataRow output) throws InterruptedException {
		
		List<WebElement> DealTabsList = uiDriver.webDr.findElements(By.xpath("//div[@ng-hide='hideTabs']/a/div/label"));
		String actualheader = input.get("DealTabs");
		String header[] = actualheader.split(",");
		//for(WebElement cuslist :CustomerList)
		for(int i=0;i<5;i++)
		{
			WebElement actualdeal = DealTabsList.get(i);
		    String actcus = actualdeal.getText();
		    if(actcus.equalsIgnoreCase(header[i]))
		    {
		    	passed("Tab headers in Edit Deal Page", ""+header[i]+" should be displayed", ""+actcus+" is displayed");
		    }
				else
			{
				failed("Tab headers in Edit Deal Page", ""+header[i]+" should be displayed", ""+actcus+" is not displayed");
			}
		    }
		
		
}
	
	/****************************************
	 * Name: VerifyDealPlanningHeaders
	 * Description: VerifyDealPlanningHeaders
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyDealPlanningHeaders(DataRow input, DataRow output) throws InterruptedException {
		
	
		List<WebElement> PlanningHistory = uiDriver.webDr.findElements(By.xpath("//thead[@class='k-grid-header']/tr/th"));
		String actualheader = input.get("GridHeaders");
		String header[] = actualheader.split(",");
		//for(WebElement cuslist :CustomerList)
		for(int i=0;i<8;i++)
		{
			WebElement actualdeal = PlanningHistory.get(i+1);
		    String actcus = actualdeal.getText();
		    if(actcus.equalsIgnoreCase(header[i]))
		    {
		    	
					passed("Planning history  grid headers", ""+header[i]+" should be displayed", ""+actcus+" is displayed");
		    }
				else
				{
					failed("Planning history  grid headers", ""+header[i]+" should be displayed", ""+actcus+" is not displayed");
				}
		    }
		
		if(uiDriver.checkElementPresent("WElement_PlanningHistory_PencilIcon"))
		{
			passed("Deals page", "Pencil icon should be displayed on Deals Page", "Pencil icon is displayed on Deals Page");
		} 
		else
		{
			failed("Deals page", "Pencil icon should be displayed on Deals Page", "Pencil icon is displayed on Deals Page");
		}
		
	
	}
	
	/****************************************
	 * Name: VerifyAdditionalSphereInfoTab
	 * Description: VerifyAdditionalSphereInfoTab
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyAdditionalSphereInfoTab(DataRow input, DataRow output) throws InterruptedException {
		
		
		String expManagingcostcenter = input.get("Managingcostcenter");
		String actManagingcostcenter = uiDriver.getValue("WElement_EditDealPage_ManagingCostCenter");
		if(expManagingcostcenter.equalsIgnoreCase(actManagingcostcenter))
		{
			passed("Verify Managing costcenter","Managing costcenter should be '"+expManagingcostcenter+"'","Managing costcenter is displayed as '"+actManagingcostcenter+"'");
		}
		else
		{
			failed("Verify Managing costcenter","Managing costcenter should be '"+expManagingcostcenter+"'","Managing costcenter is displayed as '"+actManagingcostcenter+"'");
		}
		
		String expDealStatus = input.get("DealStatus");
		String actDealStatus = uiDriver.getValue("WElement_EditDealPage_DealStatus");
		if(expDealStatus.equalsIgnoreCase(actDealStatus))
		{
			passed("Verify Deal Status","Deal Status should be '"+expDealStatus+"'","Deal Status is displayed as '"+actDealStatus+"'");
		}
		else
		{
			failed("Verify Deal Status","Deal Status should be '"+expDealStatus+"'","Deal Status is displayed as '"+actDealStatus+"'");
		}
		
		
		
		/*if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_SphereDeal"))
		{
			passed("Sphere Deal field in Additonal Sphere information Tab of Edit Deal Page", "Sphere Deal field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Sphere Deal field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Sphere Deal field in Additonal Sphere information Tab of Edit Deal Page", "Sphere Deal field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Sphere Deal field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_InvoiceFormat"))
		{
			passed("Invoice Format field in Additonal Sphere information Tab of Edit Deal Page", "Invoice Format field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Invoice Format field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Invoice Format field in Additonal Sphere information Tab of Edit Deal Page", "Invoice Format field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Invoice Format field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		
		
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_InvoiceFormatCode"))
		{
			passed("Invoice Format Code field in Additonal Sphere information Tab of Edit Deal Page", "Invoice Format Code field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Invoice Format Code field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Invoice Format Code field in Additonal Sphere information Tab of Edit Deal Page", "Invoice Format Code field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Invoice Format Code field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_BillingSchedule"))
		{
			passed("Billing Schedule field in Additonal Sphere information Tab of Edit Deal Page", "Billing Schedule field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Billing Schedule field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Billing Schedule field in Additonal Sphere information Tab of Edit Deal Page", "Billing Schedule field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Billing Schedule field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealStatus"))
		{
			passed("Deal Status field in Additonal Sphere information Tab of Edit Deal Page", "Deal Status field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Status field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Status field in Additonal Sphere information Tab of Edit Deal Page", "Deal Status field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Status field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealStatusCode"))
		{
			passed("Deal Status Code field in Additonal Sphere information Tab of Edit Deal Page", "Deal Status Code field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Status Code field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Status Code field in Additonal Sphere information Tab of Edit Deal Page", "Deal Status Code field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Status Code field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_Project"))
		{
			passed("Project field in Additonal Sphere information Tab of Edit Deal Page", "Project field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Project field in Additonal Sphere information Tab of Edit Deal Page", "Project field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ProjectType"))
		{
			passed("Project Type field in Additonal Sphere information Tab of Edit Deal Page", "Project Type field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Type field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Project Type field in Additonal Sphere information Tab of Edit Deal Page", "Project Type field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Type field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ProjectInternal"))
		{
			passed("Project Internal field in Additonal Sphere information Tab of Edit Deal Page", "Project Internal field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Internal field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Project Internal field in Additonal Sphere information Tab of Edit Deal Page", "Project Internal field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Internal field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ProjectActive"))
		{
			passed("Project Active field in Additonal Sphere information Tab of Edit Deal Page", "Project Active field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Active field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Project Active field in Additonal Sphere information Tab of Edit Deal Page", "Project Active field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Active field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ProjectClusterId"))
		{
			passed("Project Cluster Id field in Additonal Sphere information Tab of Edit Deal Page", "Project Cluster Id field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Cluster Id field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Project Cluster Id field in Additonal Sphere information Tab of Edit Deal Page", "Project Cluster Id field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Project Cluster Id field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ManagingCostCenter"))
		{
			passed("Managing Cost Center field in Additonal Sphere information Tab of Edit Deal Page", "Managing Cost Center field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Managing Cost Center field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Managing Cost Center field in Additonal Sphere information Tab of Edit Deal Page", "Managing Cost Center field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Managing Cost Center field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ManagingCostCenterId"))
		{
			passed("Managing Cost Center Id field in Additonal Sphere information Tab of Edit Deal Page", "Managing Cost Center Id field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Managing Cost Center Id field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Managing Cost Center Id field in Additonal Sphere information Tab of Edit Deal Page", "Managing Cost Center Id field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Managing Cost Center Id field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealStartDate"))
		{
			passed("Deal Start Date field in Additonal Sphere information Tab of Edit Deal Page", "Deal Start Date field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Start Date field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Start Date field in Additonal Sphere information Tab of Edit Deal Page", "Deal Start Date field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Start Date field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealCloseDate"))
		{
			passed("Deal Close Date field in Additonal Sphere information Tab of Edit Deal Page", "Deal Close Date field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Close Date field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Close Date field in Additonal Sphere information Tab of Edit Deal Page", "Deal Close Date field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Close Date field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_ContactFullName"))
		{
			passed("Contact Full Name field in Additonal Sphere information Tab of Edit Deal Page", "Contact Full Name field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Contact Full Name field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Contact Full Name field in Additonal Sphere information Tab of Edit Deal Page", "Contact Full Name field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Contact Full Name field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_Taxed"))
		{
			passed("Taxed field in Additonal Sphere information Tab of Edit Deal Page", "Taxed field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Taxed field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Taxed field in Additonal Sphere information Tab of Edit Deal Page", "Taxed field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Taxed field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_MultiDepartment"))
		{
			passed("Multi Department field in Additonal Sphere information Tab of Edit Deal Page", "Multi Department field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Multi Department field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Multi Department field in Additonal Sphere information Tab of Edit Deal Page", "Multi Department field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Multi Department field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_RevenueShare"))
		{
			passed("Revenue Share field in Additonal Sphere information Tab of Edit Deal Page", "Revenue Share field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Revenue Share field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Revenue Share field in Additonal Sphere information Tab of Edit Deal Page", "Revenue Share field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Revenue Share field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_Onlot"))
		{
			passed("On lot field in Additonal Sphere information Tab of Edit Deal Page", "On lot field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "On lot field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("On lot field in Additonal Sphere information Tab of Edit Deal Page", "On lot field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "On lot field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		

		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_Insured"))
		{
			passed("Insured field in Additonal Sphere information Tab of Edit Deal Page", "Insured field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Insured field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Insured field in Additonal Sphere information Tab of Edit Deal Page", "Insured field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Insured field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealMakerSSO"))
		{
			passed("Deal Maker SSO field in Additonal Sphere information Tab of Edit Deal Page", "Deal Maker SSO field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Maker SSO field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Maker SSO field in Additonal Sphere information Tab of Edit Deal Page", "Deal Maker SSO field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Maker SSO field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealMakerFirstName"))
		{
			passed("Deal Maker First Name field in Additonal Sphere information Tab of Edit Deal Page", "Deal Maker First Name field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Maker First Name field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Maker First Name field in Additonal Sphere information Tab of Edit Deal Page", "Deal Maker First Name field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Maker First Name field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_DealMakerLastName"))
		{
			passed("Deal Maker Last Name field in Additonal Sphere information Tab of Edit Deal Page", "Deal Maker Last Name field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Maker Last Name field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Deal Maker Last Name field in Additonal Sphere information Tab of Edit Deal Page", "Deal Maker Last Name field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Deal Maker Last Name field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_CostPlus"))
		{
			passed("Cost Plus field in Additonal Sphere information Tab of Edit Deal Page", "Cost Plus field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Cost Plus field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Cost Plus field in Additonal Sphere information Tab of Edit Deal Page", "Cost Plus field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Cost Plus field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_PONumber"))
		{
			passed("PO Number field in Additonal Sphere information Tab of Edit Deal Page", "PO Number field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "PO Number field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("PO Number field in Additonal Sphere information Tab of Edit Deal Page", "PO Number field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "PO Number field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_AdditionalSphereInformation_SalesForceId"))
		{
			passed("Sales Force Id field in Additonal Sphere information Tab of Edit Deal Page", "Sales Force Id field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Sales Force Id field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Sales Force Id field in Additonal Sphere information Tab of Edit Deal Page", "Sales Force Id field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Sales Force Id field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}*/
	}
	
	
	/****************************************
	 * Name: VerifyPlanningLisTabHeaders
	 * Description: VerifyPlanningLisTabHeaders
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyPlanningLisTabHeaders(DataRow input, DataRow output) throws InterruptedException {
		
	
		List<WebElement> PlanningHistory = uiDriver.webDr.findElements(By.xpath("//thead[@class='k-grid-header']/tr/th"));
		String actualheader = input.get("GridHeaders");
		String header[] = actualheader.split(",");
		//for(WebElement cuslist :CustomerList)
		for(int i=0;i<9;i++)
		{
			WebElement actualdeal = PlanningHistory.get(i+1);
		    String actcus = actualdeal.getText();
		    if(actcus.equalsIgnoreCase(header[i]))
		    {
		    	
					passed("Planning List  grid headers", ""+header[i]+" should be displayed", ""+actcus+" is displayed");
		    }
				else
				{
					failed("Planning List  grid headers", ""+header[i]+" should be displayed", ""+actcus+" is not displayed");
				}
		    }
		
		if(uiDriver.checkElementPresent("WElement_PlanningList_PencilIcon"))
		{
			passed("PlanningList page", "Pencil icon should be displayed on PlanningList Page", "Pencil icon is displayed on PlanningList Page");
		} 
		else
		{
			failed("PlanningList page", "Pencil icon should be displayed on PlanningList Page", "Pencil icon is displayed on PlanningList Page");
		}
		
	
	}
	
	/****************************************
	 * Name: VerifyAddPlanningListTabs
	 * Description: VerifyAddPlanningListTabs
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyAddPlanningListTabs(DataRow input, DataRow output) throws InterruptedException {
		
	
		List<WebElement> DealTabsList = uiDriver.webDr.findElements(By.xpath("//div[@ng-hide='hideTabs']/a/div/label"));
		String actualheader = input.get("PlanningTabs");
		String header[] = actualheader.split(",");
		//for(WebElement cuslist :CustomerList)
		for(int i=0;i<5;i++)
		{
			WebElement actualdeal = DealTabsList.get(i);
		    String actcus = actualdeal.getText();
		    if(actcus.equalsIgnoreCase(header[i]))
		    {
		    	
					passed("Customers page grid headers", ""+header[i]+" should be displayed", ""+actcus+" is displayed");
		    }
				else
				{
					failed("Customers page grid headers", ""+header[i]+" should be displayed", ""+actcus+" is not displayed");
				}
		    }
		
	
	}
	
	/****************************************
	 * Name: VerifyPlanningGeneralTabDetails
	 * Description: VerifyPlanningGeneralTabDetails
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyPlanningGeneralTabDetails(DataRow input, DataRow output) throws InterruptedException {
		
	
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_Type"))
		{
			passed("Type field in Additonal Sphere information Tab of Edit Deal Page", "Type field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Type field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Type field in Additonal Sphere information Tab of Edit Deal Page", "Type field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Type field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningType"))
		{
			passed("Insured field in Additonal Sphere information Tab of Edit Deal Page", "Insured field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Insured field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Insured field in Additonal Sphere information Tab of Edit Deal Page", "Insured field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Insured field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningCategory"))
		{
			passed("Insured field in Additonal Sphere information Tab of Edit Deal Page", "Insured field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Insured field in Additonal Sphere information Tab of Edit Deal Page is displayed");
		} 
		else
		{
			failed("Insured field in Additonal Sphere information Tab of Edit Deal Page", "Insured field in Additonal Sphere information Tab of Edit Deal Page should be displayed", "Insured field in Additonal Sphere information Tab of Edit Deal Page is not displayed");
		}
		

		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningCanOverlap"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningCustomer"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningCustomerMototrCarrier"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningCustomerContactPerson"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPaymentType"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningTransactionType"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningNonBillable"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningInvoiceNote"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPrintTripTickets"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		
		//deal verification
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningDeal"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPrimarycharges"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningOrderNumber"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningFuelcharges"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningOrderNumber2"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber2"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		//vehicle verification
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningVehicle"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningVehicleType"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPlannedStartTime"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPlannedEndTime"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPerformingLocation"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningPerformingCostCenter"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningMotorCarrierNumber"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningReservationProcessMemo"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningTransWorksImportNumber"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningNext90DaysInspection"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningSuggestedInspectionResponsibility"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningSuggestedInspectionResponsibility"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningActualStartTime"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningActualEndTime"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningStartMileage"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningStartMileage"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningFinalMileage"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningFinalMileage"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningStarthours"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningEndhours"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningStartFuelLevel"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningEndFuelLevel"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
	}
	
	/****************************************
	 * Name: AddPlanningDetails
	 * Description: AddPlanningDetails
	 
	 * @throws InterruptedException 
	 * @throws AWTException 
	 ****************************************/
	
	public void AddPlanningDetails(DataRow input, DataRow output) throws InterruptedException, AWTException {
		
		
		String OrderNo1 = input.get("OrderNumber");
		String OrderNo = "ORDER"+OrderNo1;
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
		SleepUtils.sleep(2);
		String typee = input.get("selectType");
		String type = uiDriver.getDyanmicData("WElement_SelectType");
	    String type1 = type.replace("#",typee);
	    SleepUtils.sleep(2);
 	    uiDriver.click_dynamic(type1);
		//uiDriver.click("WElement_SelectType");
 	   SleepUtils.sleep(2);
			
			passed("Type", "Type Should display correctly", "Type is displayed correctly");
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
		// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[16].click()");
		SleepUtils.sleep(2);
		String selectPlanningType2 = input.get("selectPlanningType");
		String SelectPlanningType = uiDriver.getDyanmicData("WElement_SelectPlanningType");
	    String SelectPlanningType1 = SelectPlanningType.replace("#",selectPlanningType2);
	    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(SelectPlanningType1);
		//uiDriver.click("WElement_SelectPlanningType") ;
	    SleepUtils.sleep(2);
			
			passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
		SleepUtils.sleep(3);
		//uiDriver.click("WElement_SelectCategory");
		String Categoryy = input.get("Category");
		String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
	    String Category1 = Category.replace("#",Categoryy);
	    SleepUtils.sleep(2);
 	    uiDriver.click_dynamic(Category1);
 	    SleepUtils.sleep(2);
			
			passed("Category", "Category Should display correctly", "Category is displayed correctly");
		

			SleepUtils.sleep(2);
		
		uiDriver.click("Wchkbox_CanOverlap");
		
		String Deal = input.get("DealNumber");
		//((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[10].click()");
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
		SleepUtils.sleep(3);
		//uiDriver.executeJavaScript("document.getElementsByClassName('k-textbox')[14].value='"+Deal+"');");
		uiDriver.setValue("WElement_Planning_SearchDeal", Deal);
		SleepUtils.sleep(6);
		String Deal1 = uiDriver.getDyanmicData("WElement_DealDisplayed");
		//Thread.sleep(4000);
		String DealNum = Deal1.replace("#",Deal);
		//SleepUtils.sleep(4);
 	    uiDriver.click_dynamic(DealNum);
 	    	passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
		SleepUtils.sleep(4);
		
		
		uiDriver.setValue("WElement_Planning_SearchOrder", OrderNo);
		SleepUtils.sleep(6);
		String Order1 = uiDriver.getDyanmicData("WElement_SearchedOrderDisplayed");
		//Thread.sleep(4000);
		String OrderN = Order1.replace("#",OrderNo);
		SleepUtils.sleep(2);
 	    
		uiDriver.click_dynamic(OrderN);		
 	    	passed("Order", "Order Should display correctly", "Order is displayed correctly");
 	    
 	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
 	    jse.executeScript("window.scrollBy(0,450)", "");	
 	  	SleepUtils.sleep(3);
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
		//uiDriver.click("WElement_vehicle");
		SleepUtils.sleep(3);
		
		uiDriver.click("WElement_PlanningVehicleNumber");	
			passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
 	    
		SleepUtils.sleep(3);
		Date date = new Date();
		String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
		Date startDate1 = DateUtils.addDays(new Date(),-4);
		
		
		String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
		
		uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
		SleepUtils.sleep(2);
			passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
		
		uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
		 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
	 	SleepUtils.sleep(2);
	 	
	 	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
		 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
	 	SleepUtils.sleep(2);
	 	
	 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
		 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
	 	SleepUtils.sleep(2);
		
		String SAPType = input.get("SAPType");
		String CostObject = input.get("CostObject");
		String SAPAccount = input.get("SAPAccount");
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType"))
		{
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType", SAPType);
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_CostObject", CostObject);
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPAccount", SAPAccount);
		} 
		
		String PerformingCC = uiDriver.getValue("WElement_PlanningPerformingCC");
		String Location = input.get("Location");
		
		if(PerformingCC.equalsIgnoreCase(Location))
		{
			passed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is displayed as "+PerformingCC+"");
		} 
		else
		{
			failed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is not displayed as "+PerformingCC+"");
		}
		
		String PerformingCostCenter = uiDriver.getValue("WElement_PlanningPerformingCostCENTER");
		String CostCenter = input.get("Costcenter");
		if(PerformingCostCenter.equalsIgnoreCase(CostCenter))
		{
			passed("Planning page performing cOSTCENTER", "Planning page performing COSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is displayed as "+PerformingCostCenter+"");
		} 
		else
		{
			failed("Planning page performing COSTCENTER", "Planning page performing cOSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is not displayed as "+PerformingCostCenter+"");
		}
		  
		  
		jse.executeScript("window.scrollBy(0,-450)", ""); 
		  
		
	}
	
	/****************************************
	 * Name: AddPlanningDetailsCustomerHold
	 * Description: AddPlanningDetailsCustomerHold
	
	 * @throws InterruptedException 
	 ****************************************/
	
	public void AddPlanningDetailsCustomerHold (DataRow input, DataRow output) throws InterruptedException {
		
		String OrderNo1 = input.get("OrderNumber");
		String OrderNo = "ORDER"+OrderNo1;
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
		SleepUtils.sleep(3);
		String typee = input.get("selectType");
		String type = uiDriver.getDyanmicData("WElement_SelectType");
	    String type1 = type.replace("#",typee);
	    Thread.sleep(200);
 	    uiDriver.click_dynamic(type1);
		//uiDriver.click("WElement_SelectType");
 	   SleepUtils.sleep(3);
			
			passed("Type", "Type Should display correctly", "Type is displayed correctly");
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
		// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[16].click()");
		SleepUtils.sleep(2);
		String selectPlanningType2 = input.get("selectPlanningType");
		String SelectPlanningType = uiDriver.getDyanmicData("WElement_SelectPlanningType");
	    String SelectPlanningType1 = SelectPlanningType.replace("#",selectPlanningType2);
	    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(SelectPlanningType1);
		//uiDriver.click("WElement_SelectPlanningType") ;
	    SleepUtils.sleep(2);
			
			passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
		SleepUtils.sleep(10);
		//uiDriver.click("WElement_SelectCategory");
		String Categoryy = input.get("Category");
		String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
	    String Category1 = Category.replace("#",Categoryy);
	    SleepUtils.sleep(2);
 	    uiDriver.click_dynamic(Category1);
 	   SleepUtils.sleep(2);
			
			passed("Category", "Category Should display correctly", "Category is displayed correctly");
		

			SleepUtils.sleep(2);
		
		/*uiDriver.click("Wchkbox_CanOverlap");
		Thread.sleep(2000);*/
		
		String Deal = input.get("DealNumber");
		//((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[10].click()");
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
		SleepUtils.sleep(10);
		//uiDriver.executeJavaScript("document.getElementsByClassName('k-textbox')[14].value='"+Deal+"');");
		uiDriver.setValue("WElement_Planning_SearchDeal", Deal);
		SleepUtils.sleep(20);
		String Deal1 = uiDriver.getDyanmicData("WElement_DealDisplayed");
		//Thread.sleep(4000);
		String DealNum = Deal1.replace("#",Deal);
		SleepUtils.sleep(2);
 	    uiDriver.click_dynamic(DealNum);
 	    	passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
		
 	    	
    	
		
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
		SleepUtils.sleep(10);
		
		
		uiDriver.setValue("WElement_Planning_SearchOrder", OrderNo);
		SleepUtils.sleep(20);
		String Order1 = uiDriver.getDyanmicData("WElement_SearchedOrderDisplayed");
		//Thread.sleep(4000);
		String OrderN = Order1.replace("#",OrderNo);
		SleepUtils.sleep(2);
 	    uiDriver.click_dynamic(OrderN);	
 	    	
 	    	passed("Order", "Order Should display correctly", "Order is displayed correctly");
 	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
 	    jse.executeScript("window.scrollBy(0,450)", "");	
 	   SleepUtils.sleep(3);
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
		//uiDriver.click("WElement_vehicle");
		SleepUtils.sleep(3);
		uiDriver.click("WElement_PlanningVehicleNumber");	
			passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
 	    
			SleepUtils.sleep(3);
		Date date = new Date();
		String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
		Date startDate1 = DateUtils.addDays(new Date(),-4);
		
		
		String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
		
		uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
		SleepUtils.sleep(2);
			passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
		 uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
		 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
		 	SleepUtils.sleep(2);
		 uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
		 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
		 	SleepUtils.sleep(2);
		 uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
		 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
		 	SleepUtils.sleep(2);
		
		String SAPType = input.get("SAPType");
		String CostObject = input.get("CostObject");
		String SAPAccount = input.get("SAPAccount");
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType"))
		{
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType", SAPType);
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_CostObject", CostObject);
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPAccount", SAPAccount);
		} 
		
		
		String PerformingCC = uiDriver.getValue("WElement_PlanningPerformingCC");
		String Location = input.get("Location");
		
		if(PerformingCC.equalsIgnoreCase(Location))
		{
			passed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is displayed as "+PerformingCC+"");
		} 
		else
		{
			failed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is not displayed as "+PerformingCC+"");
		}
		
		String PerformingCostCenter = uiDriver.getValue("WElement_PlanningPerformingCostCENTER");
		String CostCenter = input.get("Costcenter");
		if(PerformingCostCenter.equalsIgnoreCase(CostCenter))
		{
			passed("Planning page performing cOSTCENTER", "Planning page performing COSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is displayed as "+PerformingCostCenter+"");
		} 
		else
		{
			failed("Planning page performing COSTCENTER", "Planning page performing cOSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is not displayed as "+PerformingCostCenter+"");
		}
		  
		  
		  
		jse.executeScript("window.scrollBy(0,-450)", ""); 
		
		 
	}
	
	/****************************************
	 * Name: AddPlanningDetails
	 * Description: AddPlanningDetails
	 * Date: 18-Oct-2017
	 * @throws InterruptedException 
	 ****************************************/
	
	public void AddPlanningDetailsMonthlyRate(DataRow input, DataRow output) throws InterruptedException {
		
		
		String OrderNo1 = input.get("OrderNumber");
		String OrderNo = "ORDER"+OrderNo1;
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
		Thread.sleep(2000);
		String typee = input.get("selectType");
		String type = uiDriver.getDyanmicData("WElement_SelectType");
	    String type1 = type.replace("#",typee);
	    Thread.sleep(200);
 	    uiDriver.click_dynamic(type1);
		//uiDriver.click("WElement_SelectType");
		Thread.sleep(2000);
			
			passed("Type", "Type Should display correctly", "Type is displayed correctly");
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
		// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[16].click()");
		Thread.sleep(2000);
		String selectPlanningType2 = input.get("selectPlanningType");
		String SelectPlanningType = uiDriver.getDyanmicData("WElement_SelectPlanningType");
	    String SelectPlanningType1 = SelectPlanningType.replace("#",selectPlanningType2);
	    Thread.sleep(2000);
	    uiDriver.click_dynamic(SelectPlanningType1);
		//uiDriver.click("WElement_SelectPlanningType") ;
		Thread.sleep(2000);
			
			passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
		/*
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
		SleepUtils.sleep(10);
		//uiDriver.click("WElement_SelectCategory");
		String Categoryy = input.get("Category");
		String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
	    String Category1 = Category.replace("#",Categoryy);
	    Thread.sleep(200);
 	    uiDriver.click_dynamic(Category1);
		Thread.sleep(2000);
			
			passed("Category", "Category Should display correctly", "Category is displayed correctly");*/
		
//		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[5].click()");
		// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-item')[1].click()");
		Thread.sleep(2000);
		/*String customer="909244 - SH PRODUCTION COMPANY LLC";
		  ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-textbox')[3].value=customer;");
	//	uiDriver.setValue("WElement_PlanningCustomerSearchBox", customer);
		String actCustomer = "//td[contains(text(),'#')]";
		String customr = actCustomer.replace("#", customer);
		uiDriver.click(customr);
		*/
//		uiDriver.click("WElement_SelectCustomer") ;
		uiDriver.click("Wchkbox_CanOverlap");
		
		String Deal = input.get("DealNumber");
		//((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[10].click()");
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
		SleepUtils.sleep(10);
		//uiDriver.executeJavaScript("document.getElementsByClassName('k-textbox')[14].value='"+Deal+"');");
		uiDriver.setValue("WElement_Planning_SearchDeal", Deal);
		SleepUtils.sleep(20);
		String Deal1 = uiDriver.getDyanmicData("WElement_DealDisplayed");
		//Thread.sleep(4000);
		String DealNum = Deal1.replace("#",Deal);
	    Thread.sleep(200);
 	    uiDriver.click_dynamic(DealNum);
 	    	passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
		
 	    	
    	
		
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
		SleepUtils.sleep(10);
		
		
		uiDriver.setValue("WElement_Planning_SearchOrder", OrderNo);
		SleepUtils.sleep(20);
		String Order1 = uiDriver.getDyanmicData("WElement_SearchedOrderDisplayed");
		//Thread.sleep(4000);
		String OrderN = Order1.replace("#",OrderNo);
	    Thread.sleep(200);
 	    uiDriver.click_dynamic(OrderN);	
 	    	
 	    	passed("Order", "Order Should display correctly", "Order is displayed correctly");
 	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
 	    jse.executeScript("window.scrollBy(0,450)", "");	
    	Thread.sleep(3000);
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
		//uiDriver.click("WElement_vehicle");
		Thread.sleep(3000);
		uiDriver.click("WElement_PlanningVehicleNumber");	
			passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
 	    
		Thread.sleep(3000);
		Date date = new Date();
		String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
		Date startDate1 = DateUtils.addDays(new Date(),-4);
		
		
		String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
		
		uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
		Thread.sleep(2000);
			passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
		 uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
		 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
		 Thread.sleep(2000);
		 uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
		 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
		 Thread.sleep(2000);
		 uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
		 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
		Thread.sleep(2000);
		
		String SAPType = input.get("SAPType");
		String CostObject = input.get("CostObject");
		String SAPAccount = input.get("SAPAccount");
		if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType"))
		{
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType", SAPType);
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_CostObject", CostObject);
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPAccount", SAPAccount);
		} 
		
		
		String PerformingCC = uiDriver.getValue("WElement_PlanningPerformingCC");
		String Location = input.get("Location");
		
		if(PerformingCC.equalsIgnoreCase(Location))
		{
			passed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is displayed as "+PerformingCC+"");
		} 
		else
		{
			failed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is not displayed as "+PerformingCC+"");
		}
		
		String PerformingCostCenter = uiDriver.getValue("WElement_PlanningPerformingCostCENTER");
		String CostCenter = input.get("Costcenter");
		if(PerformingCostCenter.equalsIgnoreCase(CostCenter))
		{
			passed("Planning page performing cOSTCENTER", "Planning page performing COSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is displayed as "+PerformingCostCenter+"");
		} 
		else
		{
			failed("Planning page performing COSTCENTER", "Planning page performing cOSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is not displayed as "+PerformingCostCenter+"");
		}
		  
		  
		  
		jse.executeScript("window.scrollBy(0,-450)", ""); 
		  
		/*  output.put( "",);*/
		  
		  
		  
		  
		/*  
		  ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item k-state-selected k-state-focused')[7].click()");
		 ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-widget k-dropdown k-header form-control ng-empty ng-invalid ng-invalid-required ng-dirty ng-valid-parse ng-touched')[0].click();");
		  Select dropdown = new Select(uiDriver.webDr.findElement(By.xpath("(//li[@class='k-virtual-item k-item k-state-selected k-state-focused'])[7]")));
		  dropdown.selectByIndex(2);
		  
		*/
		
	
	}
	
	/****************************************
	 * Name: VerifyPlanningDailyPlanningPage
	 * Description: VerifyPlanningDailyPlanningPage
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyPlanningDailyPlanningPage(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(2);
		if(uiDriver.checkElementPresent("WElement_Planning_DailyPlanning_BillingFrequency"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}
		
		String BillingFrequency = uiDriver.getValue("WElement_Planning_BillingFrequency");
		if(BillingFrequency.equalsIgnoreCase("Weekly"))
		{
				passed("Billing Frequency Value", "Billing Frequency value should be displayed as Weekly", "Billing Frequency value is displayed as weekly");
			} 
			else
			{
				failed("Billing Frequency Value", "Billing Frequency value should be displayed as Weekly", "Billing Frequency value is not displayed as weekly");
		}
		
		
		if(uiDriver.checkElementPresent("WElement_Planning_DailyPlanning_Weekday"))
		{
			passed("Deal page Name Element", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		} 
		else
		{
			failed("Deal page", "deal page Name Element should be displayed", "Edit deal Name Element page is displayed");
		}		
		String weekday = uiDriver.getValue("WElement_Planning_Weekday");
		if(weekday.equalsIgnoreCase("Saturday"))
		{
			passed("WeekDay Value", "WeekDay Value value should be displayed as Saturday", "WeekDay Value should be displayed as Saturday");
		} 
		else
		{
			failed("WeekDay Value", "WeekDay Value value should be displayed as Saturday", "WeekDay Value is not displayed as Saturday");
	}
		
		
		
		
		
	}
	
	/****************************************
	 * Name: ClickOnPlanningHistory
	 * Description: ClickOnPlanningHistory
	 * Date: 18-Oct-2017
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnPlanningGeneratePlanning1(DataRow input, DataRow output) throws InterruptedException {
	SleepUtils.sleep(10);
		uiDriver.click("WBtn_Planning_GeneratePlanning");
		SleepUtils.sleep(60);
			passed("Generate Planning", "Generate Planning should be Clicked", "Generate Planning is Clicked");
		if (uiDriver.checkElementPresent("DailyPlanning_CalenderItems"))
		{
			passed("Calender items", "Calender items Should be displayed", "Calender items are displayed");
		} 
		else
		{
			uiDriver.click("WBtn_Planning_GeneratePlanning");
			SleepUtils.sleep(60);
		}
		/*uiDriver.click("DailyPlanning_CalenderItems");
		JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
		jse.executeScript("window.scrollBy(0,-250)", ""); 	
		SleepUtils.sleep(15);	
		uiDriver.click("DailyPlanning_CalenderItems_EditDetails");
		SleepUtils.sleep(10);
		String Location = input.get("Location");
		String TaxPercent = input.get("TaxPercent");
		//uiDriver.click("DailyPlanning_TaxTextValue");
		WebElement inputField = uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]"));
		jse.executeScript("arguments[0].scrollIntoView(true);", inputField);
		
		SleepUtils.sleep(6);
		//uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(Keys.BACK_SPACE);
		if(Location.equalsIgnoreCase("UniversalCity"))
		{SleepUtils.sleep(5);
		//jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].click()");
		//jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].value=�Avinash Mishra�;");
		  //jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].value='Avinash Mishra';");
		  	//jse.executeScript("arguments[0].setAttribute('value', '" + TaxPercent +"')", inputField);
		uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
		SleepUtils.sleep(5);
			uiDriver.setValue("DailyPlanning_TaxTextValue", "0");
			SleepUtils.sleep(2);
		}
		SleepUtils.sleep(2);
		if(Location.equalsIgnoreCase("New Mexico"))
		{
			SleepUtils.sleep(5);
			uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
			SleepUtils.sleep(5);
		}
		SleepUtils.sleep(2);
		if(Location.equalsIgnoreCase("New York"))
		{
			SleepUtils.sleep(5);
			uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
			//jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].value='Avinash Mishra';");
			  SleepUtils.sleep(5);
		}
		SleepUtils.sleep(2);
		if(Location.equalsIgnoreCase("Chicago"))
		{
			SleepUtils.sleep(5);
			uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
			SleepUtils.sleep(5);
		}
		SleepUtils.sleep(2);
		if(Location.equalsIgnoreCase("Atlanta"))
		{
			SleepUtils.sleep(5);
			uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
			SleepUtils.sleep(5);
		}
		passed("Tax Percentage", "Tax Percentage should be entered", "Tax Percentage is entered");
		SleepUtils.sleep(5);
		//jse.executeScript("window.scrollBy(0,-250)", ""); 
		WebElement Calculate = uiDriver.webDr.findElement(By.xpath("//a[@ng-click='calculatePrices()']"));
		//jse.executeScript("arguments[0].scrollIntoView(true);", Calculate);
		SleepUtils.sleep(6);
		//uiDriver.click("DailyPlanning_CalculatePrices");
		uiDriver.webDr.findElement(By.xpath("//a[@ng-click='calculatePrices()']")).click();
		SleepUtils.sleep(6);
		
		uiDriver.click("WElement_EditRentalPage_VehicleDriverHistoryNumber");
		uiDriver.click("WElement_EditRentalPage_VehicleDriverHistoryNumber");
		uiDriver.click("WElement_EditRentalPage_VehicleDriverHistoryNumber");
		SleepUtils.sleep(2);
		WebElement OkDropdown = uiDriver.webDr.findElement(By.xpath("(//div[@ng-repeat='item in options']/button[contains(text(),'OK')]/../button[2]/span[@class='caret'])[2]"));
		jse.executeScript("arguments[0].scrollIntoView(true);", OkDropdown);
		//uiDriver.click("DailyPlanning_OkButtonDropdown");
		SleepUtils.sleep(2);
		uiDriver.webDr.findElement(By.xpath("(//div[@ng-repeat='item in options']/button[contains(text(),'OK')]/../button[2]/span[@class='caret'])[2]")).click();
		if (uiDriver.checkElementPresent("DailyPlanning_OkButtonDropdown_BulkUpdate")){
			SleepUtils.sleep(2);
			uiDriver.webDr.findElement(By.xpath("//a[contains(text(),'Bulk update')]")).click();	
		}
		else{
			
			uiDriver.webDr.findElement(By.xpath("(//div[@ng-repeat='item in options']/button[contains(text(),'OK')]/../button[2]/span[@class='caret'])[2]")).click();
			SleepUtils.sleep(2);
			uiDriver.webDr.findElement(By.xpath("//a[contains(text(),'Bulk update')]")).click();
		}
		
		
		//uiDriver.click("DailyPlanning_OkButtonDropdown_BulkUpdate");
		passed("Bulk Update", "Bulk Update should be Clicked", "Bulk Update is Clicked");
		SleepUtils.sleep(4);
		uiDriver.webDr.findElement(By.xpath("//label[contains(text(),'All next daily activities')]/../../input")).click();
		//uiDriver.click("DailyPlanning_Allnextdailyactivities");
		SleepUtils.sleep(2);
		passed("Allnextdailyactivities", "Allnextdailyactivities should be Clicked", "Allnextdailyactivities is Clicked");
		uiDriver.webDr.findElement(By.xpath("(//button[contains(text(),'OK')])[3]")).click();
		//uiDriver.click("DailyPlanning_OkButton");
		passed("Ok Button", "Ok Button should be Clicked", "Ok Button is Clicked");
		*/
	}
	public void ClickOnPlanningGeneratePlanning(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(10);
			uiDriver.click("WBtn_Planning_GeneratePlanning");
			SleepUtils.sleep(60);
				passed("Generate Planning", "Generate Planning should be Clicked", "Generate Planning is Clicked");
			if (uiDriver.checkElementPresent("DailyPlanning_CalenderItems"))
			{
				passed("Calender items", "Calender items Should be displayed", "Calender items are displayed");
			} 
			else
			{
				uiDriver.click("WBtn_Planning_GeneratePlanning");
				SleepUtils.sleep(60);
			}
			
			uiDriver.click("WElement_PlanningCalender_PlanningType");
			
			//uiDriver.click("DailyPlanning_CalenderItems");
			JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
			jse.executeScript("window.scrollBy(0,-250)", ""); 	
			SleepUtils.sleep(15);	
			
			WebElement popup = uiDriver.webDr.findElement(By.xpath("//div/div/u"));
			List<WebElement> eleList = uiDriver.webDr.findElements(By.xpath("//div/div/u"));
			if (eleList.size() == 1)
			{
				popup.click();
				SleepUtils.sleep(3);
			}
			
			Actions action = new Actions(uiDriver.webDr);
			WebElement Mousehover = uiDriver.webDr.findElement(By.xpath("//button[contains(text(),'OK')]"));
			action.moveToElement(Mousehover).perform();
			SleepUtils.sleep(3);
			uiDriver.click("DailyPlanning_CalenderItems_EditDetails");
			SleepUtils.sleep(6);
			String Location = input.get("Location");
			String TaxPercent = input.get("TaxPercent");
			//uiDriver.click("DailyPlanning_TaxTextValue");
			WebElement inputField = uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]"));
			jse.executeScript("arguments[0].scrollIntoView(true);", inputField);
			
			SleepUtils.sleep(6);
			//uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(Keys.BACK_SPACE);
			if(Location.equalsIgnoreCase("UniversalCity"))
			{SleepUtils.sleep(5);
			//jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].click()");
			//jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].value=�Avinash Mishra�;");
			  //jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].value='Avinash Mishra';");
			  	//jse.executeScript("arguments[0].setAttribute('value', '" + TaxPercent +"')", inputField);
			uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
			SleepUtils.sleep(5);
				/*uiDriver.setValue("DailyPlanning_TaxTextValue", "0");
				SleepUtils.sleep(2);*/
			}
			SleepUtils.sleep(2);
			if(Location.equalsIgnoreCase("New Mexico"))
			{
				SleepUtils.sleep(5);
				uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
				SleepUtils.sleep(5);
			}
			SleepUtils.sleep(2);
			if(Location.equalsIgnoreCase("New York"))
			{
				SleepUtils.sleep(5);
				uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
				//jse.executeScript("document.getElementsByClassName('k-formatted-value form-control ng-pristine ng-untouched ng-valid k-input')[76].value='Avinash Mishra';");
				  SleepUtils.sleep(5);
			}
			SleepUtils.sleep(2);
			if(Location.equalsIgnoreCase("Chicago"))
			{
				SleepUtils.sleep(5);
				uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
				SleepUtils.sleep(5);
			}
			SleepUtils.sleep(2);
			if(Location.equalsIgnoreCase("Atlanta"))
			{
				SleepUtils.sleep(5);
				uiDriver.webDr.findElement(By.xpath("//input[@kendo-numeric-text-box='vat']/../input[1]")).sendKeys(TaxPercent);
				SleepUtils.sleep(5);
			}
			passed("Tax Percentage", "Tax Percentage should be entered", "Tax Percentage is entered");
			SleepUtils.sleep(5);
			//jse.executeScript("window.scrollBy(0,-250)", ""); 
			WebElement Calculate = uiDriver.webDr.findElement(By.xpath("//a[@ng-click='calculatePrices()']"));
			//jse.executeScript("arguments[0].scrollIntoView(true);", Calculate);
			SleepUtils.sleep(6);
			//uiDriver.click("DailyPlanning_CalculatePrices");
			uiDriver.webDr.findElement(By.xpath("//a[@ng-click='calculatePrices()']")).click();
			SleepUtils.sleep(6);
			
			uiDriver.click("WElement_EditRentalPage_VehicleDriverHistoryNumber");
			uiDriver.click("WElement_EditRentalPage_VehicleDriverHistoryNumber");
			uiDriver.click("WElement_EditRentalPage_VehicleDriverHistoryNumber");
			SleepUtils.sleep(2);
			WebElement OkDropdown = uiDriver.webDr.findElement(By.xpath("(//div[@ng-repeat='item in options']/button[contains(text(),'OK')]/../button[2]/span[@class='caret'])[2]"));
			jse.executeScript("arguments[0].scrollIntoView(true);", OkDropdown);
			//uiDriver.click("DailyPlanning_OkButtonDropdown");
			SleepUtils.sleep(2);
			uiDriver.webDr.findElement(By.xpath("(//div[@ng-repeat='item in options']/button[contains(text(),'OK')]/../button[2]/span[@class='caret'])[2]")).click();
			if (uiDriver.checkElementPresent("DailyPlanning_OkButtonDropdown_BulkUpdate")){
				SleepUtils.sleep(2);
				uiDriver.webDr.findElement(By.xpath("//a[contains(text(),'Bulk update')]")).click();	
			}
			else{
				
				uiDriver.webDr.findElement(By.xpath("(//div[@ng-repeat='item in options']/button[contains(text(),'OK')]/../button[2]/span[@class='caret'])[2]")).click();
				SleepUtils.sleep(2);
				uiDriver.webDr.findElement(By.xpath("//a[contains(text(),'Bulk update')]")).click();
			}
			
			
			//uiDriver.click("DailyPlanning_OkButtonDropdown_BulkUpdate");
			passed("Bulk Update", "Bulk Update should be Clicked", "Bulk Update is Clicked");
			SleepUtils.sleep(4);
			uiDriver.webDr.findElement(By.xpath("//label[contains(text(),'All next daily activities')]/../../input")).click();
			//uiDriver.click("DailyPlanning_Allnextdailyactivities");
			SleepUtils.sleep(2);
			passed("Allnextdailyactivities", "Allnextdailyactivities should be Clicked", "Allnextdailyactivities is Clicked");
			uiDriver.webDr.findElement(By.xpath("(//button[contains(text(),'OK')])[3]")).click();
			//uiDriver.click("DailyPlanning_OkButton");
			passed("Ok Button", "Ok Button should be Clicked", "Ok Button is Clicked");
			
		}
	/****************************************
	 * Name: ClickOnInvoiceProposalTab
	 * Description: ClickOnInvoiceProposalTab
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnInvoiceProposalTab(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(10);
		uiDriver.click("WElement_ClickOnInvoiceProposalTab");
		SleepUtils.sleep(10);
	}
	/****************************************
	 * Name: VerifyPlanningCalenderDetails
	 * Description: VerifyPlanningCalenderDetails
	 * Date: 18-Oct-2017
	 * @throws InterruptedException 
	 ****************************************/
	public void VerifyPlanningCalenderDetails(DataRow input, DataRow output) throws InterruptedException {
		
		SleepUtils.sleep(45);
	/*String PlanningType = uiDriver.getValue("WElement_PlanningCalender_PlanningType");
	String PlanningTime = uiDriver.getValue("WElement_PlanningCalender_PlanningTime");
	String VehicleNumber = uiDriver.getValue("WElement_PlanningCalender_VehicleNumber");*/
	String Amount = uiDriver.getValue("WElement_PlanningCalender_Amount");
		
	if(Amount.equalsIgnoreCase("0"))
	{
		uiDriver.click("WElement_PlanningCalender_PlanningType");
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[25].click()");
		SleepUtils.sleep(2);
	    // ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[11].click()");
	    uiDriver.click("WElement_SelectPriceTemplate");
	    uiDriver.click("WElement_ClickPlanningBulkUpdate");
	    uiDriver.click("WElement_PlanningBulkUpdate");
	    SleepUtils.sleep(2);
	    uiDriver.click("WElement_PlanningBulkUpdate_AllRadioBtn");
	    uiDriver.click("WElement_PlanningBulkUpdate_OKBtn");
	    SleepUtils.sleep(2);
	    String Amount1 = uiDriver.getValue("WElement_PlanningCalender_Amount");
	    if(Amount1 != "0")
	    {
			passed("Verify Amount", "Amount should not be equal to 0", "Amount is not  equal to 0");
		} 
		else
		{
			failed("Verify Amount", "Amount should not be equal to 0", "Amount is equal to 0");
		}
	}
	
	/*if(uiDriver.checkElementPresent("WElement_EditDeal_PlanningCalenderDateDetails"))
	{
		passed("Planning calender page", "Planning calender date page should be displayed", "Planning calender date page should be displayed with proper details");
	} 
	else
	{
		failed("Planning calender page", "Planning calender date page should be displayed", "Planning calender date page is not displayed with proper details");
	}
	
	if(uiDriver.checkElementPresent("WElement_EditDeal_PlanningCalenderDateDetails1"))
	{
		passed("Planning calender page", "Planning calender date page should be displayed", "Planning calender date page should be displayed with proper details");
	} 
	else
	{
		failed("Planning calender page", "Planning calender date page should be displayed", "Planning calender date page is not displayed with proper details");
	}*/
	JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	jse.executeScript("window.scrollBy(0,-250)", ""); 	
	SleepUtils.sleep(15);
	 uiDriver.click("WElement_PlanningCalender_OK_Btn");
	 passed("Ok Button", "Ok Button should be Clicked", "Ok Button is Clicked");
	 SleepUtils.sleep(45);
	/* uiDriver.click("WElement_AddPlanningList");
	Thread.sleep(4000);*/
	 uiDriver.click("WElement_createdPlanning");
	 SleepUtils.sleep(20);
	 String planningNumber = uiDriver.getValue("WElement_EditRentalPage_VehicleDriverHistoryNumber");
	 //output.put("planningNumber", planningNumber);
	 SleepUtils.sleep(3);
	 output.put("planningNumber", planningNumber);
	 SleepUtils.sleep(3);
	 uiDriver.click("WElement_PushEntireContractToInvoiceProposal");
	 SleepUtils.sleep(10);
	Alert alert = uiDriver.webDr.switchTo().alert();
	alert.accept();
	SleepUtils.sleep(30);
	passed("Push Entire Contract To Invoice Proposal Button", "Push Entire Contract To Invoice Proposal Button should be Clicked", "Push Entire Contract To Invoice Proposal Button is Clicked");
	SleepUtils.sleep(60);
	
	}
	
	
	
	
	/****************************************
	 * Name: VerifyPlanningHistory
	 * Description: VerifyPlanningHistory
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void VerifyOnPlanningHistoryTabInEditDealPage(DataRow input, DataRow output) throws InterruptedException {
	
		String planningNumber = input.get("planningNumber");
		uiDriver.setValue("WElement_EditDealPage_PlanningHistoryTab_SearchBox", planningNumber);
			passed("Number in search field", "Number should be Entered in search field", "Number is Entered in search field");
		SleepUtils.sleep(4);
		//uiDriver.click("WElement_EditDealPage_PlanningHistoryTab_SearchedResult");
		
		//String expCustomerType = input.get("Customertype");
		
		String actplanningNumber = uiDriver.getValue("WElement_EditDealPage_PlanningHistoryTab_SearchedResult");
		if(planningNumber.equalsIgnoreCase(actplanningNumber))
		{
			passed("Verify planning Number","planning Number should be '"+planningNumber+"'","planning Number is displayed as '"+actplanningNumber+"'");
		}
		else
		{
			failed("Verify planning Number","planning Number should be '"+planningNumber+"'","planning Number is displayed as '"+actplanningNumber+"'");
		}
	
	}
	
	/****************************************
	 * Name: ClickOnAddButtonInPlanningScheduleBillingTab
	 * Description: ClickOnAddButtonInPlanningScheduleBillingTab
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void ClickOnAddButtonInPlanningScheduleBillingTab(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(4);
		uiDriver.click("WElement_Planning_ScheduledBilling_Add");
		SleepUtils.sleep(4);
		
		if(uiDriver.checkElementPresent("WSubMenu_EditDeals_GeneralTab"))
		{
			passed("General tab in Scheduled Billing Page", "General tab in Scheduled Billing Page should be displayed", "General tab in Scheduled Billing Page is displayed");
		} 
		else
			
		{
			failed("General tab in Scheduled Billing Page", "General tab in Scheduled Billing Page should be displayed", "General tab in Scheduled Billing Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_Planning_ScheduledBillingPage_PaymentTab"))
		{
			passed("Payment tab in Scheduled Billing Page", "Payment tab in Scheduled Billing Page should be displayed", "Payment tab in Scheduled Billing Page is displayed");
		} 
		else
		{
			failed("Payment tab in Scheduled Billing Page", "Payment tab in Scheduled Billing Page should be displayed", "Payment tab in Scheduled Billing Page is not displayed");
		}
		
		if(uiDriver.checkElementPresent("WElement_Planning_ScheduledBillingPage_RecurringTab"))
		{
			passed("Recurring tab in Scheduled Billing Page", "Recurring tab in Scheduled Billing Page should be displayed", "Recurring tab in Scheduled Billing Page is displayed");
		} 
		else
		{
			failed("Recurring tab in Scheduled Billing Page", "Recurring tab in Scheduled Billing Page should be displayed", "Recurring tab in Scheduled Billing Page is not displayed");
		}
		
	}
	
	public void AddDetailsForScheduledBillingGeneralTab(DataRow input, DataRow output) throws InterruptedException {
		
		Date date = new Date();
		String startDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
		
		uiDriver.setValue("WElement_Planning_ScheduledBillingPage_GeneralTab_Invoicedate", startDate);
		SleepUtils.sleep(2);
			passed("Invoice Date", "Invoice Date Should display correctly", "Invoice Date is displayed correctly");
		
		
		
	}
	
	public void AddScheduledBillingPaymentTab(DataRow input, DataRow output) throws InterruptedException {
			
		SleepUtils.sleep(4);
		uiDriver.click("WElement_Planning_ScheduledBillingPage_PaymentTab");
		SleepUtils.sleep(4);
				passed("Payment Details tab", "Payment Details tab should be clicked", "Payment Details tab is clicked");
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click();");
		SleepUtils.sleep(10);
		//uiDriver.click("WElement_SelectCategory");
		String Pricetemplate = input.get("SelectPricetemplate");
		String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
	    String SelectPriceTemplate = Category.replace("#",Pricetemplate);
	    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(SelectPriceTemplate);
	    SleepUtils.sleep(4);
			passed("Select Price Template", "Select Price Template Should Select correctly", "Select Price Template is Selected correctly");
			
		uiDriver.click("WElement_Planning_ScheduledBillingPage_PaymentTab_CalculatePrices");
		
		SleepUtils.sleep(8);
		uiDriver.click("WElement_Planning_ScheduledBillingPage_SaveButton");
		SleepUtils.sleep(10);
		String planningNumber = uiDriver.getValue("WElement_EditRentalPage_MonthlyRateNumber");
		output.put("planningNumber", planningNumber);	
		 uiDriver.click("WElement_PushEntireContractToInvoiceProposal");
		 
			Alert alert = uiDriver.webDr.switchTo().alert();
			alert.accept();
			SleepUtils.sleep(30);
		}
	
	public void NavigateToReporting(DataRow input, DataRow output) throws InterruptedException {

		uiDriver.click("WSubMenu_Reporting");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WSubMenu_Reporting_InvoiceProposalApprovalQueue"))
		{
			passed("Reports page", "Should display Reports Page", "Reports Page displayed successfully");
		} 
		else
		{
			failed("Reports page", "Should display Reports Page", "Reports Page is not displayed");
		}
	}
	
	public void ClickInvoiceProposalApprovalQueue(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(10);
		uiDriver.click("WSubMenu_Reporting_InvoiceProposalApprovalQueue");
		SleepUtils.sleep(30);
		if(uiDriver.checkElementPresent("WSubMenu_InvoiceProposalApprovalQueuePage"))
		{
			passed("Invoice Proposal Approval Queue page", "Should display Invoice Proposal Approval Queue Page", "Invoice Proposal Approval Queue Page displayed successfully");
		} 
		else
		{
			failed("Invoice Proposal Approval Queue page", "Should display Invoice Proposal Approval Queue Page", "Invoice Proposal Approval Queue Page is not displayed");
		}	
	}
	public void EnterPlanningNumberInvoiceProposalPage(DataRow input, DataRow output) throws InterruptedException {

		String planningNumber = input.get("planningNumber");
		uiDriver.setValue("WSubMenu_Reporting_InvoiceProposalApprovalQueuePage_SearchBox", planningNumber);
		SleepUtils.sleep(40);
		String actplanningNumber = uiDriver.getValue("WElement_EditDealPage_PlanningHistoryTab_SearchedResult"); 
		if(planningNumber.equalsIgnoreCase(actplanningNumber))
		{
			passed("Verify planning Number","planning Number should be '"+planningNumber+"'","planning Number is displayed as '"+actplanningNumber+"'");
		}
		else
		{
			failed("Verify planning Number","planning Number should be '"+planningNumber+"'","planning Number is displayed as '"+actplanningNumber+"'");
		}
		
		
	}
	
	public void ClickOnAcceptAndCombine(DataRow input, DataRow output) throws InterruptedException {
		String planningNumber = input.get("planningNumber");
		uiDriver.click("WElement_EditDealPage_PlanningHistoryTab_SearchedResult");
		SleepUtils.sleep(45);
		uiDriver.click("WSubMenu_Reporting_InvoiceProposalApprovalQueuePage_Acceptandcombine");
		SleepUtils.sleep(45);
		/*String actplanningNumber = uiDriver.getValue("WElement_EditDealPage_PlanningHistoryTab_SearchedResult"); 
		if(planningNumber.equalsIgnoreCase(actplanningNumber))
		{
			failed("Accept and Combine", "Accept and Combine should be clicked", "Accept and Combine is not clicked");
		} 
		else
		{*/
			passed("Accept and Combine", "Accept and Combine should be clicked", "Accept and Combine is clicked");
		//}
	}
	
	public void NavigateToSettingsGeneral(DataRow input, DataRow output) throws InterruptedException {
		SleepUtils.sleep(4);
		uiDriver.click("WSubMenu_Setting");
		SleepUtils.sleep(4);
		uiDriver.click("WSubMenu_Setting_General");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WSubMenu_Setting_General_GeneralSettingsPage"))
		{
			passed("General Settings page", "Should display General Settings Page", "General Settings Page displayed successfully");
		} 
		else
		{
			failed("General Settings page", "Should display General Settings Page", "General Settings Page is not displayed");
		}
			String testMail = input.get("TestMail");
			uiDriver.setValue("WSubMenu_Setting_General_GeneralSettingsPage_TestingMailId", testMail);
			SleepUtils.sleep(4);
			
			String actTestMail = uiDriver.getValue("WSubMenu_Setting_General_GeneralSettingsPage_TestingMailId");
			/*if(testMail.equalsIgnoreCase(actTestMail))
			{*/
				passed("Verify Testing Mail Address","Testing Mail Address should be '"+testMail+"'","Testing Mail Address is displayed as '"+actTestMail+"'");
			/*}
			else
			{
				failed("Verify Testing Mail Address","Testing Mail Address should be '"+testMail+"'","Testing Mail Address is displayed as '"+actTestMail+"'");
			}*/
				uiDriver.click("WSubMenu_GeneralSettingsPage_Locationtab");
				
	}
	
		public void NavigateToInterfaces(DataRow input, DataRow output) throws InterruptedException {

			uiDriver.click("WSubMenu_Interfaces");
			SleepUtils.sleep(10);
			if(uiDriver.checkElementPresent("WSubMenu_Interfaces_Page"))
			{
				passed("Interfaces page", "Should display Interfaces Page", "Interfaces Page displayed successfully");
			} 
			else
			{
				failed("Interfaces page", "Should displaye Interfaces Page", "Interfaces Page is not displayed");
			}
		}
			
		public void GenerateNewExport(DataRow input, DataRow output) throws InterruptedException {
			SleepUtils.sleep(4);
			uiDriver.click("WElement_Interfaces_GenerateNewExport_Button");
				passed("Generate New Export button", "Generate New Export button should be clicked", "Generate New Export button is clicked");
			SleepUtils.sleep(4);
			uiDriver.click("WSubMenu_Invoicing");
			SleepUtils.sleep(6);
			uiDriver.setValue("WSubMenu_Invoicing_InvoiceTab_SearchInvoices", input.get("DealNumber"));
			SleepUtils.sleep(6);
			String ExportStatus = uiDriver.getValue("WSubMenu_Invoicing_InvoiceTab_Exported_Status");
			if(ExportStatus.equalsIgnoreCase("Yes"))
			{
				passed("Verify Exported Status","Exported Status should be Yes","Exported Status is displayed as Yes");
			}
			else
			{
				failed("Verify Exported Status","Exported Status should be Yes","Exported Status is not displayed as Yes");
			}
	
		}
		
		public void CreditInvoice(DataRow input, DataRow output) throws InterruptedException {
			SleepUtils.sleep(4);
			String InvoiceNumber1 = uiDriver.getValue("WSubMenu_Invoices_FirstTransaction");
			uiDriver.click("WSubMenu_Invoices_FirstTransaction");
			
			SleepUtils.sleep(4);
			/*if(uiDriver.checkElementPresent("WSubMenu_EditInvoice_ContractNumber_EditButton"))
			{
				passed("Contract number", "Contract number Should be editable", "Contract number is editable");
			} 
			else
			{
				failed("Contract number", "Contract number Should be editable", "Contract number is not editable");
			}*/
			SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WSubMenu_EditInvoice_Credit_Button"))
			{
				passed("Credit Button", "Credit Button Should be displayed", "Credit Button is displayed");
			} 
			else
			{
				failed("Credit Button", "Credit Button Should be displayed", "Credit Button is not displayed");
			}
			uiDriver.click("WSubMenu_EditInvoice_Credit_Button");
			SleepUtils.sleep(2);
			Alert alert = uiDriver.webDr.switchTo().alert();
			 alert.accept();
			 SleepUtils.sleep(12);
			 //String InvoiceNumber = uiDriver.getValue("WSubMenu_Invoices_FirstTransaction");
			 String CreditInvoiceref= InvoiceNumber1.substring(7, 12);
			 System.out.println(CreditInvoiceref);
			 uiDriver.setValue("WSubMenu_Invoicing_InvoiceTab_SearchInvoices", CreditInvoiceref);
			
			 
			 SleepUtils.sleep(10);
			String InvoiceNumber = uiDriver.getValue("WElement_Invoices_CreditInvoiceFirstTransaction");
				output.put("InvoiceNumber", InvoiceNumber);
			{
				passed("CreditInvoice Number", "Credit Invoice Number should be displayed", "Credit Invoice Number is displayed as "+InvoiceNumber+" ");
			} 
			  
			 
	
		}
		
		/****************************************
		 * Name: saveattachment
		 * Description: saveattachment
		 * Date: 
		 * @throws Exception 
		 ****************************************/
		
		public void saveattachment(DataRow input, DataRow output) throws Exception {
			SleepUtils.sleep(4);
			
			 List<String> dataList = new ArrayList<String>();
			  List<String> fileList = new ArrayList<String>();
			  fileList.addAll(obje.saveAttachments());
			  System.out.println(fileList);
			
		}
		public void ResultsReportingExcel(DataRow input, DataRow output) throws Exception {
			
			String rownum = input.get("ScriptNumber");
			String Customer = input.get("Customer");
			String Deal = input.get("Deal");
			String PlanningType = input.get("PlanningType");
			String Vehicle = input.get("Vehicle");
			String Location = input.get("Location");
			String CostCenter = input.get("CostCenter");
			String Credited = input.get("Credited");
			String InvoiceType = input.get("InvoiceType");
			String OrderNo1 = input.get("OrderNumber");
			String InvoiceNumber = input.get("InvoiceNumber");
			String planningNumber = input.get("planningNumber");
			String TestCaseName = input.get("planningNumber");
			
			Date date = new Date();
			String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
			Date startDate1 = DateUtils.addDays(new Date(),-4);
			String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
			
			
			int rowno = Integer.parseInt(rownum);
			//create an object of Workbook and pass the FileInputStream object into it to create a pipeline between the sheet and eclipse.
			FileInputStream fis = new FileInputStream("C:\\FleetMaster_Automation\\CBF\\Cbf_2.6.1\\New folder\\FleetMasterReporting.xlsx");
			Workbook workbook = new XSSFWorkbook(fis);
			//call the getSheet() method of Workbook and pass the Sheet Name here. 
			//In this case I have given the sheet name as �TestData� 
	                //or if you use the method getSheetAt(), you can pass sheet number starting from 0. Index starts with 0.
			Sheet sheet = workbook.getSheet("Sheet1");
			//XSSFSheet sheet = workbook.getSheetAt(0);
			//Now create a row number and a cell where we want to enter a value. 
			//Here im about to write my test data in the cell B2. It reads Column B as 1 and Row 2 as 1. Column and Row values start from 0.
			//The below line of code will search for row number 2 and column number 2 (i.e., B) and will create a space. 
	                //The createCell() method is present inside Row class.
	        
	        
			String headings[]= {"Sr#","Deal","Customer","Location","Rental StartDate","Rental EndDate","OrderNo","Invoice Number","Planning Type","Planning No","Vehicle","Invoice date","Cost Center","Credited","Invoice Type"};
	        System.out.println(headings.length);
	        FileOutputStream fos = new FileOutputStream("C:\\FleetMaster_Automation\\CBF\\Cbf_2.6.1\\New folder\\FleetMasterReporting.xlsx");
	        if (rowno==1) {
	        Row row = sheet.createRow(0);
	        for(int i=0;i<headings.length;i++) {
	        Cell cell = row.createCell(i);
			//Now we need to  find out the type of the value we want to enter. 
	                //If it is a string, we need to set the cell type as string 
	                //if it is numeric, we need to set the cell type as number
			cell.setCellType(cell.CELL_TYPE_STRING);
			cell.setCellValue(headings[i]);
			
			System.out.println("END OF WRITING DATA IN EXCEL");
	        }
	        
	        }
			Row row1 = sheet.createRow(rowno);
			
		        Cell cell = row1.createCell(0);
				cell.setCellType(cell.CELL_TYPE_STRING);
				cell.setCellValue(rownum);
				
				//row1.createCell(2).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(1).setCellValue(Deal);
				
				//row1.createCell(3).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(2).setCellValue(Customer);
				
				//row1.createCell(4).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(3).setCellValue(Location);
				
				//row1.createCell(5).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(4).setCellValue(startDate);
				
				//row1.createCell(6).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(5).setCellValue(endDate);
				
				//row1.createCell(7).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(6).setCellValue(OrderNo1);
				
				//row1.createCell(8).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(7).setCellValue(InvoiceNumber);
				
				//row1.createCell(9).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(8).setCellValue(PlanningType);
				
				//row1.createCell(10).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(9).setCellValue(planningNumber);
				
				//row1.createCell(11).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(10).setCellValue(Vehicle);
				
				//row1.createCell(12).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(11).setCellValue(endDate);
				
				//row1.createCell(13).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(12).setCellValue(CostCenter);
				
				//row1.createCell(14).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(13).setCellValue(Credited);
				
				//row1.createCell(15).setCellType(cell.CELL_TYPE_STRING);
				row1.createCell(14).setCellValue(InvoiceType);
				
				workbook.write(fos);
				fos.close();
				
				/*FileOutputStream fos1 = new FileOutputStream("C:\\FleetMaster_Automation\\CBF\\Cbf_2.6.1\\New folder\\FleetMasterReporting.xlsx");
		        
				System.out.println("END OF WRITING DATA IN EXCEL");
				
		        workbook.write(fos1);
				fos1.close();*/
		        }
		public void Sphere_CreateDeal(DataRow input, DataRow output) throws Exception {

			
			uiDriver.click("Sphere_DealsMenu");
			/*if (uiDriver.checkElementPresent("Sphere_DashBoardHeading"))
			{
				passed("Deals", "Deals page Should be displayed", "Deals page is displayed");
			} 
			else
			{
				failed("Deals", "Deals page Should be displayed", "Deals page is not displayed");
			}
		*/
			uiDriver.click("Sphere_Deals_AddDeals");
			if (uiDriver.checkElementPresent("Sphere_Deals_AddDealsHeading"))
			{
				passed("Add Deals", "Add Deals page Should be displayed", "Add Deals page is displayed");
			} 
			else
			{
				failed("Add Deals", "Add Deals page Should be displayed", "Add Deals page is not displayed");
			}
			String CostCenter = input.get("CostCenter");
			uiDriver.webDr.findElement(By.xpath("//input[@type='search' and @role='combobox']")).sendKeys(CostCenter);
			uiDriver.webDr.findElement(By.xpath("//div[@class='ui-select-choices-row ng-scope active']/span/span[contains(@ng-bind-html,'costCenterName')]")).click();
			/*uiDriver.click("Sphere_AddDeals_CostCenter");
			uiDriver.setValue("Sphere_AddDeals_CostCenter", CostCenter);
			uiDriver.click("Sphere_AddDeals_CostCenter_SelectCostCenters");
			*/
			passed("CostCenter", "CostCenter Should be Selected", "CostCenter is Selected");
			
			String Customer = input.get("Customer");
			uiDriver.setValue("Sphere_AddDeals_SearchCustomer", Customer);
			
			uiDriver.click("Sphere_AddDeal_CustomerListSearch");
				passed("Customer", "Customer Should be Selected", "Customer is Selected");
			Random rand = new Random();
			int randomNum = rand.nextInt((14999 - 10001) + 1) + 10001;
			String sRandom = String.valueOf(randomNum);
			String sDealTitleRandom = String.valueOf(new SimpleDateFormat("ddMMYYHHmmss").format(new Date()));
			System.out.println(sDealTitleRandom);
			String sDealTitleUI = "AUTOTESTDEAL_"+sDealTitleRandom;
			
			uiDriver.setValue("Sphere_AddDeal_DealTitle", sDealTitleUI);
				passed("Deal Title", "Deal Title Should be entered", "Deal Title is entered");
			
			uiDriver.setValue("Sphere_AddDeal_DealType", "Enabled Savings");
				passed("Deal Type", "Deal Type Should be entered", "Deal Type is entered");
			
			uiDriver.setValue("Sphere_AddDeal_ProjectType", "ALL OF US");
			uiDriver.webDr.findElement(By.xpath("//ul[@class='dropdown-menu ng-isolate-scope']//li[@class='ng-scope active']/a")).click();
				passed("Project Type", "Project Type Should be entered", "Project Type is entered");
			
			uiDriver.click("Sphere_AddDeal_AddContact");
				passed("Add Contact", "Add Contacts should be clicked", "Add Contacts is clicked");
			
			uiDriver.setValue("Sphere_AddDeal_AddContact_FirstName", "Anal");
				passed("First Name", "First Name Should be entered", "First Name is entered");
			
			uiDriver.setValue("Sphere_AddDeal_AddContact_LastName", "Chauhan");
				passed("Last Name", "Last Name Should be entered", "Last Name is entered");
			
			uiDriver.setValue("Sphere_AddDeal_AddContact_Phone", "9876543210");
				passed("Phone Number", "Phone Number Should be entered", "Phone Number is entered");
			
			uiDriver.setValue("Sphere_AddDeal_AddContact_Email", "anal.a.chauhan@nbcuni.com");
				passed("Email", "Email Should be entered", "Email is entered");
			
			uiDriver.click("Sphere_AddDeal_SaveContact");
				passed("Save Contact", "Save Contacts should be clicked", "Save Contacts is clicked");
			String InvoiceFormat= input.get("InvoiceFormat");
			Select selectOption = new Select(uiDriver.webDr.findElement(By.xpath("//div[@class='col-md-6 ng-scope']//select[@name='invoiceFormat' and @ng-model='dealFormCtrl.dealObj.invoiceFormatCodeId']")));
			selectOption.selectByVisibleText(InvoiceFormat);
				passed("Invoice Format", "Invoice Format should select correctly", "Invoice Format is selected correctly");
			
			String Status= input.get("OpenStatus");	
			Select selectOption1 = new Select(uiDriver.webDr.findElement(By.xpath("//select[@name='dealStatus']")));
			selectOption1.selectByVisibleText(Status);
				passed("Status", "Status should select correctly", "Status is selected correctly");
		
			uiDriver.click("Sphere_AddDeal_SaveButton");
			passed("Save Deal", "Save Deal should be clicked", "Save Deal is clicked");
			SleepUtils.sleep(3);
			String SuccessMessage = uiDriver.getValue("Sphere_Success_Message");
			String header[] = SuccessMessage.split(" ");
			//for(WebElement cuslist :CustomerList)
			String DealNumber=header[1];
			output.put("DealNumber", DealNumber);
			
		}
		public void Sphere_SearchDeal(DataRow input, DataRow output) throws InterruptedException {
			String DealNumber=input.get("DealNumber");
			SleepUtils.sleep(2);
			uiDriver.setValue("WElement_DealSearchBox", DealNumber);
			//uiDriver.setValue("WElement_DealSearchBox", "657222");
			
			SleepUtils.sleep(8);
				passed("Deal Number", "Deal Number should be entered in Search Box", "Deal Number is entered in Search Box");
			uiDriver.click("WElement_firstRowDeal");
			SleepUtils.sleep(13);
		}
		
		public void AddOrderDetails(DataRow input, DataRow output) throws InterruptedException {
				
				uiDriver.click("WSubMenu_EditDeals_GeneralTab");
				SleepUtils.sleep(2);
			   Random rand = new Random();
			   String OrderNumber = uiDriver.getValue("WElement_DealPage_OrderNumberfield");
			   if((OrderNumber != null)==true)
			   {
				   passed("Order Number","Order Number field should have a value by default","Order Number field has a value by default");
			   }
			   else
			   {
				   failed("Order Number","Order Number field should have a value by default","Order Number field doesn't a value by default");   
			   }
				int PONumber1 = rand.nextInt((1000000-1)+1000000)+1;
				String PONumber = Integer.toString(PONumber1);
				String Description = "ORDER"+OrderNumber;
				Date date = new Date();
				String startDate1= new SimpleDateFormat("MM/dd/yyyy").format(date);
				Date endDate1 = DateUtils.addDays(new Date(), +4);
				String startDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
				uiDriver.setValue("WElement_DealPage_PONumberfield", PONumber);
					passed("PO Number","PO Number should entered","PO Number is entered");
				uiDriver.setValue("WElement_DealPage_Descriptionfield", Description);
					passed("Description","Description should entered","Description is entered");
				//uiDriver.click("WElement_DealPage_Calender");
				uiDriver.setValue("WElement_DealPage_CalenderDate", startDate);
				Thread.sleep(5000);
				uiDriver.click("WBtn_DealPage_AddOrder");
				Thread.sleep(3000);
					passed("Add Order","Add Order should be clicked","Add Order is clicked");
				output.put("OrderNumber", OrderNumber);
			
				}
		
		public void OrderValidation(DataRow input, DataRow output) throws InterruptedException {
			uiDriver.click("WSubMenu_EditDeals_GeneralTab");
			SleepUtils.sleep(2);
		   Random rand = new Random();
		   String OrderNumber = uiDriver.getValue("WElement_DealPage_OrderNumberfield");
		   if((OrderNumber != null)==true)
		   {
			   passed("Order Number","Order Number field should have a value by default","Order Number field has a value by default");
		   }
		   else
		   {
			   failed("Order Number","Order Number field should have a value by default","Order Number field doesn't a value by default");   
		   }
		   int lenghtofOrder=OrderNumber.length();
		   if (lenghtofOrder==3){
			   passed("Order Number","Order Number should be 3 digits","Order Number is 3 digits");
		   }
		   else
		   {
			   failed("Order Number","Order Number should be 3 digits","Order Number is not 3 digits");
		   }
		   
			uiDriver.click("WBtn_DealPage_AddOrder");
			Thread.sleep(3000);
				passed("Add Order","Add Order should be clicked","Add Order is clicked");
				passed("Order Number","Order should get created","Order is created");
				String OrderNumber1 = uiDriver.getValue("WElement_OrderNumber");
				int ordernum= Integer.parseInt(OrderNumber1);
				   
				   if (ordernum < 100)
				   {
					   String header[] = OrderNumber1.split("");
					   String StartingNumber=header[0];
					   if (StartingNumber.equals("0"))
					   {
						   passed("Order Number","Order Number field should start with 0 if it is less than 100","Order Number field is started with 0");
						}
					   else
					   {
						   failed("Order Number","Order Number field should start with 0 if it is less than 100","Order Number field is not started with 0");
					   }
				   }
			 uiDriver.click("WBtn_DealPage_AddOrder");
			 Thread.sleep(3000);
			 uiDriver.click("WElement_EditOrderButton");
			 passed("Order Number","Order Number field should be editable","Order Number field is editable");
			 uiDriver.setValue("WElement_DealPage_OrderNumberfield", "002");
			 uiDriver.click("WElement_LockEditOrderButton");
			 String errorMessage1=uiDriver.webDr.findElement(By.xpath("//span[@title='error']/..")).getAttribute("innerHTML");
			   if (errorMessage1.contains("Order number already exists."))
			   {
				   passed("Order Number","Order number already exists message should display","Order number already exists message is displayed");  
			   }
			   else
			   {
				   failed("Order Number","Order number already exists message should display","Order number already exists message is not displayed");
			   }
			 uiDriver.click("WElement_OrderNumber_ErrorMessage");
			 uiDriver.webDr.findElement(By.xpath("(//input[@class='form-control ng-valid ng-dirty ng-valid-parse ng-touched' and @placeholder='Order number'])[1]")).clear();
			 uiDriver.setValue("WElement_OrderNumberField_FirstRow", OrderNumber1);
			 uiDriver.click("WElement_LockEditOrderButton");	 
			 String OrderNumberExceed="7867";
				   uiDriver.setValue("WElement_DealPage_OrderNumberfield", OrderNumberExceed);
				   uiDriver.click("WBtn_DealPage_AddOrder");
					 
				   String errorMessage=uiDriver.webDr.findElement(By.xpath("//span[@title='error']/..")).getAttribute("innerHTML");
				   if (errorMessage.contains("Order number can only have 3 digits."))
				   {
					   passed("Order Number","Order Number should allow 3 digits only","Order Number is allowing 3 digits only");  
				   }
				   else
				   {
					   failed("Order Number","Order Number should allow 3 digits only","Order Number is allowing more then digits only");
				   }
			  uiDriver.click("WElement_OrderNumber_ErrorMessage");
			  uiDriver.setValue("WElement_OrderNumberField_FirstRow", "555");
			  uiDriver.click("WBtn_DealPage_AddOrder");
			  String RecentOrderNumber = uiDriver.getValue("WElement_OrderNumberField_newordernumberfield");
			   if(RecentOrderNumber.equals("003"))
			   {
				   passed("Order Number","Order Number should display with next lowest number","Order Number is displayed with next lowest number");
			   }
			   else
			   {
				   failed("Order Number","Order Number should display with next lowest number","Order Number is not displayed with next lowest number");   
			   } 
			}
		public void OrderMaxValue(DataRow input, DataRow output) throws InterruptedException {
			uiDriver.click("WSubMenu_EditDeals_GeneralTab");
			SleepUtils.sleep(20);
			//for(int i=1;i<=1000;i++)
				for(int i=1;i<=99;i++)
					
			{
					Random rand = new Random();
					   String OrderNumber = uiDriver.getValue("WElement_DealPage_OrderNumberfield");
					   //uiDriver.setValue("//input[@name='PONumber']", "123456");
					   int PONumber1 = rand.nextInt((1000000-1)+1000000)+1;
						String PONumber = Integer.toString(PONumber1);
						String Description = "ORDER"+OrderNumber;
						Date date = new Date();
						String startDate1= new SimpleDateFormat("MM/dd/yyyy").format(date);
						Date endDate1 = DateUtils.addDays(new Date(), +4);
						String startDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
					if(i==1){
						uiDriver.setValue("WElement_DealPage_PONumberfield", PONumber);
						passed("PO Number","PO Number should entered","PO Number is entered");
					uiDriver.setValue("WElement_DealPage_Descriptionfield", Description);
						passed("Description","Description should entered","Description is entered");
					//uiDriver.click("WElement_DealPage_Calender");
					uiDriver.setValue("WElement_DealPage_CalenderDate", startDate);
					Thread.sleep(2000);
					uiDriver.click("WBtn_DealPage_AddOrder");
					Thread.sleep(5000);
					passed("Add Order","Order should be added","Order is added with order number"+i);
					}
					else{
					uiDriver.setValue("WElement_DealPage_PONumberfield1", PONumber);
						passed("PO Number","PO Number should entered","PO Number is entered");
					uiDriver.setValue("WElement_DealPage_Descriptionfield", Description);
						passed("Description","Description should entered","Description is entered");
					//uiDriver.click("WElement_DealPage_Calender");
					uiDriver.setValue("WElement_DealPage_CalenderDate", startDate);
					Thread.sleep(2000);
					uiDriver.click("WBtn_DealPage_AddOrder");
					Thread.sleep(3000);
					Thread.sleep(2000);
				//uiDriver.click("WBtn_DealPage_AddOrder");
				//Thread.sleep(3000);
				passed("Add Order","Order should be added","Order is added with order number"+i);
					}
			}
		}
		public void OrderMaxValue_Main(DataRow input, DataRow output) throws InterruptedException {
			uiDriver.click("WSubMenu_EditDeals_GeneralTab");
			SleepUtils.sleep(20);
			//for(int i=1;i<=1000;i++)
				for(int i=1;i<=99;i++)
					
			{
					//uiDriver.setValue("//input[@name='PONumber']", "123456");
					uiDriver.click("WSubMenu_EditDeals_GeneralTab");
					SleepUtils.sleep(2);
				   Random rand = new Random();
				   String OrderNumber = uiDriver.getValue("WElement_DealPage_OrderNumberfield");
				   if((OrderNumber != null)==true)
				   {
					   passed("Order Number","Order Number field should have a value by default","Order Number field has a value by default");
				   }
				   else
				   {
					   failed("Order Number","Order Number field should have a value by default","Order Number field doesn't a value by default");   
				   }
					int PONumber1 = rand.nextInt((1000000-1)+1000000)+1;
					String PONumber = Integer.toString(PONumber1);
					String Description = "ORDER"+OrderNumber;
					Date date = new Date();
					String startDate1= new SimpleDateFormat("MM/dd/yyyy").format(date);
					Date endDate1 = DateUtils.addDays(new Date(), +4);
					String startDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
					uiDriver.setValue("WElement_DealPage_PONumberfield1", PONumber);
						passed("PO Number","PO Number should entered","PO Number is entered");
					uiDriver.setValue("WElement_DealPage_Descriptionfield1", Description);
						passed("Description","Description should entered","Description is entered");
					//uiDriver.click("WElement_DealPage_Calender");
					//uiDriver.setValue("WElement_DealPage_CalenderDate1", startDate);
					Thread.sleep(5000);
					uiDriver.click("WBtn_DealPage_AddOrder");
					Thread.sleep(3000);
					Thread.sleep(2000);
				//uiDriver.click("WBtn_DealPage_AddOrder");
				Thread.sleep(3000);
				passed("Add Order","Order should be added","Order is added with order number"+i);
				String value= String.valueOf(i);
				String ExpectedOrderNumber;
				String xpathOrderNumber= "(//tr/td/label[@ng-show='item.mandateId && !item.editMode'])[#]";
				String xpath1 = xpathOrderNumber.replace("#", value);
				String OrderNumber1 =  uiDriver.webDr.findElement(By.xpath(xpath1)).getText();
				
				if (i<100)
				{
					if (value.length()<2)
					{
						ExpectedOrderNumber="00"+value;
					}
					else
					{
						ExpectedOrderNumber="0"+value;
					}
					if(ExpectedOrderNumber.equals(OrderNumber1))
					{
						passed("Order Number","Order Numbers should be created subsequently","Order Numbers created subsequently"+i);
					}
					else
					{
						failed("Order Number","Order Numbers should be created subsequently","Order Numbers are not created subsequently"+i);
					}
				}
				if (((i>=100))==true){
					if(value.equals(OrderNumber1))
					{
						passed("Order Number","Order Numbers should be created subsequently","Order Numbers created subsequently"+i);
					}
					else
					{
						failed("Order Number","Order Numbers should be created subsequently","Order Numbers are not created subsequently"+i);
					}
				}
				//need to check the error message
				if(i==1000)
				{
					passed("Add Order","Order should be added","Order is added with order number"+i);
				}
			}
			
			List<WebElement> OrderNumber = uiDriver.webDr.findElements(By.xpath("//tr/td/label[@ng-show='item.mandateId && !item.editMode']"));
			Set<String> Orders=new LinkedHashSet<String>();
			int count=OrderNumber.size();
			for(int k=1;k<=999;k++)
			{
				Orders.add(OrderNumber.get(k).getText());
			}
			
			int setCount = Orders.size();
			if(count==setCount) 
			{
				passed("Order numbers","Order numbers should be unique","Order numbers are unique");
			}
			else
			{
				failed("Order numbers","Order numbers should be unique","Order numbers are  not unique");
			}
		}
		
public void Sphere_CloseDeal(DataRow input, DataRow output) throws Exception {

			
			uiDriver.click("Sphere_DealsMenu");
			/*if (uiDriver.checkElementPresent("Sphere_DashBoardHeading"))
			{
				passed("Deals", "Deals page Should be displayed", "Deals page is displayed");
			} 
			else
			{
				failed("Deals", "Deals page Should be displayed", "Deals page is not displayed");
			}
		*/
			uiDriver.click("Sphere_Deals_AddDeals");
			if (uiDriver.checkElementPresent("Sphere_Deals_AddDealsHeading"))
			{
				passed("Add Deals", "Add Deals page Should be displayed", "Add Deals page is displayed");
			} 
			else
			{
				failed("Add Deals", "Add Deals page Should be displayed", "Add Deals page is not displayed");
			}
			String DealNumber=input.get("DealNumber");
			SleepUtils.sleep(2);
			
	}
public void AddPlanningDetails1(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	
	String OrderNo1 = input.get("OrderNumber");
	String OrderNo = "ORDER"+OrderNo1;
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
	SleepUtils.sleep(2);
	String typee = input.get("selectType");
	String type = uiDriver.getDyanmicData("WElement_SelectType");
    String type1 = type.replace("#",typee);
    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(type1);
	//uiDriver.click("WElement_SelectType");
	   SleepUtils.sleep(2);
		
		passed("Type", "Type Should display correctly", "Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
	// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[16].click()");
	SleepUtils.sleep(2);
	String selectPlanningType2 = input.get("selectPlanningType");
	String SelectPlanningType = uiDriver.getDyanmicData("WElement_SelectPlanningType");
    String SelectPlanningType1 = SelectPlanningType.replace("#",selectPlanningType2);
    SleepUtils.sleep(2);
    uiDriver.click_dynamic(SelectPlanningType1);
	//uiDriver.click("WElement_SelectPlanningType") ;
    SleepUtils.sleep(2);
		
		passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
	SleepUtils.sleep(3);
	//uiDriver.click("WElement_SelectCategory");
	String Categoryy = input.get("Category");
	String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
    String Category1 = Category.replace("#",Categoryy);
    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(Category1);
	    SleepUtils.sleep(2);
		
		passed("Category", "Category Should display correctly", "Category is displayed correctly");
	

		SleepUtils.sleep(2);
	
	uiDriver.click("Wchkbox_CanOverlap");
	
	String Deal = input.get("DealNumber");
	//((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[10].click()");
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
	SleepUtils.sleep(3);
	//uiDriver.executeJavaScript("document.getElementsByClassName('k-textbox')[14].value='"+Deal+"');");
	uiDriver.setValue("WElement_Planning_SearchDeal", Deal);
	SleepUtils.sleep(6);
	String Deal1 = uiDriver.getDyanmicData("WElement_DealDisplayed");
	//Thread.sleep(4000);
	String DealNum = Deal1.replace("#",Deal);
	SleepUtils.sleep(2);
	    uiDriver.click_dynamic(DealNum);
	    	passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
	SleepUtils.sleep(4);
	
	
	uiDriver.setValue("WElement_Planning_SearchOrder", OrderNo);
	SleepUtils.sleep(6);
	String Order1 = uiDriver.getDyanmicData("WElement_SearchedOrderDisplayed");
	//Thread.sleep(4000);
	String OrderN = Order1.replace("#",OrderNo);
	SleepUtils.sleep(2);
	    
	uiDriver.click_dynamic(OrderN);		
	    	passed("Order", "Order Should display correctly", "Order is displayed correctly");
	    
	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	    jse.executeScript("window.scrollBy(0,450)", "");	
	  	SleepUtils.sleep(3);
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
	//uiDriver.click("WElement_vehicle");
	SleepUtils.sleep(3);
	
	uiDriver.click("WElement_PlanningVehicleNumber");	
		passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
	    
	SleepUtils.sleep(3);
	Date date = new Date();
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
	Date startDate1 = DateUtils.addDays(new Date(),-4);
	
	
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
	
	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
	 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
	 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
	 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
 	SleepUtils.sleep(2);
	
	String SAPType = input.get("SAPType");
	String CostObject = input.get("CostObject");
	String SAPAccount = input.get("SAPAccount");
	if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType"))
	{
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType", SAPType);
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_CostObject", CostObject);
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPAccount", SAPAccount);
	} 
	
	String PerformingCC = uiDriver.getValue("WElement_PlanningPerformingCC");
	String Location = input.get("Location");
	
	if(PerformingCC.equalsIgnoreCase(Location))
	{
		passed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is displayed as "+PerformingCC+"");
	} 
	else
	{
		failed("Planning page performing location", "Planning page performing location should be displayed as "+PerformingCC+"", "Planning page performing location is not displayed as "+PerformingCC+"");
	}
	
	String PerformingCostCenter = uiDriver.getValue("WElement_PlanningPerformingCostCENTER");
	String CostCenter = input.get("Costcenter");
	if(PerformingCostCenter.equalsIgnoreCase(CostCenter))
	{
		passed("Planning page performing cOSTCENTER", "Planning page performing COSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is displayed as "+PerformingCostCenter+"");
	} 
	else
	{
		failed("Planning page performing COSTCENTER", "Planning page performing cOSTCENTER should be displayed as "+CostCenter+"", "Planning page performing cOSTCENTER is not displayed as "+PerformingCostCenter+"");
	}
	  
	  
	jse.executeScript("window.scrollBy(0,-450)", ""); 
	  
	
}

public void OrderCantBeedited(DataRow input, DataRow output) throws InterruptedException, AWTException {

uiDriver.click("WElement_EditOrderButton");
passed("Order Number","Order Number field should be editable","Order Number field is editable");
String errorMessage=uiDriver.webDr.findElement(By.xpath("//span[@title='error']/..")).getAttribute("innerHTML");
if (errorMessage.contains("Cant edit or delete this record because deal is invoiced with this order number"))
{
	   passed("Order Number","Order Number should not be edited","Order Number is not editable");  
}
else
{
	   failed("Order Number","Order Number should not be edited","Order Number is editable");
}
}
public void ValidateActiveProduction(DataRow input, DataRow output) throws InterruptedException, AWTException {
	String value =uiDriver.getValueCheckBox("Sphere_DealsPage_ActiveProduction");
	if(value.equals("Yes"))
	{
		passed("Active Production","Active Production should be checked","Active Production is checked");
	}
	else
	{
		failed("Active Production","Active Production should be checked","Active Production is not checked");
	}
}

public void ValidateDeActiveProduction(DataRow input, DataRow output) throws InterruptedException, AWTException {
	String value =uiDriver.getValueCheckBox("Sphere_DealsPage_ActiveProduction");
	if(value.equals("No"))
	{
		passed("Active Production","Active Production should be checked","Active Production is not checked");
	}
	else
	{
		failed("Active Production","Active Production should be checked","Active Production is checked");
	}
}
public void Sphere_Deals_CloseDeal(DataRow input, DataRow output) throws InterruptedException, AWTException {
	//String Deal = input.get("DealNumber");
	String Deal = "700007";
	uiDriver.click("Sphere_DealsMenu");
	uiDriver.setValue("Sphere_DealsPage_SearchDealText", Deal);
	SleepUtils.sleep(2);
	
	uiDriver.click("Sphere_DealsPage_SerachDeal");
	passed("Deal", "Searched deal should get opened", "Searched deal is opened");
	Select selectOption1 = new Select(uiDriver.webDr.findElement(By.xpath("//select[@name='dealStatus']")));
	selectOption1.selectByVisibleText("Closed");
		passed("Status", "Status should select correctly", "Status is selected correctly");
		uiDriver.click("Sphere_AddDeal_SaveButton");
		passed("Save Deal", "Save Deal should be clicked", "Save Deal is clicked");
		SleepUtils.sleep(3);
}


public void AddPlanningDetailsWithOutEndDat(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	
	String OrderNo1 = input.get("OrderNumber");
	String OrderNo = "ORDER"+OrderNo1;
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
	SleepUtils.sleep(2);
	String typee = input.get("selectType");
	String type = uiDriver.getDyanmicData("WElement_SelectType");
    String type1 = type.replace("#",typee);
    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(type1);
	//uiDriver.click("WElement_SelectType");
	   SleepUtils.sleep(2);
		
		passed("Type", "Type Should display correctly", "Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
	// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[16].click()");
	SleepUtils.sleep(2);
	String selectPlanningType2 = input.get("selectPlanningType");
	String SelectPlanningType = uiDriver.getDyanmicData("WElement_SelectPlanningType");
    String SelectPlanningType1 = SelectPlanningType.replace("#",selectPlanningType2);
    SleepUtils.sleep(2);
    uiDriver.click_dynamic(SelectPlanningType1);
	//uiDriver.click("WElement_SelectPlanningType") ;
    SleepUtils.sleep(2);
		
		passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
	SleepUtils.sleep(3);
	//uiDriver.click("WElement_SelectCategory");
	String Categoryy = input.get("Category");
	String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
    String Category1 = Category.replace("#",Categoryy);
    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(Category1);
	    SleepUtils.sleep(2);
		
		passed("Category", "Category Should display correctly", "Category is displayed correctly");
	

		SleepUtils.sleep(2);
	
	uiDriver.click("Wchkbox_CanOverlap");
	
	String Deal = input.get("DealNumber");
	//((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[10].click()");
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
	SleepUtils.sleep(3);
	//uiDriver.executeJavaScript("document.getElementsByClassName('k-textbox')[14].value='"+Deal+"');");
	uiDriver.setValue("WElement_Planning_SearchDeal", Deal);
	SleepUtils.sleep(6);
	String Deal1 = uiDriver.getDyanmicData("WElement_DealDisplayed");
	//Thread.sleep(4000);
	String DealNum = Deal1.replace("#",Deal);
	SleepUtils.sleep(2);
	    uiDriver.click_dynamic(DealNum);
	    	passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
	SleepUtils.sleep(4);
	
	
	uiDriver.setValue("WElement_Planning_SearchOrder", OrderNo);
	SleepUtils.sleep(6);
	String Order1 = uiDriver.getDyanmicData("WElement_SearchedOrderDisplayed");
	//Thread.sleep(4000);
	String OrderN = Order1.replace("#",OrderNo);
	SleepUtils.sleep(2);
	    
	uiDriver.click_dynamic(OrderN);		
	    	passed("Order", "Order Should display correctly", "Order is displayed correctly");
	    
	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	    jse.executeScript("window.scrollBy(0,450)", "");	
	  	SleepUtils.sleep(3);
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
	//uiDriver.click("WElement_vehicle");
	SleepUtils.sleep(3);
	
	uiDriver.click("WElement_PlanningVehicleNumber");	
		passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
	    
	SleepUtils.sleep(3);
	Date date = new Date();
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
	Date startDate1 = DateUtils.addDays(new Date(),-4);
	
	
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
	
	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
	 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
 	SleepUtils.sleep(2);
 	
 	/*uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
	 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
	 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");*/
 	SleepUtils.sleep(2);
	
	String SAPType = input.get("SAPType");
	String CostObject = input.get("CostObject");
	String SAPAccount = input.get("SAPAccount");
	if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType"))
	{
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType", SAPType);
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_CostObject", CostObject);
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPAccount", SAPAccount);
	} 
	uiDriver.click("Save_Planning");	
	Alert alert = uiDriver.webDr.switchTo().alert();
	alert.accept();
	SleepUtils.sleep(30);
	
}
public void CreateContract(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	
	String OrderNo1 = input.get("OrderNumber");
	String OrderNo = "ORDER"+OrderNo1;
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
	SleepUtils.sleep(2);
	String typee = input.get("selectType");
	String type = uiDriver.getDyanmicData("WElement_SelectType");
    String type1 = type.replace("#",typee);
    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(type1);
	//uiDriver.click("WElement_SelectType");
	   SleepUtils.sleep(2);
		
		passed("Type", "Type Should display correctly", "Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
	// ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-virtual-item k-item')[16].click()");
	SleepUtils.sleep(2);
	String selectPlanningType2 = input.get("selectPlanningType");
	String SelectPlanningType = uiDriver.getDyanmicData("WElement_SelectPlanningType");
    String SelectPlanningType1 = SelectPlanningType.replace("#",selectPlanningType2);
    SleepUtils.sleep(2);
    uiDriver.click_dynamic(SelectPlanningType1);
	//uiDriver.click("WElement_SelectPlanningType") ;
    SleepUtils.sleep(2);
		
		passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
	SleepUtils.sleep(3);
	//uiDriver.click("WElement_SelectCategory");
	String Categoryy = input.get("Category");
	String Category = uiDriver.getDyanmicData("WElement_SearchedCategory");
    String Category1 = Category.replace("#",Categoryy);
    SleepUtils.sleep(2);
	    uiDriver.click_dynamic(Category1);
	    SleepUtils.sleep(2);
		
		passed("Category", "Category Should display correctly", "Category is displayed correctly");
	

		SleepUtils.sleep(2);
	
	uiDriver.click("Wchkbox_CanOverlap");
	
	String Deal = input.get("DealNumber");
	//((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[10].click()");
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
	SleepUtils.sleep(3);
	//uiDriver.executeJavaScript("document.getElementsByClassName('k-textbox')[14].value='"+Deal+"');");
	uiDriver.setValue("WElement_Planning_SearchDeal", Deal);
	SleepUtils.sleep(6);
	String Deal1 = uiDriver.getDyanmicData("WElement_DealDisplayed");
	//Thread.sleep(4000);
	String DealNum = Deal1.replace("#",Deal);
	SleepUtils.sleep(2);
	    uiDriver.click_dynamic(DealNum);
	    	passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
	SleepUtils.sleep(4);
	
	
	uiDriver.setValue("WElement_Planning_SearchOrder", OrderNo);
	SleepUtils.sleep(6);
	String Order1 = uiDriver.getDyanmicData("WElement_SearchedOrderDisplayed");
	//Thread.sleep(4000);
	String OrderN = Order1.replace("#",OrderNo);
	SleepUtils.sleep(2);
	    
	uiDriver.click_dynamic(OrderN);		
	    	passed("Order", "Order Should display correctly", "Order is displayed correctly");
	    
	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	    jse.executeScript("window.scrollBy(0,450)", "");	
	  	SleepUtils.sleep(3);
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
	//uiDriver.click("WElement_vehicle");
	SleepUtils.sleep(3);
	
	uiDriver.click("WElement_PlanningVehicleNumber");	
		passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
	    
	SleepUtils.sleep(3);
	Date date = new Date();
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
	Date startDate1 = DateUtils.addDays(new Date(),-4);
	
	
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
	
	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
	 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
	 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
	 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
 	SleepUtils.sleep(2);
	
	String SAPType = input.get("SAPType");
	String CostObject = input.get("CostObject");
	String SAPAccount = input.get("SAPAccount");
	if(uiDriver.checkElementPresent("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType"))
	{
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPType", SAPType);
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_CostObject", CostObject);
		SleepUtils.sleep(2);
		uiDriver.setValue("WElement_PlanningGeneralTab_PlanningChargenumber_SAPAccount", SAPAccount);
	} 
	uiDriver.click("Save_Planning");	
	Alert alert = uiDriver.webDr.switchTo().alert();
	alert.accept();
	SleepUtils.sleep(30);
	
}
public void CloseContract(DataRow input, DataRow output) throws InterruptedException, AWTException {
	uiDriver.click("WElement_EditDealPage_PlanningHistoryTab_SearchedResult");
	if(uiDriver.checkElementPresent("WElement_PushEntireContractToInvoiceProposal"))
	{
		passed("Bill Through Current Date","Bill Through Current Date should display as Push Entire Contract to invoice proposal","Bill Through Current Date is displayed instead of Push Entire Contract to invoice proposal");
	}
	else
	{
		failed("Bill Through Current Date","Bill Through Current Date should display as Push Entire Contract to invoice proposal","Bill Through Current Date is not displayed instead of Push Entire Contract to invoice proposal");
	}
	
	if(uiDriver.checkElementPresent("Planning_CloseContract"))
	{
		passed("Close Contract","Close Contract button should display","Close Contract button is displayed");
	}
	else
	{
		passed("Close Contract","Close Contract button should display","Close Contract button is not displayed");
	}
	uiDriver.click("Planning_CloseContract");
	Alert alert = uiDriver.webDr.switchTo().alert();
	alert.accept();
	SleepUtils.sleep(3);
	String errorMessage=uiDriver.webDr.findElement(By.xpath("//span[@title='error']/..")).getAttribute("innerHTML");
	if (errorMessage.contains("Cannot close contract without actual end date"))
	{
		   passed("Error message","Error message should display as Cannot close contract without actual end date","Error message is displayed as Cannot close contract without actual end date");  
	}
	else
	{
		failed("Error message","Error message should display as Cannot close contract without actual end date","Error message is displayed as Cannot close contract without actual end date");
	}
	
	
}
public void EditContract(DataRow input, DataRow output) throws InterruptedException, AWTException {
	uiDriver.click("WElement_EditDealPage_PlanningHistoryTab_SearchedResult");
	SleepUtils.sleep(3);
	
	Date date = new Date();
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(date);
	Date startDate1 = DateUtils.addDays(new Date(),-5);
	
	
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Contract", "Contract should be editable", "Contract is editable");
	
}



public void OrderCreationForInactiveDeal(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	uiDriver.click("WBtn_DealPage_AddOrder");
	Thread.sleep(3000);
		passed("Add Order","Add Order should be clicked","Add Order is clicked");

}


public void AddOrderButtondisabled(DataRow input, DataRow output) throws InterruptedException, AWTException {

if(uiDriver.checkElementPresent("AddOrder_button_Disabled"))
{
	passed("Add Order Button", "Add Order Button Should be disabled for inactive deal", "Add Order Button is disabled for inactive deal");
} 
else
{
	failed("Add Order Button", "Add Order Button Should be disabled for inactive deal", "Add Order Button is not disabled for inactive deal");
}
}







public void NavigateToVehicles(DataRow input, DataRow output) throws InterruptedException {
	
	uiDriver.click("Vehicle_Mainmenu");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("WElement_VehiclesPage"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
}

public void EditVehicles(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	uiDriver.click("Vehicle00057");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
		
		uiDriver.click("Tiresets");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("Vehiclepage00057"))
		{
			passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
		} 
		else
		{
			failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
		}
			
			uiDriver.click("Addbutton");
			SleepUtils.sleep(4);
				if(uiDriver.checkElementPresent("Vehiclepage00057"))
			{
				passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
			} 
			else
			{
				failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
			}
				
				uiDriver.click("GeneralElement");
				SleepUtils.sleep(4);
					if(uiDriver.checkElementPresent("Vehiclepage00057"))
				{
					passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");	
				} 
				else
				{
					failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
				}
					
					uiDriver.click("Vehiclename");
					SleepUtils.sleep(4);
						if(uiDriver.checkElementPresent("Vehiclepage00057"))
					{
						passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
						uiDriver.setValue("Vehiclename", "TEst");
						//	uiDriver.sendKey("Hello");
						//String OrderNo1 = input.get("OrderNumber");
					} 
					else
					{
						failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
					}
						((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
						SleepUtils.sleep(2);
						//String typee = "Both";
						//String type = uiDriver.getDyanmicData("WElement_SelectType");
						//String type = "(//li[contains(text(),'Both')])[1]";
						
					   //String type1 = type.replace("#",typee);
					    SleepUtils.sleep(2);
				 	    uiDriver.click_dynamic("(//li[contains(text(),'Both')])[1]");
						//uiDriver.click("WElement_SelectType");
				 	   SleepUtils.sleep(2);
							
							passed("Position", "Position Should display correctly", "Position is displayed correctly");
						/*WebElement position = uiDriver.webDr.findElement(By.xpath("//span[@class='k-input'])[3]"));
					     
						position.click();
					    WebElement Back = uiDriver.webDr.findElement(By.xpath("(//li[@data-offset-index='1'])[3]"));
					    Back.click();*/ 
					/*	uiDriver.click("Position");
						SleepUtils.sleep(4);
						Select position = new Select(uiDriver.webDr.findElement(By.xpath("(//span[@class='k-input'])[3])")));
						position.selectByVisibleText("Back");
		                position.selectByIndex(1);
						/*Robot r = new Robot();(//span[@class='k-input'])[3]
						r.keyPress(KeyEvent.VK_DOWN);
						r.keyRelease(KeyEvent.VK_DOWN);
						r.keyPress(KeyEvent.VK_ENTER);
						r.keyRelease(KeyEvent.VK_ENTER);
						
							if(uiDriver.checkElementPresent("Vehiclepage00057"))
						{
							passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
						} 
						else
						{
							failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
						}*/
							
							uiDriver.click("Numberoftires");
							SleepUtils.sleep(4);
								if(uiDriver.checkElementPresent("Vehiclepage00057"))
							{
								passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
								uiDriver.click("Numberoftiresup");

							} 
							else
							{
								failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
							}
								
								uiDriver.click("Active");
								SleepUtils.sleep(4);
									if(uiDriver.checkElementPresent("Vehiclepage00057"))
								{
									passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
								} 
								else
								{
									failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
								}
									
									
									
									uiDriver.click("Assettype");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
										uiDriver.setValue("Assettypeinput", "TEST");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}
									
									
								/*	uiDriver.click("Loadfromtemplate");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
										uiDriver.setValue("Loadfromtemplateinput", "TEST");
										Robot r = new Robot();
										r.keyPress(KeyEvent.VK_ENTER);
										r.keyRelease(KeyEvent.VK_ENTER);
									//	uiDriver.click("Loadfromtemplateinput_select");

									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}*/
									
									
									uiDriver.click("Price");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
										uiDriver.click("PriceNumber");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}
									
									uiDriver.click("Expectedmileage");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
										uiDriver.click("ExpectedmileageNumber");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}
									
									/*uiDriver.click("Selectfiles");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}*/
									
									uiDriver.click("Tire");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}
									
									uiDriver.click("Width");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}
									
									uiDriver.click("Height");
									SleepUtils.sleep(4);
										if(uiDriver.checkElementPresent("Vehiclepage00057"))
									{
										passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
									} 
									else
									{
										failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
									}
										
										((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[5].click()");
										SleepUtils.sleep(2);
							
								 	    uiDriver.click_dynamic("(//li[contains(text(),'Diagonal')])[1]");
								 	    SleepUtils.sleep(2);
											
			
									/*	Select Construction = new Select(uiDriver.webDr.findElement(By.xpath("(//span[@class='k-input'])[6]")));
										Construction.selectByVisibleText("Diagonal");
						              
										uiDriver.click("Constructiontype");
										SleepUtils.sleep(4);
											if(uiDriver.checkElementPresent("Vehiclepage00057"))
										{
											passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
										} 
										else
										{
											failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
										}	*/	
											uiDriver.click("Loadindex");
											SleepUtils.sleep(4);
												if(uiDriver.checkElementPresent("Vehiclepage00057"))
											{
												passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
											} 
											else
											{
												failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
											}
												
												
												((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[6].click()");
												SleepUtils.sleep(2);
									
										 	    uiDriver.click_dynamic("(//li[contains(text(),'P')])[1]");
										 	    SleepUtils.sleep(2);
												
											/*	uiDriver.click("Speedindex");
												SleepUtils.sleep(4);
													if(uiDriver.checkElementPresent("Vehiclepage00057"))
												{
													passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
												} 
												else
												{
													failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
												}*/
													
										 	    
										 	    
										 	    
										 	   ((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[7].click()");
												SleepUtils.sleep(2);
									
										 	    uiDriver.click_dynamic("(//li[contains(text(),'All-seasons tires')])[1]");
										 	    SleepUtils.sleep(2);
										 	    
										 	    
										 	    
												/*	uiDriver.click("Type");
													SleepUtils.sleep(4);
														if(uiDriver.checkElementPresent("Vehiclepage00057"))
													{
														passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
													} 
													else
													{
														failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
													}
														*/
														uiDriver.click("Runflat");
														SleepUtils.sleep(4);
															if(uiDriver.checkElementPresent("Vehiclepage00057"))
														{
															passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
														} 
														else
														{
															failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
														}
															
	uiDriver.click("Defaultpressure");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Remainingprofiledepth");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	uiDriver.click("Brand");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	uiDriver.setValue("Brand", "Test");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[8].click()");
	SleepUtils.sleep(2);

	    uiDriver.click_dynamic("(//li[contains(text(),'..FORD/99                          ')])[1]");
	    SleepUtils.sleep(2);
/*	uiDriver.click("Supplier");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}*/
	
	
	 WebElement selectDate = uiDriver.webDr.findElement(By.xpath("//span[@class='k-icon k-i-calendar']"));
     
	    selectDate.click();
	    SleepUtils.sleep(4);
	    WebElement selectDate1 = uiDriver.webDr.findElement(By.xpath(" //a[@data-value='2020/11/29']"));
	     
	    selectDate1.click(); 
	    SleepUtils.sleep(4);
/*	uiDriver.click("PurchaseDate");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}*/
	
	uiDriver.click("Price_excl._VAT");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Tax");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Price_incl.VAT");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Rim");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Rimsize");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("RimBrand");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	uiDriver.setValue("RimBrand", "Test");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("RimMaterial");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	uiDriver.setValue("RimMaterial", "Test");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Boltdistance");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Width_Rim");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[5].click()");
	SleepUtils.sleep(2);

	    uiDriver.click_dynamic("(//li[contains(text(),'**SEE RDO TRUCK CENTER**           ')])[1]");
	    SleepUtils.sleep(2);
	
/*	uiDriver.click("Supplier_Rim");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}*/
	
	WebElement selectDateRim = uiDriver.webDr.findElement(By.xpath("//span[@class='k-icon k-i-calendar']"));
     
	    selectDateRim.click();
	    SleepUtils.sleep(4);
	    WebElement selectDateRim1 = uiDriver.webDr.findElement(By.xpath(" //a[@data-value='2020/11/29']"));
	     
	    selectDateRim1.click();  
	    SleepUtils.sleep(4);
/*	uiDriver.click("RimPurchaseDate");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}*/
	
	
	uiDriver.click("Price_excl.VAT_Rim");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Tax_Rim");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Price_incl.VAT_Rim");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	uiDriver.click("Save_Vehicle");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Edit_Pencil");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Vehiclename");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
		uiDriver.setValue("Vehiclename", "TEST1");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
		
		
	uiDriver.click("Save_Vehicle");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	uiDriver.click("Delete_Vehicle");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
	passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
	failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
	
	
	 Alert alert = uiDriver.webDr.switchTo().alert();
	 alert.accept();
	 SleepUtils.sleep(4);											
		
}



public void AddPlanningDetails_Likitha1(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	uiDriver.click("Vehicle00057");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
		SleepUtils.sleep(2);
		
		Date date = new Date();
		String Registrationrenewal_current= new SimpleDateFormat("MM/dd/yyyy").format(date);
		uiDriver.setValue("RegistrationRenewal_date", Registrationrenewal_current);
		passed("Planned Registrationrenewal", "Registrationrenewal Date Should display correctly", "Registrationrenewal Date is displayed correctly");
	 	SleepUtils.sleep(2);
	
	 	uiDriver.click("OkVehicle");
		SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("WElement_VehiclesPage"))
		{
			passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
		} 
		else
		{
			failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
		}
			
		SleepUtils.sleep(3);
				
	    
	    uiDriver.click("WSubMenu_Planning");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_PlanningPage"))
		{
			passed("Planning page", "Should display Planning Page", "Planning Page displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye Planning Page", "Planning Page is not displayed");
		}
			
		
		if(uiDriver.checkElementPresent("WElement_PlanningPage_ListTab"))
		{
			passed("Planning page", "Should display List Tab", "List Tab displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye List Tab", "List Tab is not displayed");
		}
	    
	
	    uiDriver.click("WElement_AddPlanningList");
		SleepUtils.sleep(10);
		if(uiDriver.checkElementPresent("WElement_EditPlanning_PlanningLisAddPage"))
		{
			passed("Planning List page", "Planning List page should be displayed", "Planning List page is displayed successfully");
		} 
		else
		{
			failed("Planning List page", "Planning List page should be displayed", "Planning List page is not displayed successfully");
		}
		
		
	
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
	SleepUtils.sleep(2);
	 uiDriver.click_dynamic("(//li[contains(text(),'Rental')])[1]");
	 SleepUtils.sleep(2);
		
		passed("Type", "Type Should display correctly", "Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
	SleepUtils.sleep(2);
    uiDriver.click_dynamic("(//li[contains(text(),'Rental (Vehicle + Driver)')])[1]");
    SleepUtils.sleep(2);
		
		passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
	SleepUtils.sleep(3);
	uiDriver.click_dynamic("(//li[contains(text(),'00 - TRANSP SERVICES')])[1]");
    SleepUtils.sleep(2);
		
		passed("Category", "Category Should display correctly", "Category is displayed correctly");
	

		SleepUtils.sleep(2);
	
	uiDriver.click("Wchkbox_CanOverlap");
	SleepUtils.sleep(2);
	
	
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
	SleepUtils.sleep(2);
	uiDriver.click_dynamic("(//td[contains(text(),'131879 - 0 TO 90 (267)')])[1]");
    SleepUtils.sleep(2);
	    
	   passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
	   
	   
	   uiDriver.click("Primary_charges");
		SleepUtils.sleep(2);  
	   
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
	SleepUtils.sleep(4);	    
	uiDriver.click_dynamic("(//td[contains(text(),'001')])[1]");		
	SleepUtils.sleep(4);
	
	    passed("Order", "Order Should display correctly", "Order is displayed correctly");
	    
	/*    uiDriver.click("FuelCharges");
		SleepUtils.sleep(4);  
	    
		
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[12].click();");
		SleepUtils.sleep(4);	    
		uiDriver.click_dynamic("(//td[contains(text(),'rental of 3 ton box #240 12/14')])[1]");		
		SleepUtils.sleep(4);*/
		
		
	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	    jse.executeScript("window.scrollBy(0,450)", "");	
	  	SleepUtils.sleep(4);
	  	
	  	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
	SleepUtils.sleep(3);
	uiDriver.click_dynamic("(//li[contains(text(),'00057')])[1]");		
	SleepUtils.sleep(4);
		
		passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
	    
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[14].click()"); 
		SleepUtils.sleep(3);
		uiDriver.click_dynamic("(//li[contains(text(),'Van - Panel')])[1]");		
		SleepUtils.sleep(4);
			
			passed("VehicleType", "VehicleType Should display correctly", "VehicleType is displayed correctly");
		    
	SleepUtils.sleep(3);
	
	
	Date startDate1 = DateUtils.addDays(new Date(),+2);
	Date endDate1 = DateUtils.addDays(new Date(),+5);
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
	
	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
	 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
	 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
	 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
 	SleepUtils.sleep(2);
 	
 	
 	uiDriver.click("Daily_planning");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Generate_planning"))
	{
		passed("Daily_planning page", "Should display Daily_planning Page", "Daily_planning Page displayed successfully");
	} 
	else
	{
		failed("Daily_planning page", "Should display Daily_planning Page", "Daily_planning page is not displayed");
	}
	SleepUtils.sleep(2);	
		
	uiDriver.click("Generate_planning");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Planning_OK"))
	{
		passed("Generate_planning page", "Should display Generate_planning Page", "Generate_planning Page displayed successfully");
	} 
	else
	{
		failed("Generate_planning page", "Should display Generate_planning", "Generate_planning Page is not displayed");
	}
	SleepUtils.sleep(2);
	
	uiDriver.click("Planning_OK");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("WElement_PlanningPage"))
	{
		passed("Planning page", "Should display Planning Page", "Planning Page displayed successfully");
	} 
	else
	{
		failed("Planning page", "Should display Planning Page", "Planning Page is not displayed");
	}
	
	
/*	String actual_msg=uiDriver.webDr.findElement(By.xpath("(//*[contains(text(),'Registration renewal date has expired')])[1]")).getText();
	 String expect_msg="Registration renewal date has expired";
	 Assert.assertEquals(actual_msg,expect_msg);
	 SleepUtils.sleep(3); */
	
		if(uiDriver.checkElementPresent("Renewal_Error_msg"))
		{
			passed("Error_msg", "Should display Error_msg", "Error_msg displayed successfully");
		} 
		else
		{
			failed("Error_msg", "Should display Error_msg", "Error_msg is not displayed");
		}
	
	
	
	
	
	
	
}




public void AddPlanningDetails_Likitha2(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	uiDriver.click("Vehicle00057");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
		SleepUtils.sleep(2);
		
		
		Date date = new Date();
		Date MiddleDate1 = DateUtils.addDays(new Date(),+4);
		String Registrationrenewal_current= new SimpleDateFormat("MM/dd/yyyy").format(MiddleDate1);
		uiDriver.setValue("RegistrationRenewal_date", Registrationrenewal_current);
		passed("Planned Registrationrenewal", "Registrationrenewal Date Should display correctly", "Registrationrenewal Date is displayed correctly");
	 	SleepUtils.sleep(2);
	
	 	uiDriver.click("OkVehicle");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("Vehiclepage00057"))
		{
			passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
		} 
		else
		{
			failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
		}
			
		SleepUtils.sleep(3);
				
	    
	    uiDriver.click("WSubMenu_Planning");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_PlanningPage"))
		{
			passed("Planning page", "Should display Planning Page", "Planning Page displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye Planning Page", "Planning Page is not displayed");
		}
			
		
		if(uiDriver.checkElementPresent("WElement_PlanningPage_ListTab"))
		{
			passed("Planning page", "Should display List Tab", "List Tab displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye List Tab", "List Tab is not displayed");
		}
	    
	
	    uiDriver.click("WElement_AddPlanningList");
		SleepUtils.sleep(10);
		if(uiDriver.checkElementPresent("WElement_EditPlanning_PlanningLisAddPage"))
		{
			passed("Planning List page", "Planning List page should be displayed", "Planning List page is displayed successfully");
		} 
		else
		{
			failed("Planning List page", "Planning List page should be displayed", "Planning List page is not displayed successfully");
		}
		
		
	
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
	SleepUtils.sleep(2);
	 uiDriver.click_dynamic("(//li[contains(text(),'Rental')])[1]");
	 SleepUtils.sleep(2);
		
		passed("Type", "Type Should display correctly", "Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
	SleepUtils.sleep(2);
    uiDriver.click_dynamic("(//li[contains(text(),'Rental (Vehicle + Driver)')])[1]");
    SleepUtils.sleep(2);
		
		passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
	SleepUtils.sleep(3);
	uiDriver.click_dynamic("(//li[contains(text(),'00 - TRANSP SERVICES')])[1]");
    SleepUtils.sleep(2);
		
		passed("Category", "Category Should display correctly", "Category is displayed correctly");
	

		SleepUtils.sleep(2);
	
	uiDriver.click("Wchkbox_CanOverlap");
	SleepUtils.sleep(2);
	
	
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
	SleepUtils.sleep(2);
	uiDriver.click_dynamic("(//td[contains(text(),'131879 - 0 TO 90 (267)')])[1]");
    SleepUtils.sleep(2);
	    
	   passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
	   
	   
	   uiDriver.click("Primary_charges");
		SleepUtils.sleep(2);  
	   
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
	SleepUtils.sleep(4);	    
	uiDriver.click_dynamic("(//td[contains(text(),'001')])[1]");		
	SleepUtils.sleep(4);
	
	    passed("Order", "Order Should display correctly", "Order is displayed correctly");
	    
	   /* uiDriver.click("FuelCharges");
		SleepUtils.sleep(4);  
	    
		
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[12].click();");
		SleepUtils.sleep(4);	    
		uiDriver.click_dynamic("(//td[contains(text(),'rental of 3 ton box #240 12/14')])[1]");		
		SleepUtils.sleep(4);*/
		
		
	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	    jse.executeScript("window.scrollBy(0,450)", "");	
	  	SleepUtils.sleep(4);
	  	
	  	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
	SleepUtils.sleep(3);
	uiDriver.click_dynamic("(//li[contains(text(),'00057')])[1]");		
	SleepUtils.sleep(4);
		
		passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
	    
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[14].click()"); 
		SleepUtils.sleep(3);
		uiDriver.click_dynamic("(//li[contains(text(),'Van - Panel')])[1]");		
		SleepUtils.sleep(4);
			
			passed("VehicleType", "VehicleType Should display correctly", "VehicleType is displayed correctly");
		    
	SleepUtils.sleep(3);
	
	
	Date startDate1 = DateUtils.addDays(new Date(),+1);
	Date endDate1 = DateUtils.addDays(new Date(),+5);
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
	
	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
	 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
	 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
	 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
 	SleepUtils.sleep(2);
 	
 	
 	uiDriver.click("Daily_planning");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Generate_planning"))
	{
		passed("Daily_planning page", "Should display Daily_planning Page", "Daily_planning Page displayed successfully");
	} 
	else
	{
		failed("Daily_planning page", "Should display Daily_planning Page", "Daily_planning page is not displayed");
	}
	SleepUtils.sleep(2);	
		
	uiDriver.click("Generate_planning");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("Planning_OK"))
	{
		passed("Generate_planning page", "Should display Generate_planning Page", "Generate_planning Page displayed successfully");
	} 
	else
	{
		failed("Generate_planning page", "Should display Generate_planning", "Generate_planning Page is not displayed");
	}
	SleepUtils.sleep(2);
	
	uiDriver.click("Planning_OK");
	SleepUtils.sleep(4);
	if(uiDriver.checkElementPresent("WElement_PlanningPage"))
	{
		passed("Planning page", "Should display Planning Page", "Planning Page displayed successfully");
	} 
	else
	{
		failed("Planning page", "Should display Planning Page", "Planning Page is not displayed");
	}
	
	
/*	String actual_msg=uiDriver.webDr.findElement(By.xpath("(//*[contains(text(),'Registration renewal date has expired')])[1]")).getText();
	 String expect_msg="Registration renewal date has expired";
	 Assert.assertEquals(actual_msg,expect_msg);
	 SleepUtils.sleep(3); */
	
		if(uiDriver.checkElementPresent("Renewal_Error_msg"))
		{
			passed("Error_msg", "Should display Error_msg", "Error_msg displayed successfully");
		} 
		else
		{
			failed("Error_msg", "Should display Error_msg", "Error_msg is not displayed");
		}
		SleepUtils.sleep(3);
}


public void AddPlanningDetails_Likitha3(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	uiDriver.click("Vehicle00057");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
		SleepUtils.sleep(2);
		
		

		
		Date date = new Date();
		Date currentDate1 = DateUtils.addDays(new Date(),+6);
		String Registrationrenewal_current= new SimpleDateFormat("MM/dd/yyyy").format(currentDate1);
		uiDriver.setValue("RegistrationRenewal_date", Registrationrenewal_current);
		passed("Planned Registrationrenewal", "Registrationrenewal Date Should display correctly", "Registrationrenewal Date is displayed correctly");
	 	SleepUtils.sleep(2);
	
	 	uiDriver.click("OkVehicle");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("Vehiclepage00057"))
		{
			passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
		} 
		else
		{
			failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
		}
			
		SleepUtils.sleep(3);
				
	    
	    uiDriver.click("WSubMenu_Planning");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("WElement_PlanningPage"))
		{
			passed("Planning page", "Should display Planning Page", "Planning Page displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye Planning Page", "Planning Page is not displayed");
		}
			
		
		if(uiDriver.checkElementPresent("WElement_PlanningPage_ListTab"))
		{
			passed("Planning page", "Should display List Tab", "List Tab displayed successfully");
		} 
		else
		{
			failed("Planning page", "Should displaye List Tab", "List Tab is not displayed");
		}
	    
	
	    uiDriver.click("WElement_AddPlanningList");
		SleepUtils.sleep(10);
		if(uiDriver.checkElementPresent("WElement_EditPlanning_PlanningLisAddPage"))
		{
			passed("Planning List page", "Planning List page should be displayed", "Planning List page is displayed successfully");
		} 
		else
		{
			failed("Planning List page", "Planning List page should be displayed", "Planning List page is not displayed successfully");
		}
		
		
	
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[2].click()");
	SleepUtils.sleep(2);
	 uiDriver.click_dynamic("(//li[contains(text(),'Rental')])[1]");
	 SleepUtils.sleep(2);
		
		passed("Type", "Type Should display correctly", "Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[3].click()");
	SleepUtils.sleep(2);
    uiDriver.click_dynamic("(//li[contains(text(),'Rental (Vehicle + Driver)')])[1]");
    SleepUtils.sleep(2);
		
		passed("Planning Type", "Planning Type Should display correctly", "Planning Type is displayed correctly");
	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[4].click()");
	SleepUtils.sleep(3);
	uiDriver.click_dynamic("(//li[contains(text(),'00 - TRANSP SERVICES')])[1]");
    SleepUtils.sleep(2);
		
		passed("Category", "Category Should display correctly", "Category is displayed correctly");
	

		SleepUtils.sleep(2);
	
	uiDriver.click("Wchkbox_CanOverlap");
	SleepUtils.sleep(2);
	
	
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[10].click();");
	SleepUtils.sleep(2);
	uiDriver.click_dynamic("(//td[contains(text(),'131879 - 0 TO 90 (267)')])[1]");
    SleepUtils.sleep(2);
	    
	   passed("Deal", "Deal Should display correctly", "Deal is displayed correctly");
	   
	   
	   uiDriver.click("Primary_charges");
		SleepUtils.sleep(2);  
	   
	uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[11].click();");
	SleepUtils.sleep(4);	    
	uiDriver.click_dynamic("(//td[contains(text(),'001')])[1]");		
	SleepUtils.sleep(4);
	
	    passed("Order", "Order Should display correctly", "Order is displayed correctly");
	    
	    uiDriver.click("FuelCharges");
		SleepUtils.sleep(4);  
	    
		
		uiDriver.executeJavaScript("document.getElementsByClassName('k-icon k-i-arrow-60-down')[12].click();");
		SleepUtils.sleep(4);	    
		uiDriver.click_dynamic("(//td[contains(text(),'001')])[1]");		
		SleepUtils.sleep(4);
		
		
	    JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
	    jse.executeScript("window.scrollBy(0,450)", "");	
	  	SleepUtils.sleep(4);
	  	
	  	
	((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[13].click()"); 
	SleepUtils.sleep(3);
	uiDriver.click_dynamic("(//li[contains(text(),'00057')])[1]");		
	SleepUtils.sleep(4);
		
		passed("Vehicle", "Vehicle Should display correctly", "Vehicle is displayed correctly");
	    
		
		((JavascriptExecutor)uiDriver.webDr).executeScript("document.getElementsByClassName('k-dropdown-wrap k-state-default')[14].click()"); 
		SleepUtils.sleep(3);
		uiDriver.click_dynamic("(//li[contains(text(),'Van - Panel')])[1]");		
		SleepUtils.sleep(4);
			
			passed("VehicleType", "VehicleType Should display correctly", "VehicleType is displayed correctly");
		    
	SleepUtils.sleep(3);
	
	
	
	Date startDate1 = DateUtils.addDays(new Date(),+1);
	Date endDate1 = DateUtils.addDays(new Date(),+5);
	String endDate= new SimpleDateFormat("MM/dd/yyyy").format(endDate1);
	String startDate= new SimpleDateFormat("MM/dd/yyyy").format(startDate1);
	
	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate", startDate);
	SleepUtils.sleep(2);
		passed("Planned start time", "Planned start time Should display correctly", "Planned start time is displayed correctly");
	
	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate", endDate);
	 	passed("Planned end time", "Planned end time Should display correctly", "Planned end time is displayed correctly");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderStartDate1", startDate);
	 	passed("Actual start time", "Actual start time Should display correctly", "Actual start time is displayed as "+startDate+"");
 	SleepUtils.sleep(2);
 	
 	uiDriver.setValue("WElement_PlanningPage_CalenderEndDate1", endDate);
	 	passed("Actual end time", "Actual end time Should display correctly", "Actual end time is displayed as "+endDate+"");
 	SleepUtils.sleep(2);
 	
 	
 	SleepUtils.sleep(4);
 	
	SleepUtils.sleep(4);	
	
}


public void Registration_renewal(DataRow input, DataRow output) throws InterruptedException, AWTException {
	
	uiDriver.click("Vehicle00057");
	SleepUtils.sleep(4);
		if(uiDriver.checkElementPresent("Vehiclepage00057"))
	{
		passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
	} 
	else
	{
		failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
	}
		
	
		
		Date date = new Date();
		Date Pastdate = DateUtils.addDays(new Date(),-2);
		String Registrationrenewal= new SimpleDateFormat("MM/dd/yyyy").format(Pastdate);
		
		uiDriver.setValue("RegistrationRenewal_date", Registrationrenewal);
		passed("Planned Registrationrenewal", "Registrationrenewal Date Should display correctly", "Registrationrenewal Date is displayed correctly");
	 	SleepUtils.sleep(2);
	 	
	 	 String actual_msg=uiDriver.webDr.findElement(By.xpath("//div[@class='k-notification-wrap']")).getText();
		 String expect_msg="Registration renewal cannot be in the past";
		 Assert.assertEquals(actual_msg,expect_msg);
		 SleepUtils.sleep(3);
	
			String Registrationrenewal_current= new SimpleDateFormat("MM/dd/yyyy").format(date);
			uiDriver.setValue("RegistrationRenewal_date", Registrationrenewal_current);
			passed("Planned Registrationrenewal", "Registrationrenewal Date Should display correctly", "Registrationrenewal Date is displayed correctly");
		 	SleepUtils.sleep(2);
 	
		 	uiDriver.click("OkVehicle");
			SleepUtils.sleep(4);
				if(uiDriver.checkElementPresent("Vehiclepage00057"))
			{
				passed("Vehicles page", "Should display Vehicles Page", "Vehicles Page displayed successfully");
			} 
			else
			{
				failed("Vehicles page", "Should display Vehicles Page", "Vehicles Page is not displayed");
			}
				
			SleepUtils.sleep(4);
				
			


}

}

