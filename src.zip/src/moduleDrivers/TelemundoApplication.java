package moduleDrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.passed;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.mail.FetchProfile;
import javax.mail.Multipart;

import jxl.write.DateFormat;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.ui.Select;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import com.sun.mail.util.MailSSLSocketFactory;
//import com.sun.java.swing.plaf.windows.TMSchema.Part;
import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeBodyPart;

import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.search.FlagTerm;


import org.apache.poi.util.IOUtils;

import com.adobe.acrobat.PDFDocument;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.sun.mail.util.MailSSLSocketFactory;
import com.sun.net.httpserver.Authenticator;
import com.sun.net.httpserver.HttpExchange;

//import org.jboss.util.Base64;









import sun.net.www.protocol.http.HttpURLConnection;


public class TelemundoApplication extends BaseWebModuleDriver {
	
	//private static final String DateUtils = null;
	OutlookReader_imap obje = new OutlookReader_imap();
	
	/****************************************
	 * Name: NavigateToCustomer
	 * Description: NavigateToCustomer
	 
	 * @throws InterruptedException 
	 ****************************************/

	public void NavigateToContractSignatures(DataRow input, DataRow output) throws InterruptedException {
		
		uiDriver.click("Telemundo_ContractSignaturesSubMenu");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("Telemundo_ContractSignaturesPage"))
		{
			passed("Contract Signatures page", "Should display Contract Signatures Page", "Contract Signatures Page displayed successfully");
		} 
		else
		{
			failed("Contract Signatures page", "Should display Contract Signatures Page", "Contract Signatures Page is not displayed");
		}
			
	}
public void ClickonProject(DataRow input, DataRow output) throws Exception {
	//uiDriver.click("Telemundo_ProjectName");
	SleepUtils.sleep(6);
	List<WebElement> projectnames = uiDriver.webDr.findElements(By.xpath("//div[@class='description']"));
	int count = projectnames.size();
	System.out.println(count);
		 for(int i=0;i<=count;i++) 
		 { 
			 projectnames.get(i).click(); 
			 SleepUtils.sleep(5);
			 List<WebElement> contractpersons = uiDriver.webDr.findElements(By.xpath("//div[@class='contractperson']"));
			int count1 = contractpersons.size();
			System.out.println(count1);
			 for(int j=140;j<=count1;j++) 
			 {
				 contractpersons.get(j).click(); 
				 SleepUtils.sleep(5);
				 
			 }
		 
		 }
		 
	String ProjectName=null;
	for(WebElement ele:projectnames) 
	{
		ele.click();
		SleepUtils.sleep(8);
		ProjectName=ele.getText();
		//JavascriptExecutor jse = (JavascriptExecutor)uiDriver.webDr;
 	    //jse.executeScript("window.scrollBy(0,450)", "");
		
		List<WebElement> contractpersons = uiDriver.webDr.findElements(By.xpath("//div[@class='contractperson']"));
		int count1 = contractpersons.size();
		System.out.println(count1);
		for(WebElement cntr:contractpersons) {
			SleepUtils.sleep(8);
			System.out.println(cntr.getText());
			cntr.click();
			SleepUtils.sleep(8);
			uiDriver.click("Telemundo_PrintDocuments");
			SleepUtils.sleep(10);
			uiDriver.click("Telemundo_PrintDocuments_Print");
			SleepUtils.sleep(10);
			System.out.println("hi");
			SleepUtils.sleep(10);
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_TAB);
			r.keyPress(KeyEvent.VK_TAB);
			r.keyPress(KeyEvent.VK_S);
			//r.keyPress(KeyEvent.VK_ENTER);
			Thread.sleep(6000);
			System.out.println("hi");
			Runtime.getRuntime().exec("D:\\AUTOIT\\SaveButtonTelemundo.exe");
			Thread.sleep(10000);
			System.out.println("hi");
			Thread.sleep(10000);
			//r.keyPress(KeyEvent.VK_T);
		
			
			
			Random random = new Random();

				/*
				 * int limit = random.nextInt(1000);
				 * 
				 * 
				 * String inv = Integer.toString(limit);
				 */

           String text = "Testingmadhu";

           StringSelection stringSelection = new StringSelection(text);

           Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
           //.setContents(stringSelection, null);
           clipboard.setContents(stringSelection, null);
           
           SleepUtils.sleep(TimeSlab.LOW);
           r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			 r.keyRelease(KeyEvent.VK_CONTROL);
			 r.keyRelease(KeyEvent.VK_V);
           //uiDriver.sendKey("paste");

          SleepUtils.sleep(TimeSlab.LOW);

             uiDriver.sendKey("enter");
			Thread.sleep(7000);
			
				
			
			
		}
		
		
		
	}
	
		
	
	
	}
	
public void NavigateToContractSignatures111(DataRow input, DataRow output) throws InterruptedException, Exception {
	
//	String Projectcount = input.get("NoOfProjects");
//	String ProjectNames = input.get("ProjectNames");
	String ProjectName = input.get("ProjectName");
	SleepUtils.sleep(4);
	uiDriver.click("Telemundo_Normal_ContractSignatory");
	SleepUtils.sleep(4);
	//uiDriver.setValue("WElement_Planning_SearchDeal", "BETTY EN NY");
	uiDriver.webDr.findElement(By.xpath("//label[contains(text(),'Project')]/../../div/div/input[@type='text']")).sendKeys(ProjectName);
	SleepUtils.sleep(2);
	uiDriver.click("Telemundo_ContractSignatory_LookUp");
	SleepUtils.sleep(25);
	
		
		passed("Contract Signatures page", "Should display Contract Signatures Page", "Contract Signatures Page displayed successfully");
		
		String FullName = null;
		String fname=null;
		//List<String> fullNameList = new ArrayList<String>();
		List<String> testfullNameList = new ArrayList<String>();
		Set<String> fullNameList=new LinkedHashSet<String>();
		
		
		
		
//		List<WebElement> projectnames = uiDriver.webDr.findElements(By.xpath("//div[@class='description']"));
//		int prjct = projectnames.size();
//		System.out.println(prjct);
		
		//boolean status;
		for(int x=0;x<1;x++){
			
			//status=uiDriver.webDr.findElement(By.xpath("//input[@class='FwBrowseView-btnNext']")).isEnabled();
			List<WebElement> Firstname = uiDriver.webDr.findElements(By.xpath("//td[@class='First Name']"));
			int count = Firstname.size();
			System.out.println(count);
			List<WebElement> lastname = uiDriver.webDr.findElements(By.xpath("//td[@class='Last Name']"));
			int count1 = lastname.size();
			System.out.println(count1);
			 for(int i=1;i<count;i++) 
			 { 
				 //Firstname.get(i).click(); 
				  fname= Firstname.get(i).getText();
				  String lname= lastname.get(i).getText(); 
					
					FullName=fname+" "+lname;
					 fullNameList.add(FullName);
					 System.out.println("completed till"+i);
					 System.out.println(fullNameList);
			 }
			 if(uiDriver.checkElementPresent("Telemundo_mobile_nnextButton_contractsignatory"))
				{
			 uiDriver.click("Telemundo_mobile_nnextButton_contractsignatory");
			 SleepUtils.sleep(30);	
				}
		 }
		
		testfullNameList.addAll(fullNameList);
		int flistcount1= testfullNameList.size();
		//int flistcount= fullNameList.size();
		System.out.println(flistcount1);
		
		

		uiDriver.launchApplication(input.get("url1"));
		SleepUtils.sleep(TimeSlab.HIGH);
		
		if (uiDriver.checkPage(input.get("pageName"))) {
			passed("Launching the Application", "Should Launch the Application", "Application Launched sucessfully!");
		} else {
			failed("Launching the Application", "Should Launch the Application", "Error in Launching the Application");
		}
		
		uiDriver.setValue("Telemundo_LoginUsername", input.get("username"));
		SleepUtils.sleep(TimeSlab.LOW);
		uiDriver.setValue("Telemundo_LoginPassword", input.get("password"));
		SleepUtils.sleep(2);
		uiDriver.click("Telemundo_LoginButton");
		SleepUtils.sleep(TimeSlab.MEDIUM);
		SleepUtils.sleep(12);
		uiDriver.click("Telemundo_ContractSignaturesSubMenu");
		SleepUtils.sleep(4);
			if(uiDriver.checkElementPresent("Telemundo_ContractSignaturesPage"))
		{
			passed("Contract Signatures page", "Should display Contract Signatures Page", "Contract Signatures Page displayed successfully");
		} 
		else
		{
			failed("Contract Signatures page", "Should display Contract Signatures Page", "Contract Signatures Page is not displayed");
		}
		
		uiDriver.setValue("Telemundo_Mobile_Projectsearchfield", input.get("ProjectName"));
		SleepUtils.sleep(2);
		uiDriver.click("Telemundo_Mobile_Projectsearchfield_SearchButton");
		SleepUtils.sleep(4);
		uiDriver.click("Telemundo_Mobile_Projectsearch_FirstDisplayed");
		SleepUtils.sleep(4);
		//Iterator<String> listiterator = fullNameList.iterator();
		int e;
		for(e=0;e<flistcount1;e++)
		{
			String mainName=testfullNameList.get(e);
			SleepUtils.sleep(4);
			System.out.println("Completed till:"+e);
		//}
		//while(listiterator.hasNext())
		//{
			
			//System.out.println(listiterator.next());
			if(uiDriver.checkElementPresent("Telemundo_Mobile_ContractSignaturesPage_Clearbutton"))
			{
				uiDriver.click("Telemundo_Mobile_ContractSignaturesPage_Clearbutton");
				SleepUtils.sleep(5);
			}
			uiDriver.setValue("Telemundo_Mobile_ContractSignatory_Name", mainName);
            SleepUtils.sleep(4);
            uiDriver.click("Telemundo_Mobile_ContractSignatory_SearchButton");
    		SleepUtils.sleep(4);
    		List<WebElement> contractpersons = uiDriver.webDr.findElements(By.xpath("//div[@class='contractperson']"));
			int contractpersonscount = contractpersons.size();
			List<WebElement> datescanned = uiDriver.webDr.findElements(By.xpath("//div[@class='datescanned']"));
			int datescannedcount = datescanned.size();
			System.out.println(datescannedcount);
			System.out.println(contractpersonscount);
			String dateScan;
			String dateScanformat;
			int s;
					 for(s=1;s<=contractpersonscount;s++) 
							 {
						 //WebElement dateScanwe = datescanned.get(s);
						 String xpath="(//div[@class='searchresults']//div[@class='datescanned'])[#]";
						String xp=String.valueOf(s);
						 String xpath1 = xpath.replace("#", xp);
						 dateScan=uiDriver.webDr.findElement(By.xpath(xpath1)).getText();
								 //dateScan=dateScanwe.getText();
								 dateScanformat=dateScan.replaceAll("/", "_");
								 dateScanformat=dateScanformat.replaceAll(":", "_");
								 dateScanformat=dateScanformat.replaceAll("\\s+", "_");
								 System.out.println(dateScanformat);
								 System.out.println("Completed till:"+s);
								 //String names=listiterator.next().replaceAll(" ", "_");
								 
								 uiDriver.webDr.findElement(By.xpath(xpath1)).click(); 
								 SleepUtils.sleep(5);
								 SleepUtils.sleep(8);
								uiDriver.click("Telemundo_PrintDocuments");
								SleepUtils.sleep(5);
								WebElement Descriptiondetails= uiDriver.webDr.findElement(By.xpath("(//div[@class='button default print' and contains(text(),'Print')])[2]/../../div/div/div[@class='description']"));
								String Descriptn = Descriptiondetails.getText();
								
								/*List<WebElement> description= uiDriver.webDr.findElements(By.xpath("//div[contains(text(),'View')]/../../div/div[contains(text(),'Print')]"));
								for(int z=1;z<description.size();z++){}*/
								uiDriver.click("Telemundo_PrintDocuments_Print");
								SleepUtils.sleep(5);
								
								System.out.println("hi");
								SleepUtils.sleep(10);
								Robot r = new Robot();
								if((e==0)&&(s==1)) {
								SleepUtils.sleep(5);
								r.keyPress(KeyEvent.VK_TAB);
								r.keyPress(KeyEvent.VK_TAB);
								r.keyPress(KeyEvent.VK_S);
								//r.keyPress(KeyEvent.VK_ENTER);
								}
								Thread.sleep(6000);
								System.out.println("hi");
								Runtime.getRuntime().exec("D:\\AUTOIT\\SaveButtonTelemundo.exe");
								Thread.sleep(10000);
								System.out.println("hi");
								Thread.sleep(10000);
								//r.keyPress(KeyEvent.VK_T);
							
					           String Filename= "\\\\tfayd.com\\Shared\\departmentalsystems\\us-ush\\share\\Automation Results\\Telemundo_ExtractFiles\\"+ProjectName+"_"+mainName+"_"+dateScanformat+"_"+Descriptn;
					           StringSelection stringSelection = new StringSelection(Filename);

					           Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
					           //.setContents(stringSelection, null);
					           clipboard.setContents(stringSelection, null);
					           
					           SleepUtils.sleep(TimeSlab.LOW);
					           r.keyPress(KeyEvent.VK_CONTROL);
								r.keyPress(KeyEvent.VK_V);
								 r.keyRelease(KeyEvent.VK_CONTROL);
								 r.keyRelease(KeyEvent.VK_V);
					           //uiDriver.sendKey("paste");

					          SleepUtils.sleep(TimeSlab.LOW);

					             uiDriver.sendKey("enter");
					             
								Thread.sleep(7000);
									
										if(uiDriver.checkElementPresent("Telemundo_PrintDocuments_PrintGaurdian"))
												{
													WebElement Descriptiondetails1= uiDriver.webDr.findElement(By.xpath("(//div[@class='button default print' and contains(text(),'Print')])[3]/../../div/div/div[@class='description']"));
													String Descriptn1 = Descriptiondetails1.getText();
													uiDriver.click("Telemundo_PrintDocuments_Print");
													SleepUtils.sleep(5);
													System.out.println("hi");
													SleepUtils.sleep(10);
													Thread.sleep(6000);
													System.out.println("hi");
													Runtime.getRuntime().exec("D:\\AUTOIT\\SaveButtonTelemundo.exe");
													Thread.sleep(10000);
													System.out.println("hi");
													Thread.sleep(10000);
													String Filename1= "\\\\tfayd.com\\Shared\\departmentalsystems\\us-ush\\share\\Automation Results\\Telemundo_ExtractFiles\\"+ProjectName+"_"+mainName+"_"+dateScanformat+"_"+Descriptn;
											           StringSelection stringSelection1 = new StringSelection(Filename1);
				
										           Clipboard clipboard1 = Toolkit.getDefaultToolkit().getSystemClipboard();
										           clipboard1.setContents(stringSelection1, null);
										           
										           SleepUtils.sleep(TimeSlab.LOW);
										           r.keyPress(KeyEvent.VK_CONTROL);
										           r.keyPress(KeyEvent.VK_V);
										           r.keyRelease(KeyEvent.VK_CONTROL);
										           r.keyRelease(KeyEvent.VK_V);
										           SleepUtils.sleep(TimeSlab.LOW);
										           uiDriver.sendKey("enter");
										           Thread.sleep(7000);
												}
								uiDriver.click("Telemundo_PrintDocuments_Close");
								SleepUtils.sleep(5);
								uiDriver.click("Telemundo_Mobile_ContractSignatureDetailsPage_Back");
								SleepUtils.sleep(5);
								
								

								 
							 }
					 uiDriver.click("Telemundo_Mobile_ContractSignaturesPage_Clearbutton");
					 SleepUtils.sleep(5);
    			
		}
		/*for(int s=0;s<flistcount;s++){
			
			String ele = fullNameList.get(s);

            System.out.println(ele);
            uiDriver.setValue("Telemundo_Mobile_ContractSignatory_Name", ele);
            SleepUtils.sleep(4);
            uiDriver.click("Telemundo_Mobile_ContractSignatory_SearchButton");
    		SleepUtils.sleep(4);
          
            
            
		}
		*/
		
		
		
		

}	
		
	
}

