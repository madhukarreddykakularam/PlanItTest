package moduleDrivers;

import static cbf.engine.TestResultLogger.failed;
import static cbf.engine.TestResultLogger.passed;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.mail.FetchProfile;
import javax.mail.Multipart;

import jxl.write.DateFormat;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.sun.glass.ui.Clipboard;
import com.sun.mail.util.MailSSLSocketFactory;
//import com.sun.java.swing.plaf.windows.TMSchema.Part;
import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeBodyPart;

import cbf.utils.DataRow;
import cbf.utils.SleepUtils;
import cbf.utils.SleepUtils.TimeSlab;
import cbfx.basedrivers.BaseWebModuleDriver;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.search.FlagTerm;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

//need 








import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.adobe.acrobat.PDFDocument;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.sun.mail.util.MailSSLSocketFactory;
import com.sun.net.httpserver.Authenticator;
import com.sun.net.httpserver.HttpExchange;

//import org.jboss.util.Base64;









import sun.net.www.protocol.http.HttpURLConnection;


public class StormDriver extends BaseWebModuleDriver {
	
	//private static final String DateUtils = null;
	OutlookReader_imap obje = new OutlookReader_imap();
	
	/****************************************
	 * Name: NavigateToCustomer
	 * Description: NavigateToCustomer
	 
	 * @throws InterruptedException 
	 ****************************************/
	
	public void NavigateToNewRequestPage(DataRow input, DataRow output) throws InterruptedException {
		
		
		uiDriver.SwitchFrame(0);
		//driver.switchTo().frame(2);

		SleepUtils.sleep(4);
		uiDriver.click("WElement_Storm_MainPage_GeneralButton");
		SleepUtils.sleep(4);
		uiDriver.SwitchFrame(1);
		if(uiDriver.checkElementPresent("WElement_Storm_General_RequestsLink"))
			{
				passed("General link", "General link should be clicked", "General link is clicked");
			} 
		else
			{
				failed("General link", "General link should be clicked", "General link is not clicked");
			}
		//uiDriver.SwitchFrame(1);
		uiDriver.click("WElement_Storm_General_RequestsLink");
		Thread.sleep(2000);
		uiDriver.click("WElement_Storm_General_GeneralRequest_NewRequest");	
		Thread.sleep(2000);
		uiDriver.click("WElement_Storm_MainPage_General_NewRequest");	
		Thread.sleep(2000);
		if(uiDriver.checkElementPresent("WElement_Storm_General_NewRequest_FindCostObject_Window"))
			{
				passed("Find CostObject Window", "Find CostObject Window should be displayed", "Find CostObject Window is displayed");
			} 
		else
			{
				failed("Find CostObject Window", "Find CostObject Window should be displayed", "Find CostObject Window is not displayed");
				
			}
	}
	
	
		
	
}

